package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class MinorListItemBinding implements ViewBinding {
    public final TextView listItemCertificateNumber;
    public final TextView listItemCitizenNumber;
    public final ImageView listItemCrossIconImageView;
    public final ImageView listItemEditIconImageView;
    public final TextView listItemMinorName;
    public final ImageView listItemStatusIconImageView;
    public final TextView listItemTapToEdit;
    public final TextView minorListSourceTextView;
    private final MaterialCardView rootView;

    private MinorListItemBinding(MaterialCardView materialCardView, TextView textView, TextView textView2, ImageView imageView, ImageView imageView2, TextView textView3, ImageView imageView3, TextView textView4, TextView textView5) {
        this.rootView = materialCardView;
        this.listItemCertificateNumber = textView;
        this.listItemCitizenNumber = textView2;
        this.listItemCrossIconImageView = imageView;
        this.listItemEditIconImageView = imageView2;
        this.listItemMinorName = textView3;
        this.listItemStatusIconImageView = imageView3;
        this.listItemTapToEdit = textView4;
        this.minorListSourceTextView = textView5;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static MinorListItemBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static MinorListItemBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.minor_list_item, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static MinorListItemBinding bind(View view) {
        int i = R.id.list_item_certificate_number;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.list_item_citizen_number;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView2 != null) {
                i = R.id.list_item_cross_icon_imageView;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                if (imageView != null) {
                    i = R.id.list_item_edit_icon_imageView;
                    ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                    if (imageView2 != null) {
                        i = R.id.list_item_minor_name;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView3 != null) {
                            i = R.id.list_item_status_icon_imageView;
                            ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i);
                            if (imageView3 != null) {
                                i = R.id.list_item_tap_to_edit;
                                TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                                if (textView4 != null) {
                                    i = R.id.minor_list_source_textView;
                                    TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView5 != null) {
                                        return new MinorListItemBinding((MaterialCardView) view, textView, textView2, imageView, imageView2, textView3, imageView3, textView4, textView5);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}