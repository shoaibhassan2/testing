package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.chip.ChipGroup;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.FooterLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.HeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepTitleLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class ActivityChildDisabilityDetailBinding implements ViewBinding {
    public final ButtonLayoutBinding addDisabilityButtonLayout;
    public final FooterLayoutBinding crcFooterLayout;
    public final HeaderLayoutBinding crcHeaderLayout;
    public final RecyclerView disabilitiesRecyclerView;
    public final ChipGroup disabilityChipGroup;
    public final StepActionLayoutBinding disabilityDetailsHeading;
    public final EdittextLayoutBinding disabilityIssuanceDateLayout;
    public final AutocompletetextviewLayoutBinding disabilityTypeLayout;
    public final EdittextLayoutBinding disabiltyCertificateLayout;
    public final ButtonLayoutBinding learnMoreButtonLayout;
    private final ConstraintLayout rootView;
    public final StepTitleLayoutBinding stepTitleHeadingLayout;

    private ActivityChildDisabilityDetailBinding(ConstraintLayout constraintLayout, ButtonLayoutBinding buttonLayoutBinding, FooterLayoutBinding footerLayoutBinding, HeaderLayoutBinding headerLayoutBinding, RecyclerView recyclerView, ChipGroup chipGroup, StepActionLayoutBinding stepActionLayoutBinding, EdittextLayoutBinding edittextLayoutBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding, EdittextLayoutBinding edittextLayoutBinding2, ButtonLayoutBinding buttonLayoutBinding2, StepTitleLayoutBinding stepTitleLayoutBinding) {
        this.rootView = constraintLayout;
        this.addDisabilityButtonLayout = buttonLayoutBinding;
        this.crcFooterLayout = footerLayoutBinding;
        this.crcHeaderLayout = headerLayoutBinding;
        this.disabilitiesRecyclerView = recyclerView;
        this.disabilityChipGroup = chipGroup;
        this.disabilityDetailsHeading = stepActionLayoutBinding;
        this.disabilityIssuanceDateLayout = edittextLayoutBinding;
        this.disabilityTypeLayout = autocompletetextviewLayoutBinding;
        this.disabiltyCertificateLayout = edittextLayoutBinding2;
        this.learnMoreButtonLayout = buttonLayoutBinding2;
        this.stepTitleHeadingLayout = stepTitleLayoutBinding;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivityChildDisabilityDetailBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivityChildDisabilityDetailBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_child_disability_detail, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivityChildDisabilityDetailBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.add_disability_button_layout;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById2 != null) {
            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById2);
            i = R.id.crc_footer_layout;
            View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById3 != null) {
                FooterLayoutBinding footerLayoutBindingBind = FooterLayoutBinding.bind(viewFindChildViewById3);
                i = R.id.crc_header_layout;
                View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById4 != null) {
                    HeaderLayoutBinding headerLayoutBindingBind = HeaderLayoutBinding.bind(viewFindChildViewById4);
                    i = R.id.disabilities_recyclerView;
                    RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
                    if (recyclerView != null) {
                        i = R.id.disability_chipGroup;
                        ChipGroup chipGroup = (ChipGroup) ViewBindings.findChildViewById(view, i);
                        if (chipGroup != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.disability_details_heading))) != null) {
                            StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById);
                            i = R.id.disability_issuance_date_layout;
                            View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                            if (viewFindChildViewById5 != null) {
                                EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById5);
                                i = R.id.disability_type_layout;
                                View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                                if (viewFindChildViewById6 != null) {
                                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById6);
                                    i = R.id.disabilty_certificate_layout;
                                    View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                                    if (viewFindChildViewById7 != null) {
                                        EdittextLayoutBinding edittextLayoutBindingBind2 = EdittextLayoutBinding.bind(viewFindChildViewById7);
                                        i = R.id.learn_more_button_layout;
                                        View viewFindChildViewById8 = ViewBindings.findChildViewById(view, i);
                                        if (viewFindChildViewById8 != null) {
                                            ButtonLayoutBinding buttonLayoutBindingBind2 = ButtonLayoutBinding.bind(viewFindChildViewById8);
                                            i = R.id.step_title_heading_layout;
                                            View viewFindChildViewById9 = ViewBindings.findChildViewById(view, i);
                                            if (viewFindChildViewById9 != null) {
                                                return new ActivityChildDisabilityDetailBinding((ConstraintLayout) view, buttonLayoutBindingBind, footerLayoutBindingBind, headerLayoutBindingBind, recyclerView, chipGroup, stepActionLayoutBindingBind, edittextLayoutBindingBind, autocompletetextviewLayoutBindingBind, edittextLayoutBindingBind2, buttonLayoutBindingBind2, StepTitleLayoutBinding.bind(viewFindChildViewById9));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}