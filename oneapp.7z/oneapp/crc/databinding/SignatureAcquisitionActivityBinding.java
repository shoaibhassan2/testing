package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.HeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepTitleLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class SignatureAcquisitionActivityBinding implements ViewBinding {
    public final HeaderLayoutBinding crcHeaderLayout;
    public final StepActionLayoutBinding crcStepAction;
    public final ConstraintLayout infoConstLayout;
    public final ImageView ivInfoIcon;
    public final ImageView ivTakePhoto;
    public final ButtonLayoutBinding nextButtonLayout;
    private final ConstraintLayout rootView;
    public final ConstraintLayout signatureConstLayout;
    public final StepTitleLayoutBinding stepTitleHeadingLayout;
    public final TextView tvInfo;

    private SignatureAcquisitionActivityBinding(ConstraintLayout constraintLayout, HeaderLayoutBinding headerLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding, ConstraintLayout constraintLayout2, ImageView imageView, ImageView imageView2, ButtonLayoutBinding buttonLayoutBinding, ConstraintLayout constraintLayout3, StepTitleLayoutBinding stepTitleLayoutBinding, TextView textView) {
        this.rootView = constraintLayout;
        this.crcHeaderLayout = headerLayoutBinding;
        this.crcStepAction = stepActionLayoutBinding;
        this.infoConstLayout = constraintLayout2;
        this.ivInfoIcon = imageView;
        this.ivTakePhoto = imageView2;
        this.nextButtonLayout = buttonLayoutBinding;
        this.signatureConstLayout = constraintLayout3;
        this.stepTitleHeadingLayout = stepTitleLayoutBinding;
        this.tvInfo = textView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static SignatureAcquisitionActivityBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static SignatureAcquisitionActivityBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.signature_acquisition_activity, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static SignatureAcquisitionActivityBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i = R.id.crc_header_layout;
        View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById3 != null) {
            HeaderLayoutBinding headerLayoutBindingBind = HeaderLayoutBinding.bind(viewFindChildViewById3);
            i = R.id.crc_step_action;
            View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById4 != null) {
                StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById4);
                i = R.id.info_const_layout;
                ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(view, i);
                if (constraintLayout != null) {
                    i = R.id.iv_info_icon;
                    ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                    if (imageView != null) {
                        i = R.id.iv_take_photo;
                        ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                        if (imageView2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.next_button_layout))) != null) {
                            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById);
                            i = R.id.signature_const_layout;
                            ConstraintLayout constraintLayout2 = (ConstraintLayout) ViewBindings.findChildViewById(view, i);
                            if (constraintLayout2 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.step_title_heading_layout))) != null) {
                                StepTitleLayoutBinding stepTitleLayoutBindingBind = StepTitleLayoutBinding.bind(viewFindChildViewById2);
                                i = R.id.tv_info;
                                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                                if (textView != null) {
                                    return new SignatureAcquisitionActivityBinding((ConstraintLayout) view, headerLayoutBindingBind, stepActionLayoutBindingBind, constraintLayout, imageView, imageView2, buttonLayoutBindingBind, constraintLayout2, stepTitleLayoutBindingBind, textView);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}