package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.FooterLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.HeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepTitleLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class ActivityChildParentDetailBinding implements ViewBinding {
    public final FooterLayoutBinding crcFooterLayout;
    public final HeaderLayoutBinding crcHeaderLayout;
    public final MaskedEdittextLayoutBinding fatherCnicLayout;
    public final StepActionLayoutBinding fatherDetailsHeading;
    public final EdittextLayoutBinding fatherFullNameLayout;
    public final MaskedEdittextLayoutBinding motherCnicLayout;
    public final StepActionLayoutBinding motherDetailsHeading;
    public final EdittextLayoutBinding motherFullNameLayout;
    private final ConstraintLayout rootView;
    public final StepTitleLayoutBinding stepTitleHeadingLayout;
    public final EdittextLayoutBinding urduFatherFullNameLayout;
    public final EdittextLayoutBinding urduMotherFullNameLayout;

    private ActivityChildParentDetailBinding(ConstraintLayout constraintLayout, FooterLayoutBinding footerLayoutBinding, HeaderLayoutBinding headerLayoutBinding, MaskedEdittextLayoutBinding maskedEdittextLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding, EdittextLayoutBinding edittextLayoutBinding, MaskedEdittextLayoutBinding maskedEdittextLayoutBinding2, StepActionLayoutBinding stepActionLayoutBinding2, EdittextLayoutBinding edittextLayoutBinding2, StepTitleLayoutBinding stepTitleLayoutBinding, EdittextLayoutBinding edittextLayoutBinding3, EdittextLayoutBinding edittextLayoutBinding4) {
        this.rootView = constraintLayout;
        this.crcFooterLayout = footerLayoutBinding;
        this.crcHeaderLayout = headerLayoutBinding;
        this.fatherCnicLayout = maskedEdittextLayoutBinding;
        this.fatherDetailsHeading = stepActionLayoutBinding;
        this.fatherFullNameLayout = edittextLayoutBinding;
        this.motherCnicLayout = maskedEdittextLayoutBinding2;
        this.motherDetailsHeading = stepActionLayoutBinding2;
        this.motherFullNameLayout = edittextLayoutBinding2;
        this.stepTitleHeadingLayout = stepTitleLayoutBinding;
        this.urduFatherFullNameLayout = edittextLayoutBinding3;
        this.urduMotherFullNameLayout = edittextLayoutBinding4;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivityChildParentDetailBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivityChildParentDetailBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_child_parent_detail, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivityChildParentDetailBinding bind(View view) {
        int i = R.id.crc_footer_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            FooterLayoutBinding footerLayoutBindingBind = FooterLayoutBinding.bind(viewFindChildViewById);
            i = R.id.crc_header_layout;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById2 != null) {
                HeaderLayoutBinding headerLayoutBindingBind = HeaderLayoutBinding.bind(viewFindChildViewById2);
                i = R.id.father_cnic_layout;
                View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById3 != null) {
                    MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById3);
                    i = R.id.father_details_heading;
                    View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                    if (viewFindChildViewById4 != null) {
                        StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById4);
                        i = R.id.father_full_name_layout;
                        View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                        if (viewFindChildViewById5 != null) {
                            EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById5);
                            i = R.id.mother_cnic_layout;
                            View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                            if (viewFindChildViewById6 != null) {
                                MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind2 = MaskedEdittextLayoutBinding.bind(viewFindChildViewById6);
                                i = R.id.mother_details_heading;
                                View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                                if (viewFindChildViewById7 != null) {
                                    StepActionLayoutBinding stepActionLayoutBindingBind2 = StepActionLayoutBinding.bind(viewFindChildViewById7);
                                    i = R.id.mother_full_name_layout;
                                    View viewFindChildViewById8 = ViewBindings.findChildViewById(view, i);
                                    if (viewFindChildViewById8 != null) {
                                        EdittextLayoutBinding edittextLayoutBindingBind2 = EdittextLayoutBinding.bind(viewFindChildViewById8);
                                        i = R.id.step_title_heading_layout;
                                        View viewFindChildViewById9 = ViewBindings.findChildViewById(view, i);
                                        if (viewFindChildViewById9 != null) {
                                            StepTitleLayoutBinding stepTitleLayoutBindingBind = StepTitleLayoutBinding.bind(viewFindChildViewById9);
                                            i = R.id.urdu_father_full_name_layout;
                                            View viewFindChildViewById10 = ViewBindings.findChildViewById(view, i);
                                            if (viewFindChildViewById10 != null) {
                                                EdittextLayoutBinding edittextLayoutBindingBind3 = EdittextLayoutBinding.bind(viewFindChildViewById10);
                                                i = R.id.urdu_mother_full_name_layout;
                                                View viewFindChildViewById11 = ViewBindings.findChildViewById(view, i);
                                                if (viewFindChildViewById11 != null) {
                                                    return new ActivityChildParentDetailBinding((ConstraintLayout) view, footerLayoutBindingBind, headerLayoutBindingBind, maskedEdittextLayoutBindingBind, stepActionLayoutBindingBind, edittextLayoutBindingBind, maskedEdittextLayoutBindingBind2, stepActionLayoutBindingBind2, edittextLayoutBindingBind2, stepTitleLayoutBindingBind, edittextLayoutBindingBind3, EdittextLayoutBinding.bind(viewFindChildViewById11));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}