package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedFooterWithBackNextBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepTitleLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class SpouseListFragmentBinding implements ViewBinding {
    public final UpdatedFooterWithBackNextBinding crcFooterLayout;
    public final UpdatedHeaderLayoutBinding crcHeaderLayout;
    public final RecyclerView minorsRecyclerView;
    private final ConstraintLayout rootView;
    public final ImageView spouseListTryAgainImageView;
    public final LinearLayout spouseListTryAgainLayout;
    public final TextView spouseListTryAgainTextView;
    public final SwipeRefreshLayout spouseSwipeRefresh;
    public final UpdatedStepTitleLayoutBinding stepTitleHeadingLayout;
    public final TextView userGuideTextView;

    private SpouseListFragmentBinding(ConstraintLayout constraintLayout, UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBinding, UpdatedHeaderLayoutBinding updatedHeaderLayoutBinding, RecyclerView recyclerView, ImageView imageView, LinearLayout linearLayout, TextView textView, SwipeRefreshLayout swipeRefreshLayout, UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBinding, TextView textView2) {
        this.rootView = constraintLayout;
        this.crcFooterLayout = updatedFooterWithBackNextBinding;
        this.crcHeaderLayout = updatedHeaderLayoutBinding;
        this.minorsRecyclerView = recyclerView;
        this.spouseListTryAgainImageView = imageView;
        this.spouseListTryAgainLayout = linearLayout;
        this.spouseListTryAgainTextView = textView;
        this.spouseSwipeRefresh = swipeRefreshLayout;
        this.stepTitleHeadingLayout = updatedStepTitleLayoutBinding;
        this.userGuideTextView = textView2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static SpouseListFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static SpouseListFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.spouse_list_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static SpouseListFragmentBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.crc_footer_layout;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById2 != null) {
            UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBindingBind = UpdatedFooterWithBackNextBinding.bind(viewFindChildViewById2);
            i = R.id.crc_header_layout;
            View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById3 != null) {
                UpdatedHeaderLayoutBinding updatedHeaderLayoutBindingBind = UpdatedHeaderLayoutBinding.bind(viewFindChildViewById3);
                i = R.id.minors_recyclerView;
                RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
                if (recyclerView != null) {
                    i = R.id.spouse_list_try_again_imageView;
                    ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                    if (imageView != null) {
                        i = R.id.spouse_list_try_again_layout;
                        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                        if (linearLayout != null) {
                            i = R.id.spouse_list_try_again_textView;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView != null) {
                                i = R.id.spouse_swipeRefresh;
                                SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) ViewBindings.findChildViewById(view, i);
                                if (swipeRefreshLayout != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.step_title_heading_layout))) != null) {
                                    UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBindingBind = UpdatedStepTitleLayoutBinding.bind(viewFindChildViewById);
                                    i = R.id.user_guide_textView;
                                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView2 != null) {
                                        return new SpouseListFragmentBinding((ConstraintLayout) view, updatedFooterWithBackNextBindingBind, updatedHeaderLayoutBindingBind, recyclerView, imageView, linearLayout, textView, swipeRefreshLayout, updatedStepTitleLayoutBindingBind, textView2);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}