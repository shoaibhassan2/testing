package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.RadioGroupLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedFooterWithBackNextBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepTitleLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class ChildDetailFragmentBinding implements ViewBinding {
    public final EdittextLayoutBinding birthCertificateNumberLayout;
    public final AutocompletetextviewLayoutBinding birthCountryLayout;
    public final AutocompletetextviewLayoutBinding birthDistrictLayout;
    public final AutocompletetextviewLayoutBinding birthProvinceLayout;
    public final AutocompletetextviewLayoutBinding birthTehsilLayout;
    public final AutocompletetextviewLayoutBinding certificateTypeLayout;
    public final ScrollView childDetailsScrollView;
    public final MaskedEdittextLayoutBinding cnicLayout;
    public final RadioGroupLayoutBinding countryDistrictRadioGroup;
    public final UpdatedFooterWithBackNextBinding crcFooterLayout;
    public final UpdatedHeaderLayoutBinding crcHeaderLayout;
    public final UpdatedStepActionLayoutBinding crcStepAction;
    public final EdittextLayoutBinding dateOfBirthLayout;
    public final EdittextLayoutBinding firstNameLayout;
    public final EdittextLayoutBinding fullNameLayout;
    public final AutocompletetextviewLayoutBinding genderLayout;
    public final EdittextLayoutBinding lastNameLayout;
    public final AutocompletetextviewLayoutBinding orphanHouseNameLayout;
    public final AutocompletetextviewLayoutBinding relationApplicantLayout;
    private final ConstraintLayout rootView;
    public final UpdatedStepTitleLayoutBinding stepTitleHeadingLayout;
    public final AutocompletetextviewLayoutBinding twinLayout;
    public final EdittextLayoutBinding urduFirstNameLayout;
    public final EdittextLayoutBinding urduFullNameLayout;
    public final EdittextLayoutBinding urduLastNameLayout;

    private ChildDetailFragmentBinding(ConstraintLayout constraintLayout, EdittextLayoutBinding edittextLayoutBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding2, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding3, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding4, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding5, ScrollView scrollView, MaskedEdittextLayoutBinding maskedEdittextLayoutBinding, RadioGroupLayoutBinding radioGroupLayoutBinding, UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBinding, UpdatedHeaderLayoutBinding updatedHeaderLayoutBinding, UpdatedStepActionLayoutBinding updatedStepActionLayoutBinding, EdittextLayoutBinding edittextLayoutBinding2, EdittextLayoutBinding edittextLayoutBinding3, EdittextLayoutBinding edittextLayoutBinding4, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding6, EdittextLayoutBinding edittextLayoutBinding5, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding7, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding8, UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding9, EdittextLayoutBinding edittextLayoutBinding6, EdittextLayoutBinding edittextLayoutBinding7, EdittextLayoutBinding edittextLayoutBinding8) {
        this.rootView = constraintLayout;
        this.birthCertificateNumberLayout = edittextLayoutBinding;
        this.birthCountryLayout = autocompletetextviewLayoutBinding;
        this.birthDistrictLayout = autocompletetextviewLayoutBinding2;
        this.birthProvinceLayout = autocompletetextviewLayoutBinding3;
        this.birthTehsilLayout = autocompletetextviewLayoutBinding4;
        this.certificateTypeLayout = autocompletetextviewLayoutBinding5;
        this.childDetailsScrollView = scrollView;
        this.cnicLayout = maskedEdittextLayoutBinding;
        this.countryDistrictRadioGroup = radioGroupLayoutBinding;
        this.crcFooterLayout = updatedFooterWithBackNextBinding;
        this.crcHeaderLayout = updatedHeaderLayoutBinding;
        this.crcStepAction = updatedStepActionLayoutBinding;
        this.dateOfBirthLayout = edittextLayoutBinding2;
        this.firstNameLayout = edittextLayoutBinding3;
        this.fullNameLayout = edittextLayoutBinding4;
        this.genderLayout = autocompletetextviewLayoutBinding6;
        this.lastNameLayout = edittextLayoutBinding5;
        this.orphanHouseNameLayout = autocompletetextviewLayoutBinding7;
        this.relationApplicantLayout = autocompletetextviewLayoutBinding8;
        this.stepTitleHeadingLayout = updatedStepTitleLayoutBinding;
        this.twinLayout = autocompletetextviewLayoutBinding9;
        this.urduFirstNameLayout = edittextLayoutBinding6;
        this.urduFullNameLayout = edittextLayoutBinding7;
        this.urduLastNameLayout = edittextLayoutBinding8;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ChildDetailFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ChildDetailFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.child_detail_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ChildDetailFragmentBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.birth_certificate_number_layout;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById2 != null) {
            EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById2);
            i = R.id.birth_country_layout;
            View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById3 != null) {
                AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById3);
                i = R.id.birth_district_layout;
                View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById4 != null) {
                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind2 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById4);
                    i = R.id.birth_province_layout;
                    View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                    if (viewFindChildViewById5 != null) {
                        AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind3 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById5);
                        i = R.id.birth_tehsil_layout;
                        View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                        if (viewFindChildViewById6 != null) {
                            AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind4 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById6);
                            i = R.id.certificate_type_layout;
                            View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                            if (viewFindChildViewById7 != null) {
                                AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind5 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById7);
                                i = R.id.child_details_scrollView;
                                ScrollView scrollView = (ScrollView) ViewBindings.findChildViewById(view, i);
                                if (scrollView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.cnic_layout))) != null) {
                                    MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById);
                                    i = R.id.country_district_radio_group;
                                    View viewFindChildViewById8 = ViewBindings.findChildViewById(view, i);
                                    if (viewFindChildViewById8 != null) {
                                        RadioGroupLayoutBinding radioGroupLayoutBindingBind = RadioGroupLayoutBinding.bind(viewFindChildViewById8);
                                        i = R.id.crc_footer_layout;
                                        View viewFindChildViewById9 = ViewBindings.findChildViewById(view, i);
                                        if (viewFindChildViewById9 != null) {
                                            UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBindingBind = UpdatedFooterWithBackNextBinding.bind(viewFindChildViewById9);
                                            i = R.id.crc_header_layout;
                                            View viewFindChildViewById10 = ViewBindings.findChildViewById(view, i);
                                            if (viewFindChildViewById10 != null) {
                                                UpdatedHeaderLayoutBinding updatedHeaderLayoutBindingBind = UpdatedHeaderLayoutBinding.bind(viewFindChildViewById10);
                                                i = R.id.crc_step_action;
                                                View viewFindChildViewById11 = ViewBindings.findChildViewById(view, i);
                                                if (viewFindChildViewById11 != null) {
                                                    UpdatedStepActionLayoutBinding updatedStepActionLayoutBindingBind = UpdatedStepActionLayoutBinding.bind(viewFindChildViewById11);
                                                    i = R.id.date_of_birth_layout;
                                                    View viewFindChildViewById12 = ViewBindings.findChildViewById(view, i);
                                                    if (viewFindChildViewById12 != null) {
                                                        EdittextLayoutBinding edittextLayoutBindingBind2 = EdittextLayoutBinding.bind(viewFindChildViewById12);
                                                        i = R.id.first_name_layout;
                                                        View viewFindChildViewById13 = ViewBindings.findChildViewById(view, i);
                                                        if (viewFindChildViewById13 != null) {
                                                            EdittextLayoutBinding edittextLayoutBindingBind3 = EdittextLayoutBinding.bind(viewFindChildViewById13);
                                                            i = R.id.full_name_layout;
                                                            View viewFindChildViewById14 = ViewBindings.findChildViewById(view, i);
                                                            if (viewFindChildViewById14 != null) {
                                                                EdittextLayoutBinding edittextLayoutBindingBind4 = EdittextLayoutBinding.bind(viewFindChildViewById14);
                                                                i = R.id.gender_layout;
                                                                View viewFindChildViewById15 = ViewBindings.findChildViewById(view, i);
                                                                if (viewFindChildViewById15 != null) {
                                                                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind6 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById15);
                                                                    i = R.id.last_name_layout;
                                                                    View viewFindChildViewById16 = ViewBindings.findChildViewById(view, i);
                                                                    if (viewFindChildViewById16 != null) {
                                                                        EdittextLayoutBinding edittextLayoutBindingBind5 = EdittextLayoutBinding.bind(viewFindChildViewById16);
                                                                        i = R.id.orphan_house_name_layout;
                                                                        View viewFindChildViewById17 = ViewBindings.findChildViewById(view, i);
                                                                        if (viewFindChildViewById17 != null) {
                                                                            AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind7 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById17);
                                                                            i = R.id.relation_applicant_layout;
                                                                            View viewFindChildViewById18 = ViewBindings.findChildViewById(view, i);
                                                                            if (viewFindChildViewById18 != null) {
                                                                                AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind8 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById18);
                                                                                i = R.id.step_title_heading_layout;
                                                                                View viewFindChildViewById19 = ViewBindings.findChildViewById(view, i);
                                                                                if (viewFindChildViewById19 != null) {
                                                                                    UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBindingBind = UpdatedStepTitleLayoutBinding.bind(viewFindChildViewById19);
                                                                                    i = R.id.twin_layout;
                                                                                    View viewFindChildViewById20 = ViewBindings.findChildViewById(view, i);
                                                                                    if (viewFindChildViewById20 != null) {
                                                                                        AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind9 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById20);
                                                                                        i = R.id.urdu_first_name_layout;
                                                                                        View viewFindChildViewById21 = ViewBindings.findChildViewById(view, i);
                                                                                        if (viewFindChildViewById21 != null) {
                                                                                            EdittextLayoutBinding edittextLayoutBindingBind6 = EdittextLayoutBinding.bind(viewFindChildViewById21);
                                                                                            i = R.id.urdu_full_name_layout;
                                                                                            View viewFindChildViewById22 = ViewBindings.findChildViewById(view, i);
                                                                                            if (viewFindChildViewById22 != null) {
                                                                                                EdittextLayoutBinding edittextLayoutBindingBind7 = EdittextLayoutBinding.bind(viewFindChildViewById22);
                                                                                                i = R.id.urdu_last_name_layout;
                                                                                                View viewFindChildViewById23 = ViewBindings.findChildViewById(view, i);
                                                                                                if (viewFindChildViewById23 != null) {
                                                                                                    return new ChildDetailFragmentBinding((ConstraintLayout) view, edittextLayoutBindingBind, autocompletetextviewLayoutBindingBind, autocompletetextviewLayoutBindingBind2, autocompletetextviewLayoutBindingBind3, autocompletetextviewLayoutBindingBind4, autocompletetextviewLayoutBindingBind5, scrollView, maskedEdittextLayoutBindingBind, radioGroupLayoutBindingBind, updatedFooterWithBackNextBindingBind, updatedHeaderLayoutBindingBind, updatedStepActionLayoutBindingBind, edittextLayoutBindingBind2, edittextLayoutBindingBind3, edittextLayoutBindingBind4, autocompletetextviewLayoutBindingBind6, edittextLayoutBindingBind5, autocompletetextviewLayoutBindingBind7, autocompletetextviewLayoutBindingBind8, updatedStepTitleLayoutBindingBind, autocompletetextviewLayoutBindingBind9, edittextLayoutBindingBind6, edittextLayoutBindingBind7, EdittextLayoutBinding.bind(viewFindChildViewById23));
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}