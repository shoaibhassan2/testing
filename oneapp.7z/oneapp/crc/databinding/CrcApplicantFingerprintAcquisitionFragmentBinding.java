package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.ImageUploadLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedFooterWithBackNextBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepTitleLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class CrcApplicantFingerprintAcquisitionFragmentBinding implements ViewBinding {
    public final TextView crcApplicantFingerprintSuccessHeading;
    public final ImageUploadLayoutBinding crcFingerprintCapture;
    public final UpdatedFooterWithBackNextBinding crcFooterLayout;
    public final UpdatedHeaderLayoutBinding crcHeaderLayout;
    public final StepActionLayoutBinding crcStepAction;
    public final ScrollView fingerprintSuccessLayout;
    public final ScrollView fingerprintVerificationLayout;
    public final ImageView imageSuccess;
    private final ConstraintLayout rootView;
    public final UpdatedStepTitleLayoutBinding stepTitleHeadingLayout;

    private CrcApplicantFingerprintAcquisitionFragmentBinding(ConstraintLayout constraintLayout, TextView textView, ImageUploadLayoutBinding imageUploadLayoutBinding, UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBinding, UpdatedHeaderLayoutBinding updatedHeaderLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding, ScrollView scrollView, ScrollView scrollView2, ImageView imageView, UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBinding) {
        this.rootView = constraintLayout;
        this.crcApplicantFingerprintSuccessHeading = textView;
        this.crcFingerprintCapture = imageUploadLayoutBinding;
        this.crcFooterLayout = updatedFooterWithBackNextBinding;
        this.crcHeaderLayout = updatedHeaderLayoutBinding;
        this.crcStepAction = stepActionLayoutBinding;
        this.fingerprintSuccessLayout = scrollView;
        this.fingerprintVerificationLayout = scrollView2;
        this.imageSuccess = imageView;
        this.stepTitleHeadingLayout = updatedStepTitleLayoutBinding;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static CrcApplicantFingerprintAcquisitionFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static CrcApplicantFingerprintAcquisitionFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.crc_applicant_fingerprint_acquisition_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static CrcApplicantFingerprintAcquisitionFragmentBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i = R.id.crc_applicant_fingerprint_success_heading;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.crc_fingerprint_capture))) != null) {
            ImageUploadLayoutBinding imageUploadLayoutBindingBind = ImageUploadLayoutBinding.bind(viewFindChildViewById);
            i = R.id.crc_footer_layout;
            View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById3 != null) {
                UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBindingBind = UpdatedFooterWithBackNextBinding.bind(viewFindChildViewById3);
                i = R.id.crc_header_layout;
                View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById4 != null) {
                    UpdatedHeaderLayoutBinding updatedHeaderLayoutBindingBind = UpdatedHeaderLayoutBinding.bind(viewFindChildViewById4);
                    i = R.id.crc_step_action;
                    View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                    if (viewFindChildViewById5 != null) {
                        StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById5);
                        i = R.id.fingerprint_success_layout;
                        ScrollView scrollView = (ScrollView) ViewBindings.findChildViewById(view, i);
                        if (scrollView != null) {
                            i = R.id.fingerprint_verification_layout;
                            ScrollView scrollView2 = (ScrollView) ViewBindings.findChildViewById(view, i);
                            if (scrollView2 != null) {
                                i = R.id.image_success;
                                ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                                if (imageView != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.step_title_heading_layout))) != null) {
                                    return new CrcApplicantFingerprintAcquisitionFragmentBinding((ConstraintLayout) view, textView, imageUploadLayoutBindingBind, updatedFooterWithBackNextBindingBind, updatedHeaderLayoutBindingBind, stepActionLayoutBindingBind, scrollView, scrollView2, imageView, UpdatedStepTitleLayoutBinding.bind(viewFindChildViewById2));
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}