package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.checkbox.MaterialCheckBox;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonui.databinding.StepTitleLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedFooterWithBackNextBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class ReviewFragmentBinding implements ViewBinding {
    public final UpdatedFooterWithBackNextBinding crcFooterLayout;
    public final UpdatedHeaderLayoutBinding crcHeaderLayout;
    public final MaterialCheckBox declCriminalCaseP;
    public final MaterialCheckBox declInfoClarityP;
    public final MaterialCheckBox declInfoConcealP;
    public final MaterialCheckBox declInfoCorrectP;
    public final MaterialCheckBox declInfoVerificationP;
    public final MaterialCheckBox declPrisonCourtP;
    public final MaterialCheckBox declProphethoodFinalityP;
    public final ConfigurableButton reviewDataButton;
    public final TextView reviewDataTextView;
    private final ConstraintLayout rootView;
    public final StepTitleLayoutBinding stepTitleHeadingLayout;

    private ReviewFragmentBinding(ConstraintLayout constraintLayout, UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBinding, UpdatedHeaderLayoutBinding updatedHeaderLayoutBinding, MaterialCheckBox materialCheckBox, MaterialCheckBox materialCheckBox2, MaterialCheckBox materialCheckBox3, MaterialCheckBox materialCheckBox4, MaterialCheckBox materialCheckBox5, MaterialCheckBox materialCheckBox6, MaterialCheckBox materialCheckBox7, ConfigurableButton configurableButton, TextView textView, StepTitleLayoutBinding stepTitleLayoutBinding) {
        this.rootView = constraintLayout;
        this.crcFooterLayout = updatedFooterWithBackNextBinding;
        this.crcHeaderLayout = updatedHeaderLayoutBinding;
        this.declCriminalCaseP = materialCheckBox;
        this.declInfoClarityP = materialCheckBox2;
        this.declInfoConcealP = materialCheckBox3;
        this.declInfoCorrectP = materialCheckBox4;
        this.declInfoVerificationP = materialCheckBox5;
        this.declPrisonCourtP = materialCheckBox6;
        this.declProphethoodFinalityP = materialCheckBox7;
        this.reviewDataButton = configurableButton;
        this.reviewDataTextView = textView;
        this.stepTitleHeadingLayout = stepTitleLayoutBinding;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ReviewFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ReviewFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.review_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ReviewFragmentBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.crc_footer_layout;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById2 != null) {
            UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBindingBind = UpdatedFooterWithBackNextBinding.bind(viewFindChildViewById2);
            i = R.id.crc_header_layout;
            View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById3 != null) {
                UpdatedHeaderLayoutBinding updatedHeaderLayoutBindingBind = UpdatedHeaderLayoutBinding.bind(viewFindChildViewById3);
                i = R.id.declCriminalCaseP;
                MaterialCheckBox materialCheckBox = (MaterialCheckBox) ViewBindings.findChildViewById(view, i);
                if (materialCheckBox != null) {
                    i = R.id.declInfoClarityP;
                    MaterialCheckBox materialCheckBox2 = (MaterialCheckBox) ViewBindings.findChildViewById(view, i);
                    if (materialCheckBox2 != null) {
                        i = R.id.declInfoConcealP;
                        MaterialCheckBox materialCheckBox3 = (MaterialCheckBox) ViewBindings.findChildViewById(view, i);
                        if (materialCheckBox3 != null) {
                            i = R.id.declInfoCorrectP;
                            MaterialCheckBox materialCheckBox4 = (MaterialCheckBox) ViewBindings.findChildViewById(view, i);
                            if (materialCheckBox4 != null) {
                                i = R.id.declInfoVerificationP;
                                MaterialCheckBox materialCheckBox5 = (MaterialCheckBox) ViewBindings.findChildViewById(view, i);
                                if (materialCheckBox5 != null) {
                                    i = R.id.declPrisonCourtP;
                                    MaterialCheckBox materialCheckBox6 = (MaterialCheckBox) ViewBindings.findChildViewById(view, i);
                                    if (materialCheckBox6 != null) {
                                        i = R.id.declProphethoodFinalityP;
                                        MaterialCheckBox materialCheckBox7 = (MaterialCheckBox) ViewBindings.findChildViewById(view, i);
                                        if (materialCheckBox7 != null) {
                                            i = R.id.review_data_button;
                                            ConfigurableButton configurableButton = (ConfigurableButton) ViewBindings.findChildViewById(view, i);
                                            if (configurableButton != null) {
                                                i = R.id.review_data_textView;
                                                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                                                if (textView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.step_title_heading_layout))) != null) {
                                                    return new ReviewFragmentBinding((ConstraintLayout) view, updatedFooterWithBackNextBindingBind, updatedHeaderLayoutBindingBind, materialCheckBox, materialCheckBox2, materialCheckBox3, materialCheckBox4, materialCheckBox5, materialCheckBox6, materialCheckBox7, configurableButton, textView, StepTitleLayoutBinding.bind(viewFindChildViewById));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}