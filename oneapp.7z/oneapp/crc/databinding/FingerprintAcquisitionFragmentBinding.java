package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.FooterLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.HeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ImageUploadLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepTitleLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.TextviewLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class FingerprintAcquisitionFragmentBinding implements ViewBinding {
    public final ImageUploadLayoutBinding crcFingerprintCapture;
    public final FooterLayoutBinding crcFooterLayout;
    public final HeaderLayoutBinding crcHeaderLayout;
    public final StepActionLayoutBinding crcStepAction;
    public final TextviewLayoutBinding crcTakePhotoInstruction;
    private final ConstraintLayout rootView;
    public final StepTitleLayoutBinding stepTitleHeadingLayout;

    private FingerprintAcquisitionFragmentBinding(ConstraintLayout constraintLayout, ImageUploadLayoutBinding imageUploadLayoutBinding, FooterLayoutBinding footerLayoutBinding, HeaderLayoutBinding headerLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding, TextviewLayoutBinding textviewLayoutBinding, StepTitleLayoutBinding stepTitleLayoutBinding) {
        this.rootView = constraintLayout;
        this.crcFingerprintCapture = imageUploadLayoutBinding;
        this.crcFooterLayout = footerLayoutBinding;
        this.crcHeaderLayout = headerLayoutBinding;
        this.crcStepAction = stepActionLayoutBinding;
        this.crcTakePhotoInstruction = textviewLayoutBinding;
        this.stepTitleHeadingLayout = stepTitleLayoutBinding;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FingerprintAcquisitionFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FingerprintAcquisitionFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fingerprint_acquisition_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FingerprintAcquisitionFragmentBinding bind(View view) {
        int i = R.id.crc_fingerprint_capture;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            ImageUploadLayoutBinding imageUploadLayoutBindingBind = ImageUploadLayoutBinding.bind(viewFindChildViewById);
            i = R.id.crc_footer_layout;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById2 != null) {
                FooterLayoutBinding footerLayoutBindingBind = FooterLayoutBinding.bind(viewFindChildViewById2);
                i = R.id.crc_header_layout;
                View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById3 != null) {
                    HeaderLayoutBinding headerLayoutBindingBind = HeaderLayoutBinding.bind(viewFindChildViewById3);
                    i = R.id.crc_step_action;
                    View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                    if (viewFindChildViewById4 != null) {
                        StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById4);
                        i = R.id.crc_take_photo_instruction;
                        View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                        if (viewFindChildViewById5 != null) {
                            TextviewLayoutBinding textviewLayoutBindingBind = TextviewLayoutBinding.bind(viewFindChildViewById5);
                            i = R.id.step_title_heading_layout;
                            View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                            if (viewFindChildViewById6 != null) {
                                return new FingerprintAcquisitionFragmentBinding((ConstraintLayout) view, imageUploadLayoutBindingBind, footerLayoutBindingBind, headerLayoutBindingBind, stepActionLayoutBindingBind, textviewLayoutBindingBind, StepTitleLayoutBinding.bind(viewFindChildViewById6));
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}