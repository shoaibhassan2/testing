package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepTitleLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedFooterWithBackNextBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonutils.utils.NonScrollExpandableListView;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class CrcSupportingDocumentsFragmentBinding implements ViewBinding {
    public final UpdatedFooterWithBackNextBinding crcFooterLayout;
    public final UpdatedHeaderLayoutBinding crcHeaderLayout;
    public final StepActionLayoutBinding documentsDetailsHeading;
    public final ImageView documentsListTryAgainImageView;
    public final LinearLayout documentsListTryAgainLayout;
    public final TextView documentsListTryAgainTextView;
    public final SwipeRefreshLayout documentsSwipeRefresh;
    public final NonScrollExpandableListView expandableListViewUploadedDocuments;
    private final ConstraintLayout rootView;
    public final StepTitleLayoutBinding stepTitleHeadingLayout;
    public final NonScrollExpandableListView supportingUploadedDocumentsRecyclerView;
    public final StepActionLayoutBinding uploadedDocumentsDetailsHeading;

    private CrcSupportingDocumentsFragmentBinding(ConstraintLayout constraintLayout, UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBinding, UpdatedHeaderLayoutBinding updatedHeaderLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding, ImageView imageView, LinearLayout linearLayout, TextView textView, SwipeRefreshLayout swipeRefreshLayout, NonScrollExpandableListView nonScrollExpandableListView, StepTitleLayoutBinding stepTitleLayoutBinding, NonScrollExpandableListView nonScrollExpandableListView2, StepActionLayoutBinding stepActionLayoutBinding2) {
        this.rootView = constraintLayout;
        this.crcFooterLayout = updatedFooterWithBackNextBinding;
        this.crcHeaderLayout = updatedHeaderLayoutBinding;
        this.documentsDetailsHeading = stepActionLayoutBinding;
        this.documentsListTryAgainImageView = imageView;
        this.documentsListTryAgainLayout = linearLayout;
        this.documentsListTryAgainTextView = textView;
        this.documentsSwipeRefresh = swipeRefreshLayout;
        this.expandableListViewUploadedDocuments = nonScrollExpandableListView;
        this.stepTitleHeadingLayout = stepTitleLayoutBinding;
        this.supportingUploadedDocumentsRecyclerView = nonScrollExpandableListView2;
        this.uploadedDocumentsDetailsHeading = stepActionLayoutBinding2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static CrcSupportingDocumentsFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static CrcSupportingDocumentsFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.crc_supporting_documents_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static CrcSupportingDocumentsFragmentBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i = R.id.crc_footer_layout;
        View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById3 != null) {
            UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBindingBind = UpdatedFooterWithBackNextBinding.bind(viewFindChildViewById3);
            i = R.id.crc_header_layout;
            View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById4 != null) {
                UpdatedHeaderLayoutBinding updatedHeaderLayoutBindingBind = UpdatedHeaderLayoutBinding.bind(viewFindChildViewById4);
                i = R.id.documents_details_heading;
                View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById5 != null) {
                    StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById5);
                    i = R.id.documents_list_try_again_imageView;
                    ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                    if (imageView != null) {
                        i = R.id.documents_list_try_again_layout;
                        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                        if (linearLayout != null) {
                            i = R.id.documents_list_try_again_textView;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView != null) {
                                i = R.id.documents_swipeRefresh;
                                SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) ViewBindings.findChildViewById(view, i);
                                if (swipeRefreshLayout != null) {
                                    i = R.id.expandableListView_uploaded_documents;
                                    NonScrollExpandableListView nonScrollExpandableListView = (NonScrollExpandableListView) ViewBindings.findChildViewById(view, i);
                                    if (nonScrollExpandableListView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.step_title_heading_layout))) != null) {
                                        StepTitleLayoutBinding stepTitleLayoutBindingBind = StepTitleLayoutBinding.bind(viewFindChildViewById);
                                        i = R.id.supporting_uploaded_documents_recyclerView;
                                        NonScrollExpandableListView nonScrollExpandableListView2 = (NonScrollExpandableListView) ViewBindings.findChildViewById(view, i);
                                        if (nonScrollExpandableListView2 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.uploaded_documents_details_heading))) != null) {
                                            return new CrcSupportingDocumentsFragmentBinding((ConstraintLayout) view, updatedFooterWithBackNextBindingBind, updatedHeaderLayoutBindingBind, stepActionLayoutBindingBind, imageView, linearLayout, textView, swipeRefreshLayout, nonScrollExpandableListView, stepTitleLayoutBindingBind, nonScrollExpandableListView2, StepActionLayoutBinding.bind(viewFindChildViewById2));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}