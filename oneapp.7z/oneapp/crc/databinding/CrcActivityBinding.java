package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentContainerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class CrcActivityBinding implements ViewBinding {
    public final UpdatedHeaderLayoutBackTitleBinding crcHeaderLayout;
    public final FragmentContainerView navHostFragment;
    private final ConstraintLayout rootView;

    private CrcActivityBinding(ConstraintLayout constraintLayout, UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBinding, FragmentContainerView fragmentContainerView) {
        this.rootView = constraintLayout;
        this.crcHeaderLayout = updatedHeaderLayoutBackTitleBinding;
        this.navHostFragment = fragmentContainerView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static CrcActivityBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static CrcActivityBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.crc_activity, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static CrcActivityBinding bind(View view) {
        int i = R.id.crc_header_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
            int i2 = R.id.nav_host_fragment;
            FragmentContainerView fragmentContainerView = (FragmentContainerView) ViewBindings.findChildViewById(view, i2);
            if (fragmentContainerView != null) {
                return new CrcActivityBinding((ConstraintLayout) view, updatedHeaderLayoutBackTitleBindingBind, fragmentContainerView);
            }
            i = i2;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}