package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedFooterWithBackNextBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepTitleLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class ChildParentDetailFragmentBinding implements ViewBinding {
    public final ScrollView childParentDetailsScrollView;
    public final UpdatedFooterWithBackNextBinding crcFooterLayout;
    public final UpdatedHeaderLayoutBinding crcHeaderLayout;
    public final MaskedEdittextLayoutBinding fatherCnicLayout;
    public final UpdatedStepActionLayoutBinding fatherDetailsHeading;
    public final EdittextLayoutBinding fatherFullNameLayout;
    public final MaskedEdittextLayoutBinding motherCnicLayout;
    public final UpdatedStepActionLayoutBinding motherDetailsHeading;
    public final EdittextLayoutBinding motherFullNameLayout;
    private final ConstraintLayout rootView;
    public final UpdatedStepTitleLayoutBinding stepTitleHeadingLayout;
    public final EdittextLayoutBinding urduFatherFullNameLayout;
    public final EdittextLayoutBinding urduMotherFullNameLayout;

    private ChildParentDetailFragmentBinding(ConstraintLayout constraintLayout, ScrollView scrollView, UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBinding, UpdatedHeaderLayoutBinding updatedHeaderLayoutBinding, MaskedEdittextLayoutBinding maskedEdittextLayoutBinding, UpdatedStepActionLayoutBinding updatedStepActionLayoutBinding, EdittextLayoutBinding edittextLayoutBinding, MaskedEdittextLayoutBinding maskedEdittextLayoutBinding2, UpdatedStepActionLayoutBinding updatedStepActionLayoutBinding2, EdittextLayoutBinding edittextLayoutBinding2, UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBinding, EdittextLayoutBinding edittextLayoutBinding3, EdittextLayoutBinding edittextLayoutBinding4) {
        this.rootView = constraintLayout;
        this.childParentDetailsScrollView = scrollView;
        this.crcFooterLayout = updatedFooterWithBackNextBinding;
        this.crcHeaderLayout = updatedHeaderLayoutBinding;
        this.fatherCnicLayout = maskedEdittextLayoutBinding;
        this.fatherDetailsHeading = updatedStepActionLayoutBinding;
        this.fatherFullNameLayout = edittextLayoutBinding;
        this.motherCnicLayout = maskedEdittextLayoutBinding2;
        this.motherDetailsHeading = updatedStepActionLayoutBinding2;
        this.motherFullNameLayout = edittextLayoutBinding2;
        this.stepTitleHeadingLayout = updatedStepTitleLayoutBinding;
        this.urduFatherFullNameLayout = edittextLayoutBinding3;
        this.urduMotherFullNameLayout = edittextLayoutBinding4;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ChildParentDetailFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ChildParentDetailFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.child_parent_detail_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ChildParentDetailFragmentBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.child_parent_details_scrollView;
        ScrollView scrollView = (ScrollView) ViewBindings.findChildViewById(view, i);
        if (scrollView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.crc_footer_layout))) != null) {
            UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBindingBind = UpdatedFooterWithBackNextBinding.bind(viewFindChildViewById);
            i = R.id.crc_header_layout;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById2 != null) {
                UpdatedHeaderLayoutBinding updatedHeaderLayoutBindingBind = UpdatedHeaderLayoutBinding.bind(viewFindChildViewById2);
                i = R.id.father_cnic_layout;
                View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById3 != null) {
                    MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById3);
                    i = R.id.father_details_heading;
                    View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                    if (viewFindChildViewById4 != null) {
                        UpdatedStepActionLayoutBinding updatedStepActionLayoutBindingBind = UpdatedStepActionLayoutBinding.bind(viewFindChildViewById4);
                        i = R.id.father_full_name_layout;
                        View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                        if (viewFindChildViewById5 != null) {
                            EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById5);
                            i = R.id.mother_cnic_layout;
                            View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                            if (viewFindChildViewById6 != null) {
                                MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind2 = MaskedEdittextLayoutBinding.bind(viewFindChildViewById6);
                                i = R.id.mother_details_heading;
                                View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                                if (viewFindChildViewById7 != null) {
                                    UpdatedStepActionLayoutBinding updatedStepActionLayoutBindingBind2 = UpdatedStepActionLayoutBinding.bind(viewFindChildViewById7);
                                    i = R.id.mother_full_name_layout;
                                    View viewFindChildViewById8 = ViewBindings.findChildViewById(view, i);
                                    if (viewFindChildViewById8 != null) {
                                        EdittextLayoutBinding edittextLayoutBindingBind2 = EdittextLayoutBinding.bind(viewFindChildViewById8);
                                        i = R.id.step_title_heading_layout;
                                        View viewFindChildViewById9 = ViewBindings.findChildViewById(view, i);
                                        if (viewFindChildViewById9 != null) {
                                            UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBindingBind = UpdatedStepTitleLayoutBinding.bind(viewFindChildViewById9);
                                            i = R.id.urdu_father_full_name_layout;
                                            View viewFindChildViewById10 = ViewBindings.findChildViewById(view, i);
                                            if (viewFindChildViewById10 != null) {
                                                EdittextLayoutBinding edittextLayoutBindingBind3 = EdittextLayoutBinding.bind(viewFindChildViewById10);
                                                i = R.id.urdu_mother_full_name_layout;
                                                View viewFindChildViewById11 = ViewBindings.findChildViewById(view, i);
                                                if (viewFindChildViewById11 != null) {
                                                    return new ChildParentDetailFragmentBinding((ConstraintLayout) view, scrollView, updatedFooterWithBackNextBindingBind, updatedHeaderLayoutBindingBind, maskedEdittextLayoutBindingBind, updatedStepActionLayoutBindingBind, edittextLayoutBindingBind, maskedEdittextLayoutBindingBind2, updatedStepActionLayoutBindingBind2, edittextLayoutBindingBind2, updatedStepTitleLayoutBindingBind, edittextLayoutBindingBind3, EdittextLayoutBinding.bind(viewFindChildViewById11));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}