package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedFooterWithBackNextBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepTitleLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class SignatureAcquisitionFragmentBinding implements ViewBinding {
    public final ButtonLayoutBinding browseSignatureButtonLayout;
    public final ButtonLayoutBinding captureSignatureButtonLayout;
    public final UpdatedFooterWithBackNextBinding crcFooterLayout;
    public final UpdatedHeaderLayoutBinding crcHeaderLayout;
    public final UpdatedStepActionLayoutBinding crcStepAction;
    public final ConstraintLayout infoConstLayout;
    public final ImageView ivInfoIcon;
    public final ImageView ivTakePhoto;
    private final ConstraintLayout rootView;
    public final ConstraintLayout signatureConstLayout;
    public final UpdatedStepTitleLayoutBinding stepTitleHeadingLayout;
    public final TextView tvInfo;

    private SignatureAcquisitionFragmentBinding(ConstraintLayout constraintLayout, ButtonLayoutBinding buttonLayoutBinding, ButtonLayoutBinding buttonLayoutBinding2, UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBinding, UpdatedHeaderLayoutBinding updatedHeaderLayoutBinding, UpdatedStepActionLayoutBinding updatedStepActionLayoutBinding, ConstraintLayout constraintLayout2, ImageView imageView, ImageView imageView2, ConstraintLayout constraintLayout3, UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBinding, TextView textView) {
        this.rootView = constraintLayout;
        this.browseSignatureButtonLayout = buttonLayoutBinding;
        this.captureSignatureButtonLayout = buttonLayoutBinding2;
        this.crcFooterLayout = updatedFooterWithBackNextBinding;
        this.crcHeaderLayout = updatedHeaderLayoutBinding;
        this.crcStepAction = updatedStepActionLayoutBinding;
        this.infoConstLayout = constraintLayout2;
        this.ivInfoIcon = imageView;
        this.ivTakePhoto = imageView2;
        this.signatureConstLayout = constraintLayout3;
        this.stepTitleHeadingLayout = updatedStepTitleLayoutBinding;
        this.tvInfo = textView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static SignatureAcquisitionFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static SignatureAcquisitionFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.signature_acquisition_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static SignatureAcquisitionFragmentBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.browse_signature_button_layout;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById2 != null) {
            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById2);
            i = R.id.capture_signature_button_layout;
            View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById3 != null) {
                ButtonLayoutBinding buttonLayoutBindingBind2 = ButtonLayoutBinding.bind(viewFindChildViewById3);
                i = R.id.crc_footer_layout;
                View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById4 != null) {
                    UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBindingBind = UpdatedFooterWithBackNextBinding.bind(viewFindChildViewById4);
                    i = R.id.crc_header_layout;
                    View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                    if (viewFindChildViewById5 != null) {
                        UpdatedHeaderLayoutBinding updatedHeaderLayoutBindingBind = UpdatedHeaderLayoutBinding.bind(viewFindChildViewById5);
                        i = R.id.crc_step_action;
                        View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                        if (viewFindChildViewById6 != null) {
                            UpdatedStepActionLayoutBinding updatedStepActionLayoutBindingBind = UpdatedStepActionLayoutBinding.bind(viewFindChildViewById6);
                            i = R.id.info_const_layout;
                            ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(view, i);
                            if (constraintLayout != null) {
                                i = R.id.iv_info_icon;
                                ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                                if (imageView != null) {
                                    i = R.id.iv_take_photo;
                                    ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                                    if (imageView2 != null) {
                                        i = R.id.signature_const_layout;
                                        ConstraintLayout constraintLayout2 = (ConstraintLayout) ViewBindings.findChildViewById(view, i);
                                        if (constraintLayout2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.step_title_heading_layout))) != null) {
                                            UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBindingBind = UpdatedStepTitleLayoutBinding.bind(viewFindChildViewById);
                                            i = R.id.tv_info;
                                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                                            if (textView != null) {
                                                return new SignatureAcquisitionFragmentBinding((ConstraintLayout) view, buttonLayoutBindingBind, buttonLayoutBindingBind2, updatedFooterWithBackNextBindingBind, updatedHeaderLayoutBindingBind, updatedStepActionLayoutBindingBind, constraintLayout, imageView, imageView2, constraintLayout2, updatedStepTitleLayoutBindingBind, textView);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}