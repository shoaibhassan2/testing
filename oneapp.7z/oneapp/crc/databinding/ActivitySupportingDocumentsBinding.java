package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.FooterLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.HeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ImageUploadLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepTitleLayoutBinding;
import pk.gov.nadra.oneapp.commonutils.utils.NonScrollExpandableListView;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class ActivitySupportingDocumentsBinding implements ViewBinding {
    public final FooterLayoutBinding crcFooterLayout;
    public final HeaderLayoutBinding crcHeaderLayout;
    public final StepActionLayoutBinding documentsDetailsHeading;
    public final RecyclerView documentsTypeRecyclerView;
    public final NonScrollExpandableListView expandableListViewUploadedDocuments;
    public final ButtonLayoutBinding requireDocumentBrowseButtonLayout;
    public final ButtonLayoutBinding requireDocumentCaptureButtonLayout;
    public final ImageUploadLayoutBinding requireDocumentTakePhoto;
    public final AutocompletetextviewLayoutBinding requiredDocumentsLayout;
    private final ConstraintLayout rootView;
    public final StepTitleLayoutBinding stepTitleHeadingLayout;
    public final StepActionLayoutBinding uploadedDocumentsDetailsHeading;

    private ActivitySupportingDocumentsBinding(ConstraintLayout constraintLayout, FooterLayoutBinding footerLayoutBinding, HeaderLayoutBinding headerLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding, RecyclerView recyclerView, NonScrollExpandableListView nonScrollExpandableListView, ButtonLayoutBinding buttonLayoutBinding, ButtonLayoutBinding buttonLayoutBinding2, ImageUploadLayoutBinding imageUploadLayoutBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding, StepTitleLayoutBinding stepTitleLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding2) {
        this.rootView = constraintLayout;
        this.crcFooterLayout = footerLayoutBinding;
        this.crcHeaderLayout = headerLayoutBinding;
        this.documentsDetailsHeading = stepActionLayoutBinding;
        this.documentsTypeRecyclerView = recyclerView;
        this.expandableListViewUploadedDocuments = nonScrollExpandableListView;
        this.requireDocumentBrowseButtonLayout = buttonLayoutBinding;
        this.requireDocumentCaptureButtonLayout = buttonLayoutBinding2;
        this.requireDocumentTakePhoto = imageUploadLayoutBinding;
        this.requiredDocumentsLayout = autocompletetextviewLayoutBinding;
        this.stepTitleHeadingLayout = stepTitleLayoutBinding;
        this.uploadedDocumentsDetailsHeading = stepActionLayoutBinding2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivitySupportingDocumentsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivitySupportingDocumentsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_supporting_documents, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivitySupportingDocumentsBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.crc_footer_layout;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById2 != null) {
            FooterLayoutBinding footerLayoutBindingBind = FooterLayoutBinding.bind(viewFindChildViewById2);
            i = R.id.crc_header_layout;
            View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById3 != null) {
                HeaderLayoutBinding headerLayoutBindingBind = HeaderLayoutBinding.bind(viewFindChildViewById3);
                i = R.id.documents_details_heading;
                View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById4 != null) {
                    StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById4);
                    i = R.id.documents_type_recyclerView;
                    RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
                    if (recyclerView != null) {
                        i = R.id.expandableListView_uploaded_documents;
                        NonScrollExpandableListView nonScrollExpandableListView = (NonScrollExpandableListView) ViewBindings.findChildViewById(view, i);
                        if (nonScrollExpandableListView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.require_document_browse_button_layout))) != null) {
                            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById);
                            i = R.id.require_document_capture_button_layout;
                            View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                            if (viewFindChildViewById5 != null) {
                                ButtonLayoutBinding buttonLayoutBindingBind2 = ButtonLayoutBinding.bind(viewFindChildViewById5);
                                i = R.id.require_document_take_photo;
                                View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                                if (viewFindChildViewById6 != null) {
                                    ImageUploadLayoutBinding imageUploadLayoutBindingBind = ImageUploadLayoutBinding.bind(viewFindChildViewById6);
                                    i = R.id.required_documents_layout;
                                    View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                                    if (viewFindChildViewById7 != null) {
                                        AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById7);
                                        i = R.id.step_title_heading_layout;
                                        View viewFindChildViewById8 = ViewBindings.findChildViewById(view, i);
                                        if (viewFindChildViewById8 != null) {
                                            StepTitleLayoutBinding stepTitleLayoutBindingBind = StepTitleLayoutBinding.bind(viewFindChildViewById8);
                                            i = R.id.uploaded_documents_details_heading;
                                            View viewFindChildViewById9 = ViewBindings.findChildViewById(view, i);
                                            if (viewFindChildViewById9 != null) {
                                                return new ActivitySupportingDocumentsBinding((ConstraintLayout) view, footerLayoutBindingBind, headerLayoutBindingBind, stepActionLayoutBindingBind, recyclerView, nonScrollExpandableListView, buttonLayoutBindingBind, buttonLayoutBindingBind2, imageUploadLayoutBindingBind, autocompletetextviewLayoutBindingBind, stepTitleLayoutBindingBind, StepActionLayoutBinding.bind(viewFindChildViewById9));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}