package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.chip.ChipGroup;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.PartialHeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.PhoneNumberViewBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.VerticalShapedRadioButtonBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class ActivityNewApplicationBinding implements ViewBinding {
    public final StepActionLayoutBinding applicationDetailHeadingLayout;
    public final AutocompletetextviewLayoutBinding applicationTypeLayout;
    public final StepActionLayoutBinding contactDetailHeadingLayout;
    public final PhoneNumberViewBinding contactNumberLayout;
    public final PartialHeaderLayoutBinding crcHeaderLayout;
    public final AutocompletetextviewLayoutBinding documentTypeLayout;
    public final EdittextLayoutBinding emailLayout;
    public final VerticalShapedRadioButtonBinding executivePriorityRadioButtonLayout;
    public final VerticalShapedRadioButtonBinding normalPriorityRadioButtonLayout;
    public final LinearLayout priorityProcessingLayout;
    private final ConstraintLayout rootView;
    public final ButtonLayoutBinding startApplicationButtonLayout;
    public final TextView tvDurationNoteHeading;
    public final TextView tvPriorityHeading;
    public final VerticalShapedRadioButtonBinding urgentPriorityRadioButtonLayout;
    public final ChipGroup valueAddedServiceChipGroup;
    public final AutocompletetextviewLayoutBinding valueAddedServicesLayout;

    private ActivityNewApplicationBinding(ConstraintLayout constraintLayout, StepActionLayoutBinding stepActionLayoutBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding2, PhoneNumberViewBinding phoneNumberViewBinding, PartialHeaderLayoutBinding partialHeaderLayoutBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding2, EdittextLayoutBinding edittextLayoutBinding, VerticalShapedRadioButtonBinding verticalShapedRadioButtonBinding, VerticalShapedRadioButtonBinding verticalShapedRadioButtonBinding2, LinearLayout linearLayout, ButtonLayoutBinding buttonLayoutBinding, TextView textView, TextView textView2, VerticalShapedRadioButtonBinding verticalShapedRadioButtonBinding3, ChipGroup chipGroup, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding3) {
        this.rootView = constraintLayout;
        this.applicationDetailHeadingLayout = stepActionLayoutBinding;
        this.applicationTypeLayout = autocompletetextviewLayoutBinding;
        this.contactDetailHeadingLayout = stepActionLayoutBinding2;
        this.contactNumberLayout = phoneNumberViewBinding;
        this.crcHeaderLayout = partialHeaderLayoutBinding;
        this.documentTypeLayout = autocompletetextviewLayoutBinding2;
        this.emailLayout = edittextLayoutBinding;
        this.executivePriorityRadioButtonLayout = verticalShapedRadioButtonBinding;
        this.normalPriorityRadioButtonLayout = verticalShapedRadioButtonBinding2;
        this.priorityProcessingLayout = linearLayout;
        this.startApplicationButtonLayout = buttonLayoutBinding;
        this.tvDurationNoteHeading = textView;
        this.tvPriorityHeading = textView2;
        this.urgentPriorityRadioButtonLayout = verticalShapedRadioButtonBinding3;
        this.valueAddedServiceChipGroup = chipGroup;
        this.valueAddedServicesLayout = autocompletetextviewLayoutBinding3;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivityNewApplicationBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivityNewApplicationBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_new_application, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivityNewApplicationBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        int i = R.id.application_detail_heading_layout;
        View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById4 != null) {
            StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById4);
            i = R.id.application_type_layout;
            View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById5 != null) {
                AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById5);
                i = R.id.contact_detail_heading_layout;
                View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById6 != null) {
                    StepActionLayoutBinding stepActionLayoutBindingBind2 = StepActionLayoutBinding.bind(viewFindChildViewById6);
                    i = R.id.contact_number_layout;
                    View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                    if (viewFindChildViewById7 != null) {
                        PhoneNumberViewBinding phoneNumberViewBindingBind = PhoneNumberViewBinding.bind(viewFindChildViewById7);
                        i = R.id.crc_header_layout;
                        View viewFindChildViewById8 = ViewBindings.findChildViewById(view, i);
                        if (viewFindChildViewById8 != null) {
                            PartialHeaderLayoutBinding partialHeaderLayoutBindingBind = PartialHeaderLayoutBinding.bind(viewFindChildViewById8);
                            i = R.id.document_type_layout;
                            View viewFindChildViewById9 = ViewBindings.findChildViewById(view, i);
                            if (viewFindChildViewById9 != null) {
                                AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind2 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById9);
                                i = R.id.email_layout;
                                View viewFindChildViewById10 = ViewBindings.findChildViewById(view, i);
                                if (viewFindChildViewById10 != null) {
                                    EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById10);
                                    i = R.id.executive_priority_radioButton_layout;
                                    View viewFindChildViewById11 = ViewBindings.findChildViewById(view, i);
                                    if (viewFindChildViewById11 != null) {
                                        VerticalShapedRadioButtonBinding verticalShapedRadioButtonBindingBind = VerticalShapedRadioButtonBinding.bind(viewFindChildViewById11);
                                        i = R.id.normal_priority_radioButton_layout;
                                        View viewFindChildViewById12 = ViewBindings.findChildViewById(view, i);
                                        if (viewFindChildViewById12 != null) {
                                            VerticalShapedRadioButtonBinding verticalShapedRadioButtonBindingBind2 = VerticalShapedRadioButtonBinding.bind(viewFindChildViewById12);
                                            i = R.id.priority_processing_layout;
                                            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                                            if (linearLayout != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.start_application_button_layout))) != null) {
                                                ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById);
                                                i = R.id.tv_duration_note_heading;
                                                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                                                if (textView != null) {
                                                    i = R.id.tv_priority_heading;
                                                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                                                    if (textView2 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.urgent_priority_radioButton_layout))) != null) {
                                                        VerticalShapedRadioButtonBinding verticalShapedRadioButtonBindingBind3 = VerticalShapedRadioButtonBinding.bind(viewFindChildViewById2);
                                                        i = R.id.value_added_service__chipGroup;
                                                        ChipGroup chipGroup = (ChipGroup) ViewBindings.findChildViewById(view, i);
                                                        if (chipGroup != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(view, (i = R.id.value_added_services_layout))) != null) {
                                                            return new ActivityNewApplicationBinding((ConstraintLayout) view, stepActionLayoutBindingBind, autocompletetextviewLayoutBindingBind, stepActionLayoutBindingBind2, phoneNumberViewBindingBind, partialHeaderLayoutBindingBind, autocompletetextviewLayoutBindingBind2, edittextLayoutBindingBind, verticalShapedRadioButtonBindingBind, verticalShapedRadioButtonBindingBind2, linearLayout, buttonLayoutBindingBind, textView, textView2, verticalShapedRadioButtonBindingBind3, chipGroup, AutocompletetextviewLayoutBinding.bind(viewFindChildViewById3));
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}