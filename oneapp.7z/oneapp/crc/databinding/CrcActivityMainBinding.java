package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.CheckboxLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.FooterLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.HeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ImageUploadLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepTitleLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.TextviewLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class CrcActivityMainBinding implements ViewBinding {
    public final ButtonLayoutBinding captureButtonLayout;
    public final FooterLayoutBinding crcFooterLayout;
    public final HeaderLayoutBinding crcHeaderLayout;
    public final CheckboxLayoutBinding crcSkipCheckbox;
    public final StepActionLayoutBinding crcStepAction;
    public final ImageUploadLayoutBinding crcTakePhoto;
    public final TextviewLayoutBinding crcTakePhotoInstruction;
    private final ConstraintLayout rootView;
    public final StepTitleLayoutBinding stepTitleHeadingLayout;
    public final ButtonLayoutBinding uploadButtonLayout;

    private CrcActivityMainBinding(ConstraintLayout constraintLayout, ButtonLayoutBinding buttonLayoutBinding, FooterLayoutBinding footerLayoutBinding, HeaderLayoutBinding headerLayoutBinding, CheckboxLayoutBinding checkboxLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding, ImageUploadLayoutBinding imageUploadLayoutBinding, TextviewLayoutBinding textviewLayoutBinding, StepTitleLayoutBinding stepTitleLayoutBinding, ButtonLayoutBinding buttonLayoutBinding2) {
        this.rootView = constraintLayout;
        this.captureButtonLayout = buttonLayoutBinding;
        this.crcFooterLayout = footerLayoutBinding;
        this.crcHeaderLayout = headerLayoutBinding;
        this.crcSkipCheckbox = checkboxLayoutBinding;
        this.crcStepAction = stepActionLayoutBinding;
        this.crcTakePhoto = imageUploadLayoutBinding;
        this.crcTakePhotoInstruction = textviewLayoutBinding;
        this.stepTitleHeadingLayout = stepTitleLayoutBinding;
        this.uploadButtonLayout = buttonLayoutBinding2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static CrcActivityMainBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static CrcActivityMainBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.crc_activity_main, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static CrcActivityMainBinding bind(View view) {
        int i = R.id.capture_button_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById);
            i = R.id.crc_footer_layout;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById2 != null) {
                FooterLayoutBinding footerLayoutBindingBind = FooterLayoutBinding.bind(viewFindChildViewById2);
                i = R.id.crc_header_layout;
                View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById3 != null) {
                    HeaderLayoutBinding headerLayoutBindingBind = HeaderLayoutBinding.bind(viewFindChildViewById3);
                    i = R.id.crc_skip_checkbox;
                    View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                    if (viewFindChildViewById4 != null) {
                        CheckboxLayoutBinding checkboxLayoutBindingBind = CheckboxLayoutBinding.bind(viewFindChildViewById4);
                        i = R.id.crc_step_action;
                        View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                        if (viewFindChildViewById5 != null) {
                            StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById5);
                            i = R.id.crc_take_photo;
                            View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                            if (viewFindChildViewById6 != null) {
                                ImageUploadLayoutBinding imageUploadLayoutBindingBind = ImageUploadLayoutBinding.bind(viewFindChildViewById6);
                                i = R.id.crc_take_photo_instruction;
                                View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                                if (viewFindChildViewById7 != null) {
                                    TextviewLayoutBinding textviewLayoutBindingBind = TextviewLayoutBinding.bind(viewFindChildViewById7);
                                    i = R.id.step_title_heading_layout;
                                    View viewFindChildViewById8 = ViewBindings.findChildViewById(view, i);
                                    if (viewFindChildViewById8 != null) {
                                        StepTitleLayoutBinding stepTitleLayoutBindingBind = StepTitleLayoutBinding.bind(viewFindChildViewById8);
                                        i = R.id.upload_button_layout;
                                        View viewFindChildViewById9 = ViewBindings.findChildViewById(view, i);
                                        if (viewFindChildViewById9 != null) {
                                            return new CrcActivityMainBinding((ConstraintLayout) view, buttonLayoutBindingBind, footerLayoutBindingBind, headerLayoutBindingBind, checkboxLayoutBindingBind, stepActionLayoutBindingBind, imageUploadLayoutBindingBind, textviewLayoutBindingBind, stepTitleLayoutBindingBind, ButtonLayoutBinding.bind(viewFindChildViewById9));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}