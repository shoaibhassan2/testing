package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Guideline;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepActionLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class NewApplicationFragmentBinding implements ViewBinding {
    public final MaskedEdittextLayoutBinding applicantCnicLayout;
    public final ConstraintLayout applicantDetailLayout;
    public final UpdatedStepActionLayoutBinding applicationDetailHeadingLayout;
    public final TextView applicationFeeHeadingTextView;
    public final TextView applicationFeeTextView;
    public final AutocompletetextviewLayoutBinding applicationTypeLayout;
    public final MaterialCardView categoryFeeCardView;
    public final View categoryLineView;
    public final TextView categoryTypeTextView;
    public final UpdatedStepActionLayoutBinding contactDetailHeadingLayout;
    public final TextInputLayout contactNumberLayout;
    public final AutocompletetextviewLayoutBinding countryResidentLayout;
    public final UpdatedHeaderLayoutBinding crcHeaderLayout;
    public final TextView deliveryFeeHeadingTextView;
    public final TextView deliveryFeeTextView;
    public final AutocompletetextviewLayoutBinding documentTypeLayout;
    public final EdittextLayoutBinding emailLayout;
    public final Guideline guideline2;
    public final ScrollView newApplicationScrollView;
    public final AutocompletetextviewLayoutBinding phoneNumberOperatorLayout;
    public final TextInputEditText phoneNumberTextInputEditText;
    public final RecyclerView priorityProcessingRecyclerView;
    private final ConstraintLayout rootView;
    public final ButtonLayoutBinding startApplicationButtonLayout;
    public final TextView totalFeeTextView;
    public final TextView totalHeadingTextView;
    public final TextView tvDurationNoteHeading;
    public final TextView tvPriorityHeading;
    public final ChipGroup valueAddedServiceChipGroup;
    public final AutocompletetextviewLayoutBinding valueAddedServicesLayout;
    public final ButtonLayoutBinding verifyApplicantFingerprintButtonLayout;

    private NewApplicationFragmentBinding(ConstraintLayout constraintLayout, MaskedEdittextLayoutBinding maskedEdittextLayoutBinding, ConstraintLayout constraintLayout2, UpdatedStepActionLayoutBinding updatedStepActionLayoutBinding, TextView textView, TextView textView2, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding, MaterialCardView materialCardView, View view, TextView textView3, UpdatedStepActionLayoutBinding updatedStepActionLayoutBinding2, TextInputLayout textInputLayout, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding2, UpdatedHeaderLayoutBinding updatedHeaderLayoutBinding, TextView textView4, TextView textView5, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding3, EdittextLayoutBinding edittextLayoutBinding, Guideline guideline, ScrollView scrollView, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding4, TextInputEditText textInputEditText, RecyclerView recyclerView, ButtonLayoutBinding buttonLayoutBinding, TextView textView6, TextView textView7, TextView textView8, TextView textView9, ChipGroup chipGroup, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding5, ButtonLayoutBinding buttonLayoutBinding2) {
        this.rootView = constraintLayout;
        this.applicantCnicLayout = maskedEdittextLayoutBinding;
        this.applicantDetailLayout = constraintLayout2;
        this.applicationDetailHeadingLayout = updatedStepActionLayoutBinding;
        this.applicationFeeHeadingTextView = textView;
        this.applicationFeeTextView = textView2;
        this.applicationTypeLayout = autocompletetextviewLayoutBinding;
        this.categoryFeeCardView = materialCardView;
        this.categoryLineView = view;
        this.categoryTypeTextView = textView3;
        this.contactDetailHeadingLayout = updatedStepActionLayoutBinding2;
        this.contactNumberLayout = textInputLayout;
        this.countryResidentLayout = autocompletetextviewLayoutBinding2;
        this.crcHeaderLayout = updatedHeaderLayoutBinding;
        this.deliveryFeeHeadingTextView = textView4;
        this.deliveryFeeTextView = textView5;
        this.documentTypeLayout = autocompletetextviewLayoutBinding3;
        this.emailLayout = edittextLayoutBinding;
        this.guideline2 = guideline;
        this.newApplicationScrollView = scrollView;
        this.phoneNumberOperatorLayout = autocompletetextviewLayoutBinding4;
        this.phoneNumberTextInputEditText = textInputEditText;
        this.priorityProcessingRecyclerView = recyclerView;
        this.startApplicationButtonLayout = buttonLayoutBinding;
        this.totalFeeTextView = textView6;
        this.totalHeadingTextView = textView7;
        this.tvDurationNoteHeading = textView8;
        this.tvPriorityHeading = textView9;
        this.valueAddedServiceChipGroup = chipGroup;
        this.valueAddedServicesLayout = autocompletetextviewLayoutBinding5;
        this.verifyApplicantFingerprintButtonLayout = buttonLayoutBinding2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static NewApplicationFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static NewApplicationFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.new_application_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static NewApplicationFragmentBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        View viewFindChildViewById4;
        View viewFindChildViewById5;
        View viewFindChildViewById6;
        View viewFindChildViewById7;
        View viewFindChildViewById8;
        View viewFindChildViewById9;
        int i = R.id.applicant_cnic_layout;
        View viewFindChildViewById10 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById10 != null) {
            MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById10);
            i = R.id.applicant_detail_layout;
            ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(view, i);
            if (constraintLayout != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.application_detail_heading_layout))) != null) {
                UpdatedStepActionLayoutBinding updatedStepActionLayoutBindingBind = UpdatedStepActionLayoutBinding.bind(viewFindChildViewById);
                i = R.id.application_fee_heading_textView;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    i = R.id.application_fee_textView;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView2 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.application_type_layout))) != null) {
                        AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById2);
                        i = R.id.category_fee_cardView;
                        MaterialCardView materialCardView = (MaterialCardView) ViewBindings.findChildViewById(view, i);
                        if (materialCardView != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(view, (i = R.id.category_line_view))) != null) {
                            i = R.id.category_type_textView;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView3 != null && (viewFindChildViewById4 = ViewBindings.findChildViewById(view, (i = R.id.contact_detail_heading_layout))) != null) {
                                UpdatedStepActionLayoutBinding updatedStepActionLayoutBindingBind2 = UpdatedStepActionLayoutBinding.bind(viewFindChildViewById4);
                                i = R.id.contact_number_layout;
                                TextInputLayout textInputLayout = (TextInputLayout) ViewBindings.findChildViewById(view, i);
                                if (textInputLayout != null && (viewFindChildViewById5 = ViewBindings.findChildViewById(view, (i = R.id.country_resident_layout))) != null) {
                                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind2 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById5);
                                    i = R.id.crc_header_layout;
                                    View viewFindChildViewById11 = ViewBindings.findChildViewById(view, i);
                                    if (viewFindChildViewById11 != null) {
                                        UpdatedHeaderLayoutBinding updatedHeaderLayoutBindingBind = UpdatedHeaderLayoutBinding.bind(viewFindChildViewById11);
                                        i = R.id.delivery_fee_heading_textView;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                                        if (textView4 != null) {
                                            i = R.id.delivery_fee_textView;
                                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                            if (textView5 != null && (viewFindChildViewById6 = ViewBindings.findChildViewById(view, (i = R.id.document_type_layout))) != null) {
                                                AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind3 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById6);
                                                i = R.id.email_layout;
                                                View viewFindChildViewById12 = ViewBindings.findChildViewById(view, i);
                                                if (viewFindChildViewById12 != null) {
                                                    EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById12);
                                                    i = R.id.guideline2;
                                                    Guideline guideline = (Guideline) ViewBindings.findChildViewById(view, i);
                                                    if (guideline != null) {
                                                        i = R.id.new_application_scrollView;
                                                        ScrollView scrollView = (ScrollView) ViewBindings.findChildViewById(view, i);
                                                        if (scrollView != null && (viewFindChildViewById7 = ViewBindings.findChildViewById(view, (i = R.id.phone_number_operator_layout))) != null) {
                                                            AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind4 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById7);
                                                            i = R.id.phone_number_textInputEditText;
                                                            TextInputEditText textInputEditText = (TextInputEditText) ViewBindings.findChildViewById(view, i);
                                                            if (textInputEditText != null) {
                                                                i = R.id.priority_processing_recyclerView;
                                                                RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
                                                                if (recyclerView != null && (viewFindChildViewById8 = ViewBindings.findChildViewById(view, (i = R.id.start_application_button_layout))) != null) {
                                                                    ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById8);
                                                                    i = R.id.total_fee_textView;
                                                                    TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                    if (textView6 != null) {
                                                                        i = R.id.total_heading_textView;
                                                                        TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                        if (textView7 != null) {
                                                                            i = R.id.tv_duration_note_heading;
                                                                            TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                            if (textView8 != null) {
                                                                                i = R.id.tv_priority_heading;
                                                                                TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                if (textView9 != null) {
                                                                                    i = R.id.value_added_service__chipGroup;
                                                                                    ChipGroup chipGroup = (ChipGroup) ViewBindings.findChildViewById(view, i);
                                                                                    if (chipGroup != null && (viewFindChildViewById9 = ViewBindings.findChildViewById(view, (i = R.id.value_added_services_layout))) != null) {
                                                                                        AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind5 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById9);
                                                                                        i = R.id.verify_applicant_fingerprint_button_layout;
                                                                                        View viewFindChildViewById13 = ViewBindings.findChildViewById(view, i);
                                                                                        if (viewFindChildViewById13 != null) {
                                                                                            return new NewApplicationFragmentBinding((ConstraintLayout) view, maskedEdittextLayoutBindingBind, constraintLayout, updatedStepActionLayoutBindingBind, textView, textView2, autocompletetextviewLayoutBindingBind, materialCardView, viewFindChildViewById3, textView3, updatedStepActionLayoutBindingBind2, textInputLayout, autocompletetextviewLayoutBindingBind2, updatedHeaderLayoutBindingBind, textView4, textView5, autocompletetextviewLayoutBindingBind3, edittextLayoutBindingBind, guideline, scrollView, autocompletetextviewLayoutBindingBind4, textInputEditText, recyclerView, buttonLayoutBindingBind, textView6, textView7, textView8, textView9, chipGroup, autocompletetextviewLayoutBindingBind5, ButtonLayoutBinding.bind(viewFindChildViewById13));
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}