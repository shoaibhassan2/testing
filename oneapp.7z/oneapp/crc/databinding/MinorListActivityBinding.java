package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.HeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepTitleLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class MinorListActivityBinding implements ViewBinding {
    public final HeaderLayoutBinding crcHeaderLayout;
    public final ImageView ivTakePhoto;
    public final RecyclerView minorsRecyclerView;
    private final ConstraintLayout rootView;
    public final StepTitleLayoutBinding stepTitleHeadingLayout;
    public final TextView tvTapToAddNew;
    public final ConstraintLayout tvTapToAddNewConstLayout;

    private MinorListActivityBinding(ConstraintLayout constraintLayout, HeaderLayoutBinding headerLayoutBinding, ImageView imageView, RecyclerView recyclerView, StepTitleLayoutBinding stepTitleLayoutBinding, TextView textView, ConstraintLayout constraintLayout2) {
        this.rootView = constraintLayout;
        this.crcHeaderLayout = headerLayoutBinding;
        this.ivTakePhoto = imageView;
        this.minorsRecyclerView = recyclerView;
        this.stepTitleHeadingLayout = stepTitleLayoutBinding;
        this.tvTapToAddNew = textView;
        this.tvTapToAddNewConstLayout = constraintLayout2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static MinorListActivityBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static MinorListActivityBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.minor_list_activity, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static MinorListActivityBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.crc_header_layout;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById2 != null) {
            HeaderLayoutBinding headerLayoutBindingBind = HeaderLayoutBinding.bind(viewFindChildViewById2);
            i = R.id.iv_take_photo;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
            if (imageView != null) {
                i = R.id.minors_recyclerView;
                RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
                if (recyclerView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.step_title_heading_layout))) != null) {
                    StepTitleLayoutBinding stepTitleLayoutBindingBind = StepTitleLayoutBinding.bind(viewFindChildViewById);
                    i = R.id.tv_tap_to_add_new;
                    TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView != null) {
                        i = R.id.tv_tap_to_add_new_const_layout;
                        ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(view, i);
                        if (constraintLayout != null) {
                            return new MinorListActivityBinding((ConstraintLayout) view, headerLayoutBindingBind, imageView, recyclerView, stepTitleLayoutBindingBind, textView, constraintLayout);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}