package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.FooterLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.HeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.RadioGroupLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepTitleLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class ActivityChildDetailBinding implements ViewBinding {
    public final EdittextLayoutBinding birthCertificateNumberLayout;
    public final AutocompletetextviewLayoutBinding birthCountryDistrictLayout;
    public final AutocompletetextviewLayoutBinding certificateTypeLayout;
    public final MaskedEdittextLayoutBinding cnicLayout;
    public final RadioGroupLayoutBinding countryDistrictRadioGroup;
    public final FooterLayoutBinding crcFooterLayout;
    public final HeaderLayoutBinding crcHeaderLayout;
    public final StepActionLayoutBinding crcStepAction;
    public final EdittextLayoutBinding dateOfBirthLayout;
    public final EdittextLayoutBinding fullNameLayout;
    public final AutocompletetextviewLayoutBinding genderLayout;
    public final AutocompletetextviewLayoutBinding orphanHouseNameLayout;
    public final AutocompletetextviewLayoutBinding relationApplicantLayout;
    private final ConstraintLayout rootView;
    public final StepTitleLayoutBinding stepTitleHeadingLayout;
    public final AutocompletetextviewLayoutBinding twinLayout;
    public final EdittextLayoutBinding urduFullNameLayout;

    private ActivityChildDetailBinding(ConstraintLayout constraintLayout, EdittextLayoutBinding edittextLayoutBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding2, MaskedEdittextLayoutBinding maskedEdittextLayoutBinding, RadioGroupLayoutBinding radioGroupLayoutBinding, FooterLayoutBinding footerLayoutBinding, HeaderLayoutBinding headerLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding, EdittextLayoutBinding edittextLayoutBinding2, EdittextLayoutBinding edittextLayoutBinding3, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding3, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding4, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding5, StepTitleLayoutBinding stepTitleLayoutBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding6, EdittextLayoutBinding edittextLayoutBinding4) {
        this.rootView = constraintLayout;
        this.birthCertificateNumberLayout = edittextLayoutBinding;
        this.birthCountryDistrictLayout = autocompletetextviewLayoutBinding;
        this.certificateTypeLayout = autocompletetextviewLayoutBinding2;
        this.cnicLayout = maskedEdittextLayoutBinding;
        this.countryDistrictRadioGroup = radioGroupLayoutBinding;
        this.crcFooterLayout = footerLayoutBinding;
        this.crcHeaderLayout = headerLayoutBinding;
        this.crcStepAction = stepActionLayoutBinding;
        this.dateOfBirthLayout = edittextLayoutBinding2;
        this.fullNameLayout = edittextLayoutBinding3;
        this.genderLayout = autocompletetextviewLayoutBinding3;
        this.orphanHouseNameLayout = autocompletetextviewLayoutBinding4;
        this.relationApplicantLayout = autocompletetextviewLayoutBinding5;
        this.stepTitleHeadingLayout = stepTitleLayoutBinding;
        this.twinLayout = autocompletetextviewLayoutBinding6;
        this.urduFullNameLayout = edittextLayoutBinding4;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivityChildDetailBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivityChildDetailBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_child_detail, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivityChildDetailBinding bind(View view) {
        int i = R.id.birth_certificate_number_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById);
            i = R.id.birth_country_district_layout;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById2 != null) {
                AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById2);
                i = R.id.certificate_type_layout;
                View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById3 != null) {
                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind2 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById3);
                    i = R.id.cnic_layout;
                    View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                    if (viewFindChildViewById4 != null) {
                        MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById4);
                        i = R.id.country_district_radio_group;
                        View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                        if (viewFindChildViewById5 != null) {
                            RadioGroupLayoutBinding radioGroupLayoutBindingBind = RadioGroupLayoutBinding.bind(viewFindChildViewById5);
                            i = R.id.crc_footer_layout;
                            View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                            if (viewFindChildViewById6 != null) {
                                FooterLayoutBinding footerLayoutBindingBind = FooterLayoutBinding.bind(viewFindChildViewById6);
                                i = R.id.crc_header_layout;
                                View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                                if (viewFindChildViewById7 != null) {
                                    HeaderLayoutBinding headerLayoutBindingBind = HeaderLayoutBinding.bind(viewFindChildViewById7);
                                    i = R.id.crc_step_action;
                                    View viewFindChildViewById8 = ViewBindings.findChildViewById(view, i);
                                    if (viewFindChildViewById8 != null) {
                                        StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById8);
                                        i = R.id.date_of_birth_layout;
                                        View viewFindChildViewById9 = ViewBindings.findChildViewById(view, i);
                                        if (viewFindChildViewById9 != null) {
                                            EdittextLayoutBinding edittextLayoutBindingBind2 = EdittextLayoutBinding.bind(viewFindChildViewById9);
                                            i = R.id.full_name_layout;
                                            View viewFindChildViewById10 = ViewBindings.findChildViewById(view, i);
                                            if (viewFindChildViewById10 != null) {
                                                EdittextLayoutBinding edittextLayoutBindingBind3 = EdittextLayoutBinding.bind(viewFindChildViewById10);
                                                i = R.id.gender_layout;
                                                View viewFindChildViewById11 = ViewBindings.findChildViewById(view, i);
                                                if (viewFindChildViewById11 != null) {
                                                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind3 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById11);
                                                    i = R.id.orphan_house_name_layout;
                                                    View viewFindChildViewById12 = ViewBindings.findChildViewById(view, i);
                                                    if (viewFindChildViewById12 != null) {
                                                        AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind4 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById12);
                                                        i = R.id.relation_applicant_layout;
                                                        View viewFindChildViewById13 = ViewBindings.findChildViewById(view, i);
                                                        if (viewFindChildViewById13 != null) {
                                                            AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind5 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById13);
                                                            i = R.id.step_title_heading_layout;
                                                            View viewFindChildViewById14 = ViewBindings.findChildViewById(view, i);
                                                            if (viewFindChildViewById14 != null) {
                                                                StepTitleLayoutBinding stepTitleLayoutBindingBind = StepTitleLayoutBinding.bind(viewFindChildViewById14);
                                                                i = R.id.twin_layout;
                                                                View viewFindChildViewById15 = ViewBindings.findChildViewById(view, i);
                                                                if (viewFindChildViewById15 != null) {
                                                                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind6 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById15);
                                                                    i = R.id.urdu_full_name_layout;
                                                                    View viewFindChildViewById16 = ViewBindings.findChildViewById(view, i);
                                                                    if (viewFindChildViewById16 != null) {
                                                                        return new ActivityChildDetailBinding((ConstraintLayout) view, edittextLayoutBindingBind, autocompletetextviewLayoutBindingBind, autocompletetextviewLayoutBindingBind2, maskedEdittextLayoutBindingBind, radioGroupLayoutBindingBind, footerLayoutBindingBind, headerLayoutBindingBind, stepActionLayoutBindingBind, edittextLayoutBindingBind2, edittextLayoutBindingBind3, autocompletetextviewLayoutBindingBind3, autocompletetextviewLayoutBindingBind4, autocompletetextviewLayoutBindingBind5, stepTitleLayoutBindingBind, autocompletetextviewLayoutBindingBind6, EdittextLayoutBinding.bind(viewFindChildViewById16));
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}