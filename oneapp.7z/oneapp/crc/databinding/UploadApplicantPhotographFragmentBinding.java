package pk.gov.nadra.oneapp.crc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.CheckboxLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ImageUploadLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.TextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedFooterWithBackNextBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepTitleLayoutBinding;
import pk.gov.nadra.oneapp.crc.R;

/* loaded from: classes5.dex */
public final class UploadApplicantPhotographFragmentBinding implements ViewBinding {
    public final ButtonLayoutBinding captureButtonLayout;
    public final UpdatedFooterWithBackNextBinding crcFooterLayout;
    public final UpdatedHeaderLayoutBinding crcHeaderLayout;
    public final CheckboxLayoutBinding crcSkipCheckbox;
    public final StepActionLayoutBinding crcStepAction;
    public final ImageUploadLayoutBinding crcTakePhoto;
    public final TextviewLayoutBinding crcTakePhotoInstruction;
    private final ConstraintLayout rootView;
    public final UpdatedStepTitleLayoutBinding stepTitleHeadingLayout;
    public final ButtonLayoutBinding uploadButtonLayout;

    private UploadApplicantPhotographFragmentBinding(ConstraintLayout constraintLayout, ButtonLayoutBinding buttonLayoutBinding, UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBinding, UpdatedHeaderLayoutBinding updatedHeaderLayoutBinding, CheckboxLayoutBinding checkboxLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding, ImageUploadLayoutBinding imageUploadLayoutBinding, TextviewLayoutBinding textviewLayoutBinding, UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBinding, ButtonLayoutBinding buttonLayoutBinding2) {
        this.rootView = constraintLayout;
        this.captureButtonLayout = buttonLayoutBinding;
        this.crcFooterLayout = updatedFooterWithBackNextBinding;
        this.crcHeaderLayout = updatedHeaderLayoutBinding;
        this.crcSkipCheckbox = checkboxLayoutBinding;
        this.crcStepAction = stepActionLayoutBinding;
        this.crcTakePhoto = imageUploadLayoutBinding;
        this.crcTakePhotoInstruction = textviewLayoutBinding;
        this.stepTitleHeadingLayout = updatedStepTitleLayoutBinding;
        this.uploadButtonLayout = buttonLayoutBinding2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static UploadApplicantPhotographFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static UploadApplicantPhotographFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.upload_applicant_photograph_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static UploadApplicantPhotographFragmentBinding bind(View view) {
        int i = R.id.capture_button_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById);
            i = R.id.crc_footer_layout;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById2 != null) {
                UpdatedFooterWithBackNextBinding updatedFooterWithBackNextBindingBind = UpdatedFooterWithBackNextBinding.bind(viewFindChildViewById2);
                i = R.id.crc_header_layout;
                View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById3 != null) {
                    UpdatedHeaderLayoutBinding updatedHeaderLayoutBindingBind = UpdatedHeaderLayoutBinding.bind(viewFindChildViewById3);
                    i = R.id.crc_skip_checkbox;
                    View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                    if (viewFindChildViewById4 != null) {
                        CheckboxLayoutBinding checkboxLayoutBindingBind = CheckboxLayoutBinding.bind(viewFindChildViewById4);
                        i = R.id.crc_step_action;
                        View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                        if (viewFindChildViewById5 != null) {
                            StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById5);
                            i = R.id.crc_take_photo;
                            View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                            if (viewFindChildViewById6 != null) {
                                ImageUploadLayoutBinding imageUploadLayoutBindingBind = ImageUploadLayoutBinding.bind(viewFindChildViewById6);
                                i = R.id.crc_take_photo_instruction;
                                View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                                if (viewFindChildViewById7 != null) {
                                    TextviewLayoutBinding textviewLayoutBindingBind = TextviewLayoutBinding.bind(viewFindChildViewById7);
                                    i = R.id.step_title_heading_layout;
                                    View viewFindChildViewById8 = ViewBindings.findChildViewById(view, i);
                                    if (viewFindChildViewById8 != null) {
                                        UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBindingBind = UpdatedStepTitleLayoutBinding.bind(viewFindChildViewById8);
                                        i = R.id.upload_button_layout;
                                        View viewFindChildViewById9 = ViewBindings.findChildViewById(view, i);
                                        if (viewFindChildViewById9 != null) {
                                            return new UploadApplicantPhotographFragmentBinding((ConstraintLayout) view, buttonLayoutBindingBind, updatedFooterWithBackNextBindingBind, updatedHeaderLayoutBindingBind, checkboxLayoutBindingBind, stepActionLayoutBindingBind, imageUploadLayoutBindingBind, textviewLayoutBindingBind, updatedStepTitleLayoutBindingBind, ButtonLayoutBinding.bind(viewFindChildViewById9));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}