package pk.gov.nadra.oneapp.crc.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.databinding.MinorListItemBinding;
import pk.gov.nadra.oneapp.models.crc.minor.MinorDataResponse;

/* compiled from: MinorListAdapter.kt */
@Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\b\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001\u0019B7\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u0012\u0018\u0010\b\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u000b0\t¢\u0006\u0004\b\f\u0010\rJ\u001c\u0010\u000e\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012H\u0016J\u0014\u0010\u0013\u001a\u00020\u000b2\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006J\u001c\u0010\u0015\u001a\u00020\u000b2\n\u0010\u0016\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u0012H\u0016J\b\u0010\u0018\u001a\u00020\u0012H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\b\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u000b0\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001a"}, d2 = {"Lpk/gov/nadra/oneapp/crc/adapter/MinorListAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lpk/gov/nadra/oneapp/crc/adapter/MinorListAdapter$ViewHolder;", "context", "Landroid/content/Context;", "minorList", "", "Lpk/gov/nadra/oneapp/models/crc/minor/MinorDataResponse;", "onActionSelected", "Lkotlin/Function2;", "Lpk/gov/nadra/oneapp/crc/adapter/ActionType;", "", "<init>", "(Landroid/content/Context;Ljava/util/List;Lkotlin/jvm/functions/Function2;)V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "updateMinorList", "listItems", "onBindViewHolder", "holder", "position", "getItemCount", "ViewHolder", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class MinorListAdapter extends RecyclerView.Adapter<ViewHolder> {
    private final Context context;
    private List<MinorDataResponse> minorList;
    private final Function2<ActionType, MinorDataResponse, Unit> onActionSelected;

    /* JADX WARN: Multi-variable type inference failed */
    public MinorListAdapter(Context context, List<MinorDataResponse> minorList, Function2<? super ActionType, ? super MinorDataResponse, Unit> onActionSelected) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(minorList, "minorList");
        Intrinsics.checkNotNullParameter(onActionSelected, "onActionSelected");
        this.context = context;
        this.minorList = minorList;
        this.onActionSelected = onActionSelected;
    }

    /* compiled from: MinorListAdapter.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lpk/gov/nadra/oneapp/crc/adapter/MinorListAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lpk/gov/nadra/oneapp/crc/databinding/MinorListItemBinding;", "<init>", "(Lpk/gov/nadra/oneapp/crc/adapter/MinorListAdapter;Lpk/gov/nadra/oneapp/crc/databinding/MinorListItemBinding;)V", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/MinorListItemBinding;", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public final class ViewHolder extends RecyclerView.ViewHolder {
        private final MinorListItemBinding binding;
        final /* synthetic */ MinorListAdapter this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ViewHolder(MinorListAdapter minorListAdapter, MinorListItemBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.this$0 = minorListAdapter;
            this.binding = binding;
        }

        public final MinorListItemBinding getBinding() {
            return this.binding;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        MinorListItemBinding minorListItemBindingInflate = MinorListItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(minorListItemBindingInflate, "inflate(...)");
        return new ViewHolder(this, minorListItemBindingInflate);
    }

    public final void updateMinorList(List<MinorDataResponse> listItems) {
        Intrinsics.checkNotNullParameter(listItems, "listItems");
        this.minorList = listItems;
        notifyDataSetChanged();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder holder, final int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        MinorDataResponse minorDataResponse = this.minorList.get(position);
        MinorListItemBinding binding = holder.getBinding();
        binding.listItemCertificateNumber.setText("Certificate No. " + minorDataResponse.getBirthCertificateNumber());
        String citizenNumber = minorDataResponse.getCitizenNumber();
        if (citizenNumber == null || citizenNumber.length() == 0) {
            binding.listItemCitizenNumber.setText("Citizen No. Not Available");
        } else if (minorDataResponse.getCitizenNumber().length() == 13) {
            binding.listItemCitizenNumber.setText("Citizen No. " + Util.INSTANCE.addCharAtIndex(Util.INSTANCE.addCharAtIndex(minorDataResponse.getCitizenNumber(), '-', 5), '-', 13));
        } else {
            binding.listItemCitizenNumber.setVisibility(8);
        }
        binding.listItemMinorName.setText(String.valueOf(Util.INSTANCE.capitalizeWords(minorDataResponse.getFullName())));
        binding.minorListSourceTextView.setText(String.valueOf(minorDataResponse.getSource()));
        if (Intrinsics.areEqual(minorDataResponse.getStatus(), "PENDING")) {
            binding.listItemStatusIconImageView.setImageResource(R.drawable.ic_pending);
        } else {
            binding.listItemStatusIconImageView.setImageResource(R.drawable.selected_green);
        }
        String lowerCase = minorDataResponse.getSource().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        if (Intrinsics.areEqual(lowerCase, "nadra")) {
            binding.listItemCrossIconImageView.setVisibility(4);
            binding.minorListSourceTextView.setBackground(this.context.getResources().getDrawable(R.drawable.bg_green_source_textview));
        } else {
            binding.listItemCrossIconImageView.setVisibility(0);
            binding.listItemTapToEdit.setVisibility(0);
            binding.listItemEditIconImageView.setVisibility(0);
            binding.minorListSourceTextView.setBackground(this.context.getResources().getDrawable(R.drawable.bg_source_textview));
        }
        TextView textView = binding.listItemTapToEdit;
        Util util = Util.INSTANCE;
        Context context = this.context;
        String string = context.getString(R.string.tap_to_edit);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util, context, string, " (ایڈٹ کرنے کے لئے ٹیپ کریں)", com.intuit.sdp.R.dimen._10sdp, false, 8, null));
        binding.listItemTapToEdit.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.adapter.MinorListAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MinorListAdapter.onBindViewHolder$lambda$4$lambda$3$lambda$2$lambda$0(this.f$0, position, view);
            }
        });
        binding.listItemCrossIconImageView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.adapter.MinorListAdapter$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MinorListAdapter.onBindViewHolder$lambda$4$lambda$3$lambda$2$lambda$1(this.f$0, position, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$4$lambda$3$lambda$2$lambda$0(MinorListAdapter this$0, int i, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.onActionSelected.invoke(ActionType.EDIT, this$0.minorList.get(i));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$4$lambda$3$lambda$2$lambda$1(MinorListAdapter this$0, int i, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.onActionSelected.invoke(ActionType.CANCEL, this$0.minorList.get(i));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.minorList.size();
    }
}