package pk.gov.nadra.oneapp.crc.adapter;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: SpouseListAdapter.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004¨\u0006\u0005"}, d2 = {"Lpk/gov/nadra/oneapp/crc/adapter/SpouseVerifyAction;", "", "<init>", "(Ljava/lang/String;I)V", "VERIFY", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class SpouseVerifyAction {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ SpouseVerifyAction[] $VALUES;
    public static final SpouseVerifyAction VERIFY = new SpouseVerifyAction("VERIFY", 0);

    private static final /* synthetic */ SpouseVerifyAction[] $values() {
        return new SpouseVerifyAction[]{VERIFY};
    }

    public static EnumEntries<SpouseVerifyAction> getEntries() {
        return $ENTRIES;
    }

    private SpouseVerifyAction(String str, int i) {
    }

    static {
        SpouseVerifyAction[] spouseVerifyActionArr$values = $values();
        $VALUES = spouseVerifyActionArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(spouseVerifyActionArr$values);
    }

    public static SpouseVerifyAction valueOf(String str) {
        return (SpouseVerifyAction) Enum.valueOf(SpouseVerifyAction.class, str);
    }

    public static SpouseVerifyAction[] values() {
        return (SpouseVerifyAction[]) $VALUES.clone();
    }
}