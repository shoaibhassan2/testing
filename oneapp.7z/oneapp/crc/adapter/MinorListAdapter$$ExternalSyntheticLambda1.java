package pk.gov.nadra.oneapp.crc.adapter;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class MinorListAdapter$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public final /* synthetic */ int f$1;

    public /* synthetic */ MinorListAdapter$$ExternalSyntheticLambda1(int i) {
        position = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MinorListAdapter.onBindViewHolder$lambda$4$lambda$3$lambda$2$lambda$1(this.f$0, position, view);
    }
}