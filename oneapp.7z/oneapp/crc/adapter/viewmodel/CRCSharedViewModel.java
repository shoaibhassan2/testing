package pk.gov.nadra.oneapp.crc.adapter.viewmodel;

import androidx.lifecycle.ViewModel;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.models.crc.CrcTabsResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.models.crc.TrackingIDDataUpdationResponse;
import pk.gov.nadra.oneapp.models.crc.UpdateChildResponse;
import pk.gov.nadra.oneapp.models.crc.minor.ChildDataResponse;
import pk.gov.nadra.oneapp.models.crc.minor.MinorDataResponse;

/* compiled from: CRCSharedViewModel.kt */
@Metadata(d1 = {"\u0000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0010\t\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u001d\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010e\u001a\b\u0012\u0004\u0012\u00020f0\\R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001a\u0010\n\u001a\u00020\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0010\u001a\u00020\u0011X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u001a\u0010\u0016\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001bR\u001a\u0010\u001c\u001a\u00020\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R\u001a\u0010\"\u001a\u00020\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b#\u0010\u001f\"\u0004\b$\u0010!R\u001a\u0010%\u001a\u00020&X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b'\u0010(\"\u0004\b)\u0010*R\u001a\u0010+\u001a\u00020\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b,\u0010\u001f\"\u0004\b-\u0010!R\u001a\u0010.\u001a\u00020/X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b0\u00101\"\u0004\b2\u00103R\u001a\u00104\u001a\u00020\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b5\u0010\u001f\"\u0004\b6\u0010!R\u001a\u00107\u001a\u000208X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b9\u0010:\"\u0004\b;\u0010<R\u001a\u0010=\u001a\u00020>X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b?\u0010@\"\u0004\bA\u0010BR\u001a\u0010C\u001a\u00020\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bD\u0010\u001f\"\u0004\bE\u0010!R\u001a\u0010F\u001a\u00020\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bG\u0010\u001f\"\u0004\bH\u0010!R\u001a\u0010I\u001a\u00020\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bJ\u0010\u001f\"\u0004\bK\u0010!R\u001a\u0010L\u001a\u00020/X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bM\u00101\"\u0004\bN\u00103R\u001a\u0010O\u001a\u00020/X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bP\u00101\"\u0004\bQ\u00103R\u001a\u0010R\u001a\u00020/X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bS\u00101\"\u0004\bT\u00103R\u001a\u0010U\u001a\u00020\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bV\u0010\u001f\"\u0004\bW\u0010!R\u001a\u0010X\u001a\u00020\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bY\u0010\u001f\"\u0004\bZ\u0010!R \u0010[\u001a\b\u0012\u0004\u0012\u00020]0\\X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b^\u0010_\"\u0004\b`\u0010aR\u001a\u0010b\u001a\u00020/X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bc\u00101\"\u0004\bd\u00103¨\u0006g"}, d2 = {"Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "Landroidx/lifecycle/ViewModel;", "<init>", "()V", "reactNativeData", "Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "getReactNativeData", "()Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "setReactNativeData", "(Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;)V", "startApplicationResponse", "Lpk/gov/nadra/oneapp/models/crc/TrackingIDDataUpdationResponse;", "getStartApplicationResponse", "()Lpk/gov/nadra/oneapp/models/crc/TrackingIDDataUpdationResponse;", "setStartApplicationResponse", "(Lpk/gov/nadra/oneapp/models/crc/TrackingIDDataUpdationResponse;)V", "childDataResponse", "Lpk/gov/nadra/oneapp/models/crc/minor/ChildDataResponse;", "getChildDataResponse", "()Lpk/gov/nadra/oneapp/models/crc/minor/ChildDataResponse;", "setChildDataResponse", "(Lpk/gov/nadra/oneapp/models/crc/minor/ChildDataResponse;)V", "childDetails", "Lpk/gov/nadra/oneapp/models/crc/minor/MinorDataResponse;", "getChildDetails", "()Lpk/gov/nadra/oneapp/models/crc/minor/MinorDataResponse;", "setChildDetails", "(Lpk/gov/nadra/oneapp/models/crc/minor/MinorDataResponse;)V", "trackingId", "", "getTrackingId", "()Ljava/lang/String;", "setTrackingId", "(Ljava/lang/String;)V", "amount", "getAmount", "setAmount", "childId", "", "getChildId", "()J", "setChildId", "(J)V", "applicantPhotoPath", "getApplicantPhotoPath", "setApplicantPhotoPath", "applicantPhotoSkip", "", "getApplicantPhotoSkip", "()Z", "setApplicantPhotoSkip", "(Z)V", "applicantSignaturePath", "getApplicantSignaturePath", "setApplicantSignaturePath", "errorResponse", "Lpk/gov/nadra/oneapp/models/crc/ErrorResponse;", "getErrorResponse", "()Lpk/gov/nadra/oneapp/models/crc/ErrorResponse;", "setErrorResponse", "(Lpk/gov/nadra/oneapp/models/crc/ErrorResponse;)V", "childResponse", "Lpk/gov/nadra/oneapp/models/crc/UpdateChildResponse;", "getChildResponse", "()Lpk/gov/nadra/oneapp/models/crc/UpdateChildResponse;", "setChildResponse", "(Lpk/gov/nadra/oneapp/models/crc/UpdateChildResponse;)V", "childPhotoPath", "getChildPhotoPath", "setChildPhotoPath", "documentType", "getDocumentType", "setDocumentType", "applicationType", "getApplicationType", "setApplicationType", "attestationP", "getAttestationP", "setAttestationP", "uploadDocumentP", "getUploadDocumentP", "setUploadDocumentP", "dataEntryP", "getDataEntryP", "setDataEntryP", "documentTypeValue", "getDocumentTypeValue", "setDocumentTypeValue", "applicationTypeValue", "getApplicationTypeValue", "setApplicationTypeValue", "crcTabsList", "", "Lpk/gov/nadra/oneapp/models/crc/CrcTabsResponse;", "getCrcTabsList", "()Ljava/util/List;", "setCrcTabsList", "(Ljava/util/List;)V", "livelinessControl", "getLivelinessControl", "setLivelinessControl", "getErrorsForField", "Lpk/gov/nadra/oneapp/models/crc/ErrorResponse$Error;", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class CRCSharedViewModel extends ViewModel {
    private boolean applicantPhotoSkip;
    private long childId;
    private ReactNativeData reactNativeData = new ReactNativeData(null, null, null, null, null, null, null, false, false, false, null, null, false, null, null, null, false, null, false, false, false, false, null, null, false, false, false, null, false, false, null, null, null, false, null, null, null, false, false, null, null, null, null, false, null, null, null, null, null, null, -1, 262143, null);
    private TrackingIDDataUpdationResponse startApplicationResponse = new TrackingIDDataUpdationResponse(null, null, null, null, null, 31, null);
    private ChildDataResponse childDataResponse = new ChildDataResponse(null, null, null, null, false, false, null, false, 255, null);
    private MinorDataResponse childDetails = new MinorDataResponse(null, null, null, null, null, null, null, null, null, null, 0, null, null, null, null, null, null, null, null, null, null, null, null, null, false, null, null, null, null, null, null, Integer.MAX_VALUE, null);
    private String trackingId = "";
    private String amount = "0";
    private String applicantPhotoPath = "";
    private String applicantSignaturePath = "";
    private ErrorResponse errorResponse = new ErrorResponse(null, null, null, null, null, null, null, null, null, null, null, null, null, null, 16383, null);
    private UpdateChildResponse childResponse = new UpdateChildResponse(0, null, false, 7, null);
    private String childPhotoPath = "";
    private String documentType = "";
    private String applicationType = "";
    private boolean attestationP = true;
    private boolean uploadDocumentP = true;
    private boolean dataEntryP = true;
    private String documentTypeValue = "";
    private String applicationTypeValue = "";
    private List<CrcTabsResponse> crcTabsList = new ArrayList();
    private boolean livelinessControl = true;

    public final ReactNativeData getReactNativeData() {
        return this.reactNativeData;
    }

    public final void setReactNativeData(ReactNativeData reactNativeData) {
        Intrinsics.checkNotNullParameter(reactNativeData, "<set-?>");
        this.reactNativeData = reactNativeData;
    }

    public final TrackingIDDataUpdationResponse getStartApplicationResponse() {
        return this.startApplicationResponse;
    }

    public final void setStartApplicationResponse(TrackingIDDataUpdationResponse trackingIDDataUpdationResponse) {
        Intrinsics.checkNotNullParameter(trackingIDDataUpdationResponse, "<set-?>");
        this.startApplicationResponse = trackingIDDataUpdationResponse;
    }

    public final ChildDataResponse getChildDataResponse() {
        return this.childDataResponse;
    }

    public final void setChildDataResponse(ChildDataResponse childDataResponse) {
        Intrinsics.checkNotNullParameter(childDataResponse, "<set-?>");
        this.childDataResponse = childDataResponse;
    }

    public final MinorDataResponse getChildDetails() {
        return this.childDetails;
    }

    public final void setChildDetails(MinorDataResponse minorDataResponse) {
        Intrinsics.checkNotNullParameter(minorDataResponse, "<set-?>");
        this.childDetails = minorDataResponse;
    }

    public final String getTrackingId() {
        return this.trackingId;
    }

    public final void setTrackingId(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.trackingId = str;
    }

    public final String getAmount() {
        return this.amount;
    }

    public final void setAmount(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.amount = str;
    }

    public final long getChildId() {
        return this.childId;
    }

    public final void setChildId(long j) {
        this.childId = j;
    }

    public final String getApplicantPhotoPath() {
        return this.applicantPhotoPath;
    }

    public final void setApplicantPhotoPath(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.applicantPhotoPath = str;
    }

    public final boolean getApplicantPhotoSkip() {
        return this.applicantPhotoSkip;
    }

    public final void setApplicantPhotoSkip(boolean z) {
        this.applicantPhotoSkip = z;
    }

    public final String getApplicantSignaturePath() {
        return this.applicantSignaturePath;
    }

    public final void setApplicantSignaturePath(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.applicantSignaturePath = str;
    }

    public final ErrorResponse getErrorResponse() {
        return this.errorResponse;
    }

    public final void setErrorResponse(ErrorResponse errorResponse) {
        Intrinsics.checkNotNullParameter(errorResponse, "<set-?>");
        this.errorResponse = errorResponse;
    }

    public final UpdateChildResponse getChildResponse() {
        return this.childResponse;
    }

    public final void setChildResponse(UpdateChildResponse updateChildResponse) {
        Intrinsics.checkNotNullParameter(updateChildResponse, "<set-?>");
        this.childResponse = updateChildResponse;
    }

    public final String getChildPhotoPath() {
        return this.childPhotoPath;
    }

    public final void setChildPhotoPath(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.childPhotoPath = str;
    }

    public final String getDocumentType() {
        return this.documentType;
    }

    public final void setDocumentType(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.documentType = str;
    }

    public final String getApplicationType() {
        return this.applicationType;
    }

    public final void setApplicationType(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.applicationType = str;
    }

    public final boolean getAttestationP() {
        return this.attestationP;
    }

    public final void setAttestationP(boolean z) {
        this.attestationP = z;
    }

    public final boolean getUploadDocumentP() {
        return this.uploadDocumentP;
    }

    public final void setUploadDocumentP(boolean z) {
        this.uploadDocumentP = z;
    }

    public final boolean getDataEntryP() {
        return this.dataEntryP;
    }

    public final void setDataEntryP(boolean z) {
        this.dataEntryP = z;
    }

    public final String getDocumentTypeValue() {
        return this.documentTypeValue;
    }

    public final void setDocumentTypeValue(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.documentTypeValue = str;
    }

    public final String getApplicationTypeValue() {
        return this.applicationTypeValue;
    }

    public final void setApplicationTypeValue(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.applicationTypeValue = str;
    }

    public final List<CrcTabsResponse> getCrcTabsList() {
        return this.crcTabsList;
    }

    public final void setCrcTabsList(List<CrcTabsResponse> list) {
        Intrinsics.checkNotNullParameter(list, "<set-?>");
        this.crcTabsList = list;
    }

    public final boolean getLivelinessControl() {
        return this.livelinessControl;
    }

    public final void setLivelinessControl(boolean z) {
        this.livelinessControl = z;
    }

    public final List<ErrorResponse.Error> getErrorsForField() {
        List<ErrorResponse.Error> errors = this.errorResponse.getErrors();
        Intrinsics.checkNotNull(errors);
        return errors;
    }
}