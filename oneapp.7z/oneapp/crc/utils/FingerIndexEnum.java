package pk.gov.nadra.oneapp.crc.utils;

import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.ranges.RangesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: FingerIndexEnum.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\b\u0010\b\u0086\u0081\u0002\u0018\u0000 \u00122\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u0012B\u0011\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011¨\u0006\u0013"}, d2 = {"Lpk/gov/nadra/oneapp/crc/utils/FingerIndexEnum;", "", "id", "", "<init>", "(Ljava/lang/String;II)V", "getId", "()I", "RIGHT_THUMB", "RIGHT_INDEX", "RIGHT_MIDDLE", "RIGHT_RING", "RIGHT_LITTLE", "LEFT_THUMB", "LEFT_INDEX", "LEFT_MIDDLE", "LEFT_RING", "LEFT_LITTLE", "Companion", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class FingerIndexEnum {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ FingerIndexEnum[] $VALUES;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE;
    private static final Map<Integer, FingerIndexEnum> map;
    private final int id;
    public static final FingerIndexEnum RIGHT_THUMB = new FingerIndexEnum("RIGHT_THUMB", 0, 1);
    public static final FingerIndexEnum RIGHT_INDEX = new FingerIndexEnum("RIGHT_INDEX", 1, 2);
    public static final FingerIndexEnum RIGHT_MIDDLE = new FingerIndexEnum("RIGHT_MIDDLE", 2, 3);
    public static final FingerIndexEnum RIGHT_RING = new FingerIndexEnum("RIGHT_RING", 3, 4);
    public static final FingerIndexEnum RIGHT_LITTLE = new FingerIndexEnum("RIGHT_LITTLE", 4, 5);
    public static final FingerIndexEnum LEFT_THUMB = new FingerIndexEnum("LEFT_THUMB", 5, 6);
    public static final FingerIndexEnum LEFT_INDEX = new FingerIndexEnum("LEFT_INDEX", 6, 7);
    public static final FingerIndexEnum LEFT_MIDDLE = new FingerIndexEnum("LEFT_MIDDLE", 7, 8);
    public static final FingerIndexEnum LEFT_RING = new FingerIndexEnum("LEFT_RING", 8, 9);
    public static final FingerIndexEnum LEFT_LITTLE = new FingerIndexEnum("LEFT_LITTLE", 9, 10);

    private static final /* synthetic */ FingerIndexEnum[] $values() {
        return new FingerIndexEnum[]{RIGHT_THUMB, RIGHT_INDEX, RIGHT_MIDDLE, RIGHT_RING, RIGHT_LITTLE, LEFT_THUMB, LEFT_INDEX, LEFT_MIDDLE, LEFT_RING, LEFT_LITTLE};
    }

    public static EnumEntries<FingerIndexEnum> getEntries() {
        return $ENTRIES;
    }

    private FingerIndexEnum(String str, int i, int i2) {
        this.id = i2;
    }

    public final int getId() {
        return this.id;
    }

    static {
        FingerIndexEnum[] fingerIndexEnumArr$values = $values();
        $VALUES = fingerIndexEnumArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(fingerIndexEnumArr$values);
        INSTANCE = new Companion(null);
        FingerIndexEnum[] fingerIndexEnumArrValues = values();
        LinkedHashMap linkedHashMap = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(fingerIndexEnumArrValues.length), 16));
        for (FingerIndexEnum fingerIndexEnum : fingerIndexEnumArrValues) {
            linkedHashMap.put(Integer.valueOf(fingerIndexEnum.id), fingerIndexEnum);
        }
        map = linkedHashMap;
    }

    /* compiled from: FingerIndexEnum.kt */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\b\u001a\u0004\u0018\u00010\u00072\u0006\u0010\t\u001a\u00020\u0006R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lpk/gov/nadra/oneapp/crc/utils/FingerIndexEnum$Companion;", "", "<init>", "()V", "map", "", "", "Lpk/gov/nadra/oneapp/crc/utils/FingerIndexEnum;", "fromId", "id", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final FingerIndexEnum fromId(int id) {
            return (FingerIndexEnum) FingerIndexEnum.map.get(Integer.valueOf(id));
        }
    }

    public static FingerIndexEnum valueOf(String str) {
        return (FingerIndexEnum) Enum.valueOf(FingerIndexEnum.class, str);
    }

    public static FingerIndexEnum[] values() {
        return (FingerIndexEnum[]) $VALUES.clone();
    }
}