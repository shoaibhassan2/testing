package pk.gov.nadra.oneapp.crc.utils;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: MethodName.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0011\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011¨\u0006\u0012"}, d2 = {"Lpk/gov/nadra/oneapp/crc/utils/MethodName;", "", "<init>", "(Ljava/lang/String;I)V", "CERTIFICATE_TYPE", "RELATION", "GENDER", "COUNTRY", "PROVINCE", "DISTRICT", "TEHSIL", "TWIN", "ORPHANAGES", "MOBILE_OPERATOR", "DISABILITY_TYPE", "APPLICATION_TYPE", "DOCUMENT_TYPE", "VALUE_ADDED_SERVICE", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class MethodName {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ MethodName[] $VALUES;
    public static final MethodName CERTIFICATE_TYPE = new MethodName("CERTIFICATE_TYPE", 0);
    public static final MethodName RELATION = new MethodName("RELATION", 1);
    public static final MethodName GENDER = new MethodName("GENDER", 2);
    public static final MethodName COUNTRY = new MethodName("COUNTRY", 3);
    public static final MethodName PROVINCE = new MethodName("PROVINCE", 4);
    public static final MethodName DISTRICT = new MethodName("DISTRICT", 5);
    public static final MethodName TEHSIL = new MethodName("TEHSIL", 6);
    public static final MethodName TWIN = new MethodName("TWIN", 7);
    public static final MethodName ORPHANAGES = new MethodName("ORPHANAGES", 8);
    public static final MethodName MOBILE_OPERATOR = new MethodName("MOBILE_OPERATOR", 9);
    public static final MethodName DISABILITY_TYPE = new MethodName("DISABILITY_TYPE", 10);
    public static final MethodName APPLICATION_TYPE = new MethodName("APPLICATION_TYPE", 11);
    public static final MethodName DOCUMENT_TYPE = new MethodName("DOCUMENT_TYPE", 12);
    public static final MethodName VALUE_ADDED_SERVICE = new MethodName("VALUE_ADDED_SERVICE", 13);

    private static final /* synthetic */ MethodName[] $values() {
        return new MethodName[]{CERTIFICATE_TYPE, RELATION, GENDER, COUNTRY, PROVINCE, DISTRICT, TEHSIL, TWIN, ORPHANAGES, MOBILE_OPERATOR, DISABILITY_TYPE, APPLICATION_TYPE, DOCUMENT_TYPE, VALUE_ADDED_SERVICE};
    }

    public static EnumEntries<MethodName> getEntries() {
        return $ENTRIES;
    }

    private MethodName(String str, int i) {
    }

    static {
        MethodName[] methodNameArr$values = $values();
        $VALUES = methodNameArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(methodNameArr$values);
    }

    public static MethodName valueOf(String str) {
        return (MethodName) Enum.valueOf(MethodName.class, str);
    }

    public static MethodName[] values() {
        return (MethodName[]) $VALUES.clone();
    }
}