package pk.gov.nadra.oneapp.crc;

/* loaded from: classes5.dex */
public final class R {

    public static final class color {
        public static int chip_background = 0x7f060047;

        private color() {
        }
    }

    public static final class drawable {
        public static int ic_close_circle = 0x7f0803cc;

        private drawable() {
        }
    }

    public static final class id {
        public static int action_applicant_fp_acquisition_to_applicant_photograph = 0x7f0a0051;
        public static int action_applicant_signature_to_applicant_fp_acquisition = 0x7f0a0053;
        public static int action_applicant_signature_to_applicant_photograph = 0x7f0a0055;
        public static int action_child_detail_to_minor_list = 0x7f0a0065;
        public static int action_disability_to_child_detail = 0x7f0a006f;
        public static int action_disability_to_minor_list = 0x7f0a0070;
        public static int action_disability_to_parent_detail = 0x7f0a0071;
        public static int action_fingerprint_to_child_photograph = 0x7f0a0079;
        public static int action_fingerprint_to_minor_list = 0x7f0a007a;
        public static int action_minor_list_to_applicant_signature = 0x7f0a0094;
        public static int action_new_application_to_applicant_photograph = 0x7f0a0098;
        public static int action_parent_detail_to_child_detail = 0x7f0a009f;
        public static int action_photograph_to_child_disability = 0x7f0a00a6;
        public static int action_photograph_to_minor_list = 0x7f0a00a7;
        public static int action_review_fragment_to_minor_list = 0x7f0a00b1;
        public static int action_review_fragment_to_spouse_list = 0x7f0a00b2;
        public static int action_review_fragment_to_supporting_document = 0x7f0a00b3;
        public static int action_spouse_list_to_minor_list = 0x7f0a00b8;
        public static int action_supporting_document_to_minor_list = 0x7f0a00ba;
        public static int action_supporting_document_to_spouse_list = 0x7f0a00bb;
        public static int add_child_button_layout = 0x7f0a00e9;
        public static int add_disability_button_layout = 0x7f0a00ea;
        public static int applicantFingerprintAcquisitionFragment = 0x7f0a0123;
        public static int applicant_cnic_layout = 0x7f0a0129;
        public static int applicant_detail_layout = 0x7f0a012b;
        public static int application_detail_heading_layout = 0x7f0a0134;
        public static int application_fee_heading_textView = 0x7f0a0136;
        public static int application_fee_textView = 0x7f0a0137;
        public static int application_type_layout = 0x7f0a0139;
        public static int birth_certificate_number_layout = 0x7f0a01ec;
        public static int birth_country_district_layout = 0x7f0a01ee;
        public static int birth_country_layout = 0x7f0a01ef;
        public static int birth_district_layout = 0x7f0a01f0;
        public static int birth_province_layout = 0x7f0a01fc;
        public static int birth_tehsil_layout = 0x7f0a0204;
        public static int browse_signature_button_layout = 0x7f0a0245;
        public static int capture_button_layout = 0x7f0a0288;
        public static int capture_signature_button_layout = 0x7f0a028a;
        public static int category_fee_cardView = 0x7f0a029f;
        public static int category_line_view = 0x7f0a02a0;
        public static int category_type_textView = 0x7f0a02a3;
        public static int certificate_number_layout = 0x7f0a02c8;
        public static int certificate_type_layout = 0x7f0a02c9;
        public static int childDetailFragment = 0x7f0a02d5;
        public static int childDisabilityDetailFragment = 0x7f0a02d6;
        public static int childParentDetailFragment = 0x7f0a02d7;
        public static int child_details_scrollView = 0x7f0a02de;
        public static int child_parent_details_scrollView = 0x7f0a02e2;
        public static int cnic_layout = 0x7f0a0315;
        public static int contact_detail_heading_layout = 0x7f0a0372;
        public static int contact_number_layout = 0x7f0a0373;
        public static int country_district_radio_group = 0x7f0a0385;
        public static int country_resident_layout = 0x7f0a0387;
        public static int crc_applicant_fingerprint_success_heading = 0x7f0a038b;
        public static int crc_fingerprint_capture = 0x7f0a038c;
        public static int crc_fingerprint_success_heading = 0x7f0a038d;
        public static int crc_fingerprint_success_urdu_heading = 0x7f0a038e;
        public static int crc_footer_layout = 0x7f0a038f;
        public static int crc_header_layout = 0x7f0a0390;
        public static int crc_skip_checkbox = 0x7f0a0391;
        public static int crc_step_action = 0x7f0a0392;
        public static int crc_take_photo = 0x7f0a0393;
        public static int crc_take_photo_instruction = 0x7f0a0394;
        public static int date_of_birth_layout = 0x7f0a03f4;
        public static int declCriminalCaseP = 0x7f0a0451;
        public static int declInfoClarityP = 0x7f0a0452;
        public static int declInfoConcealP = 0x7f0a0453;
        public static int declInfoCorrectP = 0x7f0a0454;
        public static int declInfoVerificationP = 0x7f0a0455;
        public static int declPrisonCourtP = 0x7f0a045a;
        public static int declProphethoodFinalityP = 0x7f0a045b;
        public static int delivery_fee_heading_textView = 0x7f0a0475;
        public static int delivery_fee_textView = 0x7f0a0476;
        public static int disabilities_recyclerView = 0x7f0a049b;
        public static int disability_chipGroup = 0x7f0a049e;
        public static int disability_details_heading = 0x7f0a049f;
        public static int disability_issuance_date_layout = 0x7f0a04a0;
        public static int disability_type_layout = 0x7f0a04a2;
        public static int disabilty_certificate_layout = 0x7f0a04a3;
        public static int document_type_layout = 0x7f0a0519;
        public static int documents_details_heading = 0x7f0a0521;
        public static int documents_list_try_again_imageView = 0x7f0a0525;
        public static int documents_list_try_again_layout = 0x7f0a0526;
        public static int documents_list_try_again_textView = 0x7f0a0527;
        public static int documents_swipeRefresh = 0x7f0a0528;
        public static int documents_type_recyclerView = 0x7f0a0529;
        public static int email_layout = 0x7f0a0565;
        public static int executive_priority_radioButton_layout = 0x7f0a0589;
        public static int expandableListView_uploaded_documents = 0x7f0a058c;
        public static int father_cnic_layout = 0x7f0a05f2;
        public static int father_details_heading = 0x7f0a05f3;
        public static int father_full_name_layout = 0x7f0a05f4;
        public static int fingerprintAcquisitionFragment = 0x7f0a061e;
        public static int fingerprint_success_layout = 0x7f0a0627;
        public static int fingerprint_verification_layout = 0x7f0a0628;
        public static int first_name_layout = 0x7f0a062c;
        public static int full_name_layout = 0x7f0a0684;
        public static int gender_layout = 0x7f0a0687;
        public static int guideline2 = 0x7f0a06d1;
        public static int image_success = 0x7f0a075b;
        public static int info_const_layout = 0x7f0a0795;
        public static int iv_info_icon = 0x7f0a07cf;
        public static int iv_take_photo = 0x7f0a07db;
        public static int last_name_layout = 0x7f0a07ef;
        public static int learn_more_button_layout = 0x7f0a07f1;
        public static int list_item_certificate_number = 0x7f0a081b;
        public static int list_item_citizen_number = 0x7f0a081c;
        public static int list_item_cross_icon_imageView = 0x7f0a081d;
        public static int list_item_edit_icon_imageView = 0x7f0a0824;
        public static int list_item_minor_name = 0x7f0a0830;
        public static int list_item_status_icon_imageView = 0x7f0a0840;
        public static int list_item_tap_to_edit = 0x7f0a0841;
        public static int minorListFragment = 0x7f0a08d1;
        public static int minor_list_source_textView = 0x7f0a08d2;
        public static int minor_list_try_again_imageView = 0x7f0a08d3;
        public static int minors_list_try_again_layout = 0x7f0a08d4;
        public static int minors_list_try_again_textView = 0x7f0a08d5;
        public static int minors_recyclerView = 0x7f0a08d6;
        public static int minors_swipeRefresh = 0x7f0a08d7;
        public static int mother_cnic_layout = 0x7f0a0925;
        public static int mother_details_heading = 0x7f0a0926;
        public static int mother_full_name_layout = 0x7f0a0927;
        public static int nav_graph = 0x7f0a0959;
        public static int nav_host_fragment = 0x7f0a095a;
        public static int newApplicationFragment = 0x7f0a096a;
        public static int new_application_scrollView = 0x7f0a096d;
        public static int next_button_layout = 0x7f0a0971;
        public static int normal_priority_radioButton_layout = 0x7f0a097e;
        public static int orphan_house_name_layout = 0x7f0a09c5;
        public static int phone_number_operator_layout = 0x7f0a0a4e;
        public static int phone_number_textInputEditText = 0x7f0a0a4f;
        public static int priority_processing_layout = 0x7f0a0a96;
        public static int priority_processing_recyclerView = 0x7f0a0a97;
        public static int relation_applicant_layout = 0x7f0a0b1c;
        public static int require_document_browse_button_layout = 0x7f0a0b4b;
        public static int require_document_capture_button_layout = 0x7f0a0b4c;
        public static int require_document_take_photo = 0x7f0a0b4e;
        public static int required_documents_layout = 0x7f0a0b4f;
        public static int reviewFragment = 0x7f0a0b55;
        public static int review_data_button = 0x7f0a0b58;
        public static int review_data_textView = 0x7f0a0b59;
        public static int signatureAcquisitionFragment = 0x7f0a0c17;
        public static int signature_const_layout = 0x7f0a0c18;
        public static int spouseListFragment = 0x7f0a0c3a;
        public static int spouse_list_try_again_imageView = 0x7f0a0c4d;
        public static int spouse_list_try_again_layout = 0x7f0a0c4e;
        public static int spouse_list_try_again_textView = 0x7f0a0c4f;
        public static int spouse_swipeRefresh = 0x7f0a0c54;
        public static int start_application_button_layout = 0x7f0a0c6f;
        public static int step_title_heading_layout = 0x7f0a0c77;
        public static int supportingDocumentsFragment = 0x7f0a0c8d;
        public static int supporting_uploaded_documents_recyclerView = 0x7f0a0c8e;
        public static int total_fee_textView = 0x7f0a0d29;
        public static int total_heading_textView = 0x7f0a0d2a;
        public static int tv_duration_note_heading = 0x7f0a0d74;
        public static int tv_info = 0x7f0a0d8c;
        public static int tv_info_message = 0x7f0a0d8e;
        public static int tv_priority_heading = 0x7f0a0dad;
        public static int tv_tap_to_add_new = 0x7f0a0dd5;
        public static int tv_tap_to_add_new_const_layout = 0x7f0a0dd6;
        public static int twin_layout = 0x7f0a0dee;
        public static int uploadApplicantPhotographFragment = 0x7f0a0e02;
        public static int uploadPhotographFragment = 0x7f0a0e03;
        public static int upload_button_layout = 0x7f0a0e05;
        public static int uploaded_documents_details_heading = 0x7f0a0e08;
        public static int urdu_father_full_name_layout = 0x7f0a0e0b;
        public static int urdu_first_name_layout = 0x7f0a0e0c;
        public static int urdu_full_name_layout = 0x7f0a0e0d;
        public static int urdu_last_name_layout = 0x7f0a0e12;
        public static int urdu_mother_full_name_layout = 0x7f0a0e13;
        public static int urgent_priority_radioButton_layout = 0x7f0a0e18;
        public static int user_guide_textView = 0x7f0a0e1b;
        public static int value_added_service__chipGroup = 0x7f0a0e24;
        public static int value_added_services_layout = 0x7f0a0e25;
        public static int verify_applicant_fingerprint_button_layout = 0x7f0a0e4c;

        private id() {
        }
    }

    public static final class layout {
        public static int activity_child_detail = 0x7f0d0027;
        public static int activity_child_disability_detail = 0x7f0d0028;
        public static int activity_child_parent_detail = 0x7f0d0029;
        public static int activity_new_application = 0x7f0d004c;
        public static int activity_supporting_documents = 0x7f0d0058;
        public static int child_detail_fragment = 0x7f0d0087;
        public static int child_disability_detail_fragment = 0x7f0d0088;
        public static int child_parent_detail_fragment = 0x7f0d0089;
        public static int crc_activity = 0x7f0d0090;
        public static int crc_activity_main = 0x7f0d0091;
        public static int crc_applicant_fingerprint_acquisition_fragment = 0x7f0d0092;
        public static int crc_supporting_documents_fragment = 0x7f0d0093;
        public static int fingerprint_acquisition_activity = 0x7f0d0112;
        public static int fingerprint_acquisition_fragment = 0x7f0d0113;
        public static int minor_list_activity = 0x7f0d019e;
        public static int minor_list_fragment = 0x7f0d019f;
        public static int minor_list_item = 0x7f0d01a0;
        public static int new_application_fragment = 0x7f0d01cc;
        public static int review_fragment = 0x7f0d0228;
        public static int signature_acquisition_activity = 0x7f0d0237;
        public static int signature_acquisition_fragment = 0x7f0d0238;
        public static int spouse_list_fragment = 0x7f0d023f;
        public static int upload_applicant_photograph_fragment = 0x7f0d0260;
        public static int upload_photograph_fragment = 0x7f0d0261;

        private layout() {
        }
    }

    public static final class navigation {
        public static int nav_graph = 0x7f110013;

        private navigation() {
        }
    }

    public static final class string {
        public static int application_processing_priority = 0x7f140076;
        public static int browse = 0x7f1400ef;
        public static int capture = 0x7f140108;
        public static int printing_duration = 0x7f1406b0;

        private string() {
        }
    }

    public static final class style {
        public static int CustomOutlinedButtonStyle = 0x7f150138;
        public static int ThemeOverlay_PhoneNumberKit_BottomSheetDialog = 0x7f150348;
        public static int Theme_OneApp = 0x7f1502cf;
        public static int Widget_PhoneNumberKit_BottomSheet = 0x7f1504d2;

        private style() {
        }
    }

    private R() {
    }
}