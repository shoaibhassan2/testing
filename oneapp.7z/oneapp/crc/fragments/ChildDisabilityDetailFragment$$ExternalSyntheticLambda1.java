package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;
import pk.gov.nadra.oneapp.crc.databinding.ChildDisabilityDetailFragmentBinding;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDisabilityDetailFragment$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public final /* synthetic */ ChildDisabilityDetailFragmentBinding f$1;

    public /* synthetic */ ChildDisabilityDetailFragment$$ExternalSyntheticLambda1(ChildDisabilityDetailFragmentBinding childDisabilityDetailFragmentBinding) {
        binding = childDisabilityDetailFragmentBinding;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$6(this.f$0, binding, view);
    }
}