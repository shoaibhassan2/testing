package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SupportingDocumentsFragment$$ExternalSyntheticLambda5 implements Function0 {
    public /* synthetic */ SupportingDocumentsFragment$$ExternalSyntheticLambda5() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return SupportingDocumentsFragment.handleFailureCase$lambda$16(this.f$0);
    }
}