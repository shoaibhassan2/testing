package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class FingerprintAcquisitionFragment$$ExternalSyntheticLambda8 implements View.OnClickListener {
    public /* synthetic */ FingerprintAcquisitionFragment$$ExternalSyntheticLambda8() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        FingerprintAcquisitionFragment.onViewCreated$lambda$4$lambda$3(this.f$0, view);
    }
}