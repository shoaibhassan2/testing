package pk.gov.nadra.oneapp.crc.fragments;

import com.google.gson.JsonObject;
import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SpouseListFragment$verifySpouseFingerprint$1$$ExternalSyntheticLambda0 implements Function3 {
    public /* synthetic */ SpouseListFragment$verifySpouseFingerprint$1$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return SpouseListFragment.C12491.invokeSuspend$lambda$0(spouseListFragment, (JsonObject) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}