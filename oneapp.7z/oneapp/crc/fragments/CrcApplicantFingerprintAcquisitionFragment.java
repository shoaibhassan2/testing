package pk.gov.nadra.oneapp.crc.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.compose.material3.MenuKt;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.fingerprint.FingerprintScanSelectionActivityUnikrewEnroll;
import pk.gov.nadra.oneapp.commonutils.preferences.AppPreferences;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.FingerIndexEnum;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.adapter.viewmodel.CRCSharedViewModel;
import pk.gov.nadra.oneapp.crc.databinding.CrcApplicantFingerprintAcquisitionFragmentBinding;
import pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;
import pk.gov.nadra.oneapp.models.biometricupdate.BiometricUpdateFingerprintStatus;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.TabUpdateRequest;
import pk.gov.nadra.oneapp.models.crc.fingerprint.EnrollFingerprintRequest;
import pk.gov.nadra.oneapp.models.crc.fingerprint.FingerPreference;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: CrcApplicantFingerprintAcquisitionFragment.kt */
@Metadata(d1 = {"\u0000n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\b\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0018H\u0016J$\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001c2\b\u0010\u001d\u001a\u0004\u0018\u00010\u001e2\b\u0010\u001f\u001a\u0004\u0018\u00010 H\u0016J\u001a\u0010!\u001a\u00020\u00162\u0006\u0010\"\u001a\u00020\u001a2\b\u0010\u001f\u001a\u0004\u0018\u00010 H\u0016J\b\u0010'\u001a\u00020\u0016H\u0002J\u0010\u0010(\u001a\u00020\u00162\u0006\u0010)\u001a\u00020*H\u0002J\u0010\u0010+\u001a\u00020\u00162\u0006\u0010,\u001a\u00020-H\u0002J\u0018\u0010.\u001a\u00020\u00162\u0006\u0010,\u001a\u00020-2\u0006\u0010/\u001a\u000200H\u0002J\b\u00101\u001a\u00020\u0016H\u0002J\u0010\u00102\u001a\u00020\u00162\u0006\u00103\u001a\u00020-H\u0002J\b\u00104\u001a\u00020\u0016H\u0002J\b\u00105\u001a\u00020\u0016H\u0002J\u0010\u00106\u001a\u00020\u00162\u0006\u00103\u001a\u00020-H\u0002J\b\u00107\u001a\u00020\u0016H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u001c\u0010#\u001a\u0010\u0012\f\u0012\n &*\u0004\u0018\u00010%0%0$X\u0082\u0004¢\u0006\u0002\n\u0000¨\u00068"}, d2 = {"Lpk/gov/nadra/oneapp/crc/fragments/CrcApplicantFingerprintAcquisitionFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/crc/databinding/CrcApplicantFingerprintAcquisitionFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/CrcApplicantFingerprintAcquisitionFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/crc/views/CRCActivity;)V", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "fingerprintLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "handleCaptureSuccess", "enrollFingerprints", "enrollFingerprintRequest", "Lpk/gov/nadra/oneapp/models/crc/fingerprint/EnrollFingerprintRequest;", "processEnrollFingerprintSuccessResponse", "jsonResponse", "Lcom/google/gson/JsonObject;", "handleFailureCase", "responseCode", "", "saveFingerprintTab", "processFingerprintTabSuccessResponse", "jSonObject", "launchNextScreen", "getFingerprintsStatus", "processFingerprintsSuccessResponse", "initFooterView", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class CrcApplicantFingerprintAcquisitionFragment extends Fragment {
    private CrcApplicantFingerprintAcquisitionFragmentBinding _binding;
    public CRCActivity activity;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;
    private final ActivityResultLauncher<Intent> fingerprintLauncher;

    public CrcApplicantFingerprintAcquisitionFragment() {
        final CrcApplicantFingerprintAcquisitionFragment crcApplicantFingerprintAcquisitionFragment = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(crcApplicantFingerprintAcquisitionFragment, Reflection.getOrCreateKotlinClass(CRCSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = crcApplicantFingerprintAcquisitionFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = crcApplicantFingerprintAcquisitionFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = crcApplicantFingerprintAcquisitionFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda8
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) throws JsonSyntaxException {
                CrcApplicantFingerprintAcquisitionFragment.fingerprintLauncher$lambda$5(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.fingerprintLauncher = activityResultLauncherRegisterForActivityResult;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final CRCSharedViewModel getCrcSharedViewModel() {
        return (CRCSharedViewModel) this.crcSharedViewModel.getValue();
    }

    private final CrcApplicantFingerprintAcquisitionFragmentBinding getBinding() {
        CrcApplicantFingerprintAcquisitionFragmentBinding crcApplicantFingerprintAcquisitionFragmentBinding = this._binding;
        Intrinsics.checkNotNull(crcApplicantFingerprintAcquisitionFragmentBinding);
        return crcApplicantFingerprintAcquisitionFragmentBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final CRCActivity getActivity() {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity != null) {
            return cRCActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(CRCActivity cRCActivity) {
        Intrinsics.checkNotNullParameter(cRCActivity, "<set-?>");
        this.activity = cRCActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.crc.views.CRCActivity");
        setActivity((CRCActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = CrcApplicantFingerprintAcquisitionFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        CrcApplicantFingerprintAcquisitionFragmentBinding binding = getBinding();
        TextView textView = binding.crcHeaderLayout.textTitle;
        String upperCase = getCrcSharedViewModel().getDocumentTypeValue().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(String.valueOf(upperCase));
        binding.crcHeaderLayout.textSubtitle.setText(String.valueOf(getCrcSharedViewModel().getApplicationTypeValue()));
        binding.crcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.roboto_medium));
        binding.crcHeaderLayout.tvHeaderTrackingId.setText(getCrcSharedViewModel().getTrackingId());
        binding.crcHeaderLayout.tvHeaderFee.setText(String.valueOf(getCrcSharedViewModel().getAmount()));
        binding.stepTitleHeadingLayout.tvStepTitleHeading.setText("Fingerprint Acquisition");
        binding.stepTitleHeadingLayout.tvStepTitleHeadingUrdu.setText("انگلیوں کےنشانات لیں");
        binding.crcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                CrcApplicantFingerprintAcquisitionFragment.onViewCreated$lambda$4$lambda$0(this.f$0, view2);
            }
        });
        binding.crcHeaderLayout.iconHome.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                CrcApplicantFingerprintAcquisitionFragment.onViewCreated$lambda$4$lambda$1(this.f$0, view2);
            }
        });
        binding.crcHeaderLayout.iconInfo.setVisibility(0);
        binding.crcHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                CrcApplicantFingerprintAcquisitionFragment.onViewCreated$lambda$4$lambda$2(this.f$0, view2);
            }
        });
        binding.crcFingerprintCapture.ivTakePhoto.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.ic_fingerprint_green));
        binding.crcFingerprintCapture.tvTapToUpload.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Tap to Capture Fingerprints\n", " انگلیوں کے نشان لینے کے لیے ٹیپ کریں", 0, false, 12, null));
        TextView textView2 = binding.crcApplicantFingerprintSuccessHeading;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.fingerprint_acquisition_successful_label);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView2.setText(Util.setEnglishTextSpan$default(util, activity, string, "\nآپ کے انگلیوں کے نشانات  کامیابی سے حاصل  کر لیے گئے ہیں۔ اگلے مرحلے کی طرف بڑھنے کے لیے ''آگے ' بٹن دبائیں۔", 0, false, 12, null));
        binding.crcFingerprintCapture.constraintLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                CrcApplicantFingerprintAcquisitionFragment.onViewCreated$lambda$4$lambda$3(this.f$0, view2);
            }
        });
        initFooterView();
        getFingerprintsStatus();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$0(CrcApplicantFingerprintAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$1(CrcApplicantFingerprintAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$2(CrcApplicantFingerprintAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.crc_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.CRC_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$3(CrcApplicantFingerprintAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intent intent = new Intent(this$0.getActivity(), (Class<?>) FingerprintScanSelectionActivityUnikrewEnroll.class);
        intent.putExtra(Constant.CAPTURE_TYPE, "ENROLL");
        this$0.fingerprintLauncher.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void fingerprintLauncher$lambda$5(CrcApplicantFingerprintAcquisitionFragment this$0, ActivityResult result) throws JsonSyntaxException {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1 && result.getData() != null) {
            Intent data = result.getData();
            Intrinsics.checkNotNull(data);
            if (data.hasExtra(Constant.CAPTURE_SUCCESS)) {
                this$0.handleCaptureSuccess();
                return;
            }
        }
        result.getResultCode();
    }

    private final void handleCaptureSuccess() throws JsonSyntaxException {
        String strName;
        String fingerprints = AppPreferences.getInstance(getActivity()).getFingerprints();
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d(Constant.TAG, fingerprints);
        }
        Object objFromJson = new Gson().fromJson(fingerprints, (Class<Object>) FingerPreference[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List<FingerPreference> listAsList = ArraysKt.asList((Object[]) objFromJson);
        EnrollFingerprintRequest enrollFingerprintRequest = new EnrollFingerprintRequest(null, null, 0L, 7, null);
        enrollFingerprintRequest.setTrackingId(getCrcSharedViewModel().getTrackingId());
        ArrayList arrayList = new ArrayList();
        for (FingerPreference fingerPreference : listAsList) {
            EnrollFingerprintRequest.Finger finger = new EnrollFingerprintRequest.Finger(null, null, 0L, null, null, 31, null);
            FingerIndexEnum fingerIndexEnumFromId = FingerIndexEnum.INSTANCE.fromId(Integer.parseInt(fingerPreference.getFingerIndex()));
            if (fingerIndexEnumFromId == null || (strName = fingerIndexEnumFromId.name()) == null) {
                strName = "";
            }
            finger.setIndexName(strName);
            finger.setWsq(fingerPreference.getBase64());
            arrayList.add(finger);
        }
        enrollFingerprintRequest.setFingerList(arrayList);
        enrollFingerprints(enrollFingerprintRequest);
    }

    /* compiled from: CrcApplicantFingerprintAcquisitionFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$enrollFingerprints$1", f = "CrcApplicantFingerprintAcquisitionFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$enrollFingerprints$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ EnrollFingerprintRequest $enrollFingerprintRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(EnrollFingerprintRequest enrollFingerprintRequest, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$enrollFingerprintRequest = enrollFingerprintRequest;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return CrcApplicantFingerprintAcquisitionFragment.this.new AnonymousClass1(this.$enrollFingerprintRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(CrcApplicantFingerprintAcquisitionFragment.this.getActivity());
            EnrollFingerprintRequest enrollFingerprintRequest = this.$enrollFingerprintRequest;
            final CrcApplicantFingerprintAcquisitionFragment crcApplicantFingerprintAcquisitionFragment = CrcApplicantFingerprintAcquisitionFragment.this;
            aPIRequests.saveBiometricUpdateFingerprint(enrollFingerprintRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$enrollFingerprints$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return CrcApplicantFingerprintAcquisitionFragment.AnonymousClass1.invokeSuspend$lambda$0(crcApplicantFingerprintAcquisitionFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(CrcApplicantFingerprintAcquisitionFragment crcApplicantFingerprintAcquisitionFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(crcApplicantFingerprintAcquisitionFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                crcApplicantFingerprintAcquisitionFragment.processEnrollFingerprintSuccessResponse(jsonObject);
            } else {
                crcApplicantFingerprintAcquisitionFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void enrollFingerprints(EnrollFingerprintRequest enrollFingerprintRequest) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(enrollFingerprintRequest, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processEnrollFingerprintSuccessResponse(JsonObject jsonResponse) {
        getBinding().fingerprintSuccessLayout.setVisibility(0);
        getBinding().fingerprintVerificationLayout.setVisibility(8);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors == null || errors.isEmpty()) {
                    return;
                }
                List<ErrorResponse.Error> errors2 = errorResponse.getErrors();
                Intrinsics.checkNotNull(errors2);
                String message = errors2.get(0).getMessage();
                if (message != null) {
                    BottomSheetUtils.showMessageBottomSheet$default(BottomSheetUtils.INSTANCE, (FragmentActivity) getActivity(), "Alert", message, false, false, (String) null, (Function1) null, MenuKt.InTransitionDuration, (Object) null);
                    return;
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            CRCActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda6
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return CrcApplicantFingerprintAcquisitionFragment.handleFailureCase$lambda$7(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return CrcApplicantFingerprintAcquisitionFragment.handleFailureCase$lambda$8(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$7(CrcApplicantFingerprintAcquisitionFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$8(CrcApplicantFingerprintAcquisitionFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* compiled from: CrcApplicantFingerprintAcquisitionFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$saveFingerprintTab$1", f = "CrcApplicantFingerprintAcquisitionFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$saveFingerprintTab$1, reason: invalid class name and case insensitive filesystem */
    static final class C12301 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Ref.ObjectRef<TabUpdateRequest> $tabUpdateRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12301(Ref.ObjectRef<TabUpdateRequest> objectRef, Continuation<? super C12301> continuation) {
            super(2, continuation);
            this.$tabUpdateRequest = objectRef;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return CrcApplicantFingerprintAcquisitionFragment.this.new C12301(this.$tabUpdateRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12301) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(CrcApplicantFingerprintAcquisitionFragment.this.getActivity());
            APIRequests aPIRequests = new APIRequests(CrcApplicantFingerprintAcquisitionFragment.this.getActivity());
            TabUpdateRequest tabUpdateRequest = this.$tabUpdateRequest.element;
            final CrcApplicantFingerprintAcquisitionFragment crcApplicantFingerprintAcquisitionFragment = CrcApplicantFingerprintAcquisitionFragment.this;
            aPIRequests.saveCrcFingerprintTab(tabUpdateRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$saveFingerprintTab$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return CrcApplicantFingerprintAcquisitionFragment.C12301.invokeSuspend$lambda$0(crcApplicantFingerprintAcquisitionFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(CrcApplicantFingerprintAcquisitionFragment crcApplicantFingerprintAcquisitionFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(crcApplicantFingerprintAcquisitionFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("saveApplicantPhotograph() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                crcApplicantFingerprintAcquisitionFragment.processFingerprintTabSuccessResponse(jsonObject);
            } else {
                crcApplicantFingerprintAcquisitionFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [T, pk.gov.nadra.oneapp.models.crc.TabUpdateRequest] */
    private final void saveFingerprintTab() {
        Ref.ObjectRef objectRef = new Ref.ObjectRef();
        objectRef.element = new TabUpdateRequest(getCrcSharedViewModel().getTrackingId(), null, 2, null);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12301(objectRef, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processFingerprintTabSuccessResponse(JsonObject jSonObject) {
        Log.d("processDataUpdation()", jSonObject.toString());
        launchNextScreen();
    }

    private final void launchNextScreen() {
        getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.signatureAcquisitionFragment);
    }

    /* compiled from: CrcApplicantFingerprintAcquisitionFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$getFingerprintsStatus$1", f = "CrcApplicantFingerprintAcquisitionFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$getFingerprintsStatus$1, reason: invalid class name and case insensitive filesystem */
    static final class C12291 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12291(Continuation<? super C12291> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return CrcApplicantFingerprintAcquisitionFragment.this.new C12291(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12291) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(CrcApplicantFingerprintAcquisitionFragment.this.getActivity());
            APIRequests aPIRequests = new APIRequests(CrcApplicantFingerprintAcquisitionFragment.this.getActivity());
            String trackingId = CrcApplicantFingerprintAcquisitionFragment.this.getCrcSharedViewModel().getTrackingId();
            final CrcApplicantFingerprintAcquisitionFragment crcApplicantFingerprintAcquisitionFragment = CrcApplicantFingerprintAcquisitionFragment.this;
            aPIRequests.getBiometricUpdateFingerprints(trackingId, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$getFingerprintsStatus$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return CrcApplicantFingerprintAcquisitionFragment.C12291.invokeSuspend$lambda$0(crcApplicantFingerprintAcquisitionFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(CrcApplicantFingerprintAcquisitionFragment crcApplicantFingerprintAcquisitionFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(crcApplicantFingerprintAcquisitionFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                crcApplicantFingerprintAcquisitionFragment.processFingerprintsSuccessResponse(jsonObject);
            } else {
                crcApplicantFingerprintAcquisitionFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getFingerprintsStatus() {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12291(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processFingerprintsSuccessResponse(JsonObject jSonObject) {
        if (!((BiometricUpdateFingerprintStatus) new Gson().fromJson(jSonObject.toString(), BiometricUpdateFingerprintStatus.class)).getFingerList().isEmpty()) {
            getBinding().fingerprintSuccessLayout.setVisibility(0);
            getBinding().fingerprintVerificationLayout.setVisibility(8);
        } else {
            getBinding().fingerprintSuccessLayout.setVisibility(8);
            getBinding().fingerprintVerificationLayout.setVisibility(0);
        }
    }

    private final void initFooterView() {
        CrcApplicantFingerprintAcquisitionFragmentBinding binding = getBinding();
        binding.crcFooterLayout.backButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                CrcApplicantFingerprintAcquisitionFragment.initFooterView$lambda$12$lambda$10(this.f$0, view);
            }
        });
        binding.crcFooterLayout.backButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Back", "\n(واپس جائیں)", 0, false, 12, null));
        MaterialButton materialButton = binding.crcFooterLayout.nextButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.next);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        materialButton.setText(Util.setEnglishTextSpan$default(util, activity, string, "\n(آگے بڑھیں)", 0, false, 12, null));
        binding.crcFooterLayout.nextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                CrcApplicantFingerprintAcquisitionFragment.initFooterView$lambda$12$lambda$11(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$12$lambda$10(CrcApplicantFingerprintAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$12$lambda$11(CrcApplicantFingerprintAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.saveFingerprintTab();
    }
}