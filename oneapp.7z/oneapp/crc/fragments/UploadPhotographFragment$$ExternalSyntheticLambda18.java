package pk.gov.nadra.oneapp.crc.fragments;

import android.content.Intent;
import kotlin.jvm.functions.Function2;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class UploadPhotographFragment$$ExternalSyntheticLambda18 implements Function2 {
    public /* synthetic */ UploadPhotographFragment$$ExternalSyntheticLambda18() {
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return UploadPhotographFragment.dispatchCameraIntentForPhotoCapture$lambda$12(this.f$0, (String) obj, (Intent) obj2);
    }
}