package pk.gov.nadra.oneapp.crc.fragments;

import android.net.Uri;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class UploadApplicantPhotographFragment$$ExternalSyntheticLambda6 implements ActivityResultCallback {
    public /* synthetic */ UploadApplicantPhotographFragment$$ExternalSyntheticLambda6() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        UploadApplicantPhotographFragment.photoPickerLauncher$lambda$26(this.f$0, (Uri) obj);
    }
}