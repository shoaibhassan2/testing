package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class MinorListFragment$$ExternalSyntheticLambda8 implements View.OnClickListener {
    public /* synthetic */ MinorListFragment$$ExternalSyntheticLambda8() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MinorListFragment.initFooterView$lambda$34$lambda$33(this.f$0, view);
    }
}