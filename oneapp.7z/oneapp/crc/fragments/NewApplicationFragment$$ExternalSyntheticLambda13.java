package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;
import com.google.android.material.chip.Chip;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class NewApplicationFragment$$ExternalSyntheticLambda13 implements View.OnClickListener {
    public final /* synthetic */ Chip f$1;

    public /* synthetic */ NewApplicationFragment$$ExternalSyntheticLambda13(Chip chip) {
        chip = chip;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        NewApplicationFragment.addChip$lambda$17$lambda$16(this.f$0, chip, view);
    }
}