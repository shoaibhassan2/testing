package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ReviewFragment$$ExternalSyntheticLambda3 implements Function0 {
    public /* synthetic */ ReviewFragment$$ExternalSyntheticLambda3() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return ReviewFragment.processSubmitFormReceivingSuccessResponse$lambda$10(this.f$0);
    }
}