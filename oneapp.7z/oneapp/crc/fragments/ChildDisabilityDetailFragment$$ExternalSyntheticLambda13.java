package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;
import com.google.android.material.chip.Chip;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDisabilityDetailFragment$$ExternalSyntheticLambda13 implements View.OnClickListener {
    public final /* synthetic */ Chip f$1;

    public /* synthetic */ ChildDisabilityDetailFragment$$ExternalSyntheticLambda13(Chip chip) {
        chip = chip;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ChildDisabilityDetailFragment.addChip$lambda$22$lambda$21(this.f$0, chip, view);
    }
}