package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;
import pk.gov.nadra.oneapp.crc.databinding.ChildDetailFragmentBinding;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDetailFragment$$ExternalSyntheticLambda2 implements View.OnClickListener {
    public final /* synthetic */ ChildDetailFragmentBinding f$1;

    public /* synthetic */ ChildDetailFragment$$ExternalSyntheticLambda2(ChildDetailFragmentBinding childDetailFragmentBinding) {
        binding = childDetailFragmentBinding;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ChildDetailFragment.attachLayoutViews$lambda$18$lambda$9(this.f$0, binding, view);
    }
}