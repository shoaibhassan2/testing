package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SpouseListFragment$$ExternalSyntheticLambda7 implements Function0 {
    public final /* synthetic */ VerifyFingerprintResponse f$1;

    public /* synthetic */ SpouseListFragment$$ExternalSyntheticLambda7(VerifyFingerprintResponse verifyFingerprintResponse) {
        verifyFingerprintResponse = verifyFingerprintResponse;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return SpouseListFragment.processSpouseVerifySuccessResponse$lambda$19(this.f$0, verifyFingerprintResponse);
    }
}