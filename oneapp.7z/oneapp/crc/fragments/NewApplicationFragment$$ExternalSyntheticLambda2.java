package pk.gov.nadra.oneapp.crc.fragments;

import android.view.ViewTreeObserver;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class NewApplicationFragment$$ExternalSyntheticLambda2 implements ViewTreeObserver.OnGlobalLayoutListener {
    public /* synthetic */ NewApplicationFragment$$ExternalSyntheticLambda2() {
    }

    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
    public final void onGlobalLayout() {
        NewApplicationFragment.attachLayoutViews$lambda$11$lambda$9(this.f$0);
    }
}