package pk.gov.nadra.oneapp.crc.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import com.google.gson.JsonSyntaxException;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SpouseListFragment$$ExternalSyntheticLambda15 implements ActivityResultCallback {
    public /* synthetic */ SpouseListFragment$$ExternalSyntheticLambda15() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) throws JsonSyntaxException {
        SpouseListFragment.fingerprintLauncher$lambda$17(this.f$0, (ActivityResult) obj);
    }
}