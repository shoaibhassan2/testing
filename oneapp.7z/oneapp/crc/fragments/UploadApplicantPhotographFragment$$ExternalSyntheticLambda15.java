package pk.gov.nadra.oneapp.crc.fragments;

import android.widget.CompoundButton;
import pk.gov.nadra.oneapp.crc.databinding.UploadApplicantPhotographFragmentBinding;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class UploadApplicantPhotographFragment$$ExternalSyntheticLambda15 implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ UploadApplicantPhotographFragmentBinding f$1;

    public /* synthetic */ UploadApplicantPhotographFragment$$ExternalSyntheticLambda15(UploadApplicantPhotographFragmentBinding uploadApplicantPhotographFragmentBinding) {
        binding = uploadApplicantPhotographFragmentBinding;
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        UploadApplicantPhotographFragment.onViewCreated$lambda$10$lambda$8(this.f$0, binding, compoundButton, z);
    }
}