package pk.gov.nadra.oneapp.crc.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class NewApplicationFragment$$ExternalSyntheticLambda12 implements ActivityResultCallback {
    public /* synthetic */ NewApplicationFragment$$ExternalSyntheticLambda12() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        NewApplicationFragment.unikrewFacialLauncher$lambda$60(this.f$0, (ActivityResult) obj);
    }
}