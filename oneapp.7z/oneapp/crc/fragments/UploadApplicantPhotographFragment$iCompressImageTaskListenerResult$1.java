package pk.gov.nadra.oneapp.crc.fragments;

import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import java.io.File;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonui.databinding.ImageUploadLayoutBinding;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;

/* compiled from: UploadApplicantPhotographFragment.kt */
@Metadata(d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\b\u0010\u0006\u001a\u00020\u0003H\u0016¨\u0006\u0007"}, d2 = {"pk/gov/nadra/oneapp/crc/fragments/UploadApplicantPhotographFragment$iCompressImageTaskListenerResult$1", "Lpk/gov/nadra/oneapp/commonutils/utils/ImageCompressor$ICompressImageTaskListener;", "onComplete", "", "compressed", "Ljava/io/File;", "onError", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class UploadApplicantPhotographFragment$iCompressImageTaskListenerResult$1 implements ImageCompressor.ICompressImageTaskListener {
    UploadApplicantPhotographFragment$iCompressImageTaskListenerResult$1() {
    }

    @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
    public void onComplete(File compressed) {
        Intrinsics.checkNotNullParameter(compressed, "compressed");
        Glide.with((FragmentActivity) this.this$0.getActivity()).load(compressed).into(this.this$0.getBinding().crcTakePhoto.ivShowPhoto);
        ImageUploadLayoutBinding imageUploadLayoutBinding = this.this$0.getBinding().crcTakePhoto;
        imageUploadLayoutBinding.ivTakePhoto.setVisibility(4);
        imageUploadLayoutBinding.tvTapToUpload.setVisibility(4);
        imageUploadLayoutBinding.tvPhotoDimension.setVisibility(4);
        this.this$0.getBinding().captureButtonLayout.commonButton.setButtonText(Util.setEnglishTextSpan$default(Util.INSTANCE, this.this$0.getActivity(), "Re-capture", " (دوبارہ کھینچیں) ", 0, false, 12, null));
        this.this$0.setCapturedImageFile(compressed);
        if (this.this$0.capturedImageFile != null) {
            this.this$0.handleUploadPhotograph();
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this.this$0.getActivity();
        String string = this.this$0.getString(R.string.please_upload_photo);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this.this$0.getString(R.string.please_upload_photo_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }

    @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
    public void onError() {
        Util.INSTANCE.showToast(this.this$0.getActivity(), "Failed");
    }
}