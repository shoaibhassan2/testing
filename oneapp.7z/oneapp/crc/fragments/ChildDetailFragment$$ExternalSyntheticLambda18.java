package pk.gov.nadra.oneapp.crc.fragments;

import android.widget.RadioGroup;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDetailFragment$$ExternalSyntheticLambda18 implements RadioGroup.OnCheckedChangeListener {
    public final /* synthetic */ ChildDetailFragment f$1;

    public /* synthetic */ ChildDetailFragment$$ExternalSyntheticLambda18(ChildDetailFragment childDetailFragment) {
        this = childDetailFragment;
    }

    @Override // android.widget.RadioGroup.OnCheckedChangeListener
    public final void onCheckedChanged(RadioGroup radioGroup, int i) {
        ChildDetailFragment.attachLayoutViews$lambda$18$lambda$17(binding, this, radioGroup, i);
    }
}