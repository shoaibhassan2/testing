package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SpouseListFragment$$ExternalSyntheticLambda14 implements View.OnClickListener {
    public /* synthetic */ SpouseListFragment$$ExternalSyntheticLambda14() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        SpouseListFragment.initFooterView$lambda$30$lambda$29(this.f$0, view);
    }
}