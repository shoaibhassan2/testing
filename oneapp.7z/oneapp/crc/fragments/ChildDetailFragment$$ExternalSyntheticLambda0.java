package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDetailFragment$$ExternalSyntheticLambda0 implements Function0 {
    public /* synthetic */ ChildDetailFragment$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return ChildDetailFragment.handleFailureCaseJsonArray$lambda$60(this.f$0);
    }
}