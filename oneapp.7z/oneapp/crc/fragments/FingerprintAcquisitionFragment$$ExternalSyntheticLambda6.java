package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class FingerprintAcquisitionFragment$$ExternalSyntheticLambda6 implements View.OnClickListener {
    public /* synthetic */ FingerprintAcquisitionFragment$$ExternalSyntheticLambda6() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        FingerprintAcquisitionFragment.onViewCreated$lambda$4$lambda$1(this.f$0, view);
    }
}