package pk.gov.nadra.oneapp.crc.fragments;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.farrakhj.stringpickerlibrary.views.StringPickerActivity;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.internal.ViewUtils;
import com.google.android.material.radiobutton.MaterialRadioButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import org.apache.commons.imaging.formats.jpeg.iptc.IptcConstants;
import pk.gov.nadra.oneapp.commonui.CnicMaskWatcher;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.adapter.viewmodel.CRCSharedViewModel;
import pk.gov.nadra.oneapp.crc.databinding.ChildDetailFragmentBinding;
import pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment;
import pk.gov.nadra.oneapp.crc.utils.MethodName;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.library.LibraryResponse;
import pk.gov.nadra.oneapp.models.crc.minor.BirthCountry;
import pk.gov.nadra.oneapp.models.crc.minor.BirthDistrict;
import pk.gov.nadra.oneapp.models.crc.minor.BirthProvince;
import pk.gov.nadra.oneapp.models.crc.minor.BirthTehsil;
import pk.gov.nadra.oneapp.models.crc.minor.CertificateType;
import pk.gov.nadra.oneapp.models.crc.minor.Gender;
import pk.gov.nadra.oneapp.models.crc.minor.MinorDataResponse;
import pk.gov.nadra.oneapp.models.crc.minor.OrphanHouseName;
import pk.gov.nadra.oneapp.models.crc.minor.RelationWithApplicant;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: ChildDetailFragment.kt */
@Metadata(d1 = {"\u0000¨\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0010\u000e\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\u0018\u00002\u00020\u00012\u00020\u0002B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u0010\u0010P\u001a\u00020Q2\u0006\u0010R\u001a\u00020SH\u0016J$\u0010T\u001a\u00020U2\u0006\u0010V\u001a\u00020W2\b\u0010X\u001a\u0004\u0018\u00010Y2\b\u0010Z\u001a\u0004\u0018\u00010[H\u0016J\u001a\u0010\\\u001a\u00020Q2\u0006\u0010]\u001a\u00020U2\b\u0010Z\u001a\u0004\u0018\u00010[H\u0016J\b\u0010^\u001a\u00020QH\u0002J\b\u0010_\u001a\u00020QH\u0002J\f\u0010`\u001a\u00020Q*\u00020\u0012H\u0002J\f\u0010a\u001a\u00020Q*\u00020\u0012H\u0002J\f\u0010b\u001a\u00020Q*\u00020\u0012H\u0002J\f\u0010c\u001a\u00020Q*\u00020\u0012H\u0002J\f\u0010d\u001a\u00020Q*\u00020\u0012H\u0002J\u0010\u0010e\u001a\u00020Q2\u0006\u0010f\u001a\u00020\fH\u0002J%\u0010g\u001a\u00020Q2\u0016\u0010h\u001a\u0012\u0012\u0004\u0012\u0002060\u001dj\b\u0012\u0004\u0012\u000206`iH\u0002¢\u0006\u0002\u0010\"J\b\u0010n\u001a\u00020QH\u0002J\b\u0010o\u001a\u00020QH\u0002J\b\u0010p\u001a\u00020QH\u0002J\b\u0010q\u001a\u00020QH\u0002J\b\u0010'\u001a\u00020QH\u0002J\b\u0010r\u001a\u00020QH\u0002J\b\u0010s\u001a\u00020QH\u0002J\u0010\u0010t\u001a\u00020Q2\u0006\u0010u\u001a\u000206H\u0002J\u0010\u0010v\u001a\u00020Q2\u0006\u0010w\u001a\u000206H\u0002J\b\u0010x\u001a\u00020QH\u0002J\u0018\u0010y\u001a\u00020Q2\u0006\u0010z\u001a\u00020{2\u0006\u0010|\u001a\u00020EH\u0002J\u0019\u0010}\u001a\u00020Q2\u0006\u0010~\u001a\u00020{2\u0007\u0010\u007f\u001a\u00030\u0080\u0001H\u0002J\u001e\u0010\u0081\u0001\u001a\u00020Q2\t\u0010\u0082\u0001\u001a\u0004\u0018\u00010U2\b\u0010\u0083\u0001\u001a\u00030\u0084\u0001H\u0017J\u0011\u0010\u0085\u0001\u001a\u00020Q2\u0006\u0010]\u001a\u00020LH\u0002J\t\u0010\u0086\u0001\u001a\u00020QH\u0002R\u001b\u0010\u0005\u001a\u00020\u00068BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\bR\u001a\u0010\u000b\u001a\u00020\fX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0013\u001a\u00020\u00128BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0015R\u001a\u0010\u0016\u001a\u00020\u0017X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001bR \u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010 \"\u0004\b!\u0010\"R \u0010#\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b$\u0010 \"\u0004\b%\u0010\"R \u0010&\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b'\u0010 \"\u0004\b(\u0010\"R \u0010)\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b*\u0010 \"\u0004\b+\u0010\"R \u0010,\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b-\u0010 \"\u0004\b.\u0010\"R \u0010/\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b0\u0010 \"\u0004\b1\u0010\"R \u00102\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b3\u0010 \"\u0004\b4\u0010\"R \u00105\u001a\b\u0012\u0004\u0012\u0002060\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b7\u0010 \"\u0004\b8\u0010\"R \u00109\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b:\u0010 \"\u0004\b;\u0010\"R\u000e\u0010<\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010>\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010?\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010A\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010B\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010C\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010D\u001a\u00020EX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bF\u0010G\"\u0004\bH\u0010IR'\u0010J\u001a\u000e\u0012\u0004\u0012\u000206\u0012\u0004\u0012\u00020L0K8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\bO\u0010\n\u001a\u0004\bM\u0010NR\u001c\u0010j\u001a\u0010\u0012\f\u0012\n m*\u0004\u0018\u00010l0l0kX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0087\u0001"}, d2 = {"Lpk/gov/nadra/oneapp/crc/fragments/ChildDetailFragment;", "Landroidx/fragment/app/Fragment;", "Landroid/view/View$OnFocusChangeListener;", "<init>", "()V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "childDetails", "Lpk/gov/nadra/oneapp/models/crc/minor/MinorDataResponse;", "getChildDetails", "()Lpk/gov/nadra/oneapp/models/crc/minor/MinorDataResponse;", "setChildDetails", "(Lpk/gov/nadra/oneapp/models/crc/minor/MinorDataResponse;)V", "_binding", "Lpk/gov/nadra/oneapp/crc/databinding/ChildDetailFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/ChildDetailFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/crc/views/CRCActivity;)V", "certificateTypeList", "Ljava/util/ArrayList;", "Lpk/gov/nadra/oneapp/models/crc/library/LibraryResponse;", "getCertificateTypeList", "()Ljava/util/ArrayList;", "setCertificateTypeList", "(Ljava/util/ArrayList;)V", "genderList", "getGenderList", "setGenderList", "relationsList", "getRelationsList", "setRelationsList", "birthCountriesList", "getBirthCountriesList", "setBirthCountriesList", "birthProvincesList", "getBirthProvincesList", "setBirthProvincesList", "birthDistrictsList", "getBirthDistrictsList", "setBirthDistrictsList", "birthTehsilsList", "getBirthTehsilsList", "setBirthTehsilsList", "twin", "", "getTwin", "setTwin", "orphanHouseName", "getOrphanHouseName", "setOrphanHouseName", "selectedCertificateType", "selectedGender", "selectedRelation", "selectedBirthCountry", "selectedBirthProvince", "selectedBirthDistrict", "selectedBirthTehsil", "selectedOrphanage", "dropdownCalling", "Lpk/gov/nadra/oneapp/crc/utils/MethodName;", "getDropdownCalling", "()Lpk/gov/nadra/oneapp/crc/utils/MethodName;", "setDropdownCalling", "(Lpk/gov/nadra/oneapp/crc/utils/MethodName;)V", "fieldToViewMap", "", "Lcom/google/android/material/textfield/TextInputLayout;", "getFieldToViewMap", "()Ljava/util/Map;", "fieldToViewMap$delegate", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "displayErrors", "attachLayoutViews", "handleFirstAndLastNameViews", "updateFullNameTextView", "handleUrduFirstAndLastNameViews", "updateUrduFullNameTextView", "handleNameTranslation", "initViewsData", "childData", "launchStringPickerActivity", "arrayList", "Lkotlin/collections/ArrayList;", "startForResult", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "launchNextActivity", "getViewsData", "getBirthCertificateType", "getGendersList", "getCountriesList", "getProvincesList", "getDistrictsList", "provinceId", "getTehsilsList", "districtId", "getOrphanages", "processLibrarySuccessResponse", "jSonObject", "Lcom/google/gson/JsonArray;", "methodName", "handleFailureCaseJsonArray", "jsonResponse", "responseCode", "", "onFocusChange", "v", "hasFocus", "", "scrollToView", "initFooterView", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ChildDetailFragment extends Fragment implements View.OnFocusChangeListener {
    private ChildDetailFragmentBinding _binding;
    public CRCActivity activity;
    public MinorDataResponse childDetails;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;
    private final ActivityResultLauncher<Intent> startForResult;
    private ArrayList<LibraryResponse> certificateTypeList = new ArrayList<>();
    private ArrayList<LibraryResponse> genderList = new ArrayList<>();
    private ArrayList<LibraryResponse> relationsList = new ArrayList<>();
    private ArrayList<LibraryResponse> birthCountriesList = new ArrayList<>();
    private ArrayList<LibraryResponse> birthProvincesList = new ArrayList<>();
    private ArrayList<LibraryResponse> birthDistrictsList = new ArrayList<>();
    private ArrayList<LibraryResponse> birthTehsilsList = new ArrayList<>();
    private ArrayList<String> twin = CollectionsKt.arrayListOf("Yes", "No");
    private ArrayList<LibraryResponse> orphanHouseName = new ArrayList<>();
    private LibraryResponse selectedCertificateType = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedGender = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedRelation = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedBirthCountry = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedBirthProvince = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedBirthDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedBirthTehsil = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedOrphanage = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private MethodName dropdownCalling = MethodName.CERTIFICATE_TYPE;

    /* renamed from: fieldToViewMap$delegate, reason: from kotlin metadata */
    private final Lazy fieldToViewMap = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda7
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return ChildDetailFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
        }
    });

    /* compiled from: ChildDetailFragment.kt */
    @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[MethodName.values().length];
            try {
                iArr[MethodName.CERTIFICATE_TYPE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[MethodName.RELATION.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[MethodName.GENDER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[MethodName.COUNTRY.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[MethodName.PROVINCE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[MethodName.DISTRICT.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[MethodName.TEHSIL.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr[MethodName.TWIN.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr[MethodName.ORPHANAGES.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public ChildDetailFragment() {
        final ChildDetailFragment childDetailFragment = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(childDetailFragment, Reflection.getOrCreateKotlinClass(CRCSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = childDetailFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = childDetailFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = childDetailFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda8
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                ChildDetailFragment.startForResult$lambda$36(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.startForResult = activityResultLauncherRegisterForActivityResult;
    }

    private final CRCSharedViewModel getCrcSharedViewModel() {
        return (CRCSharedViewModel) this.crcSharedViewModel.getValue();
    }

    public final MinorDataResponse getChildDetails() {
        MinorDataResponse minorDataResponse = this.childDetails;
        if (minorDataResponse != null) {
            return minorDataResponse;
        }
        Intrinsics.throwUninitializedPropertyAccessException("childDetails");
        return null;
    }

    public final void setChildDetails(MinorDataResponse minorDataResponse) {
        Intrinsics.checkNotNullParameter(minorDataResponse, "<set-?>");
        this.childDetails = minorDataResponse;
    }

    private final ChildDetailFragmentBinding getBinding() {
        ChildDetailFragmentBinding childDetailFragmentBinding = this._binding;
        Intrinsics.checkNotNull(childDetailFragmentBinding);
        return childDetailFragmentBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final CRCActivity getActivity() {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity != null) {
            return cRCActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(CRCActivity cRCActivity) {
        Intrinsics.checkNotNullParameter(cRCActivity, "<set-?>");
        this.activity = cRCActivity;
    }

    public final ArrayList<LibraryResponse> getCertificateTypeList() {
        return this.certificateTypeList;
    }

    public final void setCertificateTypeList(ArrayList<LibraryResponse> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.certificateTypeList = arrayList;
    }

    public final ArrayList<LibraryResponse> getGenderList() {
        return this.genderList;
    }

    public final void setGenderList(ArrayList<LibraryResponse> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.genderList = arrayList;
    }

    /* renamed from: getRelationsList, reason: collision with other method in class */
    public final ArrayList<LibraryResponse> m9362getRelationsList() {
        return this.relationsList;
    }

    public final void setRelationsList(ArrayList<LibraryResponse> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.relationsList = arrayList;
    }

    public final ArrayList<LibraryResponse> getBirthCountriesList() {
        return this.birthCountriesList;
    }

    public final void setBirthCountriesList(ArrayList<LibraryResponse> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.birthCountriesList = arrayList;
    }

    public final ArrayList<LibraryResponse> getBirthProvincesList() {
        return this.birthProvincesList;
    }

    public final void setBirthProvincesList(ArrayList<LibraryResponse> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.birthProvincesList = arrayList;
    }

    public final ArrayList<LibraryResponse> getBirthDistrictsList() {
        return this.birthDistrictsList;
    }

    public final void setBirthDistrictsList(ArrayList<LibraryResponse> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.birthDistrictsList = arrayList;
    }

    public final ArrayList<LibraryResponse> getBirthTehsilsList() {
        return this.birthTehsilsList;
    }

    public final void setBirthTehsilsList(ArrayList<LibraryResponse> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.birthTehsilsList = arrayList;
    }

    public final ArrayList<String> getTwin() {
        return this.twin;
    }

    public final void setTwin(ArrayList<String> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.twin = arrayList;
    }

    public final ArrayList<LibraryResponse> getOrphanHouseName() {
        return this.orphanHouseName;
    }

    public final void setOrphanHouseName(ArrayList<LibraryResponse> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.orphanHouseName = arrayList;
    }

    public final MethodName getDropdownCalling() {
        return this.dropdownCalling;
    }

    public final void setDropdownCalling(MethodName methodName) {
        Intrinsics.checkNotNullParameter(methodName, "<set-?>");
        this.dropdownCalling = methodName;
    }

    private final Map<String, TextInputLayout> getFieldToViewMap() {
        return (Map) this.fieldToViewMap.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Map fieldToViewMap_delegate$lambda$0(ChildDetailFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        return MapsKt.mapOf(TuplesKt.to("citizenNumber", this$0.getBinding().cnicLayout.maskedCnicTextInputLayout), TuplesKt.to("nameUrdu", this$0.getBinding().urduFullNameLayout.textInputLayout), TuplesKt.to("tehsil", this$0.getBinding().birthTehsilLayout.textInputLayout), TuplesKt.to("orphanHouseName", this$0.getBinding().orphanHouseNameLayout.textInputLayout), TuplesKt.to("dateOfBirth", this$0.getBinding().dateOfBirthLayout.textInputLayout), TuplesKt.to("province", this$0.getBinding().birthProvinceLayout.textInputLayout), TuplesKt.to("name", this$0.getBinding().fullNameLayout.textInputLayout), TuplesKt.to("district", this$0.getBinding().birthDistrictLayout.textInputLayout), TuplesKt.to("birthCertificateNumber", this$0.getBinding().birthCertificateNumberLayout.textInputLayout), TuplesKt.to("relationWithApplicant", this$0.getBinding().relationApplicantLayout.textInputLayout), TuplesKt.to("firstName", this$0.getBinding().firstNameLayout.textInputLayout), TuplesKt.to("lastName", this$0.getBinding().lastNameLayout.textInputLayout), TuplesKt.to("firstNameLocal", this$0.getBinding().urduFirstNameLayout.textInputLayout), TuplesKt.to("lastNameLocal", this$0.getBinding().urduLastNameLayout.textInputLayout));
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.crc.views.CRCActivity");
        setActivity((CRCActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = ChildDetailFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        setChildDetails(getCrcSharedViewModel().getChildDetails());
        getChildDetails().getRelationWithApplicant().setKey(ExifInterface.GPS_MEASUREMENT_3D);
        getChildDetails().getRelationWithApplicant().setValue(Util.INSTANCE.capitalizeWords(CrmsConstants.CNIC_CHILD));
        getChildDetails().getMeta().getRelationWithApplicant().setDisable(true);
        attachLayoutViews();
        displayErrors();
    }

    private final void displayErrors() {
        List<ErrorResponse.Error> errorsForField = getCrcSharedViewModel().getErrorsForField();
        List<ErrorResponse.Error> list = errorsForField;
        if (list == null || list.isEmpty()) {
            return;
        }
        for (ErrorResponse.Error error : errorsForField) {
            TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
            if (textInputLayout != null) {
                textInputLayout.setError(String.valueOf(error.getMessage()));
                textInputLayout.setErrorEnabled(true);
            }
        }
    }

    private final void attachLayoutViews() {
        SpannableStringBuilder spannableStringBuilderHintWithRedStar;
        final ChildDetailFragmentBinding binding = getBinding();
        TextView textView = binding.crcHeaderLayout.textTitle;
        String upperCase = getCrcSharedViewModel().getDocumentTypeValue().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(String.valueOf(upperCase));
        binding.crcHeaderLayout.textSubtitle.setText(String.valueOf(getCrcSharedViewModel().getApplicationTypeValue()));
        binding.crcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.roboto_medium));
        binding.crcHeaderLayout.iconHome.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda14
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$3(this.f$0, view);
            }
        });
        binding.crcHeaderLayout.iconInfo.setVisibility(0);
        binding.crcHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda19
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$4(this.f$0, view);
            }
        });
        binding.crcHeaderLayout.tvHeaderTrackingId.setText(getCrcSharedViewModel().getTrackingId());
        binding.crcHeaderLayout.tvHeaderFee.setText(String.valueOf(getCrcSharedViewModel().getAmount()));
        binding.crcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$5(this.f$0, view);
            }
        });
        binding.stepTitleHeadingLayout.tvStepTitleHeading.setText(getString(R.string.child_details));
        binding.stepTitleHeadingLayout.tvStepTitleHeadingUrdu.setText("بچے کی تفصیلات");
        TextInputLayout textInputLayout = binding.cnicLayout.maskedCnicTextInputLayout;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.citizen_number);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textInputLayout.setHint(Util.setEnglishTextSpan$default(util, activity, string, " (شناختی کارڈ نمبر) ", 0, false, 12, null));
        binding.cnicLayout.maskedCnicEditText.addTextChangedListener(new CnicMaskWatcher("#####-#######-#"));
        Util util2 = Util.INSTANCE;
        CRCActivity activity2 = getActivity();
        TextInputEditText maskedCnicEditText = binding.cnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        TextInputLayout maskedCnicTextInputLayout = binding.cnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        util2.removeErrorOnTextChanged(activity2, maskedCnicEditText, maskedCnicTextInputLayout);
        TextInputLayout textInputLayout2 = binding.certificateTypeLayout.textInputLayout;
        Util util3 = Util.INSTANCE;
        CRCActivity activity3 = getActivity();
        String string2 = getString(R.string.certificate_type);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textInputLayout2.setHint(Util.setEnglishTextSpan$default(util3, activity3, string2, " (سرٹیفیکیٹ کی نوعیت) ", 0, false, 12, null));
        binding.certificateTypeLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda21
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$6(this.f$0, view);
            }
        });
        TextInputLayout textInputLayout3 = binding.birthCertificateNumberLayout.textInputLayout;
        Util util4 = Util.INSTANCE;
        CRCActivity activity4 = getActivity();
        String string3 = getString(R.string.birth_certificate_number);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        textInputLayout3.setHint(Util.setEnglishTextSpan$default(util4, activity4, string3, " (پیدائشی سرٹیفیکیٹ نمبر) ", 0, false, 12, null));
        Util util5 = Util.INSTANCE;
        CRCActivity activity5 = getActivity();
        TextInputEditText textInputEditText = binding.birthCertificateNumberLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        TextInputLayout textInputLayout4 = binding.birthCertificateNumberLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout4, "textInputLayout");
        util5.removeErrorOnTextChanged(activity5, textInputEditText, textInputLayout4);
        handleFirstAndLastNameViews(binding);
        TextInputLayout textInputLayout5 = binding.fullNameLayout.textInputLayout;
        Util util6 = Util.INSTANCE;
        CRCActivity activity6 = getActivity();
        String string4 = getString(R.string.full_name);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        textInputLayout5.setHint(Util.setEnglishTextSpan$default(util6, activity6, string4, " (مکمل نام) ", 0, true, 4, null));
        Util util7 = Util.INSTANCE;
        CRCActivity activity7 = getActivity();
        TextInputEditText textInputEditText2 = binding.fullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        TextInputLayout textInputLayout6 = binding.fullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout6, "textInputLayout");
        util7.removeErrorOnTextChanged(activity7, textInputEditText2, textInputLayout6);
        binding.fullNameLayout.textInputEditText.setImeOptions(5);
        handleUrduFirstAndLastNameViews(binding);
        handleNameTranslation(binding);
        TextInputLayout textInputLayout7 = binding.urduFullNameLayout.textInputLayout;
        CRCActivity activity8 = getActivity();
        if (activity8 != null) {
            String string5 = getString(R.string.urdu_full_name);
            Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
            spannableStringBuilderHintWithRedStar = Util.INSTANCE.hintWithRedStar(activity8, string5);
        } else {
            spannableStringBuilderHintWithRedStar = null;
        }
        textInputLayout7.setHint(spannableStringBuilderHintWithRedStar);
        binding.urduFullNameLayout.textInputLayout.setGravity(5);
        binding.urduFullNameLayout.textInputLayout.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.mehr_nastaliq));
        binding.urduFullNameLayout.textInputEditText.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.mehr_nastaliq));
        Util util8 = Util.INSTANCE;
        CRCActivity activity9 = getActivity();
        TextInputEditText textInputEditText3 = binding.urduFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText3, "textInputEditText");
        TextInputLayout textInputLayout8 = binding.urduFullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout8, "textInputLayout");
        util8.removeErrorOnTextChanged(activity9, textInputEditText3, textInputLayout8);
        binding.urduFullNameLayout.textInputEditText.setImeOptions(6);
        TextInputLayout textInputLayout9 = binding.genderLayout.textInputLayout;
        Util util9 = Util.INSTANCE;
        CRCActivity activity10 = getActivity();
        String string6 = getString(R.string.gender);
        Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
        textInputLayout9.setHint(Util.setEnglishTextSpan$default(util9, activity10, string6, " (جنس) ", 0, false, 12, null));
        binding.genderLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$7(this.f$0, view);
            }
        });
        Util util10 = Util.INSTANCE;
        CRCActivity activity11 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView = binding.genderLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        TextInputLayout textInputLayout10 = binding.genderLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout10, "textInputLayout");
        util10.removeErrorOnAutoCompleteTextChanged(activity11, autoCompleteTextView, textInputLayout10);
        TextInputLayout textInputLayout11 = binding.dateOfBirthLayout.textInputLayout;
        Util util11 = Util.INSTANCE;
        CRCActivity activity12 = getActivity();
        String string7 = getString(R.string.select_birth_date);
        Intrinsics.checkNotNullExpressionValue(string7, "getString(...)");
        textInputLayout11.setHint(Util.setEnglishTextSpan$default(util11, activity12, string7, " (پیدائش کی تاریخ منتخب کریں) ", 0, false, 12, null));
        binding.dateOfBirthLayout.textInputEditText.setFocusableInTouchMode(false);
        binding.dateOfBirthLayout.textInputEditText.setFocusable(false);
        binding.dateOfBirthLayout.textInputEditText.setClickable(true);
        binding.dateOfBirthLayout.textInputLayout.setEndIconMode(-1);
        binding.dateOfBirthLayout.textInputLayout.setEndIconDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.ic_calender));
        binding.dateOfBirthLayout.textInputEditText.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$9(this.f$0, binding, view);
            }
        });
        Util util12 = Util.INSTANCE;
        CRCActivity activity13 = getActivity();
        TextInputEditText textInputEditText4 = binding.dateOfBirthLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText4, "textInputEditText");
        TextInputLayout textInputLayout12 = binding.dateOfBirthLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout12, "textInputLayout");
        util12.removeErrorOnTextChanged(activity13, textInputEditText4, textInputLayout12);
        TextInputLayout textInputLayout13 = binding.relationApplicantLayout.textInputLayout;
        Util util13 = Util.INSTANCE;
        CRCActivity activity14 = getActivity();
        String string8 = getString(R.string.relation_with_applicant);
        Intrinsics.checkNotNullExpressionValue(string8, "getString(...)");
        textInputLayout13.setHint(Util.setEnglishTextSpan$default(util13, activity14, string8, " (درخواست گزار سے تعلق) ", 0, false, 12, null));
        binding.relationApplicantLayout.autoCompleteTextView.setClickable(true);
        binding.relationApplicantLayout.autoCompleteTextView.setFocusable(false);
        binding.relationApplicantLayout.autoCompleteTextView.setFocusableInTouchMode(false);
        binding.relationApplicantLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$10(this.f$0, view);
            }
        });
        Util util14 = Util.INSTANCE;
        CRCActivity activity15 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView2 = binding.relationApplicantLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView2, "autoCompleteTextView");
        TextInputLayout textInputLayout14 = binding.relationApplicantLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout14, "textInputLayout");
        util14.removeErrorOnAutoCompleteTextChanged(activity15, autoCompleteTextView2, textInputLayout14);
        TextInputLayout textInputLayout15 = binding.twinLayout.textInputLayout;
        Util util15 = Util.INSTANCE;
        CRCActivity activity16 = getActivity();
        String string9 = getString(R.string.twin);
        Intrinsics.checkNotNullExpressionValue(string9, "getString(...)");
        textInputLayout15.setHint(Util.setEnglishTextSpan$default(util15, activity16, string9, " (جڑواں) ", 0, false, 12, null));
        binding.twinLayout.autoCompleteTextView.setClickable(true);
        binding.twinLayout.autoCompleteTextView.setFocusable(false);
        binding.twinLayout.autoCompleteTextView.setFocusableInTouchMode(false);
        binding.twinLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$11(this.f$0, view);
            }
        });
        Util util16 = Util.INSTANCE;
        CRCActivity activity17 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView3 = binding.twinLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView3, "autoCompleteTextView");
        TextInputLayout textInputLayout16 = binding.twinLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout16, "textInputLayout");
        util16.removeErrorOnAutoCompleteTextChanged(activity17, autoCompleteTextView3, textInputLayout16);
        TextInputLayout textInputLayout17 = binding.orphanHouseNameLayout.textInputLayout;
        Util util17 = Util.INSTANCE;
        CRCActivity activity18 = getActivity();
        String string10 = getString(R.string.orphan_house_name);
        Intrinsics.checkNotNullExpressionValue(string10, "getString(...)");
        textInputLayout17.setHint(Util.setEnglishTextSpan$default(util17, activity18, string10, " (یتیم خانہ کا نام) ", 0, false, 12, null));
        binding.orphanHouseNameLayout.autoCompleteTextView.setClickable(true);
        binding.orphanHouseNameLayout.autoCompleteTextView.setFocusable(false);
        binding.orphanHouseNameLayout.autoCompleteTextView.setFocusableInTouchMode(false);
        binding.orphanHouseNameLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$12(this.f$0, view);
            }
        });
        Util util18 = Util.INSTANCE;
        CRCActivity activity19 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView4 = binding.orphanHouseNameLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView4, "autoCompleteTextView");
        TextInputLayout textInputLayout18 = binding.orphanHouseNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout18, "textInputLayout");
        util18.removeErrorOnAutoCompleteTextChanged(activity19, autoCompleteTextView4, textInputLayout18);
        MaterialRadioButton materialRadioButton = binding.countryDistrictRadioGroup.countryRadioButton.radioButton;
        Util util19 = Util.INSTANCE;
        CRCActivity activity20 = getActivity();
        String string11 = getString(R.string.country);
        Intrinsics.checkNotNullExpressionValue(string11, "getString(...)");
        materialRadioButton.setText(Util.setEnglishTextSpan$default(util19, activity20, string11, " (ملک) ", 0, false, 12, null));
        MaterialRadioButton materialRadioButton2 = binding.countryDistrictRadioGroup.districtRadioButton.radioButton;
        Util util20 = Util.INSTANCE;
        CRCActivity activity21 = getActivity();
        String string12 = getString(R.string.district);
        Intrinsics.checkNotNullExpressionValue(string12, "getString(...)");
        materialRadioButton2.setText(Util.setEnglishTextSpan$default(util20, activity21, string12, " (ضلع) ", 0, false, 12, null));
        TextInputLayout textInputLayout19 = binding.birthCountryLayout.textInputLayout;
        Util util21 = Util.INSTANCE;
        CRCActivity activity22 = getActivity();
        String string13 = getString(R.string.birth_country);
        Intrinsics.checkNotNullExpressionValue(string13, "getString(...)");
        textInputLayout19.setHint(Util.setEnglishTextSpan$default(util21, activity22, string13, " (پیدائش کا ملک) ", 0, false, 12, null));
        binding.birthCountryLayout.autoCompleteTextView.setClickable(true);
        binding.birthCountryLayout.autoCompleteTextView.setFocusable(false);
        binding.birthCountryLayout.autoCompleteTextView.setFocusableInTouchMode(false);
        binding.birthCountryLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$13(this.f$0, view);
            }
        });
        Util util22 = Util.INSTANCE;
        CRCActivity activity23 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView5 = binding.birthCountryLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView5, "autoCompleteTextView");
        TextInputLayout textInputLayout20 = binding.birthCountryLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout20, "textInputLayout");
        util22.removeErrorOnAutoCompleteTextChanged(activity23, autoCompleteTextView5, textInputLayout20);
        TextInputLayout textInputLayout21 = binding.birthProvinceLayout.textInputLayout;
        Util util23 = Util.INSTANCE;
        CRCActivity activity24 = getActivity();
        String string14 = getString(R.string.birth_province);
        Intrinsics.checkNotNullExpressionValue(string14, "getString(...)");
        textInputLayout21.setHint(Util.setEnglishTextSpan$default(util23, activity24, string14, " (پیدائش کا صوبہ) ", 0, false, 12, null));
        binding.birthProvinceLayout.autoCompleteTextView.setClickable(true);
        binding.birthProvinceLayout.autoCompleteTextView.setFocusable(false);
        binding.birthProvinceLayout.autoCompleteTextView.setFocusableInTouchMode(false);
        binding.birthProvinceLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda15
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$14(this.f$0, view);
            }
        });
        Util util24 = Util.INSTANCE;
        CRCActivity activity25 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView6 = binding.birthProvinceLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView6, "autoCompleteTextView");
        TextInputLayout textInputLayout22 = binding.birthProvinceLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout22, "textInputLayout");
        util24.removeErrorOnAutoCompleteTextChanged(activity25, autoCompleteTextView6, textInputLayout22);
        TextInputLayout textInputLayout23 = binding.birthDistrictLayout.textInputLayout;
        Util util25 = Util.INSTANCE;
        CRCActivity activity26 = getActivity();
        String string15 = getString(R.string.birth_district);
        Intrinsics.checkNotNullExpressionValue(string15, "getString(...)");
        textInputLayout23.setHint(Util.setEnglishTextSpan$default(util25, activity26, string15, " (پیدائش کا ضلع) ", 0, false, 12, null));
        binding.birthDistrictLayout.autoCompleteTextView.setClickable(true);
        binding.birthDistrictLayout.autoCompleteTextView.setFocusable(false);
        binding.birthDistrictLayout.autoCompleteTextView.setFocusableInTouchMode(false);
        binding.birthDistrictLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$15(this.f$0, view);
            }
        });
        Util util26 = Util.INSTANCE;
        CRCActivity activity27 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView7 = binding.birthDistrictLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView7, "autoCompleteTextView");
        TextInputLayout textInputLayout24 = binding.birthDistrictLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout24, "textInputLayout");
        util26.removeErrorOnAutoCompleteTextChanged(activity27, autoCompleteTextView7, textInputLayout24);
        TextInputLayout textInputLayout25 = binding.birthTehsilLayout.textInputLayout;
        Util util27 = Util.INSTANCE;
        CRCActivity activity28 = getActivity();
        String string16 = getString(R.string.birth_tehsil);
        Intrinsics.checkNotNullExpressionValue(string16, "getString(...)");
        textInputLayout25.setHint(Util.setEnglishTextSpan$default(util27, activity28, string16, " (پیدائش کی تحصیل) ", 0, false, 12, null));
        binding.birthTehsilLayout.autoCompleteTextView.setClickable(true);
        binding.birthTehsilLayout.autoCompleteTextView.setFocusable(false);
        binding.birthTehsilLayout.autoCompleteTextView.setFocusableInTouchMode(false);
        Util util28 = Util.INSTANCE;
        CRCActivity activity29 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView8 = binding.birthTehsilLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView8, "autoCompleteTextView");
        TextInputLayout textInputLayout26 = binding.birthTehsilLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout26, "textInputLayout");
        util28.removeErrorOnAutoCompleteTextChanged(activity29, autoCompleteTextView8, textInputLayout26);
        binding.birthTehsilLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda17
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$16(this.f$0, view);
            }
        });
        binding.countryDistrictRadioGroup.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda18
            @Override // android.widget.RadioGroup.OnCheckedChangeListener
            public final void onCheckedChanged(RadioGroup radioGroup, int i) {
                ChildDetailFragment.attachLayoutViews$lambda$18$lambda$17(binding, this, radioGroup, i);
            }
        });
        initFooterView();
        if (getChildDetails() != null) {
            initViewsData(getChildDetails());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$3(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$4(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.crc_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.CRC_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$5(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$6(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.CERTIFICATE_TYPE;
        this$0.getBirthCertificateType();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$7(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.GENDER;
        this$0.getGendersList();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$9(ChildDetailFragment this$0, final ChildDetailFragmentBinding this_apply, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        Util.INSTANCE.showDatePickerDialog(this$0.getActivity(), new Function1() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda10
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return ChildDetailFragment.attachLayoutViews$lambda$18$lambda$9$lambda$8(this_apply, (Date) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit attachLayoutViews$lambda$18$lambda$9$lambda$8(ChildDetailFragmentBinding this_apply, Date selectedDate) {
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        Intrinsics.checkNotNullParameter(selectedDate, "selectedDate");
        this_apply.dateOfBirthLayout.textInputEditText.setText(Util.INSTANCE.dateFormat(selectedDate));
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$10(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.RELATION;
        this$0.getRelationsList();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$11(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.TWIN;
        this$0.launchStringPickerActivity(this$0.twin);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$12(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.ORPHANAGES;
        this$0.getOrphanages();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$13(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.COUNTRY;
        this$0.getCountriesList();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$14(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.PROVINCE;
        this$0.getProvincesList();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$15(ChildDetailFragment this$0, View view) {
        String key;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.DISTRICT;
        String key2 = this$0.selectedBirthProvince.getKey();
        if (key2 != null && key2.length() != 0) {
            key = this$0.selectedBirthProvince.getKey();
        } else if (this$0.getChildDetails() == null) {
            key = "0";
        } else {
            key = this$0.getChildDetails().getBirthProvince().getKey();
        }
        this$0.getDistrictsList(key);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$16(ChildDetailFragment this$0, View view) {
        String key;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.TEHSIL;
        String key2 = this$0.selectedBirthDistrict.getKey();
        if (key2 != null && key2.length() != 0) {
            key = this$0.selectedBirthDistrict.getKey();
        } else if (this$0.getChildDetails() == null) {
            key = "0";
        } else {
            key = this$0.getChildDetails().getBirthDistrict().getKey();
        }
        this$0.getTehsilsList(key);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$18$lambda$17(ChildDetailFragmentBinding this_apply, ChildDetailFragment this$0, RadioGroup radioGroup, int i) {
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this_apply.countryDistrictRadioGroup.countryRadioButton.radioButton.getId() == i) {
            TextInputLayout textInputLayout = this_apply.birthCountryLayout.textInputLayout;
            Util util = Util.INSTANCE;
            CRCActivity activity = this$0.getActivity();
            String string = this$0.getString(R.string.birth_country);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            textInputLayout.setHint(Util.setEnglishTextSpan$default(util, activity, string, " (پیدائش کا ملک) ", 0, false, 12, null));
            return;
        }
        TextInputLayout textInputLayout2 = this_apply.birthCountryLayout.textInputLayout;
        Util util2 = Util.INSTANCE;
        CRCActivity activity2 = this$0.getActivity();
        String string2 = this$0.getString(R.string.birth_district);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textInputLayout2.setHint(Util.setEnglishTextSpan$default(util2, activity2, string2, " (پیدائش کا ضلع) ", 0, false, 12, null));
    }

    private final void handleFirstAndLastNameViews(final ChildDetailFragmentBinding childDetailFragmentBinding) {
        TextInputLayout textInputLayout = childDetailFragmentBinding.firstNameLayout.textInputLayout;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.child_first_name);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textInputLayout.setHint(Util.setEnglishTextSpan$default(util, activity, string, " (پہلا نام) ", 0, true, 4, null));
        Util util2 = Util.INSTANCE;
        CRCActivity activity2 = getActivity();
        TextInputEditText textInputEditText = childDetailFragmentBinding.firstNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        TextInputLayout textInputLayout2 = childDetailFragmentBinding.firstNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        util2.removeErrorOnTextChanged(activity2, textInputEditText, textInputLayout2);
        childDetailFragmentBinding.firstNameLayout.textInputEditText.setImeOptions(5);
        childDetailFragmentBinding.firstNameLayout.textInputEditText.addTextChangedListener(new TextWatcher() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment.handleFirstAndLastNameViews.1
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ChildDetailFragment.this.updateFullNameTextView(childDetailFragmentBinding);
            }
        });
        TextInputLayout textInputLayout3 = childDetailFragmentBinding.lastNameLayout.textInputLayout;
        Util util3 = Util.INSTANCE;
        CRCActivity activity3 = getActivity();
        String string2 = getString(R.string.child_last_name);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textInputLayout3.setHint(Util.setEnglishTextSpan$default(util3, activity3, string2, " (آخری نام) ", 0, true, 4, null));
        Util util4 = Util.INSTANCE;
        CRCActivity activity4 = getActivity();
        TextInputEditText textInputEditText2 = childDetailFragmentBinding.lastNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        TextInputLayout textInputLayout4 = childDetailFragmentBinding.lastNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout4, "textInputLayout");
        util4.removeErrorOnTextChanged(activity4, textInputEditText2, textInputLayout4);
        childDetailFragmentBinding.lastNameLayout.textInputEditText.setImeOptions(5);
        childDetailFragmentBinding.lastNameLayout.textInputEditText.addTextChangedListener(new TextWatcher() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment.handleFirstAndLastNameViews.2
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ChildDetailFragment.this.updateFullNameTextView(childDetailFragmentBinding);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateFullNameTextView(ChildDetailFragmentBinding childDetailFragmentBinding) {
        Editable text = childDetailFragmentBinding.firstNameLayout.textInputEditText.getText();
        String string = text != null ? text.toString() : null;
        if (string == null) {
            string = "";
        }
        Editable text2 = childDetailFragmentBinding.lastNameLayout.textInputEditText.getText();
        String string2 = text2 != null ? text2.toString() : null;
        childDetailFragmentBinding.fullNameLayout.textInputEditText.setText(StringsKt.trim((CharSequence) (StringsKt.trim((CharSequence) string).toString() + ' ' + StringsKt.trim((CharSequence) (string2 != null ? string2 : "")).toString())).toString());
    }

    private final void handleUrduFirstAndLastNameViews(final ChildDetailFragmentBinding childDetailFragmentBinding) {
        SpannableStringBuilder spannableStringBuilderHintWithRedStar;
        TextInputLayout textInputLayout = childDetailFragmentBinding.urduFirstNameLayout.textInputLayout;
        CRCActivity activity = getActivity();
        SpannableStringBuilder spannableStringBuilderHintWithRedStar2 = null;
        if (activity != null) {
            String string = getString(R.string.child_urdu_first_name);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            spannableStringBuilderHintWithRedStar = Util.INSTANCE.hintWithRedStar(activity, string);
        } else {
            spannableStringBuilderHintWithRedStar = null;
        }
        textInputLayout.setHint(spannableStringBuilderHintWithRedStar);
        childDetailFragmentBinding.urduFirstNameLayout.textInputLayout.setGravity(5);
        childDetailFragmentBinding.urduFirstNameLayout.textInputLayout.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.mehr_nastaliq));
        childDetailFragmentBinding.urduFirstNameLayout.textInputEditText.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.mehr_nastaliq));
        Util util = Util.INSTANCE;
        CRCActivity activity2 = getActivity();
        TextInputEditText textInputEditText = childDetailFragmentBinding.urduFirstNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        TextInputLayout textInputLayout2 = childDetailFragmentBinding.urduFirstNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        util.removeErrorOnTextChanged(activity2, textInputEditText, textInputLayout2);
        childDetailFragmentBinding.urduFirstNameLayout.textInputEditText.setImeOptions(6);
        childDetailFragmentBinding.urduFirstNameLayout.textInputEditText.addTextChangedListener(new TextWatcher() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment.handleUrduFirstAndLastNameViews.1
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ChildDetailFragment.this.updateUrduFullNameTextView(childDetailFragmentBinding);
            }
        });
        TextInputLayout textInputLayout3 = childDetailFragmentBinding.urduLastNameLayout.textInputLayout;
        CRCActivity activity3 = getActivity();
        if (activity3 != null) {
            String string2 = getString(R.string.child_urdu_last_name);
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            spannableStringBuilderHintWithRedStar2 = Util.INSTANCE.hintWithRedStar(activity3, string2);
        }
        textInputLayout3.setHint(spannableStringBuilderHintWithRedStar2);
        childDetailFragmentBinding.urduLastNameLayout.textInputLayout.setGravity(5);
        childDetailFragmentBinding.urduLastNameLayout.textInputLayout.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.mehr_nastaliq));
        childDetailFragmentBinding.urduLastNameLayout.textInputEditText.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.mehr_nastaliq));
        Util util2 = Util.INSTANCE;
        CRCActivity activity4 = getActivity();
        TextInputEditText textInputEditText2 = childDetailFragmentBinding.urduLastNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        TextInputLayout textInputLayout4 = childDetailFragmentBinding.urduLastNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout4, "textInputLayout");
        util2.removeErrorOnTextChanged(activity4, textInputEditText2, textInputLayout4);
        childDetailFragmentBinding.urduLastNameLayout.textInputEditText.setImeOptions(6);
        childDetailFragmentBinding.urduLastNameLayout.textInputEditText.addTextChangedListener(new TextWatcher() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment.handleUrduFirstAndLastNameViews.2
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ChildDetailFragment.this.updateUrduFullNameTextView(childDetailFragmentBinding);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateUrduFullNameTextView(ChildDetailFragmentBinding childDetailFragmentBinding) {
        Editable text = childDetailFragmentBinding.urduFirstNameLayout.textInputEditText.getText();
        String string = text != null ? text.toString() : null;
        if (string == null) {
            string = "";
        }
        Editable text2 = childDetailFragmentBinding.urduLastNameLayout.textInputEditText.getText();
        String string2 = text2 != null ? text2.toString() : null;
        childDetailFragmentBinding.urduFullNameLayout.textInputEditText.setText(StringsKt.trim((CharSequence) (StringsKt.trim((CharSequence) string).toString() + ' ' + StringsKt.trim((CharSequence) (string2 != null ? string2 : "")).toString())).toString());
    }

    private final void handleNameTranslation(ChildDetailFragmentBinding childDetailFragmentBinding) {
        Util util = Util.INSTANCE;
        TextInputEditText textInputEditText = childDetailFragmentBinding.firstNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        TextInputEditText textInputEditText2 = childDetailFragmentBinding.urduFirstNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        Util.setUpFocusChangeListener$default(util, textInputEditText, textInputEditText2, getActivity(), null, 8, null);
        Util util2 = Util.INSTANCE;
        TextInputEditText textInputEditText3 = childDetailFragmentBinding.lastNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText3, "textInputEditText");
        TextInputEditText textInputEditText4 = childDetailFragmentBinding.urduLastNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText4, "textInputEditText");
        Util.setUpFocusChangeListener$default(util2, textInputEditText3, textInputEditText4, getActivity(), null, 8, null);
    }

    private final void initViewsData(MinorDataResponse childData) {
        ChildDetailFragmentBinding binding = getBinding();
        binding.crcHeaderLayout.tvHeaderTrackingId.setText(getCrcSharedViewModel().getTrackingId());
        binding.crcHeaderLayout.tvHeaderFee.setText(getCrcSharedViewModel().getAmount());
        if (childData.getCitizenNumber().length() > 0) {
            binding.cnicLayout.maskedCnicEditText.setText(childData.getCitizenNumber());
        }
        binding.birthCertificateNumberLayout.textInputEditText.setText(childData.getBirthCertificateNumber());
        binding.certificateTypeLayout.autoCompleteTextView.setText(childData.getCertificateType().getValue());
        binding.fullNameLayout.textInputEditText.setText(childData.getFullName());
        binding.firstNameLayout.textInputEditText.setText(childData.getFirstName());
        binding.lastNameLayout.textInputEditText.setText(childData.getLastName());
        binding.urduFullNameLayout.textInputEditText.setText(childData.getFullNameLocal());
        binding.urduFirstNameLayout.textInputEditText.setText(childData.getFirstNameLocal());
        binding.urduLastNameLayout.textInputEditText.setText(childData.getLastNameLocal());
        binding.genderLayout.autoCompleteTextView.setText(childData.getGender().getValue());
        LibraryResponse libraryResponse = this.selectedGender;
        libraryResponse.setKey(childData.getGender().getKey());
        libraryResponse.setValue(childData.getGender().getValue());
        binding.dateOfBirthLayout.textInputEditText.setText(Util.INSTANCE.dateFormatDateMonthYear(childData.getBirthDate()));
        binding.relationApplicantLayout.autoCompleteTextView.setText(childData.getRelationWithApplicant().getValue());
        LibraryResponse libraryResponse2 = this.selectedRelation;
        libraryResponse2.setKey(childData.getRelationWithApplicant().getKey());
        libraryResponse2.setValue(childData.getRelationWithApplicant().getValue());
        MaterialAutoCompleteTextView materialAutoCompleteTextView = binding.birthCountryLayout.autoCompleteTextView;
        String upperCase = childData.getBirthCountry().getValue().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        materialAutoCompleteTextView.setText(upperCase);
        String lowerCase = childData.getBirthCountry().getKey().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        if (Intrinsics.areEqual(lowerCase, "pak")) {
            binding.birthDistrictLayout.getRoot().setVisibility(0);
            binding.birthProvinceLayout.getRoot().setVisibility(0);
            binding.birthTehsilLayout.getRoot().setVisibility(0);
            binding.birthProvinceLayout.autoCompleteTextView.setText(childData.getBirthProvince().getValue());
            binding.birthDistrictLayout.autoCompleteTextView.setText(childData.getBirthDistrict().getValue());
            binding.birthTehsilLayout.autoCompleteTextView.setText(childData.getBirthTehsil().getValue());
        }
        LibraryResponse libraryResponse3 = this.selectedBirthCountry;
        libraryResponse3.setKey(childData.getBirthCountry().getKey());
        libraryResponse3.setValue(childData.getBirthCountry().getValue());
        LibraryResponse libraryResponse4 = this.selectedBirthProvince;
        libraryResponse4.setKey(childData.getBirthProvince().getKey());
        libraryResponse4.setValue(childData.getBirthProvince().getValue());
        LibraryResponse libraryResponse5 = this.selectedBirthDistrict;
        libraryResponse5.setKey(childData.getBirthDistrict().getKey());
        libraryResponse5.setValue(childData.getBirthDistrict().getValue());
        LibraryResponse libraryResponse6 = this.selectedBirthTehsil;
        libraryResponse6.setKey(childData.getBirthTehsil().getKey());
        libraryResponse6.setValue(childData.getBirthTehsil().getValue());
        binding.twinLayout.autoCompleteTextView.setText(childData.getTwin() ? "Yes" : "No");
        binding.orphanHouseNameLayout.autoCompleteTextView.setText(childData.getOrphanHouseName().getValue());
        LibraryResponse libraryResponse7 = this.selectedOrphanage;
        libraryResponse7.setId(childData.getOrphanHouseName().getId());
        libraryResponse7.setValue(childData.getOrphanHouseName().getValue());
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        TextInputLayout maskedCnicTextInputLayout = binding.cnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        TextInputEditText maskedCnicEditText = binding.cnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        util.disableTextInputEditText((Context) activity, maskedCnicTextInputLayout, maskedCnicEditText, true);
        Util util2 = Util.INSTANCE;
        CRCActivity activity2 = getActivity();
        TextInputLayout textInputLayout = binding.birthCertificateNumberLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout, "textInputLayout");
        TextInputEditText textInputEditText = binding.birthCertificateNumberLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        util2.disableTextInputEditText(activity2, textInputLayout, textInputEditText, childData.getMeta().getBirthCertificateNumber().getDisable());
        Util util3 = Util.INSTANCE;
        CRCActivity activity3 = getActivity();
        TextInputLayout textInputLayout2 = binding.certificateTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView = binding.certificateTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        util3.disableTextInputEditText(activity3, textInputLayout2, autoCompleteTextView, childData.getMeta().getCertificateType().getDisable());
        Util util4 = Util.INSTANCE;
        CRCActivity activity4 = getActivity();
        TextInputLayout textInputLayout3 = binding.fullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout3, "textInputLayout");
        TextInputEditText textInputEditText2 = binding.fullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        util4.disableTextInputEditText(activity4, textInputLayout3, textInputEditText2, childData.getMeta().getName().getDisable());
        Util util5 = Util.INSTANCE;
        CRCActivity activity5 = getActivity();
        TextInputLayout textInputLayout4 = binding.firstNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout4, "textInputLayout");
        TextInputEditText textInputEditText3 = binding.firstNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText3, "textInputEditText");
        util5.disableTextInputEditText(activity5, textInputLayout4, textInputEditText3, childData.getMeta().getFirstName().getDisable());
        Util util6 = Util.INSTANCE;
        CRCActivity activity6 = getActivity();
        TextInputLayout textInputLayout5 = binding.lastNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout5, "textInputLayout");
        TextInputEditText textInputEditText4 = binding.lastNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText4, "textInputEditText");
        util6.disableTextInputEditText(activity6, textInputLayout5, textInputEditText4, childData.getMeta().getLastName().getDisable());
        Util util7 = Util.INSTANCE;
        CRCActivity activity7 = getActivity();
        TextInputLayout textInputLayout6 = binding.urduFullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout6, "textInputLayout");
        TextInputEditText textInputEditText5 = binding.urduFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText5, "textInputEditText");
        util7.disableTextInputEditText(activity7, textInputLayout6, textInputEditText5, childData.getMeta().getNameLocal().getDisable());
        Util util8 = Util.INSTANCE;
        CRCActivity activity8 = getActivity();
        TextInputLayout textInputLayout7 = binding.urduFirstNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout7, "textInputLayout");
        TextInputEditText textInputEditText6 = binding.urduFirstNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText6, "textInputEditText");
        util8.disableTextInputEditText(activity8, textInputLayout7, textInputEditText6, childData.getMeta().getFirstNameLocal().getDisable());
        Util util9 = Util.INSTANCE;
        CRCActivity activity9 = getActivity();
        TextInputLayout textInputLayout8 = binding.urduLastNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout8, "textInputLayout");
        TextInputEditText textInputEditText7 = binding.urduLastNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText7, "textInputEditText");
        util9.disableTextInputEditText(activity9, textInputLayout8, textInputEditText7, childData.getMeta().getLastNameLocal().getDisable());
        if (!childData.getMeta().getFirstNameLocal().getDisable()) {
            Util util10 = Util.INSTANCE;
            TextInputEditText textInputEditText8 = binding.urduFirstNameLayout.textInputEditText;
            Intrinsics.checkNotNullExpressionValue(textInputEditText8, "textInputEditText");
            util10.restrictToUrduOnly(textInputEditText8);
        }
        if (!childData.getMeta().getLastNameLocal().getDisable()) {
            Util util11 = Util.INSTANCE;
            TextInputEditText textInputEditText9 = binding.urduLastNameLayout.textInputEditText;
            Intrinsics.checkNotNullExpressionValue(textInputEditText9, "textInputEditText");
            util11.restrictToUrduOnly(textInputEditText9);
        }
        Util util12 = Util.INSTANCE;
        CRCActivity activity10 = getActivity();
        TextInputLayout textInputLayout9 = binding.genderLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout9, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView2 = binding.genderLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView2, "autoCompleteTextView");
        util12.disableTextInputEditText(activity10, textInputLayout9, autoCompleteTextView2, childData.getMeta().getGender().getDisable());
        Util util13 = Util.INSTANCE;
        CRCActivity activity11 = getActivity();
        TextInputLayout textInputLayout10 = binding.dateOfBirthLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout10, "textInputLayout");
        TextInputEditText textInputEditText10 = binding.dateOfBirthLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText10, "textInputEditText");
        util13.disableTextInputEditText(activity11, textInputLayout10, textInputEditText10, childData.getMeta().getBirthDate().getDisable());
        Util util14 = Util.INSTANCE;
        CRCActivity activity12 = getActivity();
        TextInputLayout textInputLayout11 = binding.relationApplicantLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout11, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView3 = binding.relationApplicantLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView3, "autoCompleteTextView");
        util14.disableTextInputEditText(activity12, textInputLayout11, autoCompleteTextView3, childData.getMeta().getRelationWithApplicant().getDisable());
        Util util15 = Util.INSTANCE;
        CRCActivity activity13 = getActivity();
        TextInputLayout textInputLayout12 = binding.birthCountryLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout12, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView4 = binding.birthCountryLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView4, "autoCompleteTextView");
        util15.disableTextInputEditText(activity13, textInputLayout12, autoCompleteTextView4, childData.getMeta().getBirthCountry().getDisable());
        Util util16 = Util.INSTANCE;
        CRCActivity activity14 = getActivity();
        TextInputLayout textInputLayout13 = binding.birthProvinceLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout13, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView5 = binding.birthProvinceLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView5, "autoCompleteTextView");
        util16.disableTextInputEditText(activity14, textInputLayout13, autoCompleteTextView5, childData.getMeta().getBirthProvince().getDisable());
        Util util17 = Util.INSTANCE;
        CRCActivity activity15 = getActivity();
        TextInputLayout textInputLayout14 = binding.birthDistrictLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout14, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView6 = binding.birthDistrictLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView6, "autoCompleteTextView");
        util17.disableTextInputEditText(activity15, textInputLayout14, autoCompleteTextView6, childData.getMeta().getBirthDistrict().getDisable());
        Util util18 = Util.INSTANCE;
        CRCActivity activity16 = getActivity();
        TextInputLayout textInputLayout15 = binding.twinLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout15, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView7 = binding.twinLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView7, "autoCompleteTextView");
        util18.disableTextInputEditText(activity16, textInputLayout15, autoCompleteTextView7, childData.getMeta().getTwin().getDisable());
        Util util19 = Util.INSTANCE;
        CRCActivity activity17 = getActivity();
        TextInputLayout textInputLayout16 = binding.orphanHouseNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout16, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView8 = binding.orphanHouseNameLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView8, "autoCompleteTextView");
        util19.disableTextInputEditText(activity17, textInputLayout16, autoCompleteTextView8, childData.getMeta().getOrphanagesData().getDisable());
    }

    private final void launchStringPickerActivity(ArrayList<String> arrayList) {
        Intent intent = new Intent(getActivity(), (Class<?>) StringPickerActivity.class);
        intent.putStringArrayListExtra("INTENT_STRING_LIST", arrayList);
        this.startForResult.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startForResult$lambda$36(ChildDetailFragment this$0, ActivityResult result) {
        Intent data;
        String stringExtra;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || (data = result.getData()) == null || !data.hasExtra("INTENT_STRING_ITEM") || (stringExtra = data.getStringExtra("INTENT_STRING_ITEM")) == null) {
            return;
        }
        Object obj = null;
        switch (WhenMappings.$EnumSwitchMapping$0[this$0.dropdownCalling.ordinal()]) {
            case 1:
                Iterator<T> it = this$0.certificateTypeList.iterator();
                while (true) {
                    if (it.hasNext()) {
                        Object next = it.next();
                        if (Intrinsics.areEqual(((LibraryResponse) next).getValue(), stringExtra)) {
                            obj = next;
                        }
                    }
                }
                Intrinsics.checkNotNull(obj);
                this$0.selectedCertificateType = (LibraryResponse) obj;
                CertificateType certificateType = this$0.getChildDetails().getCertificateType();
                certificateType.setKey(this$0.selectedCertificateType.getKey());
                certificateType.setValue(this$0.selectedCertificateType.getValue());
                this$0.getBinding().certificateTypeLayout.autoCompleteTextView.setText(stringExtra);
                break;
            case 2:
                Iterator<T> it2 = this$0.relationsList.iterator();
                while (true) {
                    if (it2.hasNext()) {
                        Object next2 = it2.next();
                        if (Intrinsics.areEqual(((LibraryResponse) next2).getValue(), stringExtra)) {
                            obj = next2;
                        }
                    }
                }
                Intrinsics.checkNotNull(obj);
                this$0.selectedRelation = (LibraryResponse) obj;
                this$0.getBinding().relationApplicantLayout.autoCompleteTextView.setText(stringExtra);
                break;
            case 3:
                Iterator<T> it3 = this$0.genderList.iterator();
                while (true) {
                    if (it3.hasNext()) {
                        Object next3 = it3.next();
                        if (Intrinsics.areEqual(((LibraryResponse) next3).getValue(), stringExtra)) {
                            obj = next3;
                        }
                    }
                }
                Intrinsics.checkNotNull(obj);
                this$0.selectedGender = (LibraryResponse) obj;
                this$0.getBinding().genderLayout.autoCompleteTextView.setText(stringExtra);
                break;
            case 4:
                Iterator<T> it4 = this$0.birthCountriesList.iterator();
                while (true) {
                    if (it4.hasNext()) {
                        Object next4 = it4.next();
                        if (Intrinsics.areEqual(((LibraryResponse) next4).getValue(), stringExtra)) {
                            obj = next4;
                        }
                    }
                }
                Intrinsics.checkNotNull(obj);
                this$0.selectedBirthCountry = (LibraryResponse) obj;
                this$0.getBinding().birthCountryLayout.autoCompleteTextView.setText(stringExtra);
                String lowerCase = stringExtra.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                if (Intrinsics.areEqual(lowerCase, "pakistan")) {
                    this$0.getBinding().birthProvinceLayout.getRoot().setVisibility(0);
                } else {
                    this$0.getBinding().birthProvinceLayout.getRoot().setVisibility(8);
                    this$0.getBinding().birthDistrictLayout.getRoot().setVisibility(8);
                    this$0.getBinding().birthTehsilLayout.getRoot().setVisibility(8);
                }
                this$0.getBinding().birthProvinceLayout.autoCompleteTextView.setText("");
                this$0.getBinding().birthDistrictLayout.autoCompleteTextView.setText("");
                this$0.getBinding().birthTehsilLayout.autoCompleteTextView.setText("");
                this$0.selectedBirthProvince = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
                this$0.selectedBirthDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
                this$0.selectedBirthTehsil = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
                break;
            case 5:
                Iterator<T> it5 = this$0.birthProvincesList.iterator();
                while (true) {
                    if (it5.hasNext()) {
                        Object next5 = it5.next();
                        if (Intrinsics.areEqual(((LibraryResponse) next5).getValue(), stringExtra)) {
                            obj = next5;
                        }
                    }
                }
                Intrinsics.checkNotNull(obj);
                this$0.selectedBirthProvince = (LibraryResponse) obj;
                this$0.getBinding().birthProvinceLayout.autoCompleteTextView.setText(stringExtra);
                this$0.getBinding().birthDistrictLayout.autoCompleteTextView.setText("");
                this$0.selectedBirthDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
                this$0.getBinding().birthDistrictLayout.getRoot().setVisibility(0);
                break;
            case 6:
                Iterator<T> it6 = this$0.birthDistrictsList.iterator();
                while (true) {
                    if (it6.hasNext()) {
                        Object next6 = it6.next();
                        if (Intrinsics.areEqual(((LibraryResponse) next6).getValue(), stringExtra)) {
                            obj = next6;
                        }
                    }
                }
                Intrinsics.checkNotNull(obj);
                this$0.selectedBirthDistrict = (LibraryResponse) obj;
                this$0.getBinding().birthDistrictLayout.autoCompleteTextView.setText(stringExtra);
                this$0.getBinding().birthTehsilLayout.autoCompleteTextView.setText("");
                this$0.selectedBirthTehsil = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
                this$0.getBinding().birthTehsilLayout.getRoot().setVisibility(0);
                break;
            case 7:
                Iterator<T> it7 = this$0.birthTehsilsList.iterator();
                while (true) {
                    if (it7.hasNext()) {
                        Object next7 = it7.next();
                        if (Intrinsics.areEqual(((LibraryResponse) next7).getValue(), stringExtra)) {
                            obj = next7;
                        }
                    }
                }
                Intrinsics.checkNotNull(obj);
                this$0.selectedBirthTehsil = (LibraryResponse) obj;
                this$0.getBinding().birthTehsilLayout.autoCompleteTextView.setText(stringExtra);
                break;
            case 8:
                this$0.getBinding().twinLayout.autoCompleteTextView.setText(stringExtra);
                break;
            case 9:
                Iterator<T> it8 = this$0.orphanHouseName.iterator();
                while (true) {
                    if (it8.hasNext()) {
                        Object next8 = it8.next();
                        if (Intrinsics.areEqual(((LibraryResponse) next8).getValue(), stringExtra)) {
                            obj = next8;
                        }
                    }
                }
                Intrinsics.checkNotNull(obj);
                this$0.selectedOrphanage = (LibraryResponse) obj;
                this$0.getBinding().orphanHouseNameLayout.autoCompleteTextView.setText(stringExtra);
                break;
        }
    }

    private final void launchNextActivity() {
        ChildDetailFragmentBinding binding = getBinding();
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        TextInputLayout textInputLayout = binding.certificateTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView = binding.certificateTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        boolean zValidateAutoCompleteTextView = util.validateAutoCompleteTextView(activity, textInputLayout, autoCompleteTextView);
        Util util2 = Util.INSTANCE;
        CRCActivity activity2 = getActivity();
        TextInputLayout textInputLayout2 = binding.genderLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView2 = binding.genderLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView2, "autoCompleteTextView");
        if (!util2.validateAutoCompleteTextView(activity2, textInputLayout2, autoCompleteTextView2)) {
            zValidateAutoCompleteTextView = false;
        }
        Util util3 = Util.INSTANCE;
        CRCActivity activity3 = getActivity();
        TextInputLayout textInputLayout3 = binding.dateOfBirthLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout3, "textInputLayout");
        TextInputEditText textInputEditText = binding.dateOfBirthLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        if (!util3.validateEditText(activity3, textInputLayout3, textInputEditText)) {
            zValidateAutoCompleteTextView = false;
        }
        Util util4 = Util.INSTANCE;
        CRCActivity activity4 = getActivity();
        TextInputLayout textInputLayout4 = binding.relationApplicantLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout4, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView3 = binding.relationApplicantLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView3, "autoCompleteTextView");
        if (!util4.validateAutoCompleteTextView(activity4, textInputLayout4, autoCompleteTextView3)) {
            zValidateAutoCompleteTextView = false;
        }
        Util util5 = Util.INSTANCE;
        CRCActivity activity5 = getActivity();
        TextInputLayout textInputLayout5 = binding.birthCountryLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout5, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView4 = binding.birthCountryLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView4, "autoCompleteTextView");
        if (!util5.validateAutoCompleteTextView(activity5, textInputLayout5, autoCompleteTextView4)) {
            zValidateAutoCompleteTextView = false;
        }
        Util util6 = Util.INSTANCE;
        CRCActivity activity6 = getActivity();
        TextInputLayout textInputLayout6 = binding.twinLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout6, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView5 = binding.twinLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView5, "autoCompleteTextView");
        if (util6.validateAutoCompleteTextView(activity6, textInputLayout6, autoCompleteTextView5) ? zValidateAutoCompleteTextView : false) {
            getViewsData();
        }
    }

    private final void getViewsData() {
        ChildDetailFragmentBinding binding = getBinding();
        MinorDataResponse childDetails = getChildDetails();
        childDetails.setCitizenNumber(StringsKt.replace$default(String.valueOf(binding.cnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null));
        childDetails.setBirthCertificateNumber(String.valueOf(binding.birthCertificateNumberLayout.textInputEditText.getText()));
        childDetails.setFullName(String.valueOf(binding.fullNameLayout.textInputEditText.getText()));
        childDetails.setFirstName(String.valueOf(binding.firstNameLayout.textInputEditText.getText()));
        childDetails.setLastName(String.valueOf(binding.lastNameLayout.textInputEditText.getText()));
        childDetails.setFullNameLocal(String.valueOf(binding.urduFullNameLayout.textInputEditText.getText()));
        childDetails.setFirstNameLocal(String.valueOf(binding.urduFirstNameLayout.textInputEditText.getText()));
        childDetails.setLastNameLocal(String.valueOf(binding.urduLastNameLayout.textInputEditText.getText()));
        Gender gender = childDetails.getGender();
        gender.setKey(this.selectedGender.getKey());
        gender.setValue(this.selectedGender.getValue());
        childDetails.setBirthDate(Util.INSTANCE.dateFormatYearMonthDate(String.valueOf(binding.dateOfBirthLayout.textInputEditText.getText())));
        RelationWithApplicant relationWithApplicant = childDetails.getRelationWithApplicant();
        relationWithApplicant.setKey(this.selectedRelation.getKey());
        relationWithApplicant.setValue(this.selectedRelation.getValue());
        BirthCountry birthCountry = childDetails.getBirthCountry();
        birthCountry.setKey(this.selectedBirthCountry.getKey());
        birthCountry.setValue(this.selectedBirthCountry.getValue());
        BirthProvince birthProvince = childDetails.getBirthProvince();
        birthProvince.setKey(this.selectedBirthProvince.getKey());
        birthProvince.setValue(this.selectedBirthProvince.getValue());
        BirthDistrict birthDistrict = childDetails.getBirthDistrict();
        birthDistrict.setKey(this.selectedBirthDistrict.getKey());
        birthDistrict.setValue(this.selectedBirthDistrict.getValue());
        BirthTehsil birthTehsil = childDetails.getBirthTehsil();
        birthTehsil.setKey(this.selectedBirthTehsil.getKey());
        birthTehsil.setValue(this.selectedBirthTehsil.getValue());
        String lowerCase = binding.twinLayout.autoCompleteTextView.getText().toString().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        childDetails.setTwin(Intrinsics.areEqual(lowerCase, "yes"));
        OrphanHouseName orphanHouseName = childDetails.getOrphanHouseName();
        orphanHouseName.setId(this.selectedOrphanage.getId());
        orphanHouseName.setValue(this.selectedOrphanage.getValue());
        getCrcSharedViewModel().setChildDetails(getChildDetails());
        getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.childParentDetailFragment);
    }

    private final void getBirthCertificateType() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(null), 3, null);
    }

    /* compiled from: ChildDetailFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getBirthCertificateType$1", f = "ChildDetailFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getBirthCertificateType$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ChildDetailFragment.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ChildDetailFragment.this.getActivity());
            final ChildDetailFragment childDetailFragment = ChildDetailFragment.this;
            aPIRequests.birthCertificateType(new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getBirthCertificateType$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ChildDetailFragment.AnonymousClass1.invokeSuspend$lambda$0(childDetailFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ChildDetailFragment childDetailFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(childDetailFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getBirthCertificateType() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                childDetailFragment.processLibrarySuccessResponse(jsonArray, MethodName.CERTIFICATE_TYPE);
            } else {
                childDetailFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getGendersList() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12201(null), 3, null);
    }

    /* compiled from: ChildDetailFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getGendersList$1", f = "ChildDetailFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getGendersList$1, reason: invalid class name and case insensitive filesystem */
    static final class C12201 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12201(Continuation<? super C12201> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ChildDetailFragment.this.new C12201(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12201) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ChildDetailFragment.this.getActivity());
            final ChildDetailFragment childDetailFragment = ChildDetailFragment.this;
            aPIRequests.getGendersList(new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getGendersList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ChildDetailFragment.C12201.invokeSuspend$lambda$0(childDetailFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ChildDetailFragment childDetailFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(childDetailFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getGendersList() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                childDetailFragment.processLibrarySuccessResponse(jsonArray, MethodName.CERTIFICATE_TYPE);
            } else {
                childDetailFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getRelationsList() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12231(null), 3, null);
    }

    /* compiled from: ChildDetailFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getRelationsList$1", f = "ChildDetailFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getRelationsList$1, reason: invalid class name and case insensitive filesystem */
    static final class C12231 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12231(Continuation<? super C12231> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ChildDetailFragment.this.new C12231(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12231) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ChildDetailFragment.this.getActivity());
            final ChildDetailFragment childDetailFragment = ChildDetailFragment.this;
            aPIRequests.getRelationsList(new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getRelationsList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ChildDetailFragment.C12231.invokeSuspend$lambda$0(childDetailFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ChildDetailFragment childDetailFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(childDetailFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getRelationsList() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                childDetailFragment.processLibrarySuccessResponse(jsonArray, MethodName.CERTIFICATE_TYPE);
            } else {
                childDetailFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getCountriesList() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12181(null), 3, null);
    }

    /* compiled from: ChildDetailFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getCountriesList$1", f = "ChildDetailFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getCountriesList$1, reason: invalid class name and case insensitive filesystem */
    static final class C12181 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12181(Continuation<? super C12181> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ChildDetailFragment.this.new C12181(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12181) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ChildDetailFragment.this.getActivity());
            final ChildDetailFragment childDetailFragment = ChildDetailFragment.this;
            aPIRequests.getCountriesList(new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getCountriesList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ChildDetailFragment.C12181.invokeSuspend$lambda$0(childDetailFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ChildDetailFragment childDetailFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(childDetailFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getCountriesList() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                childDetailFragment.processLibrarySuccessResponse(jsonArray, MethodName.CERTIFICATE_TYPE);
            } else {
                childDetailFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getProvincesList() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12221(null), 3, null);
    }

    /* compiled from: ChildDetailFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getProvincesList$1", f = "ChildDetailFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getProvincesList$1, reason: invalid class name and case insensitive filesystem */
    static final class C12221 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12221(Continuation<? super C12221> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ChildDetailFragment.this.new C12221(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12221) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ChildDetailFragment.this.getActivity());
            final ChildDetailFragment childDetailFragment = ChildDetailFragment.this;
            aPIRequests.getProvincesList(new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getProvincesList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ChildDetailFragment.C12221.invokeSuspend$lambda$0(childDetailFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ChildDetailFragment childDetailFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(childDetailFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getProvincesList() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                childDetailFragment.processLibrarySuccessResponse(jsonArray, MethodName.CERTIFICATE_TYPE);
            } else {
                childDetailFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getDistrictsList(String provinceId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12191(provinceId, null), 3, null);
    }

    /* compiled from: ChildDetailFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getDistrictsList$1", f = "ChildDetailFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getDistrictsList$1, reason: invalid class name and case insensitive filesystem */
    static final class C12191 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $provinceId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12191(String str, Continuation<? super C12191> continuation) {
            super(2, continuation);
            this.$provinceId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ChildDetailFragment.this.new C12191(this.$provinceId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12191) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ChildDetailFragment.this.getActivity());
            String str = this.$provinceId;
            final ChildDetailFragment childDetailFragment = ChildDetailFragment.this;
            aPIRequests.getDistrictsList(str, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getDistrictsList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ChildDetailFragment.C12191.invokeSuspend$lambda$0(childDetailFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ChildDetailFragment childDetailFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(childDetailFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getDistrictsList() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                childDetailFragment.processLibrarySuccessResponse(jsonArray, MethodName.CERTIFICATE_TYPE);
            } else {
                childDetailFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getTehsilsList(String districtId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12241(districtId, null), 3, null);
    }

    /* compiled from: ChildDetailFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getTehsilsList$1", f = "ChildDetailFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getTehsilsList$1, reason: invalid class name and case insensitive filesystem */
    static final class C12241 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $districtId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12241(String str, Continuation<? super C12241> continuation) {
            super(2, continuation);
            this.$districtId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ChildDetailFragment.this.new C12241(this.$districtId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12241) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ChildDetailFragment.this.getActivity());
            String str = this.$districtId;
            final ChildDetailFragment childDetailFragment = ChildDetailFragment.this;
            aPIRequests.getTehsilsList(str, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getTehsilsList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ChildDetailFragment.C12241.invokeSuspend$lambda$0(childDetailFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ChildDetailFragment childDetailFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(childDetailFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getTehsilsList() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                childDetailFragment.processLibrarySuccessResponse(jsonArray, MethodName.CERTIFICATE_TYPE);
            } else {
                childDetailFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getOrphanages() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12211(null), 3, null);
    }

    /* compiled from: ChildDetailFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getOrphanages$1", f = "ChildDetailFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getOrphanages$1, reason: invalid class name and case insensitive filesystem */
    static final class C12211 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12211(Continuation<? super C12211> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ChildDetailFragment.this.new C12211(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12211) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ChildDetailFragment.this.getActivity());
            final ChildDetailFragment childDetailFragment = ChildDetailFragment.this;
            aPIRequests.getOrphanages(new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$getOrphanages$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ChildDetailFragment.C12211.invokeSuspend$lambda$0(childDetailFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ChildDetailFragment childDetailFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(childDetailFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getOrphanages() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                childDetailFragment.processLibrarySuccessResponse(jsonArray, MethodName.CERTIFICATE_TYPE);
            } else {
                childDetailFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processLibrarySuccessResponse(JsonArray jSonObject, MethodName methodName) throws JsonSyntaxException {
        Object objFromJson = new Gson().fromJson(jSonObject.toString(), (Class<Object>) LibraryResponse[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List mutableList = ArraysKt.toMutableList((Object[]) objFromJson);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("LibraryResponse", methodName + " :: Response: " + mutableList);
        }
        ArrayList arrayList = new ArrayList<>();
        switch (WhenMappings.$EnumSwitchMapping$0[this.dropdownCalling.ordinal()]) {
            case 1:
                this.certificateTypeList = new ArrayList<>();
                Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
                ArrayList<LibraryResponse> arrayList2 = (ArrayList) mutableList;
                this.certificateTypeList = arrayList2;
                ArrayList arrayList3 = new ArrayList();
                for (Object obj : arrayList2) {
                    String lowerCase = ((LibraryResponse) obj).getKey().toLowerCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                    if (!Intrinsics.areEqual(lowerCase, "other")) {
                        arrayList3.add(obj);
                    }
                }
                ArrayList arrayList4 = arrayList3;
                ArrayList arrayList5 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList4, 10));
                Iterator it = arrayList4.iterator();
                while (it.hasNext()) {
                    arrayList5.add(((LibraryResponse) it.next()).getValue());
                }
                arrayList = arrayList5;
                break;
            case 2:
                this.relationsList = new ArrayList<>();
                Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
                ArrayList<LibraryResponse> arrayList6 = (ArrayList) mutableList;
                this.relationsList = arrayList6;
                ArrayList<LibraryResponse> arrayList7 = arrayList6;
                ArrayList arrayList8 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList7, 10));
                Iterator<T> it2 = arrayList7.iterator();
                while (it2.hasNext()) {
                    arrayList8.add(((LibraryResponse) it2.next()).getValue());
                }
                arrayList = arrayList8;
                break;
            case 3:
                this.genderList = new ArrayList<>();
                Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
                ArrayList<LibraryResponse> arrayList9 = (ArrayList) mutableList;
                this.genderList = arrayList9;
                ArrayList<LibraryResponse> arrayList10 = arrayList9;
                ArrayList arrayList11 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList10, 10));
                Iterator<T> it3 = arrayList10.iterator();
                while (it3.hasNext()) {
                    arrayList11.add(((LibraryResponse) it3.next()).getValue());
                }
                arrayList = arrayList11;
                break;
            case 4:
                this.birthCountriesList = new ArrayList<>();
                Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
                ArrayList<LibraryResponse> arrayList12 = (ArrayList) mutableList;
                this.birthCountriesList = arrayList12;
                ArrayList<LibraryResponse> arrayList13 = arrayList12;
                ArrayList arrayList14 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList13, 10));
                Iterator<T> it4 = arrayList13.iterator();
                while (it4.hasNext()) {
                    arrayList14.add(((LibraryResponse) it4.next()).getValue());
                }
                arrayList = arrayList14;
                break;
            case 5:
                this.birthProvincesList = new ArrayList<>();
                Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
                ArrayList<LibraryResponse> arrayList15 = (ArrayList) mutableList;
                this.birthProvincesList = arrayList15;
                ArrayList<LibraryResponse> arrayList16 = arrayList15;
                ArrayList arrayList17 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList16, 10));
                Iterator<T> it5 = arrayList16.iterator();
                while (it5.hasNext()) {
                    arrayList17.add(((LibraryResponse) it5.next()).getValue());
                }
                arrayList = arrayList17;
                break;
            case 6:
                this.birthDistrictsList = new ArrayList<>();
                Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
                ArrayList<LibraryResponse> arrayList18 = (ArrayList) mutableList;
                this.birthDistrictsList = arrayList18;
                ArrayList<LibraryResponse> arrayList19 = arrayList18;
                ArrayList arrayList20 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList19, 10));
                Iterator<T> it6 = arrayList19.iterator();
                while (it6.hasNext()) {
                    arrayList20.add(((LibraryResponse) it6.next()).getValue());
                }
                arrayList = arrayList20;
                break;
            case 7:
                this.birthTehsilsList = new ArrayList<>();
                Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
                ArrayList<LibraryResponse> arrayList21 = (ArrayList) mutableList;
                this.birthTehsilsList = arrayList21;
                ArrayList<LibraryResponse> arrayList22 = arrayList21;
                ArrayList arrayList23 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList22, 10));
                Iterator<T> it7 = arrayList22.iterator();
                while (it7.hasNext()) {
                    arrayList23.add(((LibraryResponse) it7.next()).getValue());
                }
                arrayList = arrayList23;
                break;
            case 9:
                this.orphanHouseName = new ArrayList<>();
                Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
                ArrayList<LibraryResponse> arrayList24 = (ArrayList) mutableList;
                this.orphanHouseName = arrayList24;
                ArrayList<LibraryResponse> arrayList25 = arrayList24;
                ArrayList arrayList26 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList25, 10));
                Iterator<T> it8 = arrayList25.iterator();
                while (it8.hasNext()) {
                    arrayList26.add(((LibraryResponse) it8.next()).getValue());
                }
                arrayList = arrayList26;
                break;
        }
        if (arrayList.isEmpty()) {
            return;
        }
        launchStringPickerActivity(arrayList);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCaseJsonArray(JsonArray jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson((JsonElement) jsonResponse.get(0).getAsJsonObject(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    for (ErrorResponse.Error error : errors) {
                        TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                        if (textInputLayout != null) {
                            textInputLayout.setError(String.valueOf(error.getMessage()));
                            textInputLayout.setErrorEnabled(true);
                        }
                    }
                    return;
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            CRCActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return ChildDetailFragment.handleFailureCaseJsonArray$lambda$60(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda11
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ChildDetailFragment.handleFailureCaseJsonArray$lambda$61(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$60(ChildDetailFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$61(ChildDetailFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    @Override // android.view.View.OnFocusChangeListener
    public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus || v == null) {
            return;
        }
        ViewUtils.hideKeyboard(v, true);
    }

    private final void scrollToView(final TextInputLayout view) {
        getBinding().childDetailsScrollView.post(new Runnable() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                ChildDetailFragment.scrollToView$lambda$62(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void scrollToView$lambda$62(ChildDetailFragment this$0, TextInputLayout view) {
        int top;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(view, "$view");
        Rect rect = new Rect();
        this$0.getBinding().childDetailsScrollView.getHitRect(rect);
        int iHeight = rect.height();
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        int[] iArr2 = new int[2];
        this$0.getBinding().childDetailsScrollView.getLocationOnScreen(iArr2);
        int i = iArr[1] - iArr2[1];
        int height = view.getHeight();
        if (i < 0) {
            top = view.getTop();
        } else if (i + height > iHeight) {
            top = view.getBottom() - iHeight;
        } else {
            top = (view.getTop() - (iHeight / 2)) + (height / 2);
        }
        this$0.getBinding().childDetailsScrollView.smoothScrollTo(0, top);
    }

    private final void initFooterView() {
        ChildDetailFragmentBinding binding = getBinding();
        binding.crcFooterLayout.backButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.initFooterView$lambda$65$lambda$63(this.f$0, view);
            }
        });
        binding.crcFooterLayout.backButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Back", "\n(واپس جائیں)", 0, false, 12, null));
        MaterialButton materialButton = binding.crcFooterLayout.nextButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.next);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        materialButton.setText(Util.setEnglishTextSpan$default(util, activity, string, "\n(آگے بڑھیں)", 0, false, 12, null));
        binding.crcFooterLayout.nextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDetailFragment.initFooterView$lambda$65$lambda$64(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$65$lambda$63(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$65$lambda$64(ChildDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.launchNextActivity();
    }
}