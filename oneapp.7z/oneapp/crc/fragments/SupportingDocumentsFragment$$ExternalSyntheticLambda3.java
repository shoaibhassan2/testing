package pk.gov.nadra.oneapp.crc.fragments;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import pk.gov.nadra.oneapp.crc.databinding.CrcSupportingDocumentsFragmentBinding;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SupportingDocumentsFragment$$ExternalSyntheticLambda3 implements SwipeRefreshLayout.OnRefreshListener {
    public final /* synthetic */ CrcSupportingDocumentsFragmentBinding f$1;

    public /* synthetic */ SupportingDocumentsFragment$$ExternalSyntheticLambda3(CrcSupportingDocumentsFragmentBinding crcSupportingDocumentsFragmentBinding) {
        binding = crcSupportingDocumentsFragmentBinding;
    }

    @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
    public final void onRefresh() {
        SupportingDocumentsFragment.onViewCreated$lambda$11$lambda$10(this.f$0, binding);
    }
}