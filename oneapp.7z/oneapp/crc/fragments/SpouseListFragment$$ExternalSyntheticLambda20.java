package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SpouseListFragment$$ExternalSyntheticLambda20 implements View.OnClickListener {
    public /* synthetic */ SpouseListFragment$$ExternalSyntheticLambda20() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        SpouseListFragment.onViewCreated$lambda$6$lambda$0(this.f$0, view);
    }
}