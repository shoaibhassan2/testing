package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ReviewFragment$$ExternalSyntheticLambda5 implements Function0 {
    public /* synthetic */ ReviewFragment$$ExternalSyntheticLambda5() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return ReviewFragment.handleFailureCase$lambda$8(this.f$0);
    }
}