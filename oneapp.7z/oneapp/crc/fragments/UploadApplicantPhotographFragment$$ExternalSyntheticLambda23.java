package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class UploadApplicantPhotographFragment$$ExternalSyntheticLambda23 implements View.OnClickListener {
    public /* synthetic */ UploadApplicantPhotographFragment$$ExternalSyntheticLambda23() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UploadApplicantPhotographFragment.initFooterView$lambda$33$lambda$29(this.f$0, view);
    }
}