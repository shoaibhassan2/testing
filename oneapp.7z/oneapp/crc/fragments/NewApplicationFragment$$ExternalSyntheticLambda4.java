package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class NewApplicationFragment$$ExternalSyntheticLambda4 implements Function0 {
    public /* synthetic */ NewApplicationFragment$$ExternalSyntheticLambda4() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return NewApplicationFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
    }
}