package pk.gov.nadra.oneapp.crc.fragments;

import android.net.Uri;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class UploadPhotographFragment$$ExternalSyntheticLambda2 implements ActivityResultCallback {
    public /* synthetic */ UploadPhotographFragment$$ExternalSyntheticLambda2() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        UploadPhotographFragment.photoPickerLauncher$lambda$22(this.f$0, (Uri) obj);
    }
}