package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class NewApplicationFragment$$ExternalSyntheticLambda11 implements Function0 {
    public /* synthetic */ NewApplicationFragment$$ExternalSyntheticLambda11() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return NewApplicationFragment.handleFailureCaseJsonArray$lambda$47(this.f$0);
    }
}