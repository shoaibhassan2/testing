package pk.gov.nadra.oneapp.crc.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SpouseListFragment$$ExternalSyntheticLambda18 implements ActivityResultCallback {
    public /* synthetic */ SpouseListFragment$$ExternalSyntheticLambda18() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        SpouseListFragment.cropLauncher$lambda$26(this.f$0, (ActivityResult) obj);
    }
}