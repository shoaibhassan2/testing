package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDetailFragment$$ExternalSyntheticLambda15 implements View.OnClickListener {
    public /* synthetic */ ChildDetailFragment$$ExternalSyntheticLambda15() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ChildDetailFragment.attachLayoutViews$lambda$18$lambda$14(this.f$0, view);
    }
}