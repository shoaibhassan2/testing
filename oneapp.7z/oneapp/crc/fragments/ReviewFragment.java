package pk.gov.nadra.oneapp.crc.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.FileProvider;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.File;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.pdf.ViewPdfActivity;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data;
import pk.gov.nadra.oneapp.crc.adapter.viewmodel.CRCSharedViewModel;
import pk.gov.nadra.oneapp.crc.databinding.ReviewFragmentBinding;
import pk.gov.nadra.oneapp.crc.fragments.ReviewFragment;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;
import pk.gov.nadra.oneapp.models.certificate.Document;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.GeneratePdfResponse;
import pk.gov.nadra.oneapp.models.crc.SubmitFormReceivingRequest;
import pk.gov.nadra.oneapp.models.crc.minor.ChildDataResponse;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: ReviewFragment.kt */
@Metadata(d1 = {"\u0000~\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001aH\u0016J$\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001e2\b\u0010\u001f\u001a\u0004\u0018\u00010 2\b\u0010!\u001a\u0004\u0018\u00010\"H\u0016J\u001a\u0010#\u001a\u00020\u00182\u0006\u0010$\u001a\u00020\u001c2\b\u0010!\u001a\u0004\u0018\u00010\"H\u0016J\b\u0010%\u001a\u00020\u0018H\u0002J\u0010\u0010&\u001a\u00020\u00182\u0006\u0010'\u001a\u00020(H\u0002J\u0010\u0010)\u001a\u00020\u00182\u0006\u0010*\u001a\u00020+H\u0002J\u0018\u0010,\u001a\u00020\u00182\u0006\u0010-\u001a\u00020+2\u0006\u0010.\u001a\u00020/H\u0002J\u0010\u00100\u001a\u00020\u00182\u0006\u00101\u001a\u00020(H\u0002J\b\u00104\u001a\u00020\u0018H\u0002J\u0010\u00105\u001a\u00020\u00182\u0006\u0010*\u001a\u00020+H\u0002J\u0010\u00106\u001a\u00020\u00182\u0006\u00107\u001a\u00020(H\u0002J\u0012\u00108\u001a\u0004\u0018\u0001092\u0006\u0010:\u001a\u00020;H\u0002J\u0010\u0010<\u001a\u00020\u00182\u0006\u0010=\u001a\u00020(H\u0002J\u0010\u0010>\u001a\u00020\u00182\u0006\u0010'\u001a\u00020(H\u0002J\u0010\u0010?\u001a\u00020\u00182\u0006\u0010*\u001a\u00020+H\u0002J\b\u0010@\u001a\u00020\u0018H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00102\u001a\u000203X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006A"}, d2 = {"Lpk/gov/nadra/oneapp/crc/fragments/ReviewFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/crc/databinding/ReviewFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/ReviewFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/crc/views/CRCActivity;)V", "attestationRequired", "", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "updateProphetHoodCheckBoxVisibility", "generatePdf", "trackingId", "", "processGeneratePdfSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "handleFailureCase", "jsonResponse", "responseCode", "", "writePdfBase64Data", "photoBase64", "iwritePdfBase64DataServiceResult", "Lpk/gov/nadra/oneapp/commonutils/utils/WritePhotoBase64Data$ICompressImageTaskListener;", "submitFormReceiving", "processSubmitFormReceivingSuccessResponse", "sharePdf", "documentPath", "getFileUri", "Landroid/net/Uri;", "pdfFile", "Ljava/io/File;", "writeBase64ToFile", "pdfBase64", "getTrackingData", "processTrackingDataSuccessResponse", "initFooterView", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ReviewFragment extends Fragment {
    private ReviewFragmentBinding _binding;
    public CRCActivity activity;
    private boolean attestationRequired;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;
    private WritePhotoBase64Data.ICompressImageTaskListener iwritePdfBase64DataServiceResult = new WritePhotoBase64Data.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$iwritePdfBase64DataServiceResult$1
        @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
        public void onComplete(File compressed) {
            Intrinsics.checkNotNullParameter(compressed, "compressed");
            LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
            ReviewFragment reviewFragment = this.this$0;
            String absolutePath = compressed.getAbsolutePath();
            Intrinsics.checkNotNullExpressionValue(absolutePath, "getAbsolutePath(...)");
            reviewFragment.sharePdf(absolutePath);
        }

        @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
        public void onError() {
            LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
        }
    };

    public ReviewFragment() {
        final ReviewFragment reviewFragment = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(reviewFragment, Reflection.getOrCreateKotlinClass(CRCSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = reviewFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = reviewFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = reviewFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final CRCSharedViewModel getCrcSharedViewModel() {
        return (CRCSharedViewModel) this.crcSharedViewModel.getValue();
    }

    private final ReviewFragmentBinding getBinding() {
        ReviewFragmentBinding reviewFragmentBinding = this._binding;
        Intrinsics.checkNotNull(reviewFragmentBinding);
        return reviewFragmentBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final CRCActivity getActivity() {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity != null) {
            return cRCActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(CRCActivity cRCActivity) {
        Intrinsics.checkNotNullParameter(cRCActivity, "<set-?>");
        this.activity = cRCActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.crc.views.CRCActivity");
        setActivity((CRCActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = ReviewFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        ReviewFragmentBinding binding = getBinding();
        TextView textView = binding.crcHeaderLayout.textTitle;
        String upperCase = getCrcSharedViewModel().getDocumentTypeValue().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(String.valueOf(upperCase));
        binding.crcHeaderLayout.textSubtitle.setText(String.valueOf(getCrcSharedViewModel().getApplicationTypeValue()));
        binding.crcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.roboto_medium));
        binding.crcHeaderLayout.iconHome.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ReviewFragment.onViewCreated$lambda$4$lambda$0(this.f$0, view2);
            }
        });
        binding.crcHeaderLayout.iconInfo.setVisibility(0);
        binding.crcHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ReviewFragment.onViewCreated$lambda$4$lambda$1(this.f$0, view2);
            }
        });
        binding.crcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$$ExternalSyntheticLambda8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ReviewFragment.onViewCreated$lambda$4$lambda$2(this.f$0, view2);
            }
        });
        getBinding().crcHeaderLayout.tvHeaderTrackingId.setText(getCrcSharedViewModel().getTrackingId());
        getBinding().crcHeaderLayout.tvHeaderFee.setText(String.valueOf(getCrcSharedViewModel().getAmount()));
        getBinding().crcHeaderLayout.tvHeaderTrackingId.setText(getCrcSharedViewModel().getTrackingId());
        binding.stepTitleHeadingLayout.tvStepTitleHeading.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Review Information", "\nمعلومات کا جائزہ لیں", 0, false, 12, null));
        binding.stepTitleHeadingLayout.tvMandatoryField.setText("Review your complete application data");
        binding.reviewDataTextView.setText("اپنی درخواست کے مکمل ڈیٹا کا جائزہ لیں");
        binding.stepTitleHeadingLayout.tvStrikeMandatory.setVisibility(8);
        binding.reviewDataButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Review Your Data", " (اپنے ڈیٹا کا جائزہ لیں) ", 0, false, 12, null));
        binding.reviewDataButton.setFilled(true);
        binding.reviewDataButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ReviewFragment.onViewCreated$lambda$4$lambda$3(this.f$0, view2);
            }
        });
        MaterialCheckBox materialCheckBox = binding.declInfoConcealP;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.declInfoConcealP);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        materialCheckBox.setText(Util.setEnglishTextSpan$default(util, activity, string, "\nمن محلف / محلفہ حلفیہ بیان کرتا /کرتی ہوں کہ میرے علم کے مطابق  مندرجہ بالا فراہم کردہ معلومات درست ہیں اور کوئی امرء مخفی نہ رکھا گیاہے۔", 0, false, 12, null));
        MaterialCheckBox materialCheckBox2 = binding.declInfoClarityP;
        Util util2 = Util.INSTANCE;
        CRCActivity activity2 = getActivity();
        String string2 = getString(R.string.declInfoClarityP);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        materialCheckBox2.setText(Util.setEnglishTextSpan$default(util2, activity2, string2, "\nمیں سمجھتا / سمجھتی ہوں کہ مندرجہ بالا معلومات  میں ہر نقطہ کی میں نے وضاحت حاصل کی ہے جو میرے لیے غیر واضح تھا.", 0, false, 12, null));
        MaterialCheckBox materialCheckBox3 = binding.declInfoVerificationP;
        Util util3 = Util.INSTANCE;
        CRCActivity activity3 = getActivity();
        String string3 = getString(R.string.declInfoVerificationP);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        materialCheckBox3.setText(Util.setEnglishTextSpan$default(util3, activity3, string3, "\nمیں سمجھتا / سمجھتی ہوں کہ مندرجہ بالا معلومات   جو میں نے فراہم  کی ہیں  وہ تصدیق کی جا سکتی ہے اور میں اس کی اجازت دیتا/دیتی  ہوں۔", 0, false, 12, null));
        MaterialCheckBox materialCheckBox4 = binding.declInfoCorrectP;
        Util util4 = Util.INSTANCE;
        CRCActivity activity4 = getActivity();
        String string4 = getString(R.string.declInfoCorrectP);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        materialCheckBox4.setText(Util.setEnglishTextSpan$default(util4, activity4, string4, "\nمیں تصدیق کرتا  /کرتی ہوں کہ کسی بھی فارم اور منسلک دستاویزات میں فراہم کی  گئی معلومات مکمل درست اور صحیح ہیں-اگر میں جھوٹی یا گمراہ کن معلومات فراہم کروں تو میرے خلاف ادارے کو قانونی کارروائی کا حق حاصل ہے۔", 0, false, 12, null));
        MaterialCheckBox materialCheckBox5 = binding.declPrisonCourtP;
        Util util5 = Util.INSTANCE;
        CRCActivity activity5 = getActivity();
        String string5 = getString(R.string.declPrisonCourtP);
        Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
        materialCheckBox5.setText(Util.setEnglishTextSpan$default(util5, activity5, string5, "\nمن محلف / محلفہ حلفیہ بیان کرتا /کرتی ہوں کہ میں کسی بھی  فوجداری مقدمے میں مجرم نہیں ٹھہرایا گيا /گئی ہوں اور نہ ہی میرے خلاف کوئی فوجداری مقدمہ کسی بھی ادارے کے پاس زیرالتوء ہے۔", 0, false, 12, null));
        MaterialCheckBox materialCheckBox6 = binding.declCriminalCaseP;
        Util util6 = Util.INSTANCE;
        CRCActivity activity6 = getActivity();
        String string6 = getString(R.string.declCriminalCaseP);
        Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
        materialCheckBox6.setText(Util.setEnglishTextSpan$default(util6, activity6, string6, "\nمن محلف / محلفہ حلفیہ بیان کرتا /کرتی ہوں کہ آپ کے خلاف کوئی فوجداری مقدمہ زیر التوا نہیں ہے اور نہ ہی آپ  ماضی میں کسی فوجداری مقدمہ میں سزا یافتہ ہیں۔", 0, false, 12, null));
        MaterialCheckBox materialCheckBox7 = binding.declProphethoodFinalityP;
        Util util7 = Util.INSTANCE;
        CRCActivity activity7 = getActivity();
        String string7 = getString(R.string.declProphethoodFinalityP);
        Intrinsics.checkNotNullExpressionValue(string7, "getString(...)");
        materialCheckBox7.setText(Util.setEnglishTextSpan$default(util7, activity7, string7, "\nمن محلف / محلفہ حلفیہ بیان کرتا /کرتی ہوں کہ میں خاتم النبیین محمد صلی اللہ علیہ وسلم کی مکمل ، حتمی اور  غیر مشروط ختم نبوت پر ایمان رکھتا / رکھتی ہوں اور یہ کہ میں نہ کسی ایسے شخص پرایمان رکھتا / رکھتی ہوں اور نہ اسے بطور پیغمبر یا مذہبی مصلح مانتا/مانتی ہوں جس نے  حضرت محمد صلی اللہ علیہ وسلم کے بعد پیغمبر ہونے کا  لفظ  پیغمبر کے کسی بھی مفہوم یا کسی بھی تشریح کے لحاظ سے دعوی کیا  یا کرتا /کرتی ہو اور نہ ہی 'قادیانی' گروہ یا 'لاہوری' گروہ  (جو خود کو\" احمدی\"یا کسی اور نام سے موسوم کرتے ہیں) سے تعلق رکھتا / رکھتی ہوں ۔", 0, false, 12, null));
        initFooterView();
        updateProphetHoodCheckBoxVisibility();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$0(ReviewFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$1(ReviewFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.crc_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.CRC_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$2(ReviewFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$3(ReviewFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.generatePdf(this$0.getCrcSharedViewModel().getTrackingId());
    }

    private final void updateProphetHoodCheckBoxVisibility() {
        String lowerCase = getCrcSharedViewModel().getChildDataResponse().getApplicantReligion().getValue().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        if (Intrinsics.areEqual(lowerCase, "islam")) {
            getBinding().declProphethoodFinalityP.setVisibility(0);
        } else {
            getBinding().declProphethoodFinalityP.setVisibility(8);
            getBinding().declProphethoodFinalityP.setCheckedState(1);
        }
    }

    /* compiled from: ReviewFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$generatePdf$1", f = "ReviewFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$generatePdf$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$trackingId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ReviewFragment.this.new AnonymousClass1(this.$trackingId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ReviewFragment.this.getActivity());
            String str = this.$trackingId;
            final ReviewFragment reviewFragment = ReviewFragment.this;
            aPIRequests.generatePdf(str, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$generatePdf$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ReviewFragment.AnonymousClass1.invokeSuspend$lambda$0(reviewFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ReviewFragment reviewFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(reviewFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("generatePdf() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                reviewFragment.processGeneratePdfSuccessResponse(jsonObject);
            } else {
                reviewFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void generatePdf(String trackingId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(trackingId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processGeneratePdfSuccessResponse(JsonObject jSonObject) {
        GeneratePdfResponse generatePdfResponse = (GeneratePdfResponse) new Gson().fromJson(jSonObject.toString(), GeneratePdfResponse.class);
        Log.d("processGeneratePdf", generatePdfResponse.toString());
        writeBase64ToFile(generatePdfResponse.getBase64Pdf());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                errorResponse.getErrors();
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            CRCActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return ReviewFragment.handleFailureCase$lambda$7(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ReviewFragment.handleFailureCase$lambda$8(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$7(ReviewFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$8(ReviewFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final void writePdfBase64Data(String photoBase64) {
        File fileCreatePdfFile;
        try {
            fileCreatePdfFile = Util.INSTANCE.createPdfFile(getActivity());
        } catch (Exception e) {
            e.printStackTrace();
            fileCreatePdfFile = null;
        }
        if (fileCreatePdfFile == null) {
            return;
        }
        LoaderManager.INSTANCE.showLoader(getActivity());
        new WritePhotoBase64Data(getActivity(), this.iwritePdfBase64DataServiceResult).execute(new Object[]{photoBase64, fileCreatePdfFile});
    }

    /* compiled from: ReviewFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$submitFormReceiving$1", f = "ReviewFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$submitFormReceiving$1, reason: invalid class name and case insensitive filesystem */
    static final class C12431 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12431(Continuation<? super C12431> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ReviewFragment.this.new C12431(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12431) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ReviewFragment.this.getActivity());
            SubmitFormReceivingRequest submitFormReceivingRequest = new SubmitFormReceivingRequest(ReviewFragment.this.getCrcSharedViewModel().getTrackingId());
            final ReviewFragment reviewFragment = ReviewFragment.this;
            aPIRequests.submitFormReceiving(submitFormReceivingRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$submitFormReceiving$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ReviewFragment.C12431.invokeSuspend$lambda$0(reviewFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ReviewFragment reviewFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(reviewFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("submitFormReceiving() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                reviewFragment.processSubmitFormReceivingSuccessResponse(jsonObject);
            } else {
                reviewFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void submitFormReceiving() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12431(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processSubmitFormReceivingSuccessResponse(JsonObject jSonObject) {
        String str;
        String str2;
        String str3;
        getBinding().crcFooterLayout.getRoot().setVisibility(8);
        if (!this.attestationRequired) {
            str = "Submitted";
            str2 = "Your application is submitted successfully. After backend approval process you will be notified for fee payment through app. If required, our representative will contact you soon for further verification.";
            str3 = "آپ کی درخواست کامیابی کے ساتھ جمع کر دی گئی ہے۔ بیک اینڈ کی منظوری کے عمل کے بعد آپ کو ایپ کے ذریعے فیس کی ادائیگی کے لیے مطلع کیا جائے گا۔ اگر ضرورت ہو تو، ہمارا نمائندہ مزید تصدیق کے لیے جلد ہی آپ سے رابطہ کرے گا۔";
        } else {
            str = "Alert";
            str2 = "Application is pending due to Attestation. You can continue your application from inbox.";
            str3 = "تصدیق کی وجہ سے درخواست زیر التوا ہے۔ آپ اپنی درخواست ان باکس سے جاری رکھ سکتے ہیں۔";
        }
        BottomSheetUtils.INSTANCE.showMessageBottomSheet((FragmentActivity) getActivity(), str, str2, true, (CharSequence) Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Proceed", " (آگے بڑھیں)", 0, false, 12, null), true, str3, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ReviewFragment.processSubmitFormReceivingSuccessResponse$lambda$9(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ReviewFragment.processSubmitFormReceivingSuccessResponse$lambda$10(this.f$0);
            }
        });
        Util.INSTANCE.showInAppReview(getActivity());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processSubmitFormReceivingSuccessResponse$lambda$9(ReviewFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_INBOX);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processSubmitFormReceivingSuccessResponse$lambda$10(ReviewFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_INBOX);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void sharePdf(String documentPath) {
        Uri fileUri;
        if (documentPath == null || documentPath.length() == 0 || (fileUri = getFileUri(new File(documentPath))) == null) {
            return;
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("application/pdf");
        intent.putExtra("android.intent.extra.STREAM", fileUri);
        startActivity(Intent.createChooser(intent, "Share using..."));
    }

    private final Uri getFileUri(File pdfFile) {
        return FileProvider.getUriForFile(getActivity(), getActivity().getPackageName() + ".provider", pdfFile);
    }

    private final void writeBase64ToFile(String pdfBase64) {
        String json = new Gson().toJson(new Document(Util.INSTANCE.getCurrentDateTime(), getCrcSharedViewModel().getReactNativeData().getAccountHolderCnic(), "review_form", getCrcSharedViewModel().getTrackingId(), pdfBase64, "Review Form", false));
        String str = getCrcSharedViewModel().getReactNativeData().getAccountHolderCnic() + "_review_" + getCrcSharedViewModel().getTrackingId();
        Intrinsics.checkNotNull(json);
        Util.INSTANCE.writeToFile(getActivity(), "myDownloads/" + str + ".txt", json);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12441(str, null), 3, null);
    }

    /* compiled from: ReviewFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$writeBase64ToFile$1", f = "ReviewFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$writeBase64ToFile$1, reason: invalid class name and case insensitive filesystem */
    static final class C12441 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $fileName;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12441(String str, Continuation<? super C12441> continuation) {
            super(2, continuation);
            this.$fileName = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ReviewFragment.this.new C12441(this.$fileName, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12441) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.hideLoader(ReviewFragment.this.getActivity());
            Intent intent = new Intent(ReviewFragment.this.getActivity(), (Class<?>) ViewPdfActivity.class);
            intent.putExtra(Constant.TRACKING_ID, ReviewFragment.this.getCrcSharedViewModel().getTrackingId());
            intent.putExtra(Constant.DOCUMENT_TITLE, "Review Form");
            intent.putExtra(Constant.DOCUMENT_FILE_PATH, new File(ReviewFragment.this.getActivity().getFilesDir(), "myDownloads/" + this.$fileName + ".txt").getAbsolutePath());
            ReviewFragment.this.startActivity(intent);
            return Unit.INSTANCE;
        }
    }

    /* compiled from: ReviewFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$getTrackingData$1", f = "ReviewFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$getTrackingData$1, reason: invalid class name and case insensitive filesystem */
    static final class C12421 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12421(String str, Continuation<? super C12421> continuation) {
            super(2, continuation);
            this.$trackingId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ReviewFragment.this.new C12421(this.$trackingId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12421) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(ReviewFragment.this.getActivity());
            APIRequests aPIRequests = new APIRequests(ReviewFragment.this.getActivity());
            String str = this.$trackingId;
            final ReviewFragment reviewFragment = ReviewFragment.this;
            aPIRequests.minorDataList(str, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$getTrackingData$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ReviewFragment.C12421.invokeSuspend$lambda$0(reviewFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ReviewFragment reviewFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(reviewFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getTrackingDataRes: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                reviewFragment.processTrackingDataSuccessResponse(jsonObject);
            } else {
                reviewFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getTrackingData(String trackingId) {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12421(trackingId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processTrackingDataSuccessResponse(JsonObject jSonObject) {
        ChildDataResponse childDataResponse = (ChildDataResponse) new Gson().fromJson(jSonObject.toString(), ChildDataResponse.class);
        Log.d("processTrackingDataRes", childDataResponse.toString());
        this.attestationRequired = childDataResponse.getAttesterRequired();
        submitFormReceiving();
    }

    private final void initFooterView() {
        final ReviewFragmentBinding binding = getBinding();
        binding.crcFooterLayout.backButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ReviewFragment.initFooterView$lambda$14$lambda$12(this.f$0, view);
            }
        });
        binding.crcFooterLayout.backButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Back", "\n(واپس جائیں)", 0, false, 12, null));
        binding.crcFooterLayout.nextButtonLayout.commonButton.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        MaterialButton materialButton = binding.crcFooterLayout.nextButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.submit);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        materialButton.setText(Util.setEnglishTextSpan$default(util, activity, string, "\n(جمع کرائیں)", 0, false, 12, null));
        binding.crcFooterLayout.nextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ReviewFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ReviewFragment.initFooterView$lambda$14$lambda$13(binding, this, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$14$lambda$12(ReviewFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$14$lambda$13(ReviewFragmentBinding this_apply, ReviewFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this_apply.declInfoConcealP.isChecked() && this_apply.declInfoClarityP.isChecked() && this_apply.declInfoVerificationP.isChecked() && this_apply.declInfoCorrectP.isChecked() && this_apply.declPrisonCourtP.isChecked() && this_apply.declCriminalCaseP.isChecked() && this_apply.declProphethoodFinalityP.isChecked()) {
            this$0.getTrackingData(this$0.getCrcSharedViewModel().getTrackingId());
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.accept_all_terms);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.accept_all_terms_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }
}