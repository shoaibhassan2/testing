package pk.gov.nadra.oneapp.crc.fragments;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import pk.gov.nadra.oneapp.crc.databinding.SpouseListFragmentBinding;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SpouseListFragment$$ExternalSyntheticLambda4 implements SwipeRefreshLayout.OnRefreshListener {
    public final /* synthetic */ SpouseListFragmentBinding f$1;

    public /* synthetic */ SpouseListFragment$$ExternalSyntheticLambda4(SpouseListFragmentBinding spouseListFragmentBinding) {
        binding = spouseListFragmentBinding;
    }

    @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
    public final void onRefresh() {
        SpouseListFragment.onViewCreated$lambda$6$lambda$4(this.f$0, binding);
    }
}