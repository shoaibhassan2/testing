package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class MinorListFragment$$ExternalSyntheticLambda6 implements Function0 {
    public /* synthetic */ MinorListFragment$$ExternalSyntheticLambda6() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return MinorListFragment.handleFailureCase$lambda$24(this.f$0);
    }
}