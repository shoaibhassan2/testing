package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildParentDetailFragment$$ExternalSyntheticLambda5 implements View.OnClickListener {
    public /* synthetic */ ChildParentDetailFragment$$ExternalSyntheticLambda5() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ChildParentDetailFragment.initFooterView$lambda$14$lambda$12(this.f$0, view);
    }
}