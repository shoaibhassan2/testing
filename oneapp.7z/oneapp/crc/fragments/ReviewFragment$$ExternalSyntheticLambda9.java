package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ReviewFragment$$ExternalSyntheticLambda9 implements View.OnClickListener {
    public /* synthetic */ ReviewFragment$$ExternalSyntheticLambda9() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ReviewFragment.onViewCreated$lambda$4$lambda$3(this.f$0, view);
    }
}