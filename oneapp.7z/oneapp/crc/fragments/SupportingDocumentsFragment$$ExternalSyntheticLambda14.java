package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SupportingDocumentsFragment$$ExternalSyntheticLambda14 implements View.OnClickListener {
    public /* synthetic */ SupportingDocumentsFragment$$ExternalSyntheticLambda14() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        SupportingDocumentsFragment.onViewCreated$lambda$11$lambda$5(this.f$0, view);
    }
}