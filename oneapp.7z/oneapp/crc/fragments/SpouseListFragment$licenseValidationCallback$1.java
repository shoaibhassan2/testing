package pk.gov.nadra.oneapp.crc.fragments;

import androidx.fragment.app.FragmentActivity;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;

/* compiled from: SpouseListFragment.kt */
@Metadata(d1 = {"\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016J\b\u0010\u0004\u001a\u00020\u0003H\u0016¨\u0006\u0005"}, d2 = {"pk/gov/nadra/oneapp/crc/fragments/SpouseListFragment$licenseValidationCallback$1", "Lpk/gov/nadra/oneapp/commonutils/interfaces/LicenseValidationCallback;", "onSuccess", "", "onError", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class SpouseListFragment$licenseValidationCallback$1 implements LicenseValidationCallback {
    SpouseListFragment$licenseValidationCallback$1() {
    }

    @Override // pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback
    public void onSuccess() {
        LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
        this.this$0.processLicenseSuccess();
    }

    @Override // pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback
    public void onError() {
        LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this.this$0.getActivity();
        String string = this.this$0.getString(R.string.face_liveness_failed);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this.this$0.getString(R.string.face_liveness_failed_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }
}