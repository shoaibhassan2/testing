package pk.gov.nadra.oneapp.crc.fragments;

import com.google.android.material.textfield.TextInputLayout;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDetailFragment$$ExternalSyntheticLambda9 implements Runnable {
    public final /* synthetic */ TextInputLayout f$1;

    public /* synthetic */ ChildDetailFragment$$ExternalSyntheticLambda9(TextInputLayout textInputLayout) {
        view = textInputLayout;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ChildDetailFragment.scrollToView$lambda$62(this.f$0, view);
    }
}