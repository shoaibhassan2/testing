package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class MinorListFragment$$ExternalSyntheticLambda12 implements View.OnClickListener {
    public /* synthetic */ MinorListFragment$$ExternalSyntheticLambda12() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MinorListFragment.onViewCreated$lambda$13$lambda$7$lambda$6(this.f$0, view);
    }
}