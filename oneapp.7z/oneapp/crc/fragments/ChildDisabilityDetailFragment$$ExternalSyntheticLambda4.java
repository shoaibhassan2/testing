package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function2;
import pk.gov.nadra.oneapp.models.crc.minor.MinorDisability;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDisabilityDetailFragment$$ExternalSyntheticLambda4 implements Function2 {
    public /* synthetic */ ChildDisabilityDetailFragment$$ExternalSyntheticLambda4() {
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$10(this.f$0, ((Integer) obj).intValue(), (MinorDisability) obj2);
    }
}