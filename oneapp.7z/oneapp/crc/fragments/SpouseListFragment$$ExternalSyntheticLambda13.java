package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SpouseListFragment$$ExternalSyntheticLambda13 implements View.OnClickListener {
    public /* synthetic */ SpouseListFragment$$ExternalSyntheticLambda13() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        SpouseListFragment.initFooterView$lambda$30$lambda$28(this.f$0, view);
    }
}