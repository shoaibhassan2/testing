package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function2;
import pk.gov.nadra.oneapp.crc.adapter.ActionType;
import pk.gov.nadra.oneapp.models.crc.minor.MinorDataResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class MinorListFragment$$ExternalSyntheticLambda14 implements Function2 {
    public /* synthetic */ MinorListFragment$$ExternalSyntheticLambda14() {
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return MinorListFragment.onViewCreated$lambda$13$lambda$10(this.f$0, (ActionType) obj, (MinorDataResponse) obj2);
    }
}