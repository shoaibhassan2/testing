package pk.gov.nadra.oneapp.crc.fragments;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.PickVisualMediaRequestKt;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.compose.material3.MenuKt;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.bumptech.glide.Glide;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonui.databinding.ImageUploadLayoutBinding;
import pk.gov.nadra.oneapp.commonutils.idemialiveness.ChallengeActivity;
import pk.gov.nadra.oneapp.commonutils.imagePicker.BrowseAlbumActivity;
import pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback;
import pk.gov.nadra.oneapp.commonutils.service.ValidateLicenseService;
import pk.gov.nadra.oneapp.commonutils.unikrewliveness.UnikrewFacialActivity;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCropper;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.MoveUriFile;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data;
import pk.gov.nadra.oneapp.crc.adapter.viewmodel.CRCSharedViewModel;
import pk.gov.nadra.oneapp.crc.databinding.UploadApplicantPhotographFragmentBinding;
import pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;
import pk.gov.nadra.oneapp.models.crc.CrcTabsResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.MinorPhotographResponse;
import pk.gov.nadra.oneapp.models.crc.TabUpdateRequest;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: UploadApplicantPhotographFragment.kt */
@Metadata(d1 = {"\u0000Ì\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010%\u001a\u00020&2\u0006\u0010'\u001a\u00020(H\u0016J$\u0010)\u001a\u00020*2\u0006\u0010+\u001a\u00020,2\b\u0010-\u001a\u0004\u0018\u00010.2\b\u0010/\u001a\u0004\u0018\u000100H\u0016J\u001a\u00101\u001a\u00020&2\u0006\u00102\u001a\u00020*2\b\u0010/\u001a\u0004\u0018\u000100H\u0016J\u000e\u00103\u001a\u00020&2\u0006\u00104\u001a\u00020\u0016J\b\u00105\u001a\u00020&H\u0002J%\u0010:\u001a\u00020&2\u0016\u0010;\u001a\u0012\u0012\u0004\u0012\u00020=0>j\b\u0012\u0004\u0012\u00020=`<H\u0002¢\u0006\u0002\u0010?J\u0010\u0010@\u001a\u00020&2\u0006\u0010A\u001a\u00020=H\u0002J\b\u0010D\u001a\u00020&H\u0002J\b\u0010F\u001a\u00020&H\u0002J\b\u0010G\u001a\u00020&H\u0002J\u0018\u0010I\u001a\u00020&2\u0006\u0010J\u001a\u00020\u00162\u0006\u0010K\u001a\u00020LH\u0002J\u0010\u0010M\u001a\u00020&2\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\b\u0010P\u001a\u00020&H\u0002J\u0018\u0010Q\u001a\u00020&2\u0006\u0010R\u001a\u00020S2\u0006\u0010T\u001a\u00020UH\u0002J\b\u0010V\u001a\u00020&H\u0002J\b\u0010W\u001a\u00020&H\u0002J\u0010\u0010X\u001a\u00020&2\u0006\u0010Y\u001a\u00020ZH\u0002J\u0010\u0010[\u001a\u00020&2\u0006\u0010Y\u001a\u00020ZH\u0002J\u0010\u0010\\\u001a\u00020&2\u0006\u0010Y\u001a\u00020ZH\u0002J\u0018\u0010]\u001a\u00020&2\u0006\u0010^\u001a\u00020Z2\u0006\u0010_\u001a\u00020\u001cH\u0002J\b\u0010`\u001a\u00020&H\u0002J\u0010\u0010a\u001a\u00020&2\u0006\u0010b\u001a\u00020\u0016H\u0002J\b\u0010e\u001a\u00020&H\u0002J\b\u0010h\u001a\u00020&H\u0002J\b\u0010j\u001a\u00020&H\u0002J\u0010\u0010k\u001a\u00020&2\u0006\u0010T\u001a\u00020\u0016H\u0002J\u0010\u0010l\u001a\u00020&2\u0006\u0010Y\u001a\u00020mH\u0002J\u0018\u0010n\u001a\u00020&2\u0006\u0010^\u001a\u00020m2\u0006\u0010_\u001a\u00020\u001cH\u0002J\b\u0010o\u001a\u00020&H\u0002J\b\u0010s\u001a\u00020&H\u0002J\b\u0010t\u001a\u00020&H\u0002J\b\u0010v\u001a\u00020&H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u001a\u0010\u0015\u001a\u00020\u0016X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001aR\u000e\u0010\u001b\u001a\u00020\u001cX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u001f\u001a\u00020 X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\"\"\u0004\b#\u0010$R\u001c\u00106\u001a\u0010\u0012\f\u0012\n 9*\u0004\u0018\u0001080807X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010B\u001a\u00020CX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010E\u001a\u0010\u0012\f\u0012\n 9*\u0004\u0018\u0001080807X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010H\u001a\u0010\u0012\f\u0012\n 9*\u0004\u0018\u0001080807X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010N\u001a\u00020OX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010c\u001a\u00020dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010f\u001a\u00020gX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010i\u001a\u0010\u0012\f\u0012\n 9*\u0004\u0018\u0001080807X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010p\u001a\u0010\u0012\f\u0012\n 9*\u0004\u0018\u00010q0q07X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010r\u001a\u0010\u0012\f\u0012\n 9*\u0004\u0018\u0001080807X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010u\u001a\u0010\u0012\f\u0012\n 9*\u0004\u0018\u0001080807X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006w"}, d2 = {"Lpk/gov/nadra/oneapp/crc/fragments/UploadApplicantPhotographFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/crc/databinding/UploadApplicantPhotographFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/UploadApplicantPhotographFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/crc/views/CRCActivity;)V", "sourceImagePath", "", "getSourceImagePath", "()Ljava/lang/String;", "setSourceImagePath", "(Ljava/lang/String;)V", "PHOTO_EDITOR_REQUEST_CODE", "", "CAMERA", "GALLERY", "capturedImageFile", "Ljava/io/File;", "getCapturedImageFile", "()Ljava/io/File;", "setCapturedImageFile", "(Ljava/io/File;)V", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "launchGalleryOrCameraIntent", "callingFor", "dispatchGalleryIntentForPhotoSelection", "galleryLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "processOnActivityResultForGalleryIntent", "uris", "Lkotlin/collections/ArrayList;", "Landroid/net/Uri;", "Ljava/util/ArrayList;", "(Ljava/util/ArrayList;)V", "processSelectedImageUri", "selectedImageUri", "iMoveUriImageServiceResult", "Lpk/gov/nadra/oneapp/commonutils/utils/MoveUriFile$ICompressImageTaskListener;", "dispatchCameraIntentForPhotoCapture", "cameraLauncher", "processOnActivityResultForCameraIntent", "launchImageCropper", "cropLauncher", "processOnActivityResultForAnanasLibrary", "processedFilePath", "isImageEdit", "", "compressImage", "iCompressImageTaskListenerResult", "Lpk/gov/nadra/oneapp/commonutils/utils/ImageCompressor$ICompressImageTaskListener;", "handleUploadPhotograph", "saveApplicantPhotograph", "image", "Lokhttp3/MultipartBody$Part;", "trackingId", "Lokhttp3/RequestBody;", "saveApplicantPhotographTab", "getApplicantPhotograph", "processApplicantPhotographSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "processPhotographSuccessResponse", "processPhotographTabSuccessResponse", "handleFailureCase", "jsonResponse", "responseCode", "launchNextScreen", "writeChildPhotographBase64Data", "photoBase64", "iwriteChildPhotographBase64DataServiceResult", "Lpk/gov/nadra/oneapp/commonutils/utils/WritePhotoBase64Data$ICompressImageTaskListener;", "checkIdemiaLicenseActivation", "licenseValidationCallback", "Lpk/gov/nadra/oneapp/commonutils/interfaces/LicenseValidationCallback;", "processLicenseSuccess", "livelinessLauncher", "checkBrowseButtonVisibility", "getCrcTabs", "processCrcTabsResponse", "Lcom/google/gson/JsonArray;", "handleFailureCaseJsonArray", "handleLivenessControlLaunch", "photoPickerLauncher", "Landroidx/activity/result/PickVisualMediaRequest;", "legacyPickerLauncher", "checkLivenessControl", "launchUnikrewFacial", "unikrewFacialLauncher", "initFooterView", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class UploadApplicantPhotographFragment extends Fragment {
    private UploadApplicantPhotographFragmentBinding _binding;
    public CRCActivity activity;
    private final ActivityResultLauncher<Intent> cameraLauncher;
    public File capturedImageFile;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;
    private final ActivityResultLauncher<Intent> cropLauncher;
    private final ActivityResultLauncher<Intent> galleryLauncher;
    private ImageCompressor.ICompressImageTaskListener iCompressImageTaskListenerResult;
    private MoveUriFile.ICompressImageTaskListener iMoveUriImageServiceResult;
    private WritePhotoBase64Data.ICompressImageTaskListener iwriteChildPhotographBase64DataServiceResult;
    private final ActivityResultLauncher<Intent> legacyPickerLauncher;
    private LicenseValidationCallback licenseValidationCallback;
    private final ActivityResultLauncher<Intent> livelinessLauncher;
    private final ActivityResultLauncher<PickVisualMediaRequest> photoPickerLauncher;
    private final ActivityResultLauncher<Intent> unikrewFacialLauncher;
    private String sourceImagePath = "";
    private final int PHOTO_EDITOR_REQUEST_CODE = 231;
    private String CAMERA = "CAMERA";
    private String GALLERY = "GALLERY";

    public UploadApplicantPhotographFragment() {
        final UploadApplicantPhotographFragment uploadApplicantPhotographFragment = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(uploadApplicantPhotographFragment, Reflection.getOrCreateKotlinClass(CRCSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = uploadApplicantPhotographFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = uploadApplicantPhotographFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = uploadApplicantPhotographFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda2
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                UploadApplicantPhotographFragment.galleryLauncher$lambda$11(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.galleryLauncher = activityResultLauncherRegisterForActivityResult;
        this.iMoveUriImageServiceResult = new MoveUriFile.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$iMoveUriImageServiceResult$1
            @Override // pk.gov.nadra.oneapp.commonutils.utils.MoveUriFile.ICompressImageTaskListener
            public void onComplete(File compressed) {
                Intrinsics.checkNotNullParameter(compressed, "compressed");
                this.this$0.setSourceImagePath(compressed.getAbsolutePath());
                if (new File(this.this$0.getSourceImagePath()).length() < 0) {
                    return;
                }
                this.this$0.launchImageCropper();
            }

            @Override // pk.gov.nadra.oneapp.commonutils.utils.MoveUriFile.ICompressImageTaskListener
            public void onError() {
                Util.INSTANCE.showToast(this.this$0.getActivity(), "Failed");
            }
        };
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult2 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda3
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                UploadApplicantPhotographFragment.cameraLauncher$lambda$14(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult2, "registerForActivityResult(...)");
        this.cameraLauncher = activityResultLauncherRegisterForActivityResult2;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult3 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda4
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                UploadApplicantPhotographFragment.cropLauncher$lambda$16(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult3, "registerForActivityResult(...)");
        this.cropLauncher = activityResultLauncherRegisterForActivityResult3;
        this.iCompressImageTaskListenerResult = new ImageCompressor.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$iCompressImageTaskListenerResult$1
            @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
            public void onComplete(File compressed) {
                Intrinsics.checkNotNullParameter(compressed, "compressed");
                Glide.with((FragmentActivity) this.this$0.getActivity()).load(compressed).into(this.this$0.getBinding().crcTakePhoto.ivShowPhoto);
                ImageUploadLayoutBinding imageUploadLayoutBinding = this.this$0.getBinding().crcTakePhoto;
                imageUploadLayoutBinding.ivTakePhoto.setVisibility(4);
                imageUploadLayoutBinding.tvTapToUpload.setVisibility(4);
                imageUploadLayoutBinding.tvPhotoDimension.setVisibility(4);
                this.this$0.getBinding().captureButtonLayout.commonButton.setButtonText(Util.setEnglishTextSpan$default(Util.INSTANCE, this.this$0.getActivity(), "Re-capture", " (دوبارہ کھینچیں) ", 0, false, 12, null));
                this.this$0.setCapturedImageFile(compressed);
                if (this.this$0.capturedImageFile != null) {
                    this.this$0.handleUploadPhotograph();
                    return;
                }
                BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
                CRCActivity activity = this.this$0.getActivity();
                String string = this.this$0.getString(R.string.please_upload_photo);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                String string2 = this.this$0.getString(R.string.please_upload_photo_urdu);
                Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
            }

            @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
            public void onError() {
                Util.INSTANCE.showToast(this.this$0.getActivity(), "Failed");
            }
        };
        this.iwriteChildPhotographBase64DataServiceResult = new WritePhotoBase64Data.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$iwriteChildPhotographBase64DataServiceResult$1
            @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
            public void onComplete(File compressed) {
                Intrinsics.checkNotNullParameter(compressed, "compressed");
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
                this.this$0.getCrcSharedViewModel().setApplicantPhotoPath(compressed.getAbsolutePath());
                this.this$0.setCapturedImageFile(compressed);
                Glide.with((FragmentActivity) this.this$0.getActivity()).load(compressed).into(this.this$0.getBinding().crcTakePhoto.ivShowPhoto);
                this.this$0.getBinding().crcTakePhoto.ivTakePhoto.setVisibility(4);
                this.this$0.getBinding().crcTakePhoto.tvTapToUpload.setVisibility(4);
                this.this$0.getBinding().crcTakePhoto.tvPhotoDimension.setVisibility(4);
                this.this$0.getBinding().captureButtonLayout.commonButton.setButtonText(Util.setEnglishTextSpan$default(Util.INSTANCE, this.this$0.getActivity(), "Re-capture", " (دوبارہ کھینچیں) ", 0, false, 12, null));
            }

            @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
            public void onError() {
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
            }
        };
        this.licenseValidationCallback = new LicenseValidationCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$licenseValidationCallback$1
            @Override // pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback
            public void onSuccess() {
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
                this.this$0.processLicenseSuccess();
            }

            @Override // pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback
            public void onError() {
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
                BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
                CRCActivity activity = this.this$0.getActivity();
                String string = this.this$0.getString(R.string.face_liveness_failed);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                String string2 = this.this$0.getString(R.string.face_liveness_failed_urdu);
                Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
            }
        };
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult4 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda5
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                UploadApplicantPhotographFragment.livelinessLauncher$lambda$21(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult4, "registerForActivityResult(...)");
        this.livelinessLauncher = activityResultLauncherRegisterForActivityResult4;
        ActivityResultLauncher<PickVisualMediaRequest> activityResultLauncherRegisterForActivityResult5 = registerForActivityResult(new ActivityResultContracts.PickVisualMedia(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda6
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                UploadApplicantPhotographFragment.photoPickerLauncher$lambda$26(this.f$0, (Uri) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult5, "registerForActivityResult(...)");
        this.photoPickerLauncher = activityResultLauncherRegisterForActivityResult5;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult6 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda7
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                UploadApplicantPhotographFragment.legacyPickerLauncher$lambda$27(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult6, "registerForActivityResult(...)");
        this.legacyPickerLauncher = activityResultLauncherRegisterForActivityResult6;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult7 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda8
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                UploadApplicantPhotographFragment.unikrewFacialLauncher$lambda$28(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult7, "registerForActivityResult(...)");
        this.unikrewFacialLauncher = activityResultLauncherRegisterForActivityResult7;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final CRCSharedViewModel getCrcSharedViewModel() {
        return (CRCSharedViewModel) this.crcSharedViewModel.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final UploadApplicantPhotographFragmentBinding getBinding() {
        UploadApplicantPhotographFragmentBinding uploadApplicantPhotographFragmentBinding = this._binding;
        Intrinsics.checkNotNull(uploadApplicantPhotographFragmentBinding);
        return uploadApplicantPhotographFragmentBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final CRCActivity getActivity() {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity != null) {
            return cRCActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(CRCActivity cRCActivity) {
        Intrinsics.checkNotNullParameter(cRCActivity, "<set-?>");
        this.activity = cRCActivity;
    }

    public final String getSourceImagePath() {
        return this.sourceImagePath;
    }

    public final void setSourceImagePath(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.sourceImagePath = str;
    }

    public final File getCapturedImageFile() {
        File file = this.capturedImageFile;
        if (file != null) {
            return file;
        }
        Intrinsics.throwUninitializedPropertyAccessException("capturedImageFile");
        return null;
    }

    public final void setCapturedImageFile(File file) {
        Intrinsics.checkNotNullParameter(file, "<set-?>");
        this.capturedImageFile = file;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        Log.w(Constant.TAG, "onAttach: Call");
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.crc.views.CRCActivity");
        setActivity((CRCActivity) fragmentActivityRequireActivity);
        String trackingId = getCrcSharedViewModel().getStartApplicationResponse().getTrackingId();
        if (trackingId == null || trackingId.length() == 0) {
            return;
        }
        getCrcSharedViewModel().setLivelinessControl(getCrcSharedViewModel().getReactNativeData().getLivelinessControl());
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = UploadApplicantPhotographFragmentBinding.inflate(inflater, container, false);
        Log.w(Constant.TAG, "onCreateView: Call");
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        Log.w(Constant.TAG, "onViewCreated: Call");
        final UploadApplicantPhotographFragmentBinding binding = getBinding();
        binding.crcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                UploadApplicantPhotographFragment.onViewCreated$lambda$10$lambda$0(this.f$0, view2);
            }
        });
        binding.crcHeaderLayout.iconInfo.setVisibility(0);
        binding.crcHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                UploadApplicantPhotographFragment.onViewCreated$lambda$10$lambda$1(this.f$0, view2);
            }
        });
        TextView textView = binding.crcHeaderLayout.textTitle;
        String upperCase = getCrcSharedViewModel().getDocumentTypeValue().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(String.valueOf(upperCase));
        binding.crcHeaderLayout.textSubtitle.setText(String.valueOf(getCrcSharedViewModel().getApplicationTypeValue()));
        binding.crcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.roboto_medium));
        binding.crcHeaderLayout.tvHeaderTrackingId.setText(getCrcSharedViewModel().getTrackingId());
        binding.crcHeaderLayout.tvHeaderFee.setText(String.valueOf(getCrcSharedViewModel().getAmount()));
        binding.crcHeaderLayout.iconInfo.setVisibility(0);
        binding.stepTitleHeadingLayout.tvStepTitleHeading.setText("Applicant Photograph");
        binding.stepTitleHeadingLayout.tvStepTitleHeadingUrdu.setText("درخواست گزار کی تصویر");
        binding.crcHeaderLayout.textSubtitle.setTypeface(Util.INSTANCE.getNadraNastaleeqFont(getActivity()));
        binding.stepTitleHeadingLayout.tvStepTitleHeadingUrdu.setTypeface(Util.INSTANCE.getNadraNastaleeqFont(getActivity()));
        binding.crcTakePhoto.tvTapToUpload.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Photograph", " (تصویر) ", 0, false, 12, null));
        binding.crcHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                UploadApplicantPhotographFragment.onViewCreated$lambda$10$lambda$4(this.f$0, view2);
            }
        });
        binding.uploadButtonLayout.commonButton.setFilled(false);
        binding.uploadButtonLayout.commonButton.setButtonText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Browse", " (براؤز) ", 0, false, 12, null));
        binding.captureButtonLayout.commonButton.setFilled(true);
        binding.captureButtonLayout.commonButton.setButtonText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Capture", " (تصویر کھینچیں) ", 0, false, 12, null));
        binding.uploadButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                UploadApplicantPhotographFragment.onViewCreated$lambda$10$lambda$5(this.f$0, view2);
            }
        });
        binding.captureButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda14
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                UploadApplicantPhotographFragment.onViewCreated$lambda$10$lambda$6(this.f$0, view2);
            }
        });
        binding.crcSkipCheckbox.checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda15
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                UploadApplicantPhotographFragment.onViewCreated$lambda$10$lambda$8(this.f$0, binding, compoundButton, z);
            }
        });
        String applicantPhotoPath = getCrcSharedViewModel().getApplicantPhotoPath();
        if (applicantPhotoPath != null && applicantPhotoPath.length() != 0) {
            setCapturedImageFile(new File(getCrcSharedViewModel().getApplicantPhotoPath()));
            ImageUploadLayoutBinding imageUploadLayoutBinding = getBinding().crcTakePhoto;
            Glide.with((FragmentActivity) getActivity()).load(getCrcSharedViewModel().getApplicantPhotoPath()).into(binding.crcTakePhoto.ivShowPhoto);
            imageUploadLayoutBinding.ivTakePhoto.setVisibility(4);
            imageUploadLayoutBinding.tvTapToUpload.setVisibility(4);
            imageUploadLayoutBinding.tvPhotoDimension.setVisibility(4);
        }
        initFooterView();
        checkBrowseButtonVisibility();
        getApplicantPhotograph();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$10$lambda$0(UploadApplicantPhotographFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$10$lambda$1(UploadApplicantPhotographFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.crc_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.CRC_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$10$lambda$4(final UploadApplicantPhotographFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        int i = R.drawable.camera_group;
        String string = this$0.getString(R.string.tabApplicationInfo_label_photoGuidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.tabApplicationInfo_label_photoGuidelinesDesc);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        String string3 = this$0.getString(R.string.tabApplicationInfo_label_photoGuidelinesDesc_urdu);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        bottomSheetUtils.showMessageBottomSheet(activity, i, true, string, string2, true, true, true, string3, Util.setEnglishTextSpan$default(Util.INSTANCE, this$0.getActivity(), "Show More", " (مزید دکھائیں)", 0, false, 12, null), new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda19
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return UploadApplicantPhotographFragment.onViewCreated$lambda$10$lambda$4$lambda$2(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda20
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$10$lambda$4$lambda$2(UploadApplicantPhotographFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.photograph_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.PHOTO_GUIDELINES_URL, "");
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$10$lambda$5(UploadApplicantPhotographFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().setFragmentName("ApplicantPhotograph");
        this$0.getActivity().setCallingFor(this$0.GALLERY);
        if (Build.VERSION.SDK_INT >= 33) {
            this$0.photoPickerLauncher.launch(PickVisualMediaRequestKt.PickVisualMediaRequest$default(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE, 0, false, null, 14, null));
        } else {
            this$0.legacyPickerLauncher.launch(new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$10$lambda$6(UploadApplicantPhotographFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().setFragmentName("ApplicantPhotograph");
        this$0.getActivity().setCallingFor(this$0.CAMERA);
        this$0.getActivity().getPermissions().requestPermission("android.permission.CAMERA");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$10$lambda$8(UploadApplicantPhotographFragment this$0, UploadApplicantPhotographFragmentBinding this_apply, CompoundButton compoundButton, boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        this$0.getCrcSharedViewModel().setApplicantPhotoSkip(z);
        this$0.getCrcSharedViewModel().setApplicantPhotoPath("");
        ImageUploadLayoutBinding imageUploadLayoutBinding = this$0.getBinding().crcTakePhoto;
        Glide.with((FragmentActivity) this$0.getActivity()).clear(this_apply.crcTakePhoto.ivShowPhoto);
        imageUploadLayoutBinding.ivTakePhoto.setVisibility(0);
        imageUploadLayoutBinding.tvTapToUpload.setVisibility(0);
        imageUploadLayoutBinding.tvPhotoDimension.setVisibility(0);
    }

    public final void launchGalleryOrCameraIntent(String callingFor) {
        Intrinsics.checkNotNullParameter(callingFor, "callingFor");
        if (Intrinsics.areEqual(callingFor, this.GALLERY)) {
            dispatchGalleryIntentForPhotoSelection();
        }
        if (Intrinsics.areEqual(callingFor, this.CAMERA)) {
            handleLivenessControlLaunch();
        }
    }

    private final void dispatchGalleryIntentForPhotoSelection() {
        Intent intent = new Intent(getActivity(), (Class<?>) BrowseAlbumActivity.class);
        intent.putExtra("pick_files", true);
        this.galleryLauncher.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void galleryLauncher$lambda$11(UploadApplicantPhotographFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || result.getData() == null) {
            return;
        }
        Intent data = result.getData();
        Intrinsics.checkNotNull(data);
        Serializable serializableExtra = data.getSerializableExtra("checked_uris");
        Intrinsics.checkNotNull(serializableExtra, "null cannot be cast to non-null type java.util.ArrayList<android.net.Uri>");
        this$0.processOnActivityResultForGalleryIntent((ArrayList) serializableExtra);
    }

    private final void processOnActivityResultForGalleryIntent(ArrayList<Uri> uris) {
        if (uris == null || uris.size() == 0) {
            return;
        }
        Uri uri = uris.get(0);
        Intrinsics.checkNotNullExpressionValue(uri, "get(...)");
        processSelectedImageUri(uri);
    }

    private final void processSelectedImageUri(Uri selectedImageUri) {
        File fileCreatePhotoFile;
        String mimeType = Util.INSTANCE.getMimeType(getActivity(), selectedImageUri);
        String str = mimeType;
        if (str == null || str.length() == 0 || (!StringsKt.equals(mimeType, "JPG", true) && !StringsKt.equals(mimeType, "JPEG", true) && !StringsKt.equals(mimeType, "PNG", true))) {
            Util.INSTANCE.showToast(getActivity(), "Please select valid JPG/JPEG/PNG format image.");
            return;
        }
        try {
            fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
        } catch (Exception e) {
            e.printStackTrace();
            String message = e.getMessage();
            if (message != null) {
                Util.INSTANCE.showToast(getActivity(), message);
            }
            fileCreatePhotoFile = null;
        }
        if (fileCreatePhotoFile == null) {
            return;
        }
        new MoveUriFile(getActivity(), this.iMoveUriImageServiceResult).execute(Arrays.copyOf(new Object[]{selectedImageUri, fileCreatePhotoFile}, 2));
    }

    private final void dispatchCameraIntentForPhotoCapture() {
        Util.INSTANCE.createCameraUri(getActivity(), new Function2() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda16
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return UploadApplicantPhotographFragment.dispatchCameraIntentForPhotoCapture$lambda$13(this.f$0, (String) obj, (Intent) obj2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit dispatchCameraIntentForPhotoCapture$lambda$13(UploadApplicantPhotographFragment this$0, String photoPath, Intent intent) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(photoPath, "photoPath");
        Intrinsics.checkNotNullParameter(intent, "intent");
        this$0.sourceImagePath = photoPath;
        try {
            this$0.cameraLauncher.launch(intent);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void cameraLauncher$lambda$14(UploadApplicantPhotographFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1) {
            this$0.processOnActivityResultForCameraIntent();
        }
    }

    private final void processOnActivityResultForCameraIntent() {
        if (new File(this.sourceImagePath).length() < 0) {
            return;
        }
        launchImageCropper();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void launchImageCropper() {
        try {
            String str = this.sourceImagePath;
            File fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
            Intrinsics.checkNotNull(fileCreatePhotoFile);
            String absolutePath = fileCreatePhotoFile.getAbsolutePath();
            Intent intent = new Intent(getActivity(), (Class<?>) ImageCropper.class);
            intent.putExtra(ImageCropper.EXTRA_INPUT_PATH, str);
            intent.putExtra("output_path", absolutePath);
            this.cropLauncher.launch(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void cropLauncher$lambda$16(UploadApplicantPhotographFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1) {
            Intent data = result.getData();
            String stringExtra = data != null ? data.getStringExtra("output_path") : null;
            boolean booleanExtra = data != null ? data.getBooleanExtra(ImageCropper.RESULT_IMAGE_EDITED, false) : false;
            if (stringExtra != null) {
                this$0.processOnActivityResultForAnanasLibrary(stringExtra, booleanExtra);
            }
        }
    }

    private final void processOnActivityResultForAnanasLibrary(String processedFilePath, boolean isImageEdit) {
        if (isImageEdit) {
            compressImage(processedFilePath);
        } else {
            compressImage(this.sourceImagePath);
        }
    }

    private final void compressImage(String sourceImagePath) {
        File fileCreatePhotoFile;
        try {
            fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
        } catch (Exception e) {
            e.printStackTrace();
            Util.INSTANCE.showToast(getActivity(), String.valueOf(e.getMessage()));
            fileCreatePhotoFile = null;
        }
        if (fileCreatePhotoFile == null) {
            return;
        }
        new ImageCompressor(getActivity(), this.iCompressImageTaskListenerResult).execute(Arrays.copyOf(new Object[]{sourceImagePath, fileCreatePhotoFile.getAbsolutePath()}, 2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleUploadPhotograph() {
        saveApplicantPhotograph(MultipartBody.Part.INSTANCE.createFormData("file", getCapturedImageFile().getName(), RequestBody.INSTANCE.create(getCapturedImageFile(), MediaType.INSTANCE.parse("image/*"))), RequestBody.INSTANCE.create(getCrcSharedViewModel().getTrackingId(), MediaType.INSTANCE.get("text/plain")));
    }

    private final void saveApplicantPhotograph(MultipartBody.Part image, RequestBody trackingId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12551(image, trackingId, null), 3, null);
    }

    /* compiled from: UploadApplicantPhotographFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$saveApplicantPhotograph$1", f = "UploadApplicantPhotographFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$saveApplicantPhotograph$1, reason: invalid class name and case insensitive filesystem */
    static final class C12551 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ MultipartBody.Part $image;
        final /* synthetic */ RequestBody $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12551(MultipartBody.Part part, RequestBody requestBody, Continuation<? super C12551> continuation) {
            super(2, continuation);
            this.$image = part;
            this.$trackingId = requestBody;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadApplicantPhotographFragment.this.new C12551(this.$image, this.$trackingId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12551) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(UploadApplicantPhotographFragment.this.getActivity());
            MultipartBody.Part part = this.$image;
            RequestBody requestBody = this.$trackingId;
            final UploadApplicantPhotographFragment uploadApplicantPhotographFragment = UploadApplicantPhotographFragment.this;
            aPIRequests.saveApplicantPhotograph(part, requestBody, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$saveApplicantPhotograph$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return UploadApplicantPhotographFragment.C12551.invokeSuspend$lambda$0(uploadApplicantPhotographFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(UploadApplicantPhotographFragment uploadApplicantPhotographFragment, JsonObject jsonObject, String str, int i) {
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("saveApplicantPhotograph() Response: " + jsonObject));
            }
            LoaderManager.INSTANCE.hideLoader(uploadApplicantPhotographFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                uploadApplicantPhotographFragment.processPhotographSuccessResponse(jsonObject);
            } else {
                uploadApplicantPhotographFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: UploadApplicantPhotographFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$saveApplicantPhotographTab$1", f = "UploadApplicantPhotographFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$saveApplicantPhotographTab$1, reason: invalid class name and case insensitive filesystem */
    static final class C12561 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Ref.ObjectRef<TabUpdateRequest> $tabUpdateRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12561(Ref.ObjectRef<TabUpdateRequest> objectRef, Continuation<? super C12561> continuation) {
            super(2, continuation);
            this.$tabUpdateRequest = objectRef;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadApplicantPhotographFragment.this.new C12561(this.$tabUpdateRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12561) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(UploadApplicantPhotographFragment.this.getActivity());
            APIRequests aPIRequests = new APIRequests(UploadApplicantPhotographFragment.this.getActivity());
            TabUpdateRequest tabUpdateRequest = this.$tabUpdateRequest.element;
            final UploadApplicantPhotographFragment uploadApplicantPhotographFragment = UploadApplicantPhotographFragment.this;
            aPIRequests.savePhotographTab(tabUpdateRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$saveApplicantPhotographTab$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return UploadApplicantPhotographFragment.C12561.invokeSuspend$lambda$0(uploadApplicantPhotographFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(UploadApplicantPhotographFragment uploadApplicantPhotographFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(uploadApplicantPhotographFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("saveApplicantPhotograph() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                uploadApplicantPhotographFragment.processPhotographTabSuccessResponse(jsonObject);
            } else {
                uploadApplicantPhotographFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [T, pk.gov.nadra.oneapp.models.crc.TabUpdateRequest] */
    private final void saveApplicantPhotographTab() {
        Ref.ObjectRef objectRef = new Ref.ObjectRef();
        objectRef.element = new TabUpdateRequest(getCrcSharedViewModel().getTrackingId(), null, 2, null);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12561(objectRef, null), 3, null);
    }

    /* compiled from: UploadApplicantPhotographFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$getApplicantPhotograph$1", f = "UploadApplicantPhotographFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$getApplicantPhotograph$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadApplicantPhotographFragment.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(UploadApplicantPhotographFragment.this.getActivity());
            APIRequests aPIRequests = new APIRequests(UploadApplicantPhotographFragment.this.getActivity());
            String trackingId = UploadApplicantPhotographFragment.this.getCrcSharedViewModel().getTrackingId();
            final UploadApplicantPhotographFragment uploadApplicantPhotographFragment = UploadApplicantPhotographFragment.this;
            aPIRequests.getApplicantPhotograph(trackingId, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$getApplicantPhotograph$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return UploadApplicantPhotographFragment.AnonymousClass1.invokeSuspend$lambda$0(uploadApplicantPhotographFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(UploadApplicantPhotographFragment uploadApplicantPhotographFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(uploadApplicantPhotographFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getApplicantPhotograph() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                uploadApplicantPhotographFragment.processApplicantPhotographSuccessResponse(jsonObject);
            } else {
                uploadApplicantPhotographFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getApplicantPhotograph() {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processApplicantPhotographSuccessResponse(JsonObject jSonObject) {
        writeChildPhotographBase64Data(((MinorPhotographResponse) new Gson().fromJson(jSonObject.toString(), MinorPhotographResponse.class)).getBase64Photograph());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processPhotographSuccessResponse(JsonObject jSonObject) {
        getCrcSharedViewModel().setApplicantPhotoPath(getCapturedImageFile().getAbsolutePath());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processPhotographTabSuccessResponse(JsonObject jSonObject) {
        getCrcTabs(getCrcSharedViewModel().getTrackingId());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors == null || errors.isEmpty()) {
                    return;
                }
                List<ErrorResponse.Error> errors2 = errorResponse.getErrors();
                Intrinsics.checkNotNull(errors2);
                String message = errors2.get(0).getMessage();
                if (message != null) {
                    BottomSheetUtils.showMessageBottomSheet$default(BottomSheetUtils.INSTANCE, (FragmentActivity) getActivity(), "Alert", message, false, false, (String) null, (Function1) null, MenuKt.InTransitionDuration, (Object) null);
                    return;
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            CRCActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda17
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return UploadApplicantPhotographFragment.handleFailureCase$lambda$19(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda18
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return UploadApplicantPhotographFragment.handleFailureCase$lambda$20(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$19(UploadApplicantPhotographFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$20(UploadApplicantPhotographFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final void launchNextScreen() {
        if (getActivity().hasIdTwoAndFingerprints(getCrcSharedViewModel().getCrcTabsList())) {
            getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.applicantFingerprintAcquisitionFragment);
        } else {
            getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.signatureAcquisitionFragment);
        }
    }

    private final void writeChildPhotographBase64Data(String photoBase64) {
        File fileCreatePhotoFile;
        try {
            fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
        } catch (Exception e) {
            e.printStackTrace();
            fileCreatePhotoFile = null;
        }
        if (fileCreatePhotoFile == null) {
            return;
        }
        LoaderManager.INSTANCE.showLoader(getActivity());
        new WritePhotoBase64Data(getActivity(), this.iwriteChildPhotographBase64DataServiceResult).execute(new Object[]{photoBase64, fileCreatePhotoFile});
    }

    private final void checkIdemiaLicenseActivation() {
        Object[] objArr = {Constant.IDEMIA_VALUE_1, Constant.IDEMIA_VALUE_2, Constant.IDEMIA_VALUE_3};
        LoaderManager.INSTANCE.showLoader(getActivity());
        new ValidateLicenseService(this.licenseValidationCallback, getActivity(), objArr).validateLicense();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processLicenseSuccess() {
        this.livelinessLauncher.launch(new Intent(getActivity(), (Class<?>) ChallengeActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void livelinessLauncher$lambda$21(UploadApplicantPhotographFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || result.getData() == null) {
            return;
        }
        Intent data = result.getData();
        Intrinsics.checkNotNull(data);
        String stringExtra = data.getStringExtra("CAPTURE_RESULT_FACE");
        if (stringExtra != null && new File(stringExtra).length() > 0) {
            this$0.sourceImagePath = stringExtra;
            this$0.processOnActivityResultForCameraIntent();
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.unable_to_detect_face);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.unable_to_detect_face_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }

    private final void checkBrowseButtonVisibility() {
        if (Constant.INSTANCE.getDEBUG() || !getCrcSharedViewModel().getLivelinessControl()) {
            getBinding().uploadButtonLayout.commonButton.setVisibility(0);
        } else {
            getBinding().uploadButtonLayout.commonButton.setVisibility(8);
        }
    }

    /* compiled from: UploadApplicantPhotographFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$getCrcTabs$1", f = "UploadApplicantPhotographFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$getCrcTabs$1, reason: invalid class name and case insensitive filesystem */
    static final class C12541 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12541(String str, Continuation<? super C12541> continuation) {
            super(2, continuation);
            this.$trackingId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadApplicantPhotographFragment.this.new C12541(this.$trackingId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12541) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(UploadApplicantPhotographFragment.this.getActivity());
            APIRequests aPIRequests = new APIRequests(UploadApplicantPhotographFragment.this.getActivity());
            String str = this.$trackingId;
            final UploadApplicantPhotographFragment uploadApplicantPhotographFragment = UploadApplicantPhotographFragment.this;
            aPIRequests.getCrcTabs(str, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$getCrcTabs$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return UploadApplicantPhotographFragment.C12541.invokeSuspend$lambda$0(uploadApplicantPhotographFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(UploadApplicantPhotographFragment uploadApplicantPhotographFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(uploadApplicantPhotographFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                uploadApplicantPhotographFragment.processCrcTabsResponse(jsonArray);
            } else {
                uploadApplicantPhotographFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getCrcTabs(String trackingId) {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12541(trackingId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processCrcTabsResponse(JsonArray jSonObject) throws JsonSyntaxException {
        Object objFromJson = new Gson().fromJson(jSonObject.toString(), (Class<Object>) CrcTabsResponse[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        getCrcSharedViewModel().setCrcTabsList(ArraysKt.toList((Object[]) objFromJson));
        launchNextScreen();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCaseJsonArray(JsonArray jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson((JsonElement) jsonResponse.get(0).getAsJsonObject(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                errorResponse.getErrors();
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            CRCActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda21
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return UploadApplicantPhotographFragment.handleFailureCaseJsonArray$lambda$24(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda22
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return UploadApplicantPhotographFragment.handleFailureCaseJsonArray$lambda$25(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$24(UploadApplicantPhotographFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$25(UploadApplicantPhotographFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final void handleLivenessControlLaunch() {
        if (getCrcSharedViewModel().getLivelinessControl()) {
            checkLivenessControl();
        } else {
            dispatchCameraIntentForPhotoCapture();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void photoPickerLauncher$lambda$26(UploadApplicantPhotographFragment this$0, Uri uri) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (uri != null) {
            this$0.processSelectedImageUri(uri);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void legacyPickerLauncher$lambda$27(UploadApplicantPhotographFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1) {
            Intent data = result.getData();
            Uri data2 = data != null ? data.getData() : null;
            if (data2 != null) {
                this$0.processSelectedImageUri(data2);
            }
        }
    }

    private final void checkLivenessControl() {
        if (Intrinsics.areEqual(new SharedPreferencesTokenProvider(getActivity()).getUserCredentials().getLivenessControl(), Constant.UNIKREW) || Intrinsics.areEqual(new SharedPreferencesTokenProvider(getActivity()).getUserCredentials().getLivenessControl(), Constant.UNIKREW_CLOUD)) {
            launchUnikrewFacial();
        } else {
            checkIdemiaLicenseActivation();
        }
    }

    private final void launchUnikrewFacial() {
        Intent intent = new Intent(getActivity(), (Class<?>) UnikrewFacialActivity.class);
        intent.putExtra(Constant.UNIKREW_CAMERA_MODE, "FRONT");
        intent.putExtra(Constant.UNIKREW_ICAO, true);
        this.unikrewFacialLauncher.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void unikrewFacialLauncher$lambda$28(UploadApplicantPhotographFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1 && result.getData() != null) {
            Intent data = result.getData();
            Intrinsics.checkNotNull(data);
            if (data.hasExtra(Constant.UNIKREW_PROCESSED_IMAGE_PATH)) {
                Intent data2 = result.getData();
                Intrinsics.checkNotNull(data2);
                String stringExtra = data2.getStringExtra(Constant.UNIKREW_PROCESSED_IMAGE_PATH);
                Intrinsics.checkNotNull(stringExtra);
                this$0.sourceImagePath = stringExtra;
                this$0.processOnActivityResultForCameraIntent();
                return;
            }
        }
        result.getResultCode();
    }

    private final void initFooterView() {
        UploadApplicantPhotographFragmentBinding binding = getBinding();
        binding.crcFooterLayout.backButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda23
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                UploadApplicantPhotographFragment.initFooterView$lambda$33$lambda$29(this.f$0, view);
            }
        });
        binding.crcFooterLayout.backButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Back", "\n(واپس جائیں)", 0, false, 12, null));
        MaterialButton materialButton = binding.crcFooterLayout.nextButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.next);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        materialButton.setText(Util.setEnglishTextSpan$default(util, activity, string, "\n(آگے بڑھیں)", 0, false, 12, null));
        binding.crcFooterLayout.nextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                UploadApplicantPhotographFragment.initFooterView$lambda$33$lambda$32(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$33$lambda$29(UploadApplicantPhotographFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$33$lambda$32(final UploadApplicantPhotographFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.capturedImageFile != null) {
            BottomSheetUtils.INSTANCE.showPhotographConsentBottomSheet(this$0.getActivity(), new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return Unit.INSTANCE;
                }
            }, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment$$ExternalSyntheticLambda11
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return UploadApplicantPhotographFragment.initFooterView$lambda$33$lambda$32$lambda$31(this.f$0);
                }
            });
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.please_upload_photo);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.please_upload_photo_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initFooterView$lambda$33$lambda$32$lambda$31(UploadApplicantPhotographFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.saveApplicantPhotographTab();
        return Unit.INSTANCE;
    }
}