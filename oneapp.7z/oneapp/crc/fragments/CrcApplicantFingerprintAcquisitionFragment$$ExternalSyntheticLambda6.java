package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda6 implements Function0 {
    public /* synthetic */ CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda6() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return CrcApplicantFingerprintAcquisitionFragment.handleFailureCase$lambda$7(this.f$0);
    }
}