package pk.gov.nadra.oneapp.crc.fragments;

import com.google.gson.JsonObject;
import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.crc.fragments.SupportingDocumentsFragment;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SupportingDocumentsFragment$downloadUploadedDocument$1$$ExternalSyntheticLambda0 implements Function3 {
    public /* synthetic */ SupportingDocumentsFragment$downloadUploadedDocument$1$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return SupportingDocumentsFragment.C12501.invokeSuspend$lambda$0(supportingDocumentsFragment, (JsonObject) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}