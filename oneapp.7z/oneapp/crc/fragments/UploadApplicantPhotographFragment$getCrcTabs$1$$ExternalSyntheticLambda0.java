package pk.gov.nadra.oneapp.crc.fragments;

import com.google.gson.JsonArray;
import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class UploadApplicantPhotographFragment$getCrcTabs$1$$ExternalSyntheticLambda0 implements Function3 {
    public /* synthetic */ UploadApplicantPhotographFragment$getCrcTabs$1$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return UploadApplicantPhotographFragment.C12541.invokeSuspend$lambda$0(uploadApplicantPhotographFragment, (JsonArray) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}