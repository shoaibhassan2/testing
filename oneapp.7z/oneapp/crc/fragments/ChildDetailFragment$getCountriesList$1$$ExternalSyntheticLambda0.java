package pk.gov.nadra.oneapp.crc.fragments;

import com.google.gson.JsonArray;
import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.crc.fragments.ChildDetailFragment;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDetailFragment$getCountriesList$1$$ExternalSyntheticLambda0 implements Function3 {
    public /* synthetic */ ChildDetailFragment$getCountriesList$1$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return ChildDetailFragment.C12181.invokeSuspend$lambda$0(childDetailFragment, (JsonArray) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}