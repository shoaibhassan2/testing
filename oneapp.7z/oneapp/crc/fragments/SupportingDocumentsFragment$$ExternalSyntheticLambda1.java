package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function2;
import pk.gov.nadra.oneapp.models.supportingDocument.SupportingDocuments;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SupportingDocumentsFragment$$ExternalSyntheticLambda1 implements Function2 {
    public /* synthetic */ SupportingDocumentsFragment$$ExternalSyntheticLambda1() {
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return SupportingDocumentsFragment.onViewCreated$lambda$11$lambda$8(this.f$0, (SupportingDocuments.GroupDocument.GroupDocuments) obj, ((Integer) obj2).intValue());
    }
}