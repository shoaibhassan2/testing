package pk.gov.nadra.oneapp.crc.fragments;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.TuplesKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import pk.gov.nadra.oneapp.commonui.CnicMaskWatcher;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.adapter.viewmodel.CRCSharedViewModel;
import pk.gov.nadra.oneapp.crc.databinding.ChildParentDetailFragmentBinding;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.minor.MinorDataResponse;

/* compiled from: ChildParentDetailFragment.kt */
@Metadata(d1 = {"\u0000`\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!H\u0016J$\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020%2\b\u0010&\u001a\u0004\u0018\u00010'2\b\u0010(\u001a\u0004\u0018\u00010)H\u0016J\u001a\u0010*\u001a\u00020\u001f2\u0006\u0010+\u001a\u00020#2\b\u0010(\u001a\u0004\u0018\u00010)H\u0016J\b\u0010,\u001a\u00020\u001fH\u0002J\b\u0010-\u001a\u00020\u001fH\u0002J\u0010\u0010.\u001a\u00020\u001f2\u0006\u0010/\u001a\u00020\u0016H\u0002J\b\u00100\u001a\u00020\u001fH\u0002J\b\u00101\u001a\u00020\u001fH\u0002J\u0010\u00102\u001a\u00020\u001f2\u0006\u0010+\u001a\u00020\u001aH\u0002J\b\u00103\u001a\u00020\u001fH\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R'\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0019\u0012\u0004\u0012\u00020\u001a0\u00188BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u001d\u0010\t\u001a\u0004\b\u001b\u0010\u001c¨\u00064"}, d2 = {"Lpk/gov/nadra/oneapp/crc/fragments/ChildParentDetailFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/crc/databinding/ChildParentDetailFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/ChildParentDetailFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/crc/views/CRCActivity;)V", "childDetails", "Lpk/gov/nadra/oneapp/models/crc/minor/MinorDataResponse;", "fieldToViewMap", "", "", "Lcom/google/android/material/textfield/TextInputLayout;", "getFieldToViewMap", "()Ljava/util/Map;", "fieldToViewMap$delegate", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "displayErrors", "attachLayoutViews", "initParentViews", "childParentData", "launchNextActivity", "getParentViewsData", "scrollToView", "initFooterView", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ChildParentDetailFragment extends Fragment {
    private ChildParentDetailFragmentBinding _binding;
    public CRCActivity activity;
    private MinorDataResponse childDetails;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;

    /* renamed from: fieldToViewMap$delegate, reason: from kotlin metadata */
    private final Lazy fieldToViewMap = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildParentDetailFragment$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return ChildParentDetailFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
        }
    });

    public ChildParentDetailFragment() {
        final ChildParentDetailFragment childParentDetailFragment = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(childParentDetailFragment, Reflection.getOrCreateKotlinClass(CRCSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildParentDetailFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = childParentDetailFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildParentDetailFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = childParentDetailFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildParentDetailFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = childParentDetailFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    private final CRCSharedViewModel getCrcSharedViewModel() {
        return (CRCSharedViewModel) this.crcSharedViewModel.getValue();
    }

    private final ChildParentDetailFragmentBinding getBinding() {
        ChildParentDetailFragmentBinding childParentDetailFragmentBinding = this._binding;
        Intrinsics.checkNotNull(childParentDetailFragmentBinding);
        return childParentDetailFragmentBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final CRCActivity getActivity() {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity != null) {
            return cRCActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(CRCActivity cRCActivity) {
        Intrinsics.checkNotNullParameter(cRCActivity, "<set-?>");
        this.activity = cRCActivity;
    }

    private final Map<String, TextInputLayout> getFieldToViewMap() {
        return (Map) this.fieldToViewMap.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Map fieldToViewMap_delegate$lambda$0(ChildParentDetailFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        return MapsKt.mapOf(TuplesKt.to("fatherName", this$0.getBinding().fatherFullNameLayout.textInputLayout), TuplesKt.to("fatherNameUrdu", this$0.getBinding().urduFatherFullNameLayout.textInputLayout), TuplesKt.to("motherNameUrdu", this$0.getBinding().urduMotherFullNameLayout.textInputLayout), TuplesKt.to("motherName", this$0.getBinding().motherFullNameLayout.textInputLayout), TuplesKt.to("fatherCitizenNumber", this$0.getBinding().fatherCnicLayout.maskedCnicTextInputLayout), TuplesKt.to("motherCitizenNumber", this$0.getBinding().motherCnicLayout.maskedCnicTextInputLayout));
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.crc.views.CRCActivity");
        setActivity((CRCActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = ChildParentDetailFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        this.childDetails = getCrcSharedViewModel().getChildDetails();
        attachLayoutViews();
        displayErrors();
    }

    private final void displayErrors() {
        List<ErrorResponse.Error> errorsForField = getCrcSharedViewModel().getErrorsForField();
        List<ErrorResponse.Error> list = errorsForField;
        if (list == null || list.isEmpty()) {
            return;
        }
        for (ErrorResponse.Error error : errorsForField) {
            TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
            if (textInputLayout != null) {
                textInputLayout.setError(String.valueOf(error.getMessage()));
                textInputLayout.setErrorEnabled(true);
            }
        }
    }

    private final void attachLayoutViews() {
        SpannableString englishTextSpan$default;
        SpannableString englishTextSpan$default2;
        SpannableStringBuilder spannableStringBuilderHintWithRedStar;
        SpannableString englishTextSpan$default3;
        SpannableString englishTextSpan$default4;
        SpannableStringBuilder spannableStringBuilderHintWithRedStar2;
        ChildParentDetailFragmentBinding binding = getBinding();
        TextView textView = binding.crcHeaderLayout.textTitle;
        String upperCase = getCrcSharedViewModel().getDocumentTypeValue().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(String.valueOf(upperCase));
        binding.crcHeaderLayout.textSubtitle.setText(String.valueOf(getCrcSharedViewModel().getApplicationTypeValue()));
        binding.crcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.roboto_medium));
        binding.crcHeaderLayout.iconHome.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildParentDetailFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildParentDetailFragment.attachLayoutViews$lambda$6$lambda$3(this.f$0, view);
            }
        });
        binding.crcHeaderLayout.iconInfo.setVisibility(0);
        binding.crcHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildParentDetailFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildParentDetailFragment.attachLayoutViews$lambda$6$lambda$4(this.f$0, view);
            }
        });
        binding.crcHeaderLayout.tvHeaderTrackingId.setText(getCrcSharedViewModel().getTrackingId());
        binding.crcHeaderLayout.tvHeaderFee.setText(String.valueOf(getCrcSharedViewModel().getAmount()));
        binding.crcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildParentDetailFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildParentDetailFragment.attachLayoutViews$lambda$6$lambda$5(this.f$0, view);
            }
        });
        binding.stepTitleHeadingLayout.tvStepTitleHeading.setText(getString(R.string.parent_details));
        binding.stepTitleHeadingLayout.tvStepTitleHeadingUrdu.setText("والدین کی تفصیلات");
        binding.fatherDetailsHeading.tvStepHeading.setText(getString(R.string.father_details));
        binding.fatherDetailsHeading.tvStepHeadingUrdu.setText(" (والد کی تفصیلات) ");
        binding.fatherCnicLayout.maskedCnicEditText.addTextChangedListener(new CnicMaskWatcher("#####-#######-#"));
        TextInputLayout textInputLayout = binding.fatherCnicLayout.maskedCnicTextInputLayout;
        CRCActivity activity = getActivity();
        MinorDataResponse minorDataResponse = null;
        if (activity != null) {
            String string = getString(R.string.citizen_number);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            englishTextSpan$default = Util.setEnglishTextSpan$default(Util.INSTANCE, activity, string, " (شناختی کارڈ نمبر) ", 0, true, 4, null);
        } else {
            englishTextSpan$default = null;
        }
        textInputLayout.setHint(englishTextSpan$default);
        binding.fatherCnicLayout.maskedCnicEditText.setImeOptions(5);
        Util util = Util.INSTANCE;
        CRCActivity activity2 = getActivity();
        TextInputEditText maskedCnicEditText = binding.fatherCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        TextInputLayout maskedCnicTextInputLayout = binding.fatherCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        util.removeErrorOnTextChanged(activity2, maskedCnicEditText, maskedCnicTextInputLayout);
        TextInputLayout textInputLayout2 = binding.fatherFullNameLayout.textInputLayout;
        CRCActivity activity3 = getActivity();
        if (activity3 != null) {
            String string2 = getString(R.string.full_name);
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            englishTextSpan$default2 = Util.setEnglishTextSpan$default(Util.INSTANCE, activity3, string2, " (مکمل نام) ", 0, true, 4, null);
        } else {
            englishTextSpan$default2 = null;
        }
        textInputLayout2.setHint(englishTextSpan$default2);
        binding.fatherFullNameLayout.textInputEditText.setImeOptions(5);
        Util util2 = Util.INSTANCE;
        CRCActivity activity4 = getActivity();
        TextInputEditText textInputEditText = binding.fatherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        TextInputLayout textInputLayout3 = binding.fatherFullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout3, "textInputLayout");
        util2.removeErrorOnTextChanged(activity4, textInputEditText, textInputLayout3);
        TextInputLayout textInputLayout4 = binding.urduFatherFullNameLayout.textInputLayout;
        CRCActivity activity5 = getActivity();
        if (activity5 != null) {
            String string3 = getString(R.string.urdu_full_name);
            Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
            spannableStringBuilderHintWithRedStar = Util.INSTANCE.hintWithRedStar(activity5, string3);
        } else {
            spannableStringBuilderHintWithRedStar = null;
        }
        textInputLayout4.setHint(spannableStringBuilderHintWithRedStar);
        binding.urduFatherFullNameLayout.textInputLayout.setGravity(5);
        binding.urduFatherFullNameLayout.textInputLayout.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.mehr_nastaliq));
        binding.urduFatherFullNameLayout.textInputEditText.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.mehr_nastaliq));
        binding.urduFatherFullNameLayout.textInputEditText.setImeOptions(5);
        Util util3 = Util.INSTANCE;
        CRCActivity activity6 = getActivity();
        TextInputEditText textInputEditText2 = binding.urduFatherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        TextInputLayout textInputLayout5 = binding.urduFatherFullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout5, "textInputLayout");
        util3.removeErrorOnTextChanged(activity6, textInputEditText2, textInputLayout5);
        Util util4 = Util.INSTANCE;
        TextInputEditText textInputEditText3 = binding.fatherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText3, "textInputEditText");
        TextInputEditText textInputEditText4 = textInputEditText3;
        TextInputEditText textInputEditText5 = binding.urduFatherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText5, "textInputEditText");
        Util.setUpFocusChangeListener$default(util4, textInputEditText4, textInputEditText5, getActivity(), null, 8, null);
        binding.motherDetailsHeading.tvStepHeading.setText(getString(R.string.mother_details));
        binding.motherDetailsHeading.tvStepHeadingUrdu.setText(" (والدہ کی تفصیلات) ");
        binding.motherCnicLayout.maskedCnicEditText.addTextChangedListener(new CnicMaskWatcher("#####-#######-#"));
        TextInputLayout textInputLayout6 = binding.motherCnicLayout.maskedCnicTextInputLayout;
        CRCActivity activity7 = getActivity();
        if (activity7 != null) {
            Util util5 = Util.INSTANCE;
            CRCActivity cRCActivity = activity7;
            String string4 = getString(R.string.citizen_number);
            Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
            englishTextSpan$default3 = Util.setEnglishTextSpan$default(util5, cRCActivity, string4, " (شناختی کارڈ نمبر) ", 0, true, 4, null);
        } else {
            englishTextSpan$default3 = null;
        }
        textInputLayout6.setHint(englishTextSpan$default3);
        binding.motherCnicLayout.maskedCnicEditText.setImeOptions(5);
        Util util6 = Util.INSTANCE;
        CRCActivity activity8 = getActivity();
        TextInputEditText maskedCnicEditText2 = binding.motherCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText2, "maskedCnicEditText");
        TextInputLayout maskedCnicTextInputLayout2 = binding.motherCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout2, "maskedCnicTextInputLayout");
        util6.removeErrorOnTextChanged(activity8, maskedCnicEditText2, maskedCnicTextInputLayout2);
        TextInputLayout textInputLayout7 = binding.motherFullNameLayout.textInputLayout;
        CRCActivity activity9 = getActivity();
        if (activity9 != null) {
            Util util7 = Util.INSTANCE;
            CRCActivity cRCActivity2 = activity9;
            String string5 = getString(R.string.full_name);
            Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
            englishTextSpan$default4 = Util.setEnglishTextSpan$default(util7, cRCActivity2, string5, " (مکمل نام) ", 0, true, 4, null);
        } else {
            englishTextSpan$default4 = null;
        }
        textInputLayout7.setHint(englishTextSpan$default4);
        binding.motherFullNameLayout.textInputEditText.setImeOptions(5);
        Util util8 = Util.INSTANCE;
        CRCActivity activity10 = getActivity();
        TextInputEditText textInputEditText6 = binding.motherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText6, "textInputEditText");
        TextInputLayout textInputLayout8 = binding.motherFullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout8, "textInputLayout");
        util8.removeErrorOnTextChanged(activity10, textInputEditText6, textInputLayout8);
        TextInputLayout textInputLayout9 = binding.urduMotherFullNameLayout.textInputLayout;
        CRCActivity activity11 = getActivity();
        if (activity11 != null) {
            String string6 = getString(R.string.urdu_full_name);
            Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
            spannableStringBuilderHintWithRedStar2 = Util.INSTANCE.hintWithRedStar(activity11, string6);
        } else {
            spannableStringBuilderHintWithRedStar2 = null;
        }
        textInputLayout9.setHint(spannableStringBuilderHintWithRedStar2);
        binding.urduMotherFullNameLayout.textInputLayout.setGravity(5);
        binding.urduMotherFullNameLayout.textInputLayout.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.mehr_nastaliq));
        binding.urduMotherFullNameLayout.textInputEditText.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.mehr_nastaliq));
        binding.urduMotherFullNameLayout.textInputEditText.setImeOptions(5);
        Util util9 = Util.INSTANCE;
        CRCActivity activity12 = getActivity();
        TextInputEditText textInputEditText7 = binding.urduMotherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText7, "textInputEditText");
        TextInputLayout textInputLayout10 = binding.urduMotherFullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout10, "textInputLayout");
        util9.removeErrorOnTextChanged(activity12, textInputEditText7, textInputLayout10);
        Util util10 = Util.INSTANCE;
        TextInputEditText textInputEditText8 = binding.motherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText8, "textInputEditText");
        TextInputEditText textInputEditText9 = binding.urduMotherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText9, "textInputEditText");
        Util.setUpFocusChangeListener$default(util10, textInputEditText8, textInputEditText9, getActivity(), null, 8, null);
        initFooterView();
        if (this.childDetails == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
        }
        MinorDataResponse minorDataResponse2 = this.childDetails;
        if (minorDataResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
        } else {
            minorDataResponse = minorDataResponse2;
        }
        initParentViews(minorDataResponse);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$6$lambda$3(ChildParentDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$6$lambda$4(ChildParentDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.crc_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.CRC_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$6$lambda$5(ChildParentDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    private final void initParentViews(MinorDataResponse childParentData) {
        ChildParentDetailFragmentBinding binding = getBinding();
        binding.fatherCnicLayout.maskedCnicEditText.setText(childParentData.getFatherCitizenNumber());
        binding.fatherFullNameLayout.textInputEditText.setText(childParentData.getMinorFatherName());
        binding.urduFatherFullNameLayout.textInputEditText.setText(childParentData.getMinorFatherNameLocal());
        String motherCitizenNumber = childParentData.getMotherCitizenNumber();
        if (motherCitizenNumber != null && motherCitizenNumber.length() != 0) {
            binding.motherCnicLayout.maskedCnicEditText.setText(childParentData.getMotherCitizenNumber());
        }
        binding.motherFullNameLayout.textInputEditText.setText(childParentData.getMinorMotherName());
        binding.urduMotherFullNameLayout.textInputEditText.setText(childParentData.getMinorMotherNameLocal());
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        TextInputLayout maskedCnicTextInputLayout = binding.fatherCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        TextInputEditText maskedCnicEditText = binding.fatherCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        util.disableTextInputEditText(activity, maskedCnicTextInputLayout, maskedCnicEditText, childParentData.getMeta().getFatherCitizenNumber().getDisable());
        Util util2 = Util.INSTANCE;
        CRCActivity activity2 = getActivity();
        TextInputLayout textInputLayout = binding.fatherFullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout, "textInputLayout");
        TextInputEditText textInputEditText = binding.fatherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        util2.disableTextInputEditText(activity2, textInputLayout, textInputEditText, childParentData.getMeta().getFatherName().getDisable());
        Util util3 = Util.INSTANCE;
        CRCActivity activity3 = getActivity();
        TextInputLayout textInputLayout2 = binding.urduFatherFullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        TextInputEditText textInputEditText2 = binding.urduFatherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        util3.disableTextInputEditText(activity3, textInputLayout2, textInputEditText2, childParentData.getMeta().getFatherNameLocal().getDisable());
        Util util4 = Util.INSTANCE;
        CRCActivity activity4 = getActivity();
        TextInputLayout maskedCnicTextInputLayout2 = binding.motherCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout2, "maskedCnicTextInputLayout");
        TextInputEditText maskedCnicEditText2 = binding.motherCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText2, "maskedCnicEditText");
        util4.disableTextInputEditText(activity4, maskedCnicTextInputLayout2, maskedCnicEditText2, childParentData.getMeta().getMotherCitizenNumber().getDisable());
        Util util5 = Util.INSTANCE;
        CRCActivity activity5 = getActivity();
        TextInputLayout textInputLayout3 = binding.motherFullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout3, "textInputLayout");
        TextInputEditText textInputEditText3 = binding.motherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText3, "textInputEditText");
        util5.disableTextInputEditText(activity5, textInputLayout3, textInputEditText3, childParentData.getMeta().getMotherName().getDisable());
        Util util6 = Util.INSTANCE;
        CRCActivity activity6 = getActivity();
        TextInputLayout textInputLayout4 = binding.urduMotherFullNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout4, "textInputLayout");
        TextInputEditText textInputEditText4 = binding.urduMotherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText4, "textInputEditText");
        util6.disableTextInputEditText(activity6, textInputLayout4, textInputEditText4, childParentData.getMeta().getMotherNameLocal().getDisable());
        if (!childParentData.getMeta().getMotherNameLocal().getDisable()) {
            Util util7 = Util.INSTANCE;
            TextInputEditText textInputEditText5 = binding.urduMotherFullNameLayout.textInputEditText;
            Intrinsics.checkNotNullExpressionValue(textInputEditText5, "textInputEditText");
            util7.restrictToUrduOnly(textInputEditText5);
        }
        if (childParentData.getMeta().getFatherNameLocal().getDisable()) {
            return;
        }
        Util util8 = Util.INSTANCE;
        TextInputEditText textInputEditText6 = binding.urduFatherFullNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText6, "textInputEditText");
        util8.restrictToUrduOnly(textInputEditText6);
    }

    private final void launchNextActivity() {
        boolean z;
        ChildParentDetailFragmentBinding binding = getBinding();
        String strValueOf = String.valueOf(binding.fatherCnicLayout.maskedCnicEditText.getText());
        boolean z2 = false;
        if (strValueOf == null || strValueOf.length() == 0) {
            binding.fatherCnicLayout.maskedCnicTextInputLayout.setError(String.valueOf(binding.fatherCnicLayout.maskedCnicTextInputLayout.getHint()));
            binding.fatherCnicLayout.maskedCnicTextInputLayout.setErrorEnabled(true);
            Util util = Util.INSTANCE;
            CRCActivity activity = getActivity();
            TextInputEditText maskedCnicEditText = binding.fatherCnicLayout.maskedCnicEditText;
            Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
            TextInputLayout maskedCnicTextInputLayout = binding.fatherCnicLayout.maskedCnicTextInputLayout;
            Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
            util.removeErrorOnTextChanged(activity, maskedCnicEditText, maskedCnicTextInputLayout);
            z = false;
        } else {
            z = true;
        }
        if (String.valueOf(binding.fatherCnicLayout.maskedCnicEditText.getText()).length() < 15) {
            binding.fatherCnicLayout.maskedCnicTextInputLayout.setError("Enter valid CNIC");
            binding.fatherCnicLayout.maskedCnicTextInputLayout.setErrorEnabled(true);
            Util util2 = Util.INSTANCE;
            CRCActivity activity2 = getActivity();
            TextInputEditText maskedCnicEditText2 = binding.fatherCnicLayout.maskedCnicEditText;
            Intrinsics.checkNotNullExpressionValue(maskedCnicEditText2, "maskedCnicEditText");
            TextInputLayout maskedCnicTextInputLayout2 = binding.fatherCnicLayout.maskedCnicTextInputLayout;
            Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout2, "maskedCnicTextInputLayout");
            util2.removeErrorOnTextChanged(activity2, maskedCnicEditText2, maskedCnicTextInputLayout2);
            z = false;
        }
        String strValueOf2 = String.valueOf(binding.fatherFullNameLayout.textInputEditText.getText());
        if (strValueOf2 == null || strValueOf2.length() == 0) {
            binding.fatherFullNameLayout.textInputLayout.setError(String.valueOf(binding.fatherFullNameLayout.textInputLayout.getHint()));
            binding.fatherFullNameLayout.textInputLayout.setErrorEnabled(true);
            Util util3 = Util.INSTANCE;
            CRCActivity activity3 = getActivity();
            TextInputEditText textInputEditText = binding.fatherFullNameLayout.textInputEditText;
            Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
            TextInputLayout textInputLayout = binding.fatherFullNameLayout.textInputLayout;
            Intrinsics.checkNotNullExpressionValue(textInputLayout, "textInputLayout");
            util3.removeErrorOnTextChanged(activity3, textInputEditText, textInputLayout);
            z = false;
        }
        String strValueOf3 = String.valueOf(binding.motherCnicLayout.maskedCnicEditText.getText());
        if (strValueOf3 == null || strValueOf3.length() == 0) {
            binding.motherCnicLayout.maskedCnicTextInputLayout.setError(String.valueOf(binding.motherCnicLayout.maskedCnicTextInputLayout.getHint()));
            binding.motherCnicLayout.maskedCnicTextInputLayout.setErrorEnabled(true);
            Util util4 = Util.INSTANCE;
            CRCActivity activity4 = getActivity();
            TextInputEditText maskedCnicEditText3 = binding.motherCnicLayout.maskedCnicEditText;
            Intrinsics.checkNotNullExpressionValue(maskedCnicEditText3, "maskedCnicEditText");
            TextInputLayout maskedCnicTextInputLayout3 = binding.motherCnicLayout.maskedCnicTextInputLayout;
            Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout3, "maskedCnicTextInputLayout");
            util4.removeErrorOnTextChanged(activity4, maskedCnicEditText3, maskedCnicTextInputLayout3);
            z = false;
        }
        if (String.valueOf(binding.motherCnicLayout.maskedCnicEditText.getText()).length() < 15) {
            binding.motherCnicLayout.maskedCnicTextInputLayout.setError("Enter valid CNIC");
            binding.motherCnicLayout.maskedCnicTextInputLayout.setErrorEnabled(true);
            Util util5 = Util.INSTANCE;
            CRCActivity activity5 = getActivity();
            TextInputEditText maskedCnicEditText4 = binding.motherCnicLayout.maskedCnicEditText;
            Intrinsics.checkNotNullExpressionValue(maskedCnicEditText4, "maskedCnicEditText");
            TextInputLayout maskedCnicTextInputLayout4 = binding.motherCnicLayout.maskedCnicTextInputLayout;
            Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout4, "maskedCnicTextInputLayout");
            util5.removeErrorOnTextChanged(activity5, maskedCnicEditText4, maskedCnicTextInputLayout4);
            z = false;
        }
        String strValueOf4 = String.valueOf(binding.motherFullNameLayout.textInputEditText.getText());
        if (strValueOf4 == null || strValueOf4.length() == 0) {
            binding.motherFullNameLayout.textInputLayout.setError(String.valueOf(binding.motherFullNameLayout.textInputLayout.getHint()));
            binding.motherFullNameLayout.textInputLayout.setErrorEnabled(true);
            Util util6 = Util.INSTANCE;
            CRCActivity activity6 = getActivity();
            TextInputEditText textInputEditText2 = binding.motherFullNameLayout.textInputEditText;
            Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
            TextInputLayout textInputLayout2 = binding.motherFullNameLayout.textInputLayout;
            Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
            util6.removeErrorOnTextChanged(activity6, textInputEditText2, textInputLayout2);
        } else {
            z2 = z;
        }
        if (z2) {
            getParentViewsData();
        }
    }

    private final void getParentViewsData() {
        ChildParentDetailFragmentBinding binding = getBinding();
        MinorDataResponse minorDataResponse = this.childDetails;
        MinorDataResponse minorDataResponse2 = null;
        if (minorDataResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse = null;
        }
        minorDataResponse.setFatherCitizenNumber(StringsKt.replace$default(String.valueOf(binding.fatherCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null));
        minorDataResponse.setMinorFatherName(String.valueOf(binding.fatherFullNameLayout.textInputEditText.getText()));
        minorDataResponse.setMinorFatherNameLocal(String.valueOf(binding.urduFatherFullNameLayout.textInputEditText.getText()));
        minorDataResponse.setMotherCitizenNumber(StringsKt.replace$default(String.valueOf(binding.motherCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null));
        minorDataResponse.setMinorMotherName(String.valueOf(binding.motherFullNameLayout.textInputEditText.getText()));
        minorDataResponse.setMinorMotherNameLocal(String.valueOf(binding.urduMotherFullNameLayout.textInputEditText.getText()));
        CRCSharedViewModel crcSharedViewModel = getCrcSharedViewModel();
        MinorDataResponse minorDataResponse3 = this.childDetails;
        if (minorDataResponse3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
        } else {
            minorDataResponse2 = minorDataResponse3;
        }
        crcSharedViewModel.setChildDetails(minorDataResponse2);
        getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.childDisabilityDetailFragment);
    }

    private final void scrollToView(final TextInputLayout view) {
        getBinding().childParentDetailsScrollView.post(new Runnable() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildParentDetailFragment$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                ChildParentDetailFragment.scrollToView$lambda$11(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void scrollToView$lambda$11(ChildParentDetailFragment this$0, TextInputLayout view) {
        int top;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(view, "$view");
        Rect rect = new Rect();
        this$0.getBinding().childParentDetailsScrollView.getHitRect(rect);
        int iHeight = rect.height();
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        int[] iArr2 = new int[2];
        this$0.getBinding().childParentDetailsScrollView.getLocationOnScreen(iArr2);
        int i = iArr[1] - iArr2[1];
        int height = view.getHeight();
        if (i < 0) {
            top = view.getTop();
        } else if (i + height > iHeight) {
            top = view.getBottom() - iHeight;
        } else {
            top = (view.getTop() - (iHeight / 2)) + (height / 2);
        }
        this$0.getBinding().childParentDetailsScrollView.smoothScrollTo(0, top);
    }

    private final void initFooterView() {
        ChildParentDetailFragmentBinding binding = getBinding();
        binding.crcFooterLayout.backButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildParentDetailFragment$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildParentDetailFragment.initFooterView$lambda$14$lambda$12(this.f$0, view);
            }
        });
        binding.crcFooterLayout.backButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Back", "\n(واپس جائیں)", 0, false, 12, null));
        MaterialButton materialButton = binding.crcFooterLayout.nextButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.next);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        materialButton.setText(Util.setEnglishTextSpan$default(util, activity, string, "\n(آگے بڑھیں)", 0, false, 12, null));
        binding.crcFooterLayout.nextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildParentDetailFragment$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildParentDetailFragment.initFooterView$lambda$14$lambda$13(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$14$lambda$12(ChildParentDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$14$lambda$13(ChildParentDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.launchNextActivity();
    }
}