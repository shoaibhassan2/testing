package pk.gov.nadra.oneapp.crc.fragments;

import android.content.Intent;
import java.io.File;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.commonutils.document.ViewDocumentActivity;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data;

/* compiled from: SupportingDocumentsFragment.kt */
@Metadata(d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\b\u0010\u0006\u001a\u00020\u0003H\u0016¨\u0006\u0007"}, d2 = {"pk/gov/nadra/oneapp/crc/fragments/SupportingDocumentsFragment$iwritePhotoBase64DataServiceResult$1", "Lpk/gov/nadra/oneapp/commonutils/utils/WritePhotoBase64Data$ICompressImageTaskListener;", "onComplete", "", "compressed", "Ljava/io/File;", "onError", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class SupportingDocumentsFragment$iwritePhotoBase64DataServiceResult$1 implements WritePhotoBase64Data.ICompressImageTaskListener {
    SupportingDocumentsFragment$iwritePhotoBase64DataServiceResult$1() {
    }

    @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
    public void onComplete(File compressed) {
        Intrinsics.checkNotNullParameter(compressed, "compressed");
        LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
        Intent intent = new Intent(this.this$0.getActivity(), (Class<?>) ViewDocumentActivity.class);
        intent.putExtra(Constant.TRACKING_ID, this.this$0.getCrcSharedViewModel().getTrackingId());
        intent.putExtra(Constant.DOCUMENT_FILE_PATH, compressed.getAbsolutePath());
        this.this$0.startActivity(intent);
    }

    @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
    public void onError() {
        LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
    }
}