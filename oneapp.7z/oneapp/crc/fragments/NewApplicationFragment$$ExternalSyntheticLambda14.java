package pk.gov.nadra.oneapp.crc.fragments;

import android.content.Intent;
import kotlin.jvm.functions.Function2;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class NewApplicationFragment$$ExternalSyntheticLambda14 implements Function2 {
    public /* synthetic */ NewApplicationFragment$$ExternalSyntheticLambda14() {
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return NewApplicationFragment.dispatchCameraIntentForPhotoCapture$lambda$58(this.f$0, (String) obj, (Intent) obj2);
    }
}