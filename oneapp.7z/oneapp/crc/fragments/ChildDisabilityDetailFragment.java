package pk.gov.nadra.oneapp.crc.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.farrakhj.stringpickerlibrary.views.StringPickerActivity;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.internal.ViewUtils;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.adapter.DisabilityAdapter;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.adapter.viewmodel.CRCSharedViewModel;
import pk.gov.nadra.oneapp.crc.databinding.ChildDisabilityDetailFragmentBinding;
import pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment;
import pk.gov.nadra.oneapp.crc.utils.MethodName;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;
import pk.gov.nadra.oneapp.models.crc.DisabilityErrorResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.UpdateChildResponse;
import pk.gov.nadra.oneapp.models.crc.library.LibraryResponse;
import pk.gov.nadra.oneapp.models.crc.minor.MinorDataResponse;
import pk.gov.nadra.oneapp.models.crc.minor.MinorDisability;
import pk.gov.nadra.oneapp.models.crc.newChildDetails.UpdateChildDetailsRequest;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: ChildDisabilityDetailFragment.kt */
@Metadata(d1 = {"\u0000¼\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u00012\u00020\u0002B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u0010\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020%H\u0016J$\u0010&\u001a\u00020'2\u0006\u0010(\u001a\u00020)2\b\u0010*\u001a\u0004\u0018\u00010+2\b\u0010,\u001a\u0004\u0018\u00010-H\u0016J\u001a\u0010.\u001a\u00020#2\u0006\u0010/\u001a\u00020'2\b\u0010,\u001a\u0004\u0018\u00010-H\u0016J\b\u00100\u001a\u00020#H\u0002J\b\u00101\u001a\u00020#H\u0002J\b\u00102\u001a\u00020#H\u0002J\u0010\u00103\u001a\u00020#2\u0006\u00104\u001a\u000205H\u0002J%\u00106\u001a\u00020#2\u0016\u00107\u001a\u0012\u0012\u0004\u0012\u00020\u001e0\u0019j\b\u0012\u0004\u0012\u00020\u001e`8H\u0002¢\u0006\u0002\u00109J\u0010\u0010>\u001a\u00020#2\u0006\u0010?\u001a\u00020\u001eH\u0002J\b\u0010@\u001a\u00020#H\u0002J\u0010\u0010A\u001a\u00020#2\u0006\u0010B\u001a\u00020CH\u0002J\u0018\u0010D\u001a\u00020#2\u0006\u0010E\u001a\u00020F2\u0006\u0010G\u001a\u00020HH\u0002J\u0018\u0010I\u001a\u00020#2\u0006\u0010J\u001a\u00020F2\u0006\u0010K\u001a\u00020LH\u0002J\u0010\u0010M\u001a\u00020#2\u0006\u0010E\u001a\u00020NH\u0002J\u0018\u0010O\u001a\u00020#2\u0006\u0010J\u001a\u00020N2\u0006\u0010K\u001a\u00020LH\u0002J\u0010\u0010P\u001a\u00020#2\u0006\u0010Q\u001a\u00020RH\u0002J\u0010\u0010S\u001a\u00020#2\u0006\u0010Q\u001a\u00020RH\u0002J\u001a\u0010T\u001a\u00020#2\b\u0010U\u001a\u0004\u0018\u00010'2\u0006\u0010V\u001a\u000205H\u0017J\b\u0010W\u001a\u00020#H\u0002R\u001b\u0010\u0005\u001a\u00020\u00068BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\u000b\u001a\u00020\fX\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\u00020\u000e8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0012\u001a\u00020\u0013X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u001a0\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082.¢\u0006\u0002\n\u0000R\u0014\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u001e0\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020!0 X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010:\u001a\u0010\u0012\f\u0012\n =*\u0004\u0018\u00010<0<0;X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006X"}, d2 = {"Lpk/gov/nadra/oneapp/crc/fragments/ChildDisabilityDetailFragment;", "Landroidx/fragment/app/Fragment;", "Landroid/view/View$OnFocusChangeListener;", "<init>", "()V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "childDetails", "Lpk/gov/nadra/oneapp/models/crc/minor/MinorDataResponse;", "_binding", "Lpk/gov/nadra/oneapp/crc/databinding/ChildDisabilityDetailFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/ChildDisabilityDetailFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/crc/views/CRCActivity;)V", "disabilityTypes", "Ljava/util/ArrayList;", "Lpk/gov/nadra/oneapp/models/crc/library/LibraryResponse;", "disabilityAdapter", "Lpk/gov/nadra/oneapp/commonutils/adapter/DisabilityAdapter;", "selectedDisabilityList", "", "disabilityList", "", "Lpk/gov/nadra/oneapp/models/crc/minor/MinorDisability;", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "attachLayoutViews", "addDisability", "launchNextActivity", "mapUpdateChildDetails", "isSkipWarnings", "", "launchStringPickerActivity", "arrayList", "Lkotlin/collections/ArrayList;", "(Ljava/util/ArrayList;)V", "startForResult", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "addChip", "s", "getDisabilityTypes", "processUpdateChildDetails", "updateChildDetailsRequest", "Lpk/gov/nadra/oneapp/models/crc/newChildDetails/UpdateChildDetailsRequest;", "processLibrarySuccessResponse", "jSonObject", "Lcom/google/gson/JsonArray;", "methodName", "Lpk/gov/nadra/oneapp/crc/utils/MethodName;", "handleFailureCaseJsonArray", "jsonResponse", "responseCode", "", "processDataUpdationSuccessResponse", "Lcom/google/gson/JsonObject;", "handleFailureCase", "handleViewErrors", "errorResponse", "Lpk/gov/nadra/oneapp/models/crc/ErrorResponse;", "handleDisabilityErrors", "onFocusChange", "v", "hasFocus", "initFooterView", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ChildDisabilityDetailFragment extends Fragment implements View.OnFocusChangeListener {
    private ChildDisabilityDetailFragmentBinding _binding;
    public CRCActivity activity;
    private MinorDataResponse childDetails;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;
    private DisabilityAdapter disabilityAdapter;
    private final ActivityResultLauncher<Intent> startForResult;
    private ArrayList<LibraryResponse> disabilityTypes = new ArrayList<>();
    private ArrayList<String> selectedDisabilityList = new ArrayList<>();
    private List<MinorDisability> disabilityList = new ArrayList();

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$13$lambda$8(View view) {
    }

    public ChildDisabilityDetailFragment() {
        final ChildDisabilityDetailFragment childDisabilityDetailFragment = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(childDisabilityDetailFragment, Reflection.getOrCreateKotlinClass(CRCSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = childDisabilityDetailFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = childDisabilityDetailFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = childDisabilityDetailFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda15
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                ChildDisabilityDetailFragment.startForResult$lambda$20(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.startForResult = activityResultLauncherRegisterForActivityResult;
    }

    private final CRCSharedViewModel getCrcSharedViewModel() {
        return (CRCSharedViewModel) this.crcSharedViewModel.getValue();
    }

    private final ChildDisabilityDetailFragmentBinding getBinding() {
        ChildDisabilityDetailFragmentBinding childDisabilityDetailFragmentBinding = this._binding;
        Intrinsics.checkNotNull(childDisabilityDetailFragmentBinding);
        return childDisabilityDetailFragmentBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final CRCActivity getActivity() {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity != null) {
            return cRCActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(CRCActivity cRCActivity) {
        Intrinsics.checkNotNullParameter(cRCActivity, "<set-?>");
        this.activity = cRCActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.crc.views.CRCActivity");
        setActivity((CRCActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = ChildDisabilityDetailFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        this.childDetails = getCrcSharedViewModel().getChildDetails();
        attachLayoutViews();
    }

    private final void attachLayoutViews() throws Resources.NotFoundException {
        final ChildDisabilityDetailFragmentBinding binding = getBinding();
        TextView textView = binding.crcHeaderLayout.textTitle;
        String upperCase = getCrcSharedViewModel().getDocumentTypeValue().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(String.valueOf(upperCase));
        binding.crcHeaderLayout.textSubtitle.setText(String.valueOf(getCrcSharedViewModel().getApplicationTypeValue()));
        binding.crcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.roboto_medium));
        binding.crcHeaderLayout.iconHome.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$0(this.f$0, view);
            }
        });
        binding.crcHeaderLayout.iconInfo.setVisibility(0);
        binding.crcHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda17
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$1(this.f$0, view);
            }
        });
        binding.crcHeaderLayout.tvHeaderTrackingId.setText(getCrcSharedViewModel().getTrackingId());
        binding.crcHeaderLayout.tvHeaderFee.setText(String.valueOf(getCrcSharedViewModel().getAmount()));
        binding.crcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda18
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$2(this.f$0, view);
            }
        });
        binding.stepTitleHeadingLayout.tvStepTitleHeading.setText(getString(R.string.disablity_details));
        binding.stepTitleHeadingLayout.tvStepTitleHeadingUrdu.setText("معذوری کی تفصیلات");
        binding.disabilityDetailsHeading.linearLayoutInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda19
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$3(this.f$0, view);
            }
        });
        TextView textView2 = binding.tvInfoMessage;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.proceed_child_disability_details);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView2.setText(Util.setEnglishTextSpan$default(util, activity, string, "\nاگر بچے کے پاس کوئی معذوری کی تفصیلات نہیں ہیں تو برائے کرم 'آگے بڑھیں' پر کلک کریں۔", 0, false, 12, null));
        TextInputLayout textInputLayout = binding.disabilityTypeLayout.textInputLayout;
        Util util2 = Util.INSTANCE;
        CRCActivity activity2 = getActivity();
        String string2 = getString(R.string.disablity_type);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textInputLayout.setHint(Util.setEnglishTextSpan$default(util2, activity2, string2, " (معذوری کی نوعیت) ", 0, false, 12, null));
        binding.disabilityTypeLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$4(this.f$0, view);
            }
        });
        Util util3 = Util.INSTANCE;
        CRCActivity activity3 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView = binding.disabilityTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        TextInputLayout textInputLayout2 = binding.disabilityTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        util3.removeErrorOnAutoCompleteTextChanged(activity3, autoCompleteTextView, textInputLayout2);
        TextInputLayout textInputLayout3 = binding.disabiltyCertificateLayout.textInputLayout;
        Util util4 = Util.INSTANCE;
        CRCActivity activity4 = getActivity();
        String string3 = getString(R.string.disability_certificate);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        textInputLayout3.setHint(Util.setEnglishTextSpan$default(util4, activity4, string3, " (معذوری سرٹیفیکیٹ نمبر) ", 0, false, 12, null));
        TextInputLayout textInputLayout4 = binding.disabilityIssuanceDateLayout.textInputLayout;
        Util util5 = Util.INSTANCE;
        CRCActivity activity5 = getActivity();
        String string4 = getString(R.string.issuance_date);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        textInputLayout4.setHint(Util.setEnglishTextSpan$default(util5, activity5, string4, " (جاری ہونے کی تاریخ) ", 0, false, 12, null));
        binding.disabiltyCertificateLayout.textInputEditText.setImeOptions(6);
        Util util6 = Util.INSTANCE;
        CRCActivity activity6 = getActivity();
        TextInputEditText textInputEditText = binding.disabiltyCertificateLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        TextInputLayout textInputLayout5 = binding.disabiltyCertificateLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout5, "textInputLayout");
        util6.removeErrorOnTextChanged(activity6, textInputEditText, textInputLayout5);
        binding.disabilityIssuanceDateLayout.textInputEditText.setFocusableInTouchMode(false);
        binding.disabilityIssuanceDateLayout.textInputEditText.setFocusable(false);
        binding.disabilityIssuanceDateLayout.textInputEditText.setClickable(true);
        binding.disabilityIssuanceDateLayout.textInputLayout.setEndIconMode(-1);
        binding.disabilityIssuanceDateLayout.textInputLayout.setEndIconDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.ic_calender));
        Util util7 = Util.INSTANCE;
        CRCActivity activity7 = getActivity();
        TextInputEditText textInputEditText2 = binding.disabilityIssuanceDateLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        TextInputLayout textInputLayout6 = binding.disabilityIssuanceDateLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout6, "textInputLayout");
        util7.removeErrorOnTextChanged(activity7, textInputEditText2, textInputLayout6);
        binding.disabilityIssuanceDateLayout.textInputEditText.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$6(this.f$0, binding, view);
            }
        });
        ConfigurableButton configurableButton = binding.learnMoreButtonLayout.commonButton;
        Util util8 = Util.INSTANCE;
        CRCActivity activity8 = getActivity();
        String string5 = getString(R.string.learn_more);
        Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util8, activity8, string5, "\nمزید جانیں", 0, false, 12, null));
        binding.learnMoreButtonLayout.commonButton.setFilled(false);
        binding.learnMoreButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$7(this.f$0, view);
            }
        });
        ConfigurableButton configurableButton2 = binding.addDisabilityButtonLayout.commonButton;
        Util util9 = Util.INSTANCE;
        CRCActivity activity9 = getActivity();
        String string6 = getString(R.string.add_disability);
        Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
        configurableButton2.setText(Util.setEnglishTextSpan$default(util9, activity9, string6, "\nمعذوری شامل کریں", 0, false, 12, null));
        binding.addDisabilityButtonLayout.commonButton.setFilled(true);
        binding.addDisabilityButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$8(view);
            }
        });
        binding.disabilitiesRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        Context contextRequireContext = requireContext();
        Intrinsics.checkNotNullExpressionValue(contextRequireContext, "requireContext(...)");
        this.disabilityAdapter = new DisabilityAdapter(contextRequireContext, this.disabilityList, new Function2() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$10(this.f$0, ((Integer) obj).intValue(), (MinorDisability) obj2);
            }
        });
        RecyclerView recyclerView = binding.disabilitiesRecyclerView;
        DisabilityAdapter disabilityAdapter = this.disabilityAdapter;
        DisabilityAdapter disabilityAdapter2 = null;
        if (disabilityAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("disabilityAdapter");
            disabilityAdapter = null;
        }
        recyclerView.setAdapter(disabilityAdapter);
        getCrcSharedViewModel().getChildDetails().getMinorDisabilityData();
        this.disabilityList = getCrcSharedViewModel().getChildDetails().getMinorDisabilityData();
        DisabilityAdapter disabilityAdapter3 = this.disabilityAdapter;
        if (disabilityAdapter3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("disabilityAdapter");
        } else {
            disabilityAdapter2 = disabilityAdapter3;
        }
        disabilityAdapter2.updateDisabilityList(this.disabilityList);
        binding.addDisabilityButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$12(this.f$0, view);
            }
        });
        initFooterView();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$13$lambda$0(ChildDisabilityDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$13$lambda$1(ChildDisabilityDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.crc_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.CRC_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$13$lambda$2(ChildDisabilityDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$13$lambda$3(ChildDisabilityDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        int i = R.drawable.disability_icon_colorful;
        String string = this$0.getString(R.string.tabPersonalDetails_disability_type_infoText);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.tabPersonalDetails_disability_type_infoText_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, i, "Child Disability", string, false, true, string2, 16, (Object) null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$13$lambda$4(ChildDisabilityDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getDisabilityTypes();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$13$lambda$6(ChildDisabilityDetailFragment this$0, final ChildDisabilityDetailFragmentBinding this_apply, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        Util.INSTANCE.showDatePickerDialog(this$0.getActivity(), new Function1() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$6$lambda$5(this_apply, (Date) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit attachLayoutViews$lambda$13$lambda$6$lambda$5(ChildDisabilityDetailFragmentBinding this_apply, Date selectedDate) {
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        Intrinsics.checkNotNullParameter(selectedDate, "selectedDate");
        this_apply.disabilityIssuanceDateLayout.textInputEditText.setText(Util.INSTANCE.dateFormat(selectedDate));
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$13$lambda$7(ChildDisabilityDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        int i = R.drawable.disability_icon_colorful;
        String string = this$0.getString(R.string.tabPersonalDetails_disability_type_infoText);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.tabPersonalDetails_disability_type_infoText_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, i, "Child Disability", string, false, true, string2, 16, (Object) null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit attachLayoutViews$lambda$13$lambda$10(ChildDisabilityDetailFragment this$0, int i, MinorDisability minorData) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(minorData, "minorData");
        this$0.disabilityList.remove(i);
        List<MinorDisability> list = this$0.disabilityList;
        if (list != null && !list.isEmpty()) {
            Iterator<T> it = this$0.disabilityList.iterator();
            while (it.hasNext()) {
                ((MinorDisability) it.next()).setErrorMessage("");
            }
        }
        DisabilityAdapter disabilityAdapter = this$0.disabilityAdapter;
        if (disabilityAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("disabilityAdapter");
            disabilityAdapter = null;
        }
        disabilityAdapter.updateDisabilityList(this$0.disabilityList);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$13$lambda$12(ChildDisabilityDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.addDisability();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void addDisability() {
        String key;
        String value;
        String key2;
        String key3;
        ChildDisabilityDetailFragmentBinding binding = getBinding();
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        TextInputLayout textInputLayout = binding.disabilityTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView = binding.disabilityTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        boolean zValidateAutoCompleteTextView = util.validateAutoCompleteTextView(activity, textInputLayout, autoCompleteTextView);
        Util util2 = Util.INSTANCE;
        CRCActivity activity2 = getActivity();
        TextInputLayout textInputLayout2 = binding.disabiltyCertificateLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        TextInputEditText textInputEditText = binding.disabiltyCertificateLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        if (!util2.validateEditText(activity2, textInputLayout2, textInputEditText)) {
            zValidateAutoCompleteTextView = false;
        }
        Util util3 = Util.INSTANCE;
        CRCActivity activity3 = getActivity();
        TextInputLayout textInputLayout3 = binding.disabilityIssuanceDateLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout3, "textInputLayout");
        TextInputEditText textInputEditText2 = binding.disabilityIssuanceDateLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        if (!(util3.validateEditText(activity3, textInputLayout3, textInputEditText2) ? zValidateAutoCompleteTextView : false)) {
            return;
        }
        Iterator<String> it = this.selectedDisabilityList.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        while (true) {
            DisabilityAdapter disabilityAdapter = null;
            T t = 0;
            if (it.hasNext()) {
                String next = it.next();
                Intrinsics.checkNotNullExpressionValue(next, "next(...)");
                String str = next;
                Ref.ObjectRef objectRef = new Ref.ObjectRef();
                Iterator<T> it2 = this.disabilityTypes.iterator();
                while (true) {
                    if (!it2.hasNext()) {
                        break;
                    }
                    Object next2 = it2.next();
                    if (Intrinsics.areEqual(((LibraryResponse) next2).getValue(), str)) {
                        t = next2;
                        break;
                    }
                }
                objectRef.element = t;
                LibraryResponse libraryResponse = (LibraryResponse) objectRef.element;
                if (libraryResponse == null || (key = libraryResponse.getKey()) == null) {
                    key = "";
                }
                LibraryResponse libraryResponse2 = (LibraryResponse) objectRef.element;
                if (libraryResponse2 == null || (value = libraryResponse2.getValue()) == null) {
                    value = "";
                }
                MinorDisability.DisabilityType disabilityType = new MinorDisability.DisabilityType(key, value);
                List<MinorDisability> list = this.disabilityList;
                ArrayList arrayList = new ArrayList();
                for (Object obj : list) {
                    String key4 = ((MinorDisability) obj).getDisabilityType().getKey();
                    LibraryResponse libraryResponse3 = (LibraryResponse) objectRef.element;
                    if (libraryResponse3 == null || (key3 = libraryResponse3.getKey()) == null) {
                        key3 = "";
                    }
                    if (Intrinsics.areEqual(key4, key3)) {
                        arrayList.add(obj);
                    }
                }
                if (!arrayList.isEmpty()) {
                    BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
                    CRCActivity activity4 = getActivity();
                    String string = getString(R.string.duplicate_disability);
                    Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                    String string2 = getString(R.string.duplicate_disability_urdu);
                    Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                    BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity4, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
                    return;
                }
                LibraryResponse libraryResponse4 = (LibraryResponse) objectRef.element;
                this.disabilityList.add(new MinorDisability(0L, 0, disabilityType, (libraryResponse4 == null || (key2 = libraryResponse4.getKey()) == null) ? "" : key2, String.valueOf(binding.disabiltyCertificateLayout.textInputEditText.getText()), Util.INSTANCE.dateFormatYearMonthDate(String.valueOf(binding.disabilityIssuanceDateLayout.textInputEditText.getText())), null, 67, null));
            } else {
                DisabilityAdapter disabilityAdapter2 = this.disabilityAdapter;
                if (disabilityAdapter2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("disabilityAdapter");
                } else {
                    disabilityAdapter = disabilityAdapter2;
                }
                disabilityAdapter.updateDisabilityList(this.disabilityList);
                return;
            }
        }
    }

    private final void launchNextActivity() {
        mapUpdateChildDetails(false);
    }

    private final void mapUpdateChildDetails(boolean isSkipWarnings) {
        CRCSharedViewModel crcSharedViewModel = getCrcSharedViewModel();
        MinorDataResponse minorDataResponse = this.childDetails;
        MinorDataResponse minorDataResponse2 = null;
        if (minorDataResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse = null;
        }
        crcSharedViewModel.setChildDetails(minorDataResponse);
        UpdateChildDetailsRequest updateChildDetailsRequest = new UpdateChildDetailsRequest(null, 0L, null, null, null, null, null, null, null, null, null, null, null, null, false, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 536870911, null);
        updateChildDetailsRequest.setTrackingId(getCrcSharedViewModel().getTrackingId());
        MinorDataResponse minorDataResponse3 = this.childDetails;
        if (minorDataResponse3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse3 = null;
        }
        updateChildDetailsRequest.setChildId(minorDataResponse3.getChildId());
        MinorDataResponse minorDataResponse4 = this.childDetails;
        if (minorDataResponse4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse4 = null;
        }
        updateChildDetailsRequest.setRelationWithApplicant(minorDataResponse4.getRelationWithApplicant().getKey());
        MinorDataResponse minorDataResponse5 = this.childDetails;
        if (minorDataResponse5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse5 = null;
        }
        updateChildDetailsRequest.setCitizenNumber(minorDataResponse5.getCitizenNumber());
        MinorDataResponse minorDataResponse6 = this.childDetails;
        if (minorDataResponse6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse6 = null;
        }
        updateChildDetailsRequest.setBirthCertificateNumber(minorDataResponse6.getBirthCertificateNumber());
        MinorDataResponse minorDataResponse7 = this.childDetails;
        if (minorDataResponse7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse7 = null;
        }
        updateChildDetailsRequest.setCertificateType(minorDataResponse7.getCertificateType().getKey());
        MinorDataResponse minorDataResponse8 = this.childDetails;
        if (minorDataResponse8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse8 = null;
        }
        updateChildDetailsRequest.setName(minorDataResponse8.getFullName());
        MinorDataResponse minorDataResponse9 = this.childDetails;
        if (minorDataResponse9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse9 = null;
        }
        updateChildDetailsRequest.setFirstName(minorDataResponse9.getFirstName());
        MinorDataResponse minorDataResponse10 = this.childDetails;
        if (minorDataResponse10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse10 = null;
        }
        updateChildDetailsRequest.setLastName(minorDataResponse10.getLastName());
        MinorDataResponse minorDataResponse11 = this.childDetails;
        if (minorDataResponse11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse11 = null;
        }
        updateChildDetailsRequest.setNameUrdu(minorDataResponse11.getFullNameLocal());
        MinorDataResponse minorDataResponse12 = this.childDetails;
        if (minorDataResponse12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse12 = null;
        }
        updateChildDetailsRequest.setFirstNameLocal(minorDataResponse12.getFirstNameLocal());
        MinorDataResponse minorDataResponse13 = this.childDetails;
        if (minorDataResponse13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse13 = null;
        }
        updateChildDetailsRequest.setLastNameLocal(minorDataResponse13.getLastNameLocal());
        MinorDataResponse minorDataResponse14 = this.childDetails;
        if (minorDataResponse14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse14 = null;
        }
        updateChildDetailsRequest.setGender(minorDataResponse14.getGender().getKey());
        MinorDataResponse minorDataResponse15 = this.childDetails;
        if (minorDataResponse15 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse15 = null;
        }
        updateChildDetailsRequest.setDateOfBirth(minorDataResponse15.getBirthDate());
        MinorDataResponse minorDataResponse16 = this.childDetails;
        if (minorDataResponse16 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse16 = null;
        }
        updateChildDetailsRequest.setCountry(minorDataResponse16.getBirthCountry().getKey());
        MinorDataResponse minorDataResponse17 = this.childDetails;
        if (minorDataResponse17 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse17 = null;
        }
        updateChildDetailsRequest.setProvince(minorDataResponse17.getBirthProvince().getKey());
        MinorDataResponse minorDataResponse18 = this.childDetails;
        if (minorDataResponse18 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse18 = null;
        }
        updateChildDetailsRequest.setDistrict(minorDataResponse18.getBirthDistrict().getKey());
        MinorDataResponse minorDataResponse19 = this.childDetails;
        if (minorDataResponse19 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse19 = null;
        }
        updateChildDetailsRequest.setTehsil(minorDataResponse19.getBirthTehsil().getKey());
        MinorDataResponse minorDataResponse20 = this.childDetails;
        if (minorDataResponse20 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse20 = null;
        }
        updateChildDetailsRequest.setTwin(minorDataResponse20.getTwin());
        MinorDataResponse minorDataResponse21 = this.childDetails;
        if (minorDataResponse21 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse21 = null;
        }
        updateChildDetailsRequest.setFatherCitizenNumber(minorDataResponse21.getFatherCitizenNumber());
        MinorDataResponse minorDataResponse22 = this.childDetails;
        if (minorDataResponse22 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse22 = null;
        }
        updateChildDetailsRequest.setFatherName(minorDataResponse22.getMinorFatherName());
        MinorDataResponse minorDataResponse23 = this.childDetails;
        if (minorDataResponse23 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse23 = null;
        }
        updateChildDetailsRequest.setFatherNameUrdu(minorDataResponse23.getMinorFatherNameLocal());
        MinorDataResponse minorDataResponse24 = this.childDetails;
        if (minorDataResponse24 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse24 = null;
        }
        updateChildDetailsRequest.setMotherCitizenNumber(minorDataResponse24.getMotherCitizenNumber());
        MinorDataResponse minorDataResponse25 = this.childDetails;
        if (minorDataResponse25 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse25 = null;
        }
        updateChildDetailsRequest.setMotherName(minorDataResponse25.getMinorMotherName());
        MinorDataResponse minorDataResponse26 = this.childDetails;
        if (minorDataResponse26 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse26 = null;
        }
        updateChildDetailsRequest.setMotherNameUrdu(minorDataResponse26.getMinorMotherNameLocal());
        updateChildDetailsRequest.setSkipWarnings(isSkipWarnings);
        updateChildDetailsRequest.setDisabilityHtmlObjName("disability");
        MinorDataResponse minorDataResponse27 = this.childDetails;
        if (minorDataResponse27 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            minorDataResponse27 = null;
        }
        if (minorDataResponse27.getMinorDisabilityData().size() > 0) {
            MinorDataResponse minorDataResponse28 = this.childDetails;
            if (minorDataResponse28 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("childDetails");
            } else {
                minorDataResponse2 = minorDataResponse28;
            }
            for (MinorDisability minorDisability : minorDataResponse2.getMinorDisabilityData()) {
                UpdateChildDetailsRequest.Disability disability = new UpdateChildDetailsRequest.Disability(null, null, null, 7, null);
                disability.setDisability(minorDisability.getDisability());
                disability.setIssueDate(minorDisability.getIssueDate());
                disability.setDisabilityCertificateNumber(minorDisability.getDisabilityCertificateNumber());
                updateChildDetailsRequest.getDisabilityList().add(disability);
            }
        }
        processUpdateChildDetails(updateChildDetailsRequest);
    }

    private final void launchStringPickerActivity(ArrayList<String> arrayList) {
        Intent intent = new Intent(getActivity(), (Class<?>) StringPickerActivity.class);
        intent.putStringArrayListExtra("INTENT_STRING_LIST", arrayList);
        this.startForResult.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startForResult$lambda$20(ChildDisabilityDetailFragment this$0, ActivityResult result) {
        Intent data;
        String stringExtra;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || (data = result.getData()) == null || !data.hasExtra("INTENT_STRING_ITEM") || (stringExtra = data.getStringExtra("INTENT_STRING_ITEM")) == null) {
            return;
        }
        ArrayList<String> arrayList = this$0.selectedDisabilityList;
        if (!(arrayList instanceof Collection) || !arrayList.isEmpty()) {
            Iterator<T> it = arrayList.iterator();
            while (it.hasNext()) {
                if (Intrinsics.areEqual((String) it.next(), stringExtra)) {
                    BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
                    CRCActivity activity = this$0.getActivity();
                    String string = this$0.getString(R.string.disability_already_added);
                    Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                    String string2 = this$0.getString(R.string.disability_already_added_urdu);
                    Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                    BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
                    return;
                }
            }
        }
        this$0.getBinding().disabilityTypeLayout.autoCompleteTextView.setText(stringExtra);
        this$0.selectedDisabilityList.add(stringExtra);
        this$0.addChip(stringExtra);
    }

    private final void addChip(String s) {
        final Chip chip = new Chip(getActivity());
        chip.setText(s);
        chip.setChipCornerRadius(20.0f);
        chip.setCloseIconVisible(true);
        chip.setOnCloseIconClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.addChip$lambda$22$lambda$21(this.f$0, chip, view);
            }
        });
        chip.setChipBackgroundColorResource(pk.gov.nadra.oneapp.crc.R.color.chip_background);
        chip.setTextColor(-1);
        chip.setCloseIconResource(pk.gov.nadra.oneapp.crc.R.drawable.ic_close_circle);
        chip.setCloseIconTint(ColorStateList.valueOf(-1));
        chip.setChipMinHeight(100.0f);
        getBinding().disabilityChipGroup.addView(chip);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addChip$lambda$22$lambda$21(ChildDisabilityDetailFragment this$0, Chip this_apply, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        this$0.getBinding().disabilityChipGroup.removeView(this_apply);
        this$0.selectedDisabilityList.remove(this_apply.getText().toString());
    }

    private final void getDisabilityTypes() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(null), 3, null);
    }

    /* compiled from: ChildDisabilityDetailFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$getDisabilityTypes$1", f = "ChildDisabilityDetailFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$getDisabilityTypes$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ChildDisabilityDetailFragment.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ChildDisabilityDetailFragment.this.getActivity());
            final ChildDisabilityDetailFragment childDisabilityDetailFragment = ChildDisabilityDetailFragment.this;
            aPIRequests.getDisabilityTypes(new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$getDisabilityTypes$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ChildDisabilityDetailFragment.AnonymousClass1.invokeSuspend$lambda$0(childDisabilityDetailFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ChildDisabilityDetailFragment childDisabilityDetailFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(childDisabilityDetailFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getDisabilityTypes() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                childDisabilityDetailFragment.processLibrarySuccessResponse(jsonArray, MethodName.CERTIFICATE_TYPE);
            } else {
                childDisabilityDetailFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void processUpdateChildDetails(UpdateChildDetailsRequest updateChildDetailsRequest) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        getCrcSharedViewModel().setErrorResponse(new ErrorResponse(null, null, null, null, null, null, null, null, null, null, null, null, null, null, 16383, null));
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12281(updateChildDetailsRequest, null), 3, null);
    }

    /* compiled from: ChildDisabilityDetailFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$processUpdateChildDetails$1", f = "ChildDisabilityDetailFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$processUpdateChildDetails$1, reason: invalid class name and case insensitive filesystem */
    static final class C12281 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ UpdateChildDetailsRequest $updateChildDetailsRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12281(UpdateChildDetailsRequest updateChildDetailsRequest, Continuation<? super C12281> continuation) {
            super(2, continuation);
            this.$updateChildDetailsRequest = updateChildDetailsRequest;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ChildDisabilityDetailFragment.this.new C12281(this.$updateChildDetailsRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12281) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(ChildDisabilityDetailFragment.this.getActivity());
            UpdateChildDetailsRequest updateChildDetailsRequest = this.$updateChildDetailsRequest;
            final ChildDisabilityDetailFragment childDisabilityDetailFragment = ChildDisabilityDetailFragment.this;
            aPIRequests.updateChildDetails(updateChildDetailsRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$processUpdateChildDetails$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return ChildDisabilityDetailFragment.C12281.invokeSuspend$lambda$0(childDisabilityDetailFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ChildDisabilityDetailFragment childDisabilityDetailFragment, JsonObject jsonObject, String str, int i) throws NumberFormatException {
            LoaderManager.INSTANCE.hideLoader(childDisabilityDetailFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("processUpdateChildDetails() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                childDisabilityDetailFragment.processDataUpdationSuccessResponse(jsonObject);
            } else {
                childDisabilityDetailFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processLibrarySuccessResponse(JsonArray jSonObject, MethodName methodName) throws JsonSyntaxException {
        Object objFromJson = new Gson().fromJson(jSonObject.toString(), (Class<Object>) LibraryResponse[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List list = ArraysKt.toList((Object[]) objFromJson);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("LibraryResponse", methodName + " :: Response: " + list);
        }
        new ArrayList();
        this.disabilityTypes = new ArrayList<>();
        Intrinsics.checkNotNull(list, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
        ArrayList<LibraryResponse> arrayList = (ArrayList) list;
        this.disabilityTypes = arrayList;
        ArrayList<LibraryResponse> arrayList2 = arrayList;
        ArrayList arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList2, 10));
        Iterator<T> it = arrayList2.iterator();
        while (it.hasNext()) {
            arrayList3.add(((LibraryResponse) it.next()).getValue());
        }
        ArrayList arrayList4 = arrayList3;
        if (arrayList4.isEmpty()) {
            return;
        }
        launchStringPickerActivity(arrayList4);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCaseJsonArray(JsonArray jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson((JsonElement) jsonResponse.get(0).getAsJsonObject(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                errorResponse.getErrors();
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            CRCActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return ChildDisabilityDetailFragment.handleFailureCaseJsonArray$lambda$26(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda11
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ChildDisabilityDetailFragment.handleFailureCaseJsonArray$lambda$27(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$26(ChildDisabilityDetailFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$27(ChildDisabilityDetailFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processDataUpdationSuccessResponse(JsonObject jSonObject) {
        UpdateChildResponse updateChildResponse = (UpdateChildResponse) new Gson().fromJson(jSonObject.toString(), UpdateChildResponse.class);
        if (updateChildResponse != null) {
            if (updateChildResponse.getNextScreens().isEmpty()) {
                getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_disability_to_minor_list);
                return;
            }
            updateChildResponse.setNextScreens(CollectionsKt.sortedWith(updateChildResponse.getNextScreens(), new Comparator() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$processDataUpdationSuccessResponse$$inlined$sortedBy$1
                /* JADX WARN: Multi-variable type inference failed */
                @Override // java.util.Comparator
                public final int compare(T t, T t2) {
                    return ComparisonsKt.compareValues(Integer.valueOf(((UpdateChildResponse.NextScreen) t).getId()), Integer.valueOf(((UpdateChildResponse.NextScreen) t2).getId()));
                }
            }));
            getCrcSharedViewModel().setChildResponse(updateChildResponse);
            getCrcSharedViewModel().setChildId(updateChildResponse.getChildId());
            getCrcSharedViewModel().getChildDetails().setChildId(updateChildResponse.getChildId());
            if (updateChildResponse.getNextScreens().get(0).getId() == 2) {
                getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.uploadPhotographFragment);
                return;
            } else {
                if (updateChildResponse.getNextScreens().get(0).getId() == 3) {
                    getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.fingerprintAcquisitionFragment);
                    return;
                }
                return;
            }
        }
        getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_disability_to_minor_list);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) throws NumberFormatException {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "WIZARD_VALIDATION_FAILED")) {
                getCrcSharedViewModel().setErrorResponse(errorResponse);
                handleViewErrors(getCrcSharedViewModel().getErrorResponse());
                return;
            }
            if (Intrinsics.areEqual(errorResponse.getStatus(), "WIZARD_LIST_VALIDATION_FAILED")) {
                getCrcSharedViewModel().setErrorResponse(errorResponse);
                Intrinsics.checkNotNull(errorResponse);
                handleDisabilityErrors(errorResponse);
                return;
            }
            if (Intrinsics.areEqual(errorResponse.getStatus(), "WARNING")) {
                getCrcSharedViewModel().setErrorResponse(errorResponse);
                List<String> warnings = errorResponse.getWarnings();
                String message = errorResponse.getMessage();
                if (message == null) {
                    message = "";
                }
                String message_local = errorResponse.getMessage_local();
                String str = message_local == null ? "" : message_local;
                Iterator<T> it = warnings.iterator();
                String str2 = message;
                while (it.hasNext()) {
                    str2 = ((String) it.next()) + ". ";
                }
                BottomSheetUtils.INSTANCE.showMessageBottomSheet((FragmentActivity) getActivity(), "Alert", str2, true, (CharSequence) Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "OK", " (ٹھیک ہے)", 0, false, 12, null), !(str.length() == 0), str, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return ChildDisabilityDetailFragment.handleFailureCase$lambda$30(this.f$0);
                    }
                }, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda7
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return Unit.INSTANCE;
                    }
                });
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            CRCActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda8
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return ChildDisabilityDetailFragment.handleFailureCase$lambda$32(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda9
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ChildDisabilityDetailFragment.handleFailureCase$lambda$33(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$30(ChildDisabilityDetailFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.mapUpdateChildDetails(true);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$32(ChildDisabilityDetailFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$33(ChildDisabilityDetailFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final void handleViewErrors(ErrorResponse errorResponse) {
        if (errorResponse.getErrors() != null) {
            List<ErrorResponse.Error> errors = errorResponse.getErrors();
            Intrinsics.checkNotNull(errors);
            List<ErrorResponse.Error> list = errors;
            if (!(list instanceof Collection) || !list.isEmpty()) {
                for (ErrorResponse.Error error : list) {
                    if (Intrinsics.areEqual(error.getField(), "citizenNumber") || Intrinsics.areEqual(error.getField(), "nameUrdu") || Intrinsics.areEqual(error.getField(), "name") || Intrinsics.areEqual(error.getField(), "tehsil") || Intrinsics.areEqual(error.getField(), "province") || Intrinsics.areEqual(error.getField(), "orphanHouseName") || Intrinsics.areEqual(error.getField(), "dateOfBirth") || Intrinsics.areEqual(error.getField(), "district") || Intrinsics.areEqual(error.getField(), "birthCertificateNumber") || Intrinsics.areEqual(error.getField(), "relationWithApplicant") || Intrinsics.areEqual(error.getField(), "firstName") || Intrinsics.areEqual(error.getField(), "lastName") || Intrinsics.areEqual(error.getField(), "firstNameLocal") || Intrinsics.areEqual(error.getField(), "lastNameLocal")) {
                        getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_disability_to_child_detail);
                        return;
                    }
                }
            }
            List<ErrorResponse.Error> errors2 = errorResponse.getErrors();
            Intrinsics.checkNotNull(errors2);
            List<ErrorResponse.Error> list2 = errors2;
            if ((list2 instanceof Collection) && list2.isEmpty()) {
                return;
            }
            for (ErrorResponse.Error error2 : list2) {
                if (Intrinsics.areEqual(error2.getField(), "fatherCitizenNumber") || Intrinsics.areEqual(error2.getField(), "motherCitizenNumber") || Intrinsics.areEqual(error2.getField(), "fatherName") || Intrinsics.areEqual(error2.getField(), "fatherNameUrdu") || Intrinsics.areEqual(error2.getField(), "motherName") || Intrinsics.areEqual(error2.getField(), "motherNameUrdu")) {
                    getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_disability_to_parent_detail);
                    return;
                }
            }
        }
    }

    private final void handleDisabilityErrors(ErrorResponse errorResponse) throws NumberFormatException {
        List<DisabilityErrorResponse.Errors> listErrors = errorResponse.getListErrors();
        if (listErrors == null || listErrors.isEmpty()) {
            return;
        }
        Iterator<T> it = errorResponse.getListErrors().iterator();
        while (it.hasNext()) {
            for (DisabilityErrorResponse.Errors.Error error : ((DisabilityErrorResponse.Errors) it.next()).getErrors()) {
                int i = Integer.parseInt(error.getIndex());
                if (i <= this.disabilityList.size()) {
                    this.disabilityList.get(i);
                    MinorDisability minorDisability = this.disabilityList.get(i);
                    Iterator<T> it2 = error.getErrors().iterator();
                    while (it2.hasNext()) {
                        MinorDisability minorDisability2 = minorDisability;
                        minorDisability2.setErrorMessage(minorDisability2.getErrorMessage() + ' ' + ((DisabilityErrorResponse.Errors.Error.C0242Error) it2.next()).getMessage());
                    }
                    this.disabilityList.set(i, minorDisability);
                }
            }
        }
        DisabilityAdapter disabilityAdapter = this.disabilityAdapter;
        if (disabilityAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("disabilityAdapter");
            disabilityAdapter = null;
        }
        disabilityAdapter.updateDisabilityList(this.disabilityList);
    }

    @Override // android.view.View.OnFocusChangeListener
    public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus || v == null) {
            return;
        }
        ViewUtils.hideKeyboard(v, true);
    }

    private final void initFooterView() {
        ChildDisabilityDetailFragmentBinding binding = getBinding();
        binding.crcFooterLayout.backButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.initFooterView$lambda$41$lambda$39(this.f$0, view);
            }
        });
        binding.crcFooterLayout.backButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Back", "\n(واپس جائیں)", 0, false, 12, null));
        MaterialButton materialButton = binding.crcFooterLayout.nextButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.next);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        materialButton.setText(Util.setEnglishTextSpan$default(util, activity, string, "\n(آگے بڑھیں)", 0, false, 12, null));
        binding.crcFooterLayout.nextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.ChildDisabilityDetailFragment$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ChildDisabilityDetailFragment.initFooterView$lambda$41$lambda$40(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$41$lambda$39(ChildDisabilityDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$41$lambda$40(ChildDisabilityDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.launchNextActivity();
    }
}