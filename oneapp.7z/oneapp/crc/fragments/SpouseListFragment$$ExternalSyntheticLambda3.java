package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function2;
import pk.gov.nadra.oneapp.crc.adapter.SpouseVerifyAction;
import pk.gov.nadra.oneapp.models.crc.spouse.SpouseListResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SpouseListFragment$$ExternalSyntheticLambda3 implements Function2 {
    public /* synthetic */ SpouseListFragment$$ExternalSyntheticLambda3() {
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return SpouseListFragment.onViewCreated$lambda$6$lambda$3(this.f$0, (SpouseVerifyAction) obj, (SpouseListResponse) obj2);
    }
}