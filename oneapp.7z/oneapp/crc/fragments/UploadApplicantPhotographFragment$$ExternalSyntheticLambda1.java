package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class UploadApplicantPhotographFragment$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public /* synthetic */ UploadApplicantPhotographFragment$$ExternalSyntheticLambda1() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UploadApplicantPhotographFragment.initFooterView$lambda$33$lambda$32(this.f$0, view);
    }
}