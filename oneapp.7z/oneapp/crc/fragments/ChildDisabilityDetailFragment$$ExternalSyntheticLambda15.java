package pk.gov.nadra.oneapp.crc.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDisabilityDetailFragment$$ExternalSyntheticLambda15 implements ActivityResultCallback {
    public /* synthetic */ ChildDisabilityDetailFragment$$ExternalSyntheticLambda15() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        ChildDisabilityDetailFragment.startForResult$lambda$20(this.f$0, (ActivityResult) obj);
    }
}