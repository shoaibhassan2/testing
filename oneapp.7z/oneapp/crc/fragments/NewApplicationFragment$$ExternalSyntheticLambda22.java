package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;
import pk.gov.nadra.oneapp.crc.databinding.NewApplicationFragmentBinding;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class NewApplicationFragment$$ExternalSyntheticLambda22 implements View.OnClickListener {
    public final /* synthetic */ NewApplicationFragmentBinding f$1;

    public /* synthetic */ NewApplicationFragment$$ExternalSyntheticLambda22(NewApplicationFragmentBinding newApplicationFragmentBinding) {
        binding = newApplicationFragmentBinding;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        NewApplicationFragment.attachLayoutViews$lambda$11$lambda$3(this.f$0, binding, view);
    }
}