package pk.gov.nadra.oneapp.crc.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class NewApplicationFragment$$ExternalSyntheticLambda10 implements ActivityResultCallback {
    public /* synthetic */ NewApplicationFragment$$ExternalSyntheticLambda10() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        NewApplicationFragment.cameraLauncher$lambda$59(this.f$0, (ActivityResult) obj);
    }
}