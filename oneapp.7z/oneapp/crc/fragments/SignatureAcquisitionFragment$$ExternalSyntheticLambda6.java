package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SignatureAcquisitionFragment$$ExternalSyntheticLambda6 implements Function0 {
    public /* synthetic */ SignatureAcquisitionFragment$$ExternalSyntheticLambda6() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return SignatureAcquisitionFragment.handleFailureCase$lambda$15(this.f$0);
    }
}