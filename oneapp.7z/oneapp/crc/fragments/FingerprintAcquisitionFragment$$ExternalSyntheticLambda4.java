package pk.gov.nadra.oneapp.crc.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import com.google.gson.JsonSyntaxException;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class FingerprintAcquisitionFragment$$ExternalSyntheticLambda4 implements ActivityResultCallback {
    public /* synthetic */ FingerprintAcquisitionFragment$$ExternalSyntheticLambda4() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) throws JsonSyntaxException {
        FingerprintAcquisitionFragment.galleryLauncher$lambda$5(this.f$0, (ActivityResult) obj);
    }
}