package pk.gov.nadra.oneapp.crc.fragments;

import com.google.gson.JsonObject;
import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.crc.fragments.MinorListFragment;
import pk.gov.nadra.oneapp.models.crc.minor.MinorDataResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class MinorListFragment$deleteChildFromMinorList$1$$ExternalSyntheticLambda0 implements Function3 {
    public final /* synthetic */ MinorDataResponse f$1;

    public /* synthetic */ MinorListFragment$deleteChildFromMinorList$1$$ExternalSyntheticLambda0(MinorDataResponse minorDataResponse) {
        minorDataResponse = minorDataResponse;
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return MinorListFragment.AnonymousClass1.invokeSuspend$lambda$0(minorListFragment, minorDataResponse, (JsonObject) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}