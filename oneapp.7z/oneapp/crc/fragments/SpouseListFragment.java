package pk.gov.nadra.oneapp.crc.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.io.FilesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.fingerprint.FingerprintScanSelectionActivityUnikrew;
import pk.gov.nadra.oneapp.commonutils.idemialiveness.ChallengeActivity;
import pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback;
import pk.gov.nadra.oneapp.commonutils.preferences.AppPreferences;
import pk.gov.nadra.oneapp.commonutils.service.ValidateLicenseService;
import pk.gov.nadra.oneapp.commonutils.unikrewliveness.UnikrewFacialActivity;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCropper;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.adapter.SpouseListAdapter;
import pk.gov.nadra.oneapp.crc.adapter.SpouseVerifyAction;
import pk.gov.nadra.oneapp.crc.adapter.viewmodel.CRCSharedViewModel;
import pk.gov.nadra.oneapp.crc.databinding.SpouseListFragmentBinding;
import pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment;
import pk.gov.nadra.oneapp.crc.utils.FingerIndexEnum;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.fingerprint.CheckVerificationModeRequest;
import pk.gov.nadra.oneapp.models.crc.fingerprint.CheckVerificationModeResponse;
import pk.gov.nadra.oneapp.models.crc.fingerprint.FingerPreference;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintResponse;
import pk.gov.nadra.oneapp.models.crc.minor.ChildDataResponse;
import pk.gov.nadra.oneapp.models.crc.spouse.SpouseListResponse;
import pk.gov.nadra.oneapp.models.crc.spouse.SpouseVerifyRequest;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: SpouseListFragment.kt */
@Metadata(d1 = {"\u0000º\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\"H\u0016J$\u0010#\u001a\u00020$2\u0006\u0010%\u001a\u00020&2\b\u0010'\u001a\u0004\u0018\u00010(2\b\u0010)\u001a\u0004\u0018\u00010*H\u0016J\u001a\u0010+\u001a\u00020 2\u0006\u0010,\u001a\u00020$2\b\u0010)\u001a\u0004\u0018\u00010*H\u0016J\b\u0010-\u001a\u00020 H\u0002J\u0010\u0010.\u001a\u00020 2\u0006\u0010/\u001a\u00020\u001eH\u0002J\u0010\u00100\u001a\u00020 2\u0006\u00101\u001a\u000202H\u0002J\u0018\u00103\u001a\u00020 2\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u000207H\u0002J\u0018\u00108\u001a\u00020 2\u0006\u00104\u001a\u0002022\u0006\u00106\u001a\u000207H\u0002J\b\u0010=\u001a\u00020 H\u0002J\u0010\u0010>\u001a\u00020 2\u0006\u0010?\u001a\u00020\u001eH\u0002J\u0010\u0010@\u001a\u00020 2\u0006\u0010A\u001a\u00020BH\u0002J\u0010\u0010C\u001a\u00020 2\u0006\u00101\u001a\u000205H\u0002J\u0010\u0010D\u001a\u00020 2\u0006\u0010/\u001a\u00020\u001eH\u0002J\u0010\u0010E\u001a\u00020 2\u0006\u00101\u001a\u000205H\u0002J\b\u0010F\u001a\u00020 H\u0002J\b\u0010H\u001a\u00020 H\u0002J\b\u0010K\u001a\u00020 H\u0002J\b\u0010M\u001a\u00020 H\u0002J\b\u0010N\u001a\u00020 H\u0002J\u0018\u0010P\u001a\u00020 2\u0006\u0010Q\u001a\u00020\u001e2\u0006\u0010R\u001a\u00020SH\u0002J\u0010\u0010T\u001a\u00020 2\u0006\u0010\u001d\u001a\u00020\u001eH\u0002J\u0010\u0010W\u001a\u00020\u001e2\u0006\u0010X\u001a\u00020YH\u0002J\u0010\u0010Z\u001a\u00020 2\u0006\u0010[\u001a\u00020\u0017H\u0002J\u0010\u0010\\\u001a\u00020 2\u0006\u0010]\u001a\u00020^H\u0002J\u0010\u0010_\u001a\u00020 2\u0006\u00101\u001a\u000205H\u0002J\u0010\u0010`\u001a\u00020 2\u0006\u0010a\u001a\u00020\u001eH\u0002J\b\u0010b\u001a\u00020 H\u0002J\b\u0010c\u001a\u00020 H\u0002J\b\u0010e\u001a\u00020 H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R \u0010\u0015\u001a\u0012\u0012\u0004\u0012\u00020\u00170\u0018j\b\u0012\u0004\u0012\u00020\u0017`\u0016X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u0019R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0017X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u00109\u001a\u0010\u0012\f\u0012\n <*\u0004\u0018\u00010;0;0:X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010G\u001a\u0010\u0012\f\u0012\n <*\u0004\u0018\u00010\u001e0\u001e0:X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010I\u001a\u00020JX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010L\u001a\u0010\u0012\f\u0012\n <*\u0004\u0018\u00010;0;0:X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010O\u001a\u0010\u0012\f\u0012\n <*\u0004\u0018\u00010;0;0:X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010U\u001a\u00020VX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010d\u001a\u0010\u0012\f\u0012\n <*\u0004\u0018\u00010;0;0:X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006f"}, d2 = {"Lpk/gov/nadra/oneapp/crc/fragments/SpouseListFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/crc/databinding/SpouseListFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/SpouseListFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/crc/views/CRCActivity;)V", "spouseList", "Lkotlin/collections/ArrayList;", "Lpk/gov/nadra/oneapp/models/crc/spouse/SpouseListResponse;", "Ljava/util/ArrayList;", "Ljava/util/ArrayList;", "spouseListAdapter", "Lpk/gov/nadra/oneapp/crc/adapter/SpouseListAdapter;", "selectedSpouse", "sourceImagePath", "", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "handleFragmentNavigationLogic", "getSpouseList", "trackingId", "processSpouseDataListSuccessResponse", "jSonObject", "Lcom/google/gson/JsonArray;", "handleFailureCase", "jsonResponse", "Lcom/google/gson/JsonObject;", "responseCode", "", "handleFailureCaseJsonArray", "fingerprintLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "handleCaptureSuccess", "verifyAttesterWithFacial", "facialBase64", "verifySpouseFingerprint", "spouseVerifyRequest", "Lpk/gov/nadra/oneapp/models/crc/spouse/SpouseVerifyRequest;", "processSpouseVerifySuccessResponse", "getMinorDataList", "processMinorDataListSuccessResponse", "requestCameraPermissionIfNeeded", "cameraPermissionLauncher", "checkIdemiaLicenseActivation", "licenseValidationCallback", "Lpk/gov/nadra/oneapp/commonutils/interfaces/LicenseValidationCallback;", "processLicenseSuccess", "livelinessLauncher", "processOnActivityResultForCameraIntent", "launchImageCropper", "cropLauncher", "processOnActivityResultForAnanasLibrary", "processedFilePath", "isImageEdit", "", "compressImage", "iCompressImageTaskListenerResult", "Lpk/gov/nadra/oneapp/commonutils/utils/ImageCompressor$ICompressImageTaskListener;", "convertFileToBase64", "file", "Ljava/io/File;", "handleSelectedSpouseSelection", "minor", "checkFingerprints", "checkVerificationModeRequest", "Lpk/gov/nadra/oneapp/models/crc/fingerprint/CheckVerificationModeRequest;", "processCheckVerificationModeSuccessResponse", "handleVerification", "verificationMode", "checkLivenessControl", "launchUnikrewFacial", "unikrewFacialLauncher", "initFooterView", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class SpouseListFragment extends Fragment {
    private SpouseListFragmentBinding _binding;
    public CRCActivity activity;
    private final ActivityResultLauncher<String> cameraPermissionLauncher;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;
    private final ActivityResultLauncher<Intent> cropLauncher;
    private final ActivityResultLauncher<Intent> fingerprintLauncher;
    private ImageCompressor.ICompressImageTaskListener iCompressImageTaskListenerResult;
    private LicenseValidationCallback licenseValidationCallback;
    private final ActivityResultLauncher<Intent> livelinessLauncher;
    private SpouseListResponse selectedSpouse;
    private SpouseListAdapter spouseListAdapter;
    private final ActivityResultLauncher<Intent> unikrewFacialLauncher;
    private ArrayList<SpouseListResponse> spouseList = new ArrayList<>();
    private String sourceImagePath = "";

    public SpouseListFragment() {
        final SpouseListFragment spouseListFragment = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(spouseListFragment, Reflection.getOrCreateKotlinClass(CRCSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = spouseListFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = spouseListFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = spouseListFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda15
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) throws JsonSyntaxException {
                SpouseListFragment.fingerprintLauncher$lambda$17(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.fingerprintLauncher = activityResultLauncherRegisterForActivityResult;
        ActivityResultLauncher<String> activityResultLauncherRegisterForActivityResult2 = registerForActivityResult(new ActivityResultContracts.RequestPermission(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda16
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                SpouseListFragment.cameraPermissionLauncher$lambda$23(this.f$0, (Boolean) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult2, "registerForActivityResult(...)");
        this.cameraPermissionLauncher = activityResultLauncherRegisterForActivityResult2;
        this.licenseValidationCallback = new LicenseValidationCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$licenseValidationCallback$1
            @Override // pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback
            public void onSuccess() {
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
                this.this$0.processLicenseSuccess();
            }

            @Override // pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback
            public void onError() {
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
                BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
                CRCActivity activity = this.this$0.getActivity();
                String string = this.this$0.getString(R.string.face_liveness_failed);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                String string2 = this.this$0.getString(R.string.face_liveness_failed_urdu);
                Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
            }
        };
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult3 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda17
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                SpouseListFragment.livelinessLauncher$lambda$24(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult3, "registerForActivityResult(...)");
        this.livelinessLauncher = activityResultLauncherRegisterForActivityResult3;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult4 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda18
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                SpouseListFragment.cropLauncher$lambda$26(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult4, "registerForActivityResult(...)");
        this.cropLauncher = activityResultLauncherRegisterForActivityResult4;
        this.iCompressImageTaskListenerResult = new ImageCompressor.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$iCompressImageTaskListenerResult$1
            @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
            public void onComplete(File compressed) {
                Intrinsics.checkNotNullParameter(compressed, "compressed");
                String strConvertFileToBase64 = this.this$0.convertFileToBase64(compressed);
                if (Constant.INSTANCE.getDEBUG()) {
                    Log.d("Compressed (30KB)", strConvertFileToBase64);
                }
                this.this$0.verifyAttesterWithFacial(strConvertFileToBase64);
            }

            @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
            public void onError() {
                Util.INSTANCE.showToast(this.this$0.getActivity(), "Failed");
            }
        };
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult5 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda19
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                SpouseListFragment.unikrewFacialLauncher$lambda$27(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult5, "registerForActivityResult(...)");
        this.unikrewFacialLauncher = activityResultLauncherRegisterForActivityResult5;
    }

    private final CRCSharedViewModel getCrcSharedViewModel() {
        return (CRCSharedViewModel) this.crcSharedViewModel.getValue();
    }

    private final SpouseListFragmentBinding getBinding() {
        SpouseListFragmentBinding spouseListFragmentBinding = this._binding;
        Intrinsics.checkNotNull(spouseListFragmentBinding);
        return spouseListFragmentBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final CRCActivity getActivity() {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity != null) {
            return cRCActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(CRCActivity cRCActivity) {
        Intrinsics.checkNotNullParameter(cRCActivity, "<set-?>");
        this.activity = cRCActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.crc.views.CRCActivity");
        setActivity((CRCActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = SpouseListFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        final SpouseListFragmentBinding binding = getBinding();
        binding.crcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SpouseListFragment.onViewCreated$lambda$6$lambda$0(this.f$0, view2);
            }
        });
        binding.crcHeaderLayout.iconHome.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SpouseListFragment.onViewCreated$lambda$6$lambda$1(this.f$0, view2);
            }
        });
        binding.crcHeaderLayout.iconInfo.setVisibility(0);
        binding.crcHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SpouseListFragment.onViewCreated$lambda$6$lambda$2(this.f$0, view2);
            }
        });
        TextView textView = binding.crcHeaderLayout.textTitle;
        String upperCase = getCrcSharedViewModel().getDocumentTypeValue().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(String.valueOf(upperCase));
        binding.crcHeaderLayout.textSubtitle.setText(String.valueOf(getCrcSharedViewModel().getApplicationTypeValue()));
        binding.crcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.roboto_medium));
        binding.crcHeaderLayout.tvHeaderTrackingId.setText(getCrcSharedViewModel().getTrackingId());
        binding.crcHeaderLayout.tvHeaderFee.setText(String.valueOf(getCrcSharedViewModel().getAmount()));
        binding.crcHeaderLayout.iconHome.setVisibility(0);
        binding.stepTitleHeadingLayout.tvStepTitleHeading.setText(getString(R.string.attester));
        binding.stepTitleHeadingLayout.tvStepTitleHeadingUrdu.setText("تصدیق");
        binding.minorsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.spouseListAdapter = new SpouseListAdapter(this.spouseList, new Function2() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return SpouseListFragment.onViewCreated$lambda$6$lambda$3(this.f$0, (SpouseVerifyAction) obj, (SpouseListResponse) obj2);
            }
        });
        RecyclerView recyclerView = binding.minorsRecyclerView;
        SpouseListAdapter spouseListAdapter = this.spouseListAdapter;
        if (spouseListAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("spouseListAdapter");
            spouseListAdapter = null;
        }
        recyclerView.setAdapter(spouseListAdapter);
        binding.spouseSwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda4
            @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
            public final void onRefresh() {
                SpouseListFragment.onViewCreated$lambda$6$lambda$4(this.f$0, binding);
            }
        });
        binding.spouseListTryAgainLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SpouseListFragment.onViewCreated$lambda$6$lambda$5(this.f$0, view2);
            }
        });
        initFooterView();
        getSpouseList(getCrcSharedViewModel().getTrackingId());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$0(SpouseListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$1(SpouseListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$2(SpouseListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.crc_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.CRC_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$6$lambda$3(SpouseListFragment this$0, SpouseVerifyAction spouseVerifyAction, SpouseListResponse minor) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(spouseVerifyAction, "<unused var>");
        Intrinsics.checkNotNullParameter(minor, "minor");
        this$0.handleSelectedSpouseSelection(minor);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$4(SpouseListFragment this$0, SpouseListFragmentBinding this_apply) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        this$0.getSpouseList(this$0.getCrcSharedViewModel().getTrackingId());
        this_apply.spouseSwipeRefresh.setRefreshing(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$5(SpouseListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getSpouseList(this$0.getCrcSharedViewModel().getTrackingId());
    }

    private final void handleFragmentNavigationLogic() {
        if (getCrcSharedViewModel().getUploadDocumentP()) {
            getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.supportingDocumentsFragment);
        } else if (getCrcSharedViewModel().getDataEntryP()) {
            getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.reviewFragment);
        } else {
            getActivity().navigateToReactNativeInbox(Constant.GO_TO_INBOX);
        }
    }

    private final void getSpouseList(String trackingId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        getBinding().spouseListTryAgainLayout.setVisibility(8);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12481(trackingId, null), 3, null);
    }

    /* compiled from: SpouseListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$getSpouseList$1", f = "SpouseListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$getSpouseList$1, reason: invalid class name and case insensitive filesystem */
    static final class C12481 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12481(String str, Continuation<? super C12481> continuation) {
            super(2, continuation);
            this.$trackingId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return SpouseListFragment.this.new C12481(this.$trackingId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12481) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(SpouseListFragment.this.getActivity());
            String str = this.$trackingId;
            final SpouseListFragment spouseListFragment = SpouseListFragment.this;
            aPIRequests.getSpouseList(str, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$getSpouseList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return SpouseListFragment.C12481.invokeSuspend$lambda$0(spouseListFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(SpouseListFragment spouseListFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(spouseListFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getMinorDataList() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                spouseListFragment.processSpouseDataListSuccessResponse(jsonArray);
            } else {
                spouseListFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processSpouseDataListSuccessResponse(JsonArray jSonObject) throws JsonSyntaxException {
        Object objFromJson = new Gson().fromJson(jSonObject.toString(), (Class<Object>) SpouseListResponse[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List mutableList = ArraysKt.toMutableList((Object[]) objFromJson);
        Log.d("processMinorDataRes", mutableList.toString());
        Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.spouse.SpouseListResponse>");
        ArrayList<SpouseListResponse> arrayList = (ArrayList) mutableList;
        this.spouseList = arrayList;
        if (!arrayList.isEmpty()) {
            getBinding().minorsRecyclerView.setVisibility(0);
            SpouseListAdapter spouseListAdapter = this.spouseListAdapter;
            if (spouseListAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("spouseListAdapter");
                spouseListAdapter = null;
            }
            spouseListAdapter.updateSpouseList(this.spouseList);
            if (this.spouseList.size() > 1) {
                getBinding().userGuideTextView.setVisibility(0);
                return;
            }
            return;
        }
        getBinding().minorsRecyclerView.setVisibility(8);
        getBinding().userGuideTextView.setVisibility(8);
        getBinding().spouseListTryAgainLayout.setVisibility(0);
        getBinding().spouseListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_documents);
        getBinding().spouseListTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "There is nothing here...yet!", "\n (یہاں کچھ بھی نہیں ہے... ابھی تک!)", 0, false, 12, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    for (ErrorResponse.Error error : errors) {
                    }
                    return;
                }
                return;
            }
            if (Intrinsics.areEqual(errorResponse.getStatus(), "BUSINESS_RULE_FAILED")) {
                NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                CRCActivity activity = getActivity();
                Intrinsics.checkNotNull(errorResponse);
                NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda9
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return SpouseListFragment.handleFailureCase$lambda$10(this.f$0);
                    }
                }, 8, null);
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            CRCActivity activity2 = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return SpouseListFragment.handleFailureCase$lambda$11(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity3 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler3, activity3, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda12
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return SpouseListFragment.handleFailureCase$lambda$12(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$10(SpouseListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$11(SpouseListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$12(SpouseListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCaseJsonArray(JsonArray jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson((JsonElement) jsonResponse.get(0).getAsJsonObject(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    for (ErrorResponse.Error error : errors) {
                    }
                    return;
                }
                return;
            }
            if (Intrinsics.areEqual(errorResponse.getStatus(), "BUSINESS_RULE_FAILED")) {
                this.spouseList = new ArrayList<>();
                SpouseListAdapter spouseListAdapter = this.spouseListAdapter;
                if (spouseListAdapter == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("spouseListAdapter");
                    spouseListAdapter = null;
                }
                spouseListAdapter.updateSpouseList(this.spouseList);
                getBinding().minorsRecyclerView.setVisibility(8);
                getBinding().userGuideTextView.setVisibility(8);
                getBinding().spouseListTryAgainLayout.setVisibility(0);
                getBinding().spouseListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_documents);
                TextView textView = getBinding().spouseListTryAgainTextView;
                String message = errorResponse.getMessage();
                if (message == null) {
                    message = "";
                }
                textView.setText(message);
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            CRCActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return SpouseListFragment.handleFailureCaseJsonArray$lambda$15(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda11
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return SpouseListFragment.handleFailureCaseJsonArray$lambda$16(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$15(SpouseListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$16(SpouseListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void fingerprintLauncher$lambda$17(SpouseListFragment this$0, ActivityResult result) throws JsonSyntaxException {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || result.getData() == null) {
            return;
        }
        Intent data = result.getData();
        Intrinsics.checkNotNull(data);
        if (data.hasExtra(Constant.CAPTURE_SUCCESS)) {
            this$0.handleCaptureSuccess();
        }
    }

    private final void handleCaptureSuccess() throws JsonSyntaxException {
        String strName;
        String fingerprints = AppPreferences.getInstance(getActivity()).getFingerprints();
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d(Constant.TAG, fingerprints);
        }
        Object objFromJson = new Gson().fromJson(fingerprints, (Class<Object>) FingerPreference[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List<FingerPreference> listAsList = ArraysKt.asList((Object[]) objFromJson);
        SpouseListResponse spouseListResponse = null;
        SpouseVerifyRequest spouseVerifyRequest = new SpouseVerifyRequest(null, null, null, null, null, false, null, 127, null);
        SpouseListResponse spouseListResponse2 = this.selectedSpouse;
        if (spouseListResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("selectedSpouse");
            spouseListResponse2 = null;
        }
        spouseVerifyRequest.setRelation(spouseListResponse2.getRelation().getKey());
        SpouseListResponse spouseListResponse3 = this.selectedSpouse;
        if (spouseListResponse3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("selectedSpouse");
        } else {
            spouseListResponse = spouseListResponse3;
        }
        spouseVerifyRequest.setCitizenNumber(StringsKt.replace$default(spouseListResponse.getCitizenNumber(), "-", "", false, 4, (Object) null));
        spouseVerifyRequest.setTrackingId(getCrcSharedViewModel().getTrackingId());
        ArrayList arrayList = new ArrayList();
        for (FingerPreference fingerPreference : listAsList) {
            SpouseVerifyRequest.Finger finger = new SpouseVerifyRequest.Finger(null, 0, null, null, 15, null);
            FingerIndexEnum fingerIndexEnumFromId = FingerIndexEnum.INSTANCE.fromId(Integer.parseInt(fingerPreference.getFingerIndex()));
            if (fingerIndexEnumFromId == null || (strName = fingerIndexEnumFromId.name()) == null) {
                strName = "";
            }
            finger.setIndexName(strName);
            finger.setWsq(fingerPreference.getBase64());
            arrayList.add(finger);
        }
        spouseVerifyRequest.setFingerList(arrayList);
        verifySpouseFingerprint(spouseVerifyRequest);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void verifyAttesterWithFacial(String facialBase64) {
        SpouseListResponse spouseListResponse = null;
        SpouseVerifyRequest spouseVerifyRequest = new SpouseVerifyRequest(null, null, null, null, null, false, null, 127, null);
        SpouseListResponse spouseListResponse2 = this.selectedSpouse;
        if (spouseListResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("selectedSpouse");
            spouseListResponse2 = null;
        }
        spouseVerifyRequest.setRelation(spouseListResponse2.getRelation().getKey());
        SpouseListResponse spouseListResponse3 = this.selectedSpouse;
        if (spouseListResponse3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("selectedSpouse");
        } else {
            spouseListResponse = spouseListResponse3;
        }
        spouseVerifyRequest.setCitizenNumber(StringsKt.replace$default(spouseListResponse.getCitizenNumber(), "-", "", false, 4, (Object) null));
        spouseVerifyRequest.setTrackingId(getCrcSharedViewModel().getTrackingId());
        spouseVerifyRequest.setFacial(true);
        spouseVerifyRequest.setPhotograph(facialBase64);
        verifySpouseFingerprint(spouseVerifyRequest);
    }

    private final void verifySpouseFingerprint(SpouseVerifyRequest spouseVerifyRequest) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        String json = new Gson().toJson(spouseVerifyRequest);
        if (Constant.INSTANCE.getDEBUG()) {
            System.out.println((Object) ("Fingerprint Json: " + json));
        }
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12491(spouseVerifyRequest, null), 3, null);
    }

    /* compiled from: SpouseListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$verifySpouseFingerprint$1", f = "SpouseListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$verifySpouseFingerprint$1, reason: invalid class name and case insensitive filesystem */
    static final class C12491 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ SpouseVerifyRequest $spouseVerifyRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12491(SpouseVerifyRequest spouseVerifyRequest, Continuation<? super C12491> continuation) {
            super(2, continuation);
            this.$spouseVerifyRequest = spouseVerifyRequest;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return SpouseListFragment.this.new C12491(this.$spouseVerifyRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12491) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(SpouseListFragment.this.getActivity());
            SpouseVerifyRequest spouseVerifyRequest = this.$spouseVerifyRequest;
            final SpouseListFragment spouseListFragment = SpouseListFragment.this;
            aPIRequests.verifySpouseFingerprintV2(spouseVerifyRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$verifySpouseFingerprint$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return SpouseListFragment.C12491.invokeSuspend$lambda$0(spouseListFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(SpouseListFragment spouseListFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(spouseListFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("verifySpouseFingerprint() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                spouseListFragment.processSpouseVerifySuccessResponse(jsonObject);
            } else {
                spouseListFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0088  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void processSpouseVerifySuccessResponse(com.google.gson.JsonObject r13) {
        /*
            Method dump skipped, instructions count: 301
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment.processSpouseVerifySuccessResponse(com.google.gson.JsonObject):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processSpouseVerifySuccessResponse$lambda$19(SpouseListFragment this$0, VerifyFingerprintResponse verifyFingerprintResponse) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.handleVerification(verifyFingerprintResponse.getVerificationMode());
        return Unit.INSTANCE;
    }

    /* compiled from: SpouseListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$getMinorDataList$1", f = "SpouseListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$getMinorDataList$1, reason: invalid class name and case insensitive filesystem */
    static final class C12471 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12471(String str, Continuation<? super C12471> continuation) {
            super(2, continuation);
            this.$trackingId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return SpouseListFragment.this.new C12471(this.$trackingId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12471) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(SpouseListFragment.this.getActivity());
            String str = this.$trackingId;
            final SpouseListFragment spouseListFragment = SpouseListFragment.this;
            aPIRequests.minorDataList(str, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$getMinorDataList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return SpouseListFragment.C12471.invokeSuspend$lambda$0(spouseListFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(SpouseListFragment spouseListFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(spouseListFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getMinorDataList() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                spouseListFragment.processMinorDataListSuccessResponse(jsonObject);
            } else {
                spouseListFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getMinorDataList(String trackingId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12471(trackingId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processMinorDataListSuccessResponse(JsonObject jSonObject) {
        ChildDataResponse childDataResponse = (ChildDataResponse) new Gson().fromJson(jSonObject.toString(), ChildDataResponse.class);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("processMinorDataRes", childDataResponse.toString());
        }
        if (childDataResponse.getAttesterRequired()) {
            BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
            CRCActivity activity = getActivity();
            String string = getString(R.string.attester_fingerprint_pending);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            SpannableString englishTextSpan$default = Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Continue", " (جاری رکھیں)", 0, false, 12, null);
            String string2 = getString(R.string.attester_fingerprint_pending_urdu);
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Info", string, true, (CharSequence) englishTextSpan$default, true, string2, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda6
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return SpouseListFragment.processMinorDataListSuccessResponse$lambda$22$lambda$21(this.f$0);
                }
            }, (Function0) null, 256, (Object) null);
            return;
        }
        handleFragmentNavigationLogic();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processMinorDataListSuccessResponse$lambda$22$lambda$21(SpouseListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.handleFragmentNavigationLogic();
        return Unit.INSTANCE;
    }

    private final void requestCameraPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(requireContext(), "android.permission.CAMERA") == 0) {
            checkLivenessControl();
        } else {
            this.cameraPermissionLauncher.launch("android.permission.CAMERA");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void cameraPermissionLauncher$lambda$23(SpouseListFragment this$0, Boolean isGranted) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(isGranted, "isGranted");
        if (isGranted.booleanValue()) {
            this$0.checkLivenessControl();
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.permission_denied);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.permission_denied_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }

    private final void checkIdemiaLicenseActivation() {
        Object[] objArr = {Constant.IDEMIA_VALUE_1, Constant.IDEMIA_VALUE_2, Constant.IDEMIA_VALUE_3};
        LoaderManager.INSTANCE.showLoader(getActivity());
        new ValidateLicenseService(this.licenseValidationCallback, getActivity(), objArr).validateLicense();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processLicenseSuccess() {
        this.livelinessLauncher.launch(new Intent(getActivity(), (Class<?>) ChallengeActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void livelinessLauncher$lambda$24(SpouseListFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || result.getData() == null) {
            return;
        }
        Intent data = result.getData();
        Intrinsics.checkNotNull(data);
        String stringExtra = data.getStringExtra("CAPTURE_RESULT_FACE");
        if (stringExtra != null && new File(stringExtra).length() > 0) {
            this$0.sourceImagePath = stringExtra;
            this$0.processOnActivityResultForCameraIntent();
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.unable_to_detect_face);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.unable_to_detect_face_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }

    private final void processOnActivityResultForCameraIntent() {
        if (new File(this.sourceImagePath).length() < 0) {
            return;
        }
        launchImageCropper();
    }

    private final void launchImageCropper() {
        try {
            String str = this.sourceImagePath;
            File fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
            Intrinsics.checkNotNull(fileCreatePhotoFile);
            String absolutePath = fileCreatePhotoFile.getAbsolutePath();
            Intent intent = new Intent(getActivity(), (Class<?>) ImageCropper.class);
            intent.putExtra(ImageCropper.EXTRA_INPUT_PATH, str);
            intent.putExtra("output_path", absolutePath);
            this.cropLauncher.launch(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void cropLauncher$lambda$26(SpouseListFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1) {
            Intent data = result.getData();
            String stringExtra = data != null ? data.getStringExtra("output_path") : null;
            boolean booleanExtra = data != null ? data.getBooleanExtra(ImageCropper.RESULT_IMAGE_EDITED, false) : false;
            if (stringExtra != null) {
                this$0.processOnActivityResultForAnanasLibrary(stringExtra, booleanExtra);
            }
        }
    }

    private final void processOnActivityResultForAnanasLibrary(String processedFilePath, boolean isImageEdit) {
        if (isImageEdit) {
            compressImage(processedFilePath);
        } else {
            compressImage(this.sourceImagePath);
        }
    }

    private final void compressImage(String sourceImagePath) {
        File fileCreatePhotoFile;
        try {
            fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
        } catch (Exception e) {
            e.printStackTrace();
            Util.INSTANCE.showToast(getActivity(), String.valueOf(e.getMessage()));
            fileCreatePhotoFile = null;
        }
        if (fileCreatePhotoFile == null) {
            return;
        }
        new ImageCompressor(getActivity(), this.iCompressImageTaskListenerResult).execute(Arrays.copyOf(new Object[]{sourceImagePath, fileCreatePhotoFile.getAbsolutePath()}, 2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String convertFileToBase64(File file) {
        String strEncodeToString = Base64.encodeToString(FilesKt.readBytes(file), 0);
        Intrinsics.checkNotNullExpressionValue(strEncodeToString, "encodeToString(...)");
        return strEncodeToString;
    }

    private final void handleSelectedSpouseSelection(SpouseListResponse minor) {
        this.selectedSpouse = minor;
        SpouseListResponse spouseListResponse = this.selectedSpouse;
        if (spouseListResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("selectedSpouse");
            spouseListResponse = null;
        }
        checkFingerprints(new CheckVerificationModeRequest(StringsKt.replace$default(spouseListResponse.getCitizenNumber(), "-", "", false, 4, (Object) null), getCrcSharedViewModel().getTrackingId()));
    }

    /* compiled from: SpouseListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$checkFingerprints$1", f = "SpouseListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$checkFingerprints$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ CheckVerificationModeRequest $checkVerificationModeRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(CheckVerificationModeRequest checkVerificationModeRequest, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$checkVerificationModeRequest = checkVerificationModeRequest;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return SpouseListFragment.this.new AnonymousClass1(this.$checkVerificationModeRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(SpouseListFragment.this.getActivity());
            CheckVerificationModeRequest checkVerificationModeRequest = this.$checkVerificationModeRequest;
            final SpouseListFragment spouseListFragment = SpouseListFragment.this;
            aPIRequests.checkVerificationMode(checkVerificationModeRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$checkFingerprints$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return SpouseListFragment.AnonymousClass1.invokeSuspend$lambda$0(spouseListFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(SpouseListFragment spouseListFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(spouseListFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                spouseListFragment.processCheckVerificationModeSuccessResponse(jsonObject);
            } else {
                spouseListFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void checkFingerprints(CheckVerificationModeRequest checkVerificationModeRequest) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(checkVerificationModeRequest, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processCheckVerificationModeSuccessResponse(JsonObject jSonObject) {
        handleVerification(((CheckVerificationModeResponse) new Gson().fromJson(jSonObject.toString(), CheckVerificationModeResponse.class)).getVerificationMode());
    }

    private final void handleVerification(String verificationMode) {
        if (verificationMode.length() > 0) {
            if (Intrinsics.areEqual(verificationMode, "FACIAL")) {
                requestCameraPermissionIfNeeded();
            } else if (Intrinsics.areEqual(verificationMode, "FINGER")) {
                Intent intent = new Intent(getActivity(), (Class<?>) FingerprintScanSelectionActivityUnikrew.class);
                intent.putExtra(Constant.CAPTURE_TYPE, "VERIFICATION");
                this.fingerprintLauncher.launch(intent);
            }
        }
    }

    private final void checkLivenessControl() {
        if (Intrinsics.areEqual(new SharedPreferencesTokenProvider(getActivity()).getUserCredentials().getLivenessControl(), Constant.UNIKREW) || Intrinsics.areEqual(new SharedPreferencesTokenProvider(getActivity()).getUserCredentials().getLivenessControl(), Constant.UNIKREW_CLOUD)) {
            launchUnikrewFacial();
        } else {
            checkIdemiaLicenseActivation();
        }
    }

    private final void launchUnikrewFacial() {
        Intent intent = new Intent(getActivity(), (Class<?>) UnikrewFacialActivity.class);
        intent.putExtra(Constant.UNIKREW_CAMERA_MODE, "FRONT");
        intent.putExtra(Constant.UNIKREW_ICAO, false);
        this.unikrewFacialLauncher.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void unikrewFacialLauncher$lambda$27(SpouseListFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1 && result.getData() != null) {
            Intent data = result.getData();
            Intrinsics.checkNotNull(data);
            if (data.hasExtra(Constant.UNIKREW_PROCESSED_IMAGE_PATH)) {
                Intent data2 = result.getData();
                Intrinsics.checkNotNull(data2);
                String stringExtra = data2.getStringExtra(Constant.UNIKREW_PROCESSED_IMAGE_PATH);
                Intrinsics.checkNotNull(stringExtra);
                this$0.sourceImagePath = stringExtra;
                this$0.processOnActivityResultForCameraIntent();
                return;
            }
        }
        result.getResultCode();
    }

    private final void initFooterView() {
        SpouseListFragmentBinding binding = getBinding();
        binding.crcFooterLayout.backButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SpouseListFragment.initFooterView$lambda$30$lambda$28(this.f$0, view);
            }
        });
        binding.crcFooterLayout.backButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Back", "\n(واپس جائیں)", 0, false, 12, null));
        MaterialButton materialButton = binding.crcFooterLayout.nextButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.next);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        materialButton.setText(Util.setEnglishTextSpan$default(util, activity, string, "\n(آگے بڑھیں)", 0, false, 12, null));
        binding.crcFooterLayout.nextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SpouseListFragment$$ExternalSyntheticLambda14
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SpouseListFragment.initFooterView$lambda$30$lambda$29(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$30$lambda$28(SpouseListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$30$lambda$29(SpouseListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getMinorDataList(this$0.getCrcSharedViewModel().getTrackingId());
    }
}