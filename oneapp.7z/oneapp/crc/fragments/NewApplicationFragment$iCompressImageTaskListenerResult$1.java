package pk.gov.nadra.oneapp.crc.fragments;

import android.util.Log;
import java.io.File;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;

/* compiled from: NewApplicationFragment.kt */
@Metadata(d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\b\u0010\u0006\u001a\u00020\u0003H\u0016¨\u0006\u0007"}, d2 = {"pk/gov/nadra/oneapp/crc/fragments/NewApplicationFragment$iCompressImageTaskListenerResult$1", "Lpk/gov/nadra/oneapp/commonutils/utils/ImageCompressor$ICompressImageTaskListener;", "onComplete", "", "compressed", "Ljava/io/File;", "onError", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class NewApplicationFragment$iCompressImageTaskListenerResult$1 implements ImageCompressor.ICompressImageTaskListener {
    NewApplicationFragment$iCompressImageTaskListenerResult$1() {
    }

    @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
    public void onComplete(File compressed) {
        Intrinsics.checkNotNullParameter(compressed, "compressed");
        String strConvertFileToBase64 = this.this$0.convertFileToBase64(compressed);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("Compressed (30KB)", strConvertFileToBase64);
        }
        this.this$0.verifyApplicantWithFacial(strConvertFileToBase64);
    }

    @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
    public void onError() {
        Util util = Util.INSTANCE;
        CRCActivity cRCActivity = this.this$0.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        util.showToast(cRCActivity, "Failed");
    }
}