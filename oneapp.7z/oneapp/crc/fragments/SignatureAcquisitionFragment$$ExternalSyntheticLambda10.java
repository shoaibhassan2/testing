package pk.gov.nadra.oneapp.crc.fragments;

import android.net.Uri;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SignatureAcquisitionFragment$$ExternalSyntheticLambda10 implements ActivityResultCallback {
    public /* synthetic */ SignatureAcquisitionFragment$$ExternalSyntheticLambda10() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        SignatureAcquisitionFragment.photoPickerLauncher$lambda$16(this.f$0, (Uri) obj);
    }
}