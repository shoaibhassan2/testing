package pk.gov.nadra.oneapp.crc.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.PickVisualMediaRequestKt;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.compose.material3.MenuKt;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.imagePicker.BrowseAlbumActivity;
import pk.gov.nadra.oneapp.commonutils.signature.SignatureActivity;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCropper;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.MoveUriFile;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data;
import pk.gov.nadra.oneapp.crc.adapter.viewmodel.CRCSharedViewModel;
import pk.gov.nadra.oneapp.crc.databinding.SignatureAcquisitionFragmentBinding;
import pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.MinorPhotographResponse;
import pk.gov.nadra.oneapp.models.crc.TabUpdateRequest;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: SignatureAcquisitionFragment.kt */
@Metadata(d1 = {"\u0000º\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010&\u001a\u00020'2\u0006\u0010(\u001a\u00020)H\u0016J$\u0010*\u001a\u00020+2\u0006\u0010,\u001a\u00020-2\b\u0010.\u001a\u0004\u0018\u00010/2\b\u00100\u001a\u0004\u0018\u000101H\u0016J\u001a\u00102\u001a\u00020'2\u0006\u00103\u001a\u00020+2\b\u00100\u001a\u0004\u0018\u000101H\u0016J\b\u00104\u001a\u00020'H\u0002J\u0010\u00109\u001a\u00020'2\u0006\u0010:\u001a\u00020\u001cH\u0002J\u000e\u0010;\u001a\u00020'2\u0006\u0010<\u001a\u00020\u001cJ\b\u0010=\u001a\u00020'H\u0002J%\u0010?\u001a\u00020'2\u0016\u0010@\u001a\u0012\u0012\u0004\u0012\u00020B0Cj\b\u0012\u0004\u0012\u00020B`AH\u0002¢\u0006\u0002\u0010DJ\u0010\u0010E\u001a\u00020'2\u0006\u0010F\u001a\u00020BH\u0002J\b\u0010I\u001a\u00020'H\u0002J\u0018\u0010K\u001a\u00020'2\u0006\u0010L\u001a\u00020\u001c2\u0006\u0010M\u001a\u00020NH\u0002J\u0010\u0010O\u001a\u00020'2\u0006\u0010\u001b\u001a\u00020\u001cH\u0002J\b\u0010R\u001a\u00020'H\u0002J \u0010S\u001a\u00020'2\u0006\u0010T\u001a\u00020U2\u0006\u0010V\u001a\u00020W2\u0006\u0010X\u001a\u00020WH\u0002J\b\u0010Y\u001a\u00020'H\u0002J\b\u0010Z\u001a\u00020'H\u0002J\u0010\u0010[\u001a\u00020'2\u0006\u0010\\\u001a\u00020]H\u0002J\u0010\u0010^\u001a\u00020'2\u0006\u0010\\\u001a\u00020]H\u0002J\u0010\u0010_\u001a\u00020'2\u0006\u0010\\\u001a\u00020]H\u0002J\u0018\u0010`\u001a\u00020'2\u0006\u0010a\u001a\u00020]2\u0006\u0010b\u001a\u00020\"H\u0002J\b\u0010c\u001a\u00020'H\u0002J\u0010\u0010d\u001a\u00020'2\u0006\u0010e\u001a\u00020\u001cH\u0002J\b\u0010k\u001a\u00020'H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u001a\u0010\u0015\u001a\u00020\u0016X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001aR\u001a\u0010\u001b\u001a\u00020\u001cX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R\u000e\u0010!\u001a\u00020\"X\u0082D¢\u0006\u0002\n\u0000R\u001a\u0010#\u001a\u00020\u001cX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b$\u0010\u001e\"\u0004\b%\u0010 R\u001c\u00105\u001a\u0010\u0012\f\u0012\n 8*\u0004\u0018\u0001070706X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010>\u001a\u0010\u0012\f\u0012\n 8*\u0004\u0018\u0001070706X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010G\u001a\u00020HX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010J\u001a\u0010\u0012\f\u0012\n 8*\u0004\u0018\u0001070706X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010P\u001a\u00020QX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010f\u001a\u00020gX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010h\u001a\u0010\u0012\f\u0012\n 8*\u0004\u0018\u00010i0i06X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010j\u001a\u0010\u0012\f\u0012\n 8*\u0004\u0018\u0001070706X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006l"}, d2 = {"Lpk/gov/nadra/oneapp/crc/fragments/SignatureAcquisitionFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/crc/databinding/SignatureAcquisitionFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/SignatureAcquisitionFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/crc/views/CRCActivity;)V", "signatureFile", "Ljava/io/File;", "getSignatureFile", "()Ljava/io/File;", "setSignatureFile", "(Ljava/io/File;)V", "sourceImagePath", "", "getSourceImagePath", "()Ljava/lang/String;", "setSourceImagePath", "(Ljava/lang/String;)V", "PHOTO_EDITOR_REQUEST_CODE", "", "GALLERY", "getGALLERY", "setGALLERY", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "launchSignatureActivity", "signatureLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "setSignatureView", "signaturePath", "launchGalleryOrCameraIntent", "callingFor", "dispatchGalleryIntentForPhotoSelection", "galleryLauncher", "processOnActivityResultForGalleryIntent", "uris", "Lkotlin/collections/ArrayList;", "Landroid/net/Uri;", "Ljava/util/ArrayList;", "(Ljava/util/ArrayList;)V", "processSelectedImageUri", "selectedImageUri", "iMoveUriImageServiceResult", "Lpk/gov/nadra/oneapp/commonutils/utils/MoveUriFile$ICompressImageTaskListener;", "launchImageCropper", "cropLauncher", "processOnActivityResultForAnanasLibrary", "processedFilePath", "isImageEdit", "", "compressImage", "iCompressImageTaskListenerResult", "Lpk/gov/nadra/oneapp/commonutils/utils/ImageCompressor$ICompressImageTaskListener;", "handleUploadSignature", "saveApplicantSignature", "image", "Lokhttp3/MultipartBody$Part;", "trackingId", "Lokhttp3/RequestBody;", "type", "saveApplicantSignatureTab", "getApplicantSignature", "processApplicantSignatureSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "processPhotographSuccessResponse", "processSignatureTabSuccessResponse", "handleFailureCase", "jsonResponse", "responseCode", "launchNextScreen", "writeChildPhotographBase64Data", "photoBase64", "iwriteChildPhotographBase64DataServiceResult", "Lpk/gov/nadra/oneapp/commonutils/utils/WritePhotoBase64Data$ICompressImageTaskListener;", "photoPickerLauncher", "Landroidx/activity/result/PickVisualMediaRequest;", "legacyPickerLauncher", "initFooterView", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class SignatureAcquisitionFragment extends Fragment {
    private SignatureAcquisitionFragmentBinding _binding;
    public CRCActivity activity;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;
    private final ActivityResultLauncher<Intent> cropLauncher;
    private final ActivityResultLauncher<Intent> galleryLauncher;
    private ImageCompressor.ICompressImageTaskListener iCompressImageTaskListenerResult;
    private MoveUriFile.ICompressImageTaskListener iMoveUriImageServiceResult;
    private WritePhotoBase64Data.ICompressImageTaskListener iwriteChildPhotographBase64DataServiceResult;
    private final ActivityResultLauncher<Intent> legacyPickerLauncher;
    private final ActivityResultLauncher<PickVisualMediaRequest> photoPickerLauncher;
    public File signatureFile;
    private final ActivityResultLauncher<Intent> signatureLauncher;
    private String sourceImagePath = "";
    private final int PHOTO_EDITOR_REQUEST_CODE = 231;
    private String GALLERY = "GALLERY";

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$5(View view) {
    }

    public SignatureAcquisitionFragment() {
        final SignatureAcquisitionFragment signatureAcquisitionFragment = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(signatureAcquisitionFragment, Reflection.getOrCreateKotlinClass(CRCSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = signatureAcquisitionFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = signatureAcquisitionFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = signatureAcquisitionFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda7
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                SignatureAcquisitionFragment.signatureLauncher$lambda$7(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.signatureLauncher = activityResultLauncherRegisterForActivityResult;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult2 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda8
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                SignatureAcquisitionFragment.galleryLauncher$lambda$8(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult2, "registerForActivityResult(...)");
        this.galleryLauncher = activityResultLauncherRegisterForActivityResult2;
        this.iMoveUriImageServiceResult = new MoveUriFile.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$iMoveUriImageServiceResult$1
            @Override // pk.gov.nadra.oneapp.commonutils.utils.MoveUriFile.ICompressImageTaskListener
            public void onComplete(File compressed) {
                Intrinsics.checkNotNullParameter(compressed, "compressed");
                this.this$0.setSourceImagePath(compressed.getAbsolutePath());
                if (new File(this.this$0.getSourceImagePath()).length() < 0) {
                    return;
                }
                this.this$0.launchImageCropper();
            }

            @Override // pk.gov.nadra.oneapp.commonutils.utils.MoveUriFile.ICompressImageTaskListener
            public void onError() {
                Util.INSTANCE.showToast(this.this$0.getActivity(), "Failed");
            }
        };
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult3 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda9
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                SignatureAcquisitionFragment.cropLauncher$lambda$11(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult3, "registerForActivityResult(...)");
        this.cropLauncher = activityResultLauncherRegisterForActivityResult3;
        this.iCompressImageTaskListenerResult = new ImageCompressor.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$iCompressImageTaskListenerResult$1
            @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
            public void onComplete(File compressed) {
                Intrinsics.checkNotNullParameter(compressed, "compressed");
                RequestOptions requestOptionsCenterInside = new RequestOptions().centerInside();
                Intrinsics.checkNotNullExpressionValue(requestOptionsCenterInside, "centerInside(...)");
                Glide.with((FragmentActivity) this.this$0.getActivity()).load(Uri.fromFile(compressed)).apply((BaseRequestOptions<?>) requestOptionsCenterInside).into(this.this$0.getBinding().ivTakePhoto);
                this.this$0.setSignatureFile(compressed);
                if (this.this$0.signatureFile != null) {
                    this.this$0.handleUploadSignature();
                    return;
                }
                BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
                CRCActivity activity = this.this$0.getActivity();
                String string = this.this$0.getString(R.string.signature_required);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                String string2 = this.this$0.getString(R.string.signature_required_urdu);
                Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
            }

            @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
            public void onError() {
                Util.INSTANCE.showToast(this.this$0.getActivity(), "Failed");
            }
        };
        this.iwriteChildPhotographBase64DataServiceResult = new WritePhotoBase64Data.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$iwriteChildPhotographBase64DataServiceResult$1
            @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
            public void onComplete(File compressed) {
                Intrinsics.checkNotNullParameter(compressed, "compressed");
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
                this.this$0.getCrcSharedViewModel().setApplicantSignaturePath(compressed.getAbsolutePath());
                RequestOptions requestOptionsCenterInside = new RequestOptions().centerInside();
                Intrinsics.checkNotNullExpressionValue(requestOptionsCenterInside, "centerInside(...)");
                Glide.with((FragmentActivity) this.this$0.getActivity()).load(Uri.fromFile(compressed)).apply((BaseRequestOptions<?>) requestOptionsCenterInside).into(this.this$0.getBinding().ivTakePhoto);
                this.this$0.setSignatureFile(compressed);
            }

            @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
            public void onError() {
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
            }
        };
        ActivityResultLauncher<PickVisualMediaRequest> activityResultLauncherRegisterForActivityResult4 = registerForActivityResult(new ActivityResultContracts.PickVisualMedia(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda10
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                SignatureAcquisitionFragment.photoPickerLauncher$lambda$16(this.f$0, (Uri) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult4, "registerForActivityResult(...)");
        this.photoPickerLauncher = activityResultLauncherRegisterForActivityResult4;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult5 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda11
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                SignatureAcquisitionFragment.legacyPickerLauncher$lambda$17(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult5, "registerForActivityResult(...)");
        this.legacyPickerLauncher = activityResultLauncherRegisterForActivityResult5;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final CRCSharedViewModel getCrcSharedViewModel() {
        return (CRCSharedViewModel) this.crcSharedViewModel.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final SignatureAcquisitionFragmentBinding getBinding() {
        SignatureAcquisitionFragmentBinding signatureAcquisitionFragmentBinding = this._binding;
        Intrinsics.checkNotNull(signatureAcquisitionFragmentBinding);
        return signatureAcquisitionFragmentBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final CRCActivity getActivity() {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity != null) {
            return cRCActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(CRCActivity cRCActivity) {
        Intrinsics.checkNotNullParameter(cRCActivity, "<set-?>");
        this.activity = cRCActivity;
    }

    public final File getSignatureFile() {
        File file = this.signatureFile;
        if (file != null) {
            return file;
        }
        Intrinsics.throwUninitializedPropertyAccessException("signatureFile");
        return null;
    }

    public final void setSignatureFile(File file) {
        Intrinsics.checkNotNullParameter(file, "<set-?>");
        this.signatureFile = file;
    }

    public final String getSourceImagePath() {
        return this.sourceImagePath;
    }

    public final void setSourceImagePath(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.sourceImagePath = str;
    }

    public final String getGALLERY() {
        return this.GALLERY;
    }

    public final void setGALLERY(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.GALLERY = str;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.crc.views.CRCActivity");
        setActivity((CRCActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = SignatureAcquisitionFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        SignatureAcquisitionFragmentBinding binding = getBinding();
        TextView textView = binding.crcHeaderLayout.textTitle;
        String upperCase = getCrcSharedViewModel().getDocumentTypeValue().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(String.valueOf(upperCase));
        binding.crcHeaderLayout.textSubtitle.setText(String.valueOf(getCrcSharedViewModel().getApplicationTypeValue()));
        binding.crcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.roboto_medium));
        binding.crcHeaderLayout.iconHome.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda14
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SignatureAcquisitionFragment.onViewCreated$lambda$6$lambda$0(this.f$0, view2);
            }
        });
        binding.crcHeaderLayout.iconInfo.setVisibility(0);
        binding.crcHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SignatureAcquisitionFragment.onViewCreated$lambda$6$lambda$1(this.f$0, view2);
            }
        });
        binding.crcHeaderLayout.tvHeaderTrackingId.setText(getCrcSharedViewModel().getTrackingId());
        binding.crcHeaderLayout.tvHeaderFee.setText(String.valueOf(getCrcSharedViewModel().getAmount()));
        binding.crcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SignatureAcquisitionFragment.onViewCreated$lambda$6$lambda$2(this.f$0, view2);
            }
        });
        binding.stepTitleHeadingLayout.tvStepTitleHeading.setText("Signature Acquisition");
        binding.stepTitleHeadingLayout.tvStepTitleHeadingUrdu.setText("دستخط کا حصول");
        binding.stepTitleHeadingLayout.tvStepTitleHeadingUrdu.setTypeface(Util.INSTANCE.getNadraNastaleeqFont(getActivity()));
        binding.crcStepAction.tvStepHeading.setText("Applicant Signature");
        binding.crcStepAction.tvStepHeadingUrdu.setText(" (درخواست گزار کے دستخط) ");
        binding.crcStepAction.tvStepHeadingUrdu.setTypeface(Util.INSTANCE.getNadraNastaleeqFont(getActivity()));
        binding.browseSignatureButtonLayout.commonButton.setFilled(false);
        binding.browseSignatureButtonLayout.commonButton.setButtonText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Browse", " (براؤز) ", 0, false, 12, null));
        binding.captureSignatureButtonLayout.commonButton.setFilled(true);
        binding.captureSignatureButtonLayout.commonButton.setButtonText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Draw Signature", " (دستخط کریں) ", 0, false, 12, null));
        binding.captureSignatureButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SignatureAcquisitionFragment.onViewCreated$lambda$6$lambda$3(this.f$0, view2);
            }
        });
        String applicantSignaturePath = getCrcSharedViewModel().getApplicantSignaturePath();
        if (applicantSignaturePath != null && applicantSignaturePath.length() != 0) {
            setSignatureView(getCrcSharedViewModel().getApplicantSignaturePath());
        }
        binding.browseSignatureButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SignatureAcquisitionFragment.onViewCreated$lambda$6$lambda$4(this.f$0, view2);
            }
        });
        initFooterView();
        binding.signatureConstLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SignatureAcquisitionFragment.onViewCreated$lambda$6$lambda$5(view2);
            }
        });
        getApplicantSignature();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$0(SignatureAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$1(SignatureAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.crc_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.CRC_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$2(SignatureAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$3(SignatureAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.launchSignatureActivity();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$4(SignatureAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().setFragmentName("SignatureAcquisition");
        this$0.getActivity().setCallingFor(this$0.GALLERY);
        if (Build.VERSION.SDK_INT >= 33) {
            this$0.photoPickerLauncher.launch(PickVisualMediaRequestKt.PickVisualMediaRequest$default(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE, 0, false, null, 14, null));
        } else {
            this$0.legacyPickerLauncher.launch(new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI));
        }
    }

    private final void launchSignatureActivity() {
        Intent intent = new Intent(getActivity(), (Class<?>) SignatureActivity.class);
        intent.putExtra(Constant.TRACKING_ID, getCrcSharedViewModel().getTrackingId());
        this.signatureLauncher.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void signatureLauncher$lambda$7(SignatureAcquisitionFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || result.getData() == null) {
            return;
        }
        Intent data = result.getData();
        Intrinsics.checkNotNull(data);
        String stringExtra = data.getStringExtra(Constant.TEMP_SIGNATURE_PATH);
        if (stringExtra != null) {
            this$0.setSignatureView(stringExtra);
            this$0.handleUploadSignature();
        }
    }

    private final void setSignatureView(String signaturePath) {
        RequestOptions requestOptionsCenterInside = new RequestOptions().centerInside();
        Intrinsics.checkNotNullExpressionValue(requestOptionsCenterInside, "centerInside(...)");
        Glide.with((FragmentActivity) getActivity()).load(Uri.fromFile(new File(signaturePath))).apply((BaseRequestOptions<?>) requestOptionsCenterInside).into(getBinding().ivTakePhoto);
        setSignatureFile(new File(signaturePath));
    }

    public final void launchGalleryOrCameraIntent(String callingFor) {
        Intrinsics.checkNotNullParameter(callingFor, "callingFor");
        if (Intrinsics.areEqual(callingFor, this.GALLERY)) {
            dispatchGalleryIntentForPhotoSelection();
        }
    }

    private final void dispatchGalleryIntentForPhotoSelection() {
        Intent intent = new Intent(getActivity(), (Class<?>) BrowseAlbumActivity.class);
        intent.putExtra("pick_files", true);
        this.galleryLauncher.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void galleryLauncher$lambda$8(SignatureAcquisitionFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || result.getData() == null) {
            return;
        }
        Intent data = result.getData();
        Intrinsics.checkNotNull(data);
        Serializable serializableExtra = data.getSerializableExtra("checked_uris");
        Intrinsics.checkNotNull(serializableExtra, "null cannot be cast to non-null type java.util.ArrayList<android.net.Uri>");
        this$0.processOnActivityResultForGalleryIntent((ArrayList) serializableExtra);
    }

    private final void processOnActivityResultForGalleryIntent(ArrayList<Uri> uris) {
        if (uris == null || uris.size() == 0) {
            return;
        }
        Uri uri = uris.get(0);
        Intrinsics.checkNotNullExpressionValue(uri, "get(...)");
        processSelectedImageUri(uri);
    }

    private final void processSelectedImageUri(Uri selectedImageUri) {
        File fileCreatePhotoFile;
        String mimeType = Util.INSTANCE.getMimeType(getActivity(), selectedImageUri);
        String str = mimeType;
        if (str == null || str.length() == 0 || (!StringsKt.equals(mimeType, "JPG", true) && !StringsKt.equals(mimeType, "JPEG", true) && !StringsKt.equals(mimeType, "PNG", true))) {
            Util.INSTANCE.showToast(getActivity(), "Please select valid JPG/JPEG/PNG format image.");
            return;
        }
        try {
            fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
        } catch (Exception e) {
            e.printStackTrace();
            String message = e.getMessage();
            if (message != null) {
                Util.INSTANCE.showToast(getActivity(), message);
            }
            fileCreatePhotoFile = null;
        }
        if (fileCreatePhotoFile == null) {
            return;
        }
        new MoveUriFile(getActivity(), this.iMoveUriImageServiceResult).execute(Arrays.copyOf(new Object[]{selectedImageUri, fileCreatePhotoFile}, 2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void launchImageCropper() {
        try {
            String str = this.sourceImagePath;
            File fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
            Intrinsics.checkNotNull(fileCreatePhotoFile);
            String absolutePath = fileCreatePhotoFile.getAbsolutePath();
            Intent intent = new Intent(getActivity(), (Class<?>) ImageCropper.class);
            intent.putExtra(ImageCropper.EXTRA_INPUT_PATH, str);
            intent.putExtra("output_path", absolutePath);
            this.cropLauncher.launch(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void cropLauncher$lambda$11(SignatureAcquisitionFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1) {
            Intent data = result.getData();
            String stringExtra = data != null ? data.getStringExtra("output_path") : null;
            boolean booleanExtra = data != null ? data.getBooleanExtra(ImageCropper.RESULT_IMAGE_EDITED, false) : false;
            if (stringExtra != null) {
                this$0.processOnActivityResultForAnanasLibrary(stringExtra, booleanExtra);
            }
        }
    }

    private final void processOnActivityResultForAnanasLibrary(String processedFilePath, boolean isImageEdit) {
        if (isImageEdit) {
            compressImage(processedFilePath);
        } else {
            compressImage(this.sourceImagePath);
        }
    }

    private final void compressImage(String sourceImagePath) {
        File fileCreatePhotoFile;
        try {
            fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
        } catch (Exception e) {
            e.printStackTrace();
            Util.INSTANCE.showToast(getActivity(), String.valueOf(e.getMessage()));
            fileCreatePhotoFile = null;
        }
        if (fileCreatePhotoFile == null) {
            return;
        }
        new ImageCompressor(getActivity(), this.iCompressImageTaskListenerResult).execute(Arrays.copyOf(new Object[]{sourceImagePath, fileCreatePhotoFile.getAbsolutePath()}, 2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleUploadSignature() {
        saveApplicantSignature(MultipartBody.Part.INSTANCE.createFormData("file", getSignatureFile().getName(), RequestBody.INSTANCE.create(getSignatureFile(), MediaType.INSTANCE.parse("image/*"))), RequestBody.INSTANCE.create(getCrcSharedViewModel().getTrackingId(), MediaType.INSTANCE.get("text/plain")), RequestBody.INSTANCE.create("SIGNATURE", MediaType.INSTANCE.get("text/plain")));
    }

    private final void saveApplicantSignature(MultipartBody.Part image, RequestBody trackingId, RequestBody type) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12451(image, trackingId, type, null), 3, null);
    }

    /* compiled from: SignatureAcquisitionFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$saveApplicantSignature$1", f = "SignatureAcquisitionFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$saveApplicantSignature$1, reason: invalid class name and case insensitive filesystem */
    static final class C12451 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ MultipartBody.Part $image;
        final /* synthetic */ RequestBody $trackingId;
        final /* synthetic */ RequestBody $type;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12451(MultipartBody.Part part, RequestBody requestBody, RequestBody requestBody2, Continuation<? super C12451> continuation) {
            super(2, continuation);
            this.$image = part;
            this.$trackingId = requestBody;
            this.$type = requestBody2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return SignatureAcquisitionFragment.this.new C12451(this.$image, this.$trackingId, this.$type, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12451) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(SignatureAcquisitionFragment.this.getActivity());
            MultipartBody.Part part = this.$image;
            RequestBody requestBody = this.$trackingId;
            RequestBody requestBody2 = this.$type;
            final SignatureAcquisitionFragment signatureAcquisitionFragment = SignatureAcquisitionFragment.this;
            aPIRequests.saveApplicantSignature(part, requestBody, requestBody2, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$saveApplicantSignature$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return SignatureAcquisitionFragment.C12451.invokeSuspend$lambda$0(signatureAcquisitionFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(SignatureAcquisitionFragment signatureAcquisitionFragment, JsonObject jsonObject, String str, int i) {
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("saveSignatureAcquisition() Response: " + jsonObject));
            }
            LoaderManager.INSTANCE.hideLoader(signatureAcquisitionFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                signatureAcquisitionFragment.processPhotographSuccessResponse(jsonObject);
            } else {
                signatureAcquisitionFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: SignatureAcquisitionFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$saveApplicantSignatureTab$1", f = "SignatureAcquisitionFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$saveApplicantSignatureTab$1, reason: invalid class name and case insensitive filesystem */
    static final class C12461 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Ref.ObjectRef<TabUpdateRequest> $tabUpdateRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12461(Ref.ObjectRef<TabUpdateRequest> objectRef, Continuation<? super C12461> continuation) {
            super(2, continuation);
            this.$tabUpdateRequest = objectRef;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return SignatureAcquisitionFragment.this.new C12461(this.$tabUpdateRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12461) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(SignatureAcquisitionFragment.this.getActivity());
            APIRequests aPIRequests = new APIRequests(SignatureAcquisitionFragment.this.getActivity());
            TabUpdateRequest tabUpdateRequest = this.$tabUpdateRequest.element;
            final SignatureAcquisitionFragment signatureAcquisitionFragment = SignatureAcquisitionFragment.this;
            aPIRequests.saveSignatureTab(tabUpdateRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$saveApplicantSignatureTab$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return SignatureAcquisitionFragment.C12461.invokeSuspend$lambda$0(signatureAcquisitionFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(SignatureAcquisitionFragment signatureAcquisitionFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(signatureAcquisitionFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("saveSignatureAcquisition() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                signatureAcquisitionFragment.processSignatureTabSuccessResponse(jsonObject);
            } else {
                signatureAcquisitionFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [T, pk.gov.nadra.oneapp.models.crc.TabUpdateRequest] */
    private final void saveApplicantSignatureTab() {
        Ref.ObjectRef objectRef = new Ref.ObjectRef();
        objectRef.element = new TabUpdateRequest(getCrcSharedViewModel().getTrackingId(), null, 2, null);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12461(objectRef, null), 3, null);
    }

    /* compiled from: SignatureAcquisitionFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$getApplicantSignature$1", f = "SignatureAcquisitionFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$getApplicantSignature$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return SignatureAcquisitionFragment.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(SignatureAcquisitionFragment.this.getActivity());
            APIRequests aPIRequests = new APIRequests(SignatureAcquisitionFragment.this.getActivity());
            String trackingId = SignatureAcquisitionFragment.this.getCrcSharedViewModel().getTrackingId();
            final SignatureAcquisitionFragment signatureAcquisitionFragment = SignatureAcquisitionFragment.this;
            aPIRequests.getApplicantSignature(trackingId, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$getApplicantSignature$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return SignatureAcquisitionFragment.AnonymousClass1.invokeSuspend$lambda$0(signatureAcquisitionFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(SignatureAcquisitionFragment signatureAcquisitionFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(signatureAcquisitionFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getApplicantPhotograph() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                signatureAcquisitionFragment.processApplicantSignatureSuccessResponse(jsonObject);
            } else {
                signatureAcquisitionFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getApplicantSignature() {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processApplicantSignatureSuccessResponse(JsonObject jSonObject) {
        writeChildPhotographBase64Data(((MinorPhotographResponse) new Gson().fromJson(jSonObject.toString(), MinorPhotographResponse.class)).getBase64Signature());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processPhotographSuccessResponse(JsonObject jSonObject) {
        Log.d("processDataUpdation()", jSonObject.toString());
        getCrcSharedViewModel().setApplicantSignaturePath(getSignatureFile().getAbsolutePath());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processSignatureTabSuccessResponse(JsonObject jSonObject) {
        Log.d("processDataUpdation()", jSonObject.toString());
        launchNextScreen();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors == null || errors.isEmpty()) {
                    return;
                }
                List<ErrorResponse.Error> errors2 = errorResponse.getErrors();
                Intrinsics.checkNotNull(errors2);
                String message = errors2.get(0).getMessage();
                if (message != null) {
                    BottomSheetUtils.showMessageBottomSheet$default(BottomSheetUtils.INSTANCE, (FragmentActivity) getActivity(), "Alert", message, false, false, (String) null, (Function1) null, MenuKt.InTransitionDuration, (Object) null);
                    return;
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            CRCActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return SignatureAcquisitionFragment.handleFailureCase$lambda$14(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return SignatureAcquisitionFragment.handleFailureCase$lambda$15(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$14(SignatureAcquisitionFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$15(SignatureAcquisitionFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final void launchNextScreen() {
        getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.minorListFragment);
    }

    private final void writeChildPhotographBase64Data(String photoBase64) {
        File fileCreatePdfFile;
        try {
            fileCreatePdfFile = Util.INSTANCE.createPdfFile(getActivity());
        } catch (Exception e) {
            e.printStackTrace();
            fileCreatePdfFile = null;
        }
        if (fileCreatePdfFile == null) {
            return;
        }
        LoaderManager.INSTANCE.showLoader(getActivity());
        new WritePhotoBase64Data(getActivity(), this.iwriteChildPhotographBase64DataServiceResult).execute(new Object[]{photoBase64, fileCreatePdfFile});
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void photoPickerLauncher$lambda$16(SignatureAcquisitionFragment this$0, Uri uri) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (uri != null) {
            this$0.processSelectedImageUri(uri);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void legacyPickerLauncher$lambda$17(SignatureAcquisitionFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1) {
            Intent data = result.getData();
            Uri data2 = data != null ? data.getData() : null;
            if (data2 != null) {
                this$0.processSelectedImageUri(data2);
            }
        }
    }

    private final void initFooterView() {
        SignatureAcquisitionFragmentBinding binding = getBinding();
        binding.crcFooterLayout.backButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SignatureAcquisitionFragment.initFooterView$lambda$20$lambda$18(this.f$0, view);
            }
        });
        binding.crcFooterLayout.backButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Back", "\n(واپس جائیں)", 0, false, 12, null));
        MaterialButton materialButton = binding.crcFooterLayout.nextButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.next);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        materialButton.setText(Util.setEnglishTextSpan$default(util, activity, string, "\n(آگے بڑھیں)", 0, false, 12, null));
        binding.crcFooterLayout.nextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SignatureAcquisitionFragment.initFooterView$lambda$20$lambda$19(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$20$lambda$18(SignatureAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$20$lambda$19(SignatureAcquisitionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.signatureFile != null) {
            this$0.saveApplicantSignatureTab();
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.provide_applicant_signature);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.provide_applicant_signature_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }
}