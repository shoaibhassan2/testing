package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function2;
import pk.gov.nadra.oneapp.models.crc.configuration.GetConfigurations;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class NewApplicationFragment$$ExternalSyntheticLambda1 implements Function2 {
    public /* synthetic */ NewApplicationFragment$$ExternalSyntheticLambda1() {
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return NewApplicationFragment.attachLayoutViews$lambda$11$lambda$8(this.f$0, ((Integer) obj).intValue(), (GetConfigurations.DocumentType.ApplicationType.PriorityType) obj2);
    }
}