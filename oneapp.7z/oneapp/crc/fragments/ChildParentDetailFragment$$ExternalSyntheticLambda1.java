package pk.gov.nadra.oneapp.crc.fragments;

import com.google.android.material.textfield.TextInputLayout;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildParentDetailFragment$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ TextInputLayout f$1;

    public /* synthetic */ ChildParentDetailFragment$$ExternalSyntheticLambda1(TextInputLayout textInputLayout) {
        view = textInputLayout;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ChildParentDetailFragment.scrollToView$lambda$11(this.f$0, view);
    }
}