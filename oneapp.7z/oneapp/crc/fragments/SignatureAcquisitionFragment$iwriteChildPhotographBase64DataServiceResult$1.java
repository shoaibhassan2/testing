package pk.gov.nadra.oneapp.crc.fragments;

import android.net.Uri;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestOptions;
import java.io.File;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data;

/* compiled from: SignatureAcquisitionFragment.kt */
@Metadata(d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\b\u0010\u0006\u001a\u00020\u0003H\u0016¨\u0006\u0007"}, d2 = {"pk/gov/nadra/oneapp/crc/fragments/SignatureAcquisitionFragment$iwriteChildPhotographBase64DataServiceResult$1", "Lpk/gov/nadra/oneapp/commonutils/utils/WritePhotoBase64Data$ICompressImageTaskListener;", "onComplete", "", "compressed", "Ljava/io/File;", "onError", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class SignatureAcquisitionFragment$iwriteChildPhotographBase64DataServiceResult$1 implements WritePhotoBase64Data.ICompressImageTaskListener {
    SignatureAcquisitionFragment$iwriteChildPhotographBase64DataServiceResult$1() {
    }

    @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
    public void onComplete(File compressed) {
        Intrinsics.checkNotNullParameter(compressed, "compressed");
        LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
        this.this$0.getCrcSharedViewModel().setApplicantSignaturePath(compressed.getAbsolutePath());
        RequestOptions requestOptionsCenterInside = new RequestOptions().centerInside();
        Intrinsics.checkNotNullExpressionValue(requestOptionsCenterInside, "centerInside(...)");
        Glide.with((FragmentActivity) this.this$0.getActivity()).load(Uri.fromFile(compressed)).apply((BaseRequestOptions<?>) requestOptionsCenterInside).into(this.this$0.getBinding().ivTakePhoto);
        this.this$0.setSignatureFile(compressed);
    }

    @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
    public void onError() {
        LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
    }
}