package pk.gov.nadra.oneapp.crc.fragments;

import java.util.Date;
import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDetailFragment$$ExternalSyntheticLambda10 implements Function1 {
    public /* synthetic */ ChildDetailFragment$$ExternalSyntheticLambda10() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return ChildDetailFragment.attachLayoutViews$lambda$18$lambda$9$lambda$8(this_apply, (Date) obj);
    }
}