package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class UploadPhotographFragment$$ExternalSyntheticLambda8 implements View.OnClickListener {
    public /* synthetic */ UploadPhotographFragment$$ExternalSyntheticLambda8() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UploadPhotographFragment.onViewCreated$lambda$9$lambda$5(this.f$0, view);
    }
}