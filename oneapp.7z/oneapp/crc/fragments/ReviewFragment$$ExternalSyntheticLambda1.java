package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ReviewFragment$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public final /* synthetic */ ReviewFragment f$1;

    public /* synthetic */ ReviewFragment$$ExternalSyntheticLambda1(ReviewFragment reviewFragment) {
        this = reviewFragment;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ReviewFragment.initFooterView$lambda$14$lambda$13(binding, this, view);
    }
}