package pk.gov.nadra.oneapp.crc.fragments;

import android.net.Uri;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestOptions;
import java.io.File;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;

/* compiled from: SignatureAcquisitionFragment.kt */
@Metadata(d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\b\u0010\u0006\u001a\u00020\u0003H\u0016¨\u0006\u0007"}, d2 = {"pk/gov/nadra/oneapp/crc/fragments/SignatureAcquisitionFragment$iCompressImageTaskListenerResult$1", "Lpk/gov/nadra/oneapp/commonutils/utils/ImageCompressor$ICompressImageTaskListener;", "onComplete", "", "compressed", "Ljava/io/File;", "onError", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class SignatureAcquisitionFragment$iCompressImageTaskListenerResult$1 implements ImageCompressor.ICompressImageTaskListener {
    SignatureAcquisitionFragment$iCompressImageTaskListenerResult$1() {
    }

    @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
    public void onComplete(File compressed) {
        Intrinsics.checkNotNullParameter(compressed, "compressed");
        RequestOptions requestOptionsCenterInside = new RequestOptions().centerInside();
        Intrinsics.checkNotNullExpressionValue(requestOptionsCenterInside, "centerInside(...)");
        Glide.with((FragmentActivity) this.this$0.getActivity()).load(Uri.fromFile(compressed)).apply((BaseRequestOptions<?>) requestOptionsCenterInside).into(this.this$0.getBinding().ivTakePhoto);
        this.this$0.setSignatureFile(compressed);
        if (this.this$0.signatureFile != null) {
            this.this$0.handleUploadSignature();
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity activity = this.this$0.getActivity();
        String string = this.this$0.getString(R.string.signature_required);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this.this$0.getString(R.string.signature_required_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }

    @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
    public void onError() {
        Util.INSTANCE.showToast(this.this$0.getActivity(), "Failed");
    }
}