package pk.gov.nadra.oneapp.crc.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SignatureAcquisitionFragment$$ExternalSyntheticLambda8 implements ActivityResultCallback {
    public /* synthetic */ SignatureAcquisitionFragment$$ExternalSyntheticLambda8() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        SignatureAcquisitionFragment.galleryLauncher$lambda$8(this.f$0, (ActivityResult) obj);
    }
}