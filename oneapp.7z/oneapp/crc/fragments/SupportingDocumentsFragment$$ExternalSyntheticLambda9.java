package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SupportingDocumentsFragment$$ExternalSyntheticLambda9 implements Function0 {
    public /* synthetic */ SupportingDocumentsFragment$$ExternalSyntheticLambda9() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return SupportingDocumentsFragment.onViewCreated$lambda$11$lambda$5$lambda$3(this.f$0);
    }
}