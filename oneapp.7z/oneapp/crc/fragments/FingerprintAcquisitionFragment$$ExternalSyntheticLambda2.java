package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class FingerprintAcquisitionFragment$$ExternalSyntheticLambda2 implements Function0 {
    public /* synthetic */ FingerprintAcquisitionFragment$$ExternalSyntheticLambda2() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return FingerprintAcquisitionFragment.handleFailureCase$lambda$7(this.f$0);
    }
}