package pk.gov.nadra.oneapp.crc.fragments;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import pk.gov.nadra.oneapp.crc.databinding.MinorListFragmentBinding;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class MinorListFragment$$ExternalSyntheticLambda15 implements SwipeRefreshLayout.OnRefreshListener {
    public final /* synthetic */ MinorListFragmentBinding f$1;

    public /* synthetic */ MinorListFragment$$ExternalSyntheticLambda15(MinorListFragmentBinding minorListFragmentBinding) {
        binding = minorListFragmentBinding;
    }

    @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
    public final void onRefresh() {
        MinorListFragment.onViewCreated$lambda$13$lambda$11(this.f$0, binding);
    }
}