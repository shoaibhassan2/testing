package pk.gov.nadra.oneapp.crc.fragments;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class NewApplicationFragment$$ExternalSyntheticLambda15 implements Runnable {
    public /* synthetic */ NewApplicationFragment$$ExternalSyntheticLambda15() {
    }

    @Override // java.lang.Runnable
    public final void run() {
        NewApplicationFragment.scrollToBottomIfNeeded$lambda$51(this.f$0);
    }
}