package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class FingerprintAcquisitionFragment$$ExternalSyntheticLambda3 implements Function0 {
    public /* synthetic */ FingerprintAcquisitionFragment$$ExternalSyntheticLambda3() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return FingerprintAcquisitionFragment.handleFailureCase$lambda$8(this.f$0);
    }
}