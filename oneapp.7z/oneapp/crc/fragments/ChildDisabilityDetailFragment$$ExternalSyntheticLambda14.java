package pk.gov.nadra.oneapp.crc.fragments;

import java.util.Date;
import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ChildDisabilityDetailFragment$$ExternalSyntheticLambda14 implements Function1 {
    public /* synthetic */ ChildDisabilityDetailFragment$$ExternalSyntheticLambda14() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return ChildDisabilityDetailFragment.attachLayoutViews$lambda$13$lambda$6$lambda$5(this_apply, (Date) obj);
    }
}