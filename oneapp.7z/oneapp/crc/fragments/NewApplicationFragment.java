package pk.gov.nadra.oneapp.crc.fragments;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.GridLayoutManager;
import com.farrakhj.stringpickerlibrary.views.StringPickerActivity;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.chip.Chip;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.io.FilesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import org.apache.commons.imaging.formats.jpeg.iptc.IptcConstants;
import pk.gov.nadra.oneapp.commonui.CnicMaskWatcher;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.adapter.ProcessingFeeAdapter;
import pk.gov.nadra.oneapp.commonutils.fingerprint.FingerprintScanSelectionActivityUnikrew;
import pk.gov.nadra.oneapp.commonutils.idemialiveness.ChallengeActivity;
import pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback;
import pk.gov.nadra.oneapp.commonutils.preferences.AppPreferences;
import pk.gov.nadra.oneapp.commonutils.service.ValidateLicenseService;
import pk.gov.nadra.oneapp.commonutils.unikrewliveness.UnikrewFacialActivity;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCropper;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.adapter.viewmodel.CRCSharedViewModel;
import pk.gov.nadra.oneapp.crc.databinding.NewApplicationFragmentBinding;
import pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment;
import pk.gov.nadra.oneapp.crc.utils.FingerIndexEnum;
import pk.gov.nadra.oneapp.crc.utils.MethodName;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;
import pk.gov.nadra.oneapp.models.FeeCalculationRequest;
import pk.gov.nadra.oneapp.models.FeeCalculationResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.models.crc.TrackingIDDataUpdationReqeust;
import pk.gov.nadra.oneapp.models.crc.TrackingIDDataUpdationResponse;
import pk.gov.nadra.oneapp.models.crc.configuration.GetConfigurations;
import pk.gov.nadra.oneapp.models.crc.fingerprint.FingerPreference;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintRequest;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintResponse;
import pk.gov.nadra.oneapp.models.crc.library.LibraryResponse;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: NewApplicationFragment.kt */
@Metadata(d1 = {"\u0000ò\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\f\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u00107\u001a\u0002082\u0006\u00109\u001a\u00020:H\u0016J$\u0010;\u001a\u00020<2\u0006\u0010=\u001a\u00020>2\b\u0010?\u001a\u0004\u0018\u00010@2\b\u0010A\u001a\u0004\u0018\u00010BH\u0016J\u001a\u0010C\u001a\u0002082\u0006\u0010D\u001a\u00020<2\b\u0010A\u001a\u0004\u0018\u00010BH\u0016J\b\u0010E\u001a\u000208H\u0002J%\u0010F\u001a\u0002082\u0016\u0010G\u001a\u0012\u0012\u0004\u0012\u00020\u00110\u0010j\b\u0012\u0004\u0012\u00020\u0011`HH\u0002¢\u0006\u0002\u0010IJ\u0010\u0010N\u001a\u0002082\u0006\u0010O\u001a\u00020\u0011H\u0002J\b\u0010Q\u001a\u00020RH\u0002J\b\u0010S\u001a\u000208H\u0002J\b\u0010T\u001a\u000208H\u0002J\u0018\u0010U\u001a\u0002082\u0006\u0010V\u001a\u00020W2\u0006\u0010X\u001a\u00020YH\u0002J\b\u0010Z\u001a\u00020[H\u0002J\u0010\u0010\\\u001a\u00020\u00112\u0006\u0010]\u001a\u00020\u0011H\u0002J\u0010\u0010^\u001a\u0002082\u0006\u0010_\u001a\u00020WH\u0002J\u0010\u0010`\u001a\u0002082\u0006\u0010_\u001a\u00020WH\u0002J\b\u0010a\u001a\u000208H\u0002J\b\u0010b\u001a\u00020cH\u0002J\b\u0010d\u001a\u000208H\u0002J\u0010\u0010e\u001a\u0002082\u0006\u0010_\u001a\u00020WH\u0002J\b\u0010f\u001a\u000208H\u0002J\b\u0010g\u001a\u000208H\u0002J\u0018\u0010h\u001a\u0002082\u0006\u0010_\u001a\u00020i2\u0006\u0010j\u001a\u00020!H\u0002J\u0018\u0010k\u001a\u0002082\u0006\u0010V\u001a\u00020i2\u0006\u0010X\u001a\u00020YH\u0002J\u0010\u0010l\u001a\u0002082\u0006\u0010m\u001a\u00020nH\u0002J\u0010\u0010o\u001a\u0002082\u0006\u0010_\u001a\u00020WH\u0002J\u0010\u0010p\u001a\u0002082\u0006\u0010q\u001a\u000201H\u0002J\b\u0010r\u001a\u000208H\u0002J\b\u0010s\u001a\u000208H\u0002J\b\u0010u\u001a\u000208H\u0002J\b\u0010v\u001a\u000208H\u0002J\b\u0010y\u001a\u000208H\u0002J\b\u0010{\u001a\u000208H\u0002J\b\u0010|\u001a\u000208H\u0002J\u0019\u0010~\u001a\u0002082\u0006\u0010\u007f\u001a\u00020\u00112\u0007\u0010\u0080\u0001\u001a\u00020RH\u0002J\u0011\u0010\u0081\u0001\u001a\u0002082\u0006\u00102\u001a\u00020\u0011H\u0002J\u0013\u0010\u0084\u0001\u001a\u00020\u00112\b\u0010\u0085\u0001\u001a\u00030\u0086\u0001H\u0002J\u0012\u0010\u0087\u0001\u001a\u0002082\u0007\u0010\u0088\u0001\u001a\u00020\u0011H\u0002J\t\u0010\u0089\u0001\u001a\u000208H\u0002J\t\u0010\u008a\u0001\u001a\u000208H\u0002J\t\u0010\u008b\u0001\u001a\u000208H\u0002J\t\u0010\u008d\u0001\u001a\u000208H\u0002J\t\u0010\u008e\u0001\u001a\u000208H\u0002J\t\u0010\u0090\u0001\u001a\u00020RH\u0002J\t\u0010\u0091\u0001\u001a\u000208H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u001b0\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u001b0\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020!X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020#X\u0082.¢\u0006\u0002\n\u0000R\u001a\u0010$\u001a\u00020%X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b&\u0010'\"\u0004\b(\u0010)R'\u0010*\u001a\u000e\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020,0+8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b/\u0010\t\u001a\u0004\b-\u0010.R\u000e\u00100\u001a\u000201X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u00102\u001a\u00020\u0011X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b3\u00104\"\u0004\b5\u00106R\u001c\u0010J\u001a\u0010\u0012\f\u0012\n M*\u0004\u0018\u00010L0L0KX\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010P\u001a\u0010\u0012\f\u0012\n M*\u0004\u0018\u00010L0L0KX\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010t\u001a\u0010\u0012\f\u0012\n M*\u0004\u0018\u00010\u00110\u00110KX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010w\u001a\u00020xX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010z\u001a\u0010\u0012\f\u0012\n M*\u0004\u0018\u00010L0L0KX\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010}\u001a\u0010\u0012\f\u0012\n M*\u0004\u0018\u00010L0L0KX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0082\u0001\u001a\u00030\u0083\u0001X\u0082\u000e¢\u0006\u0002\n\u0000R\u001d\u0010\u008c\u0001\u001a\u0010\u0012\f\u0012\n M*\u0004\u0018\u00010L0L0KX\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\u008f\u0001\u001a\u0010\u0012\f\u0012\n M*\u0004\u0018\u00010L0L0KX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0092\u0001"}, d2 = {"Lpk/gov/nadra/oneapp/crc/fragments/NewApplicationFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/crc/databinding/NewApplicationFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/NewApplicationFragmentBinding;", "applicationTypeArray", "Ljava/util/ArrayList;", "", "documentTypeArray", "configurations", "Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations;", "selectedApplicationType", "Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations$DocumentType$ApplicationType;", "selectedDocumentType", "Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations$DocumentType;", "valueAddedArray", "applicantCountriesList", "Lpk/gov/nadra/oneapp/models/crc/library/LibraryResponse;", "selectedApplicantCountry", "mobileOperatorsList", "selectedOperator", "priorityType", "dropdownCalling", "Lpk/gov/nadra/oneapp/crc/utils/MethodName;", "activity", "Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "adapter", "Lpk/gov/nadra/oneapp/commonutils/adapter/ProcessingFeeAdapter;", "getAdapter", "()Lpk/gov/nadra/oneapp/commonutils/adapter/ProcessingFeeAdapter;", "setAdapter", "(Lpk/gov/nadra/oneapp/commonutils/adapter/ProcessingFeeAdapter;)V", "fieldToViewMap", "", "Lcom/google/android/material/textfield/TextInputLayout;", "getFieldToViewMap", "()Ljava/util/Map;", "fieldToViewMap$delegate", "verifyFingerprintResponse", "Lpk/gov/nadra/oneapp/models/crc/fingerprint/VerifyFingerprintResponse;", "sourceImagePath", "getSourceImagePath", "()Ljava/lang/String;", "setSourceImagePath", "(Ljava/lang/String;)V", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "attachLayoutViews", "launchStringPickerActivity", "arrayList", "Lkotlin/collections/ArrayList;", "(Ljava/util/ArrayList;)V", "startForResult", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "addChip", "s", "fingerprintLauncher", "validateViews", "", "getConfigurations", "processStartApplicationButtonClickAction", "handleFailureCase", "jsonResponse", "Lcom/google/gson/JsonObject;", "responseCode", "", "getTIDDataUpdationRequest", "Lpk/gov/nadra/oneapp/models/crc/TrackingIDDataUpdationReqeust;", "getNumberAfterDash", "mobileNumber", "processConfigurationResponse", "jSonObject", "processTIDDataUpdationSuccessResponse", "processFeeCalculation", "getFeeCalculationRequest", "Lpk/gov/nadra/oneapp/models/FeeCalculationRequest;", "getMobileOperatorsList", "processFeeCalculationSuccessResponse", "launchFingerprintActivity", "handleCaptureSuccess", "processLibrarySuccessResponse", "Lcom/google/gson/JsonArray;", "methodName", "handleFailureCaseJsonArray", "verifyApplicantFingerprint", "verifyFingerprintRequest", "Lpk/gov/nadra/oneapp/models/crc/fingerprint/VerifyFingerprintRequest;", "processVerifyApplicantSuccessResponse", "handleSuccessfulVerification", "response", "scrollToBottomIfNeeded", "handlePhoneNumberOperatorData", "cameraPermissionLauncher", "requestCameraPermissionIfNeeded", "checkIdemiaLicenseActivation", "licenseValidationCallback", "Lpk/gov/nadra/oneapp/commonutils/interfaces/LicenseValidationCallback;", "processLicenseSuccess", "livelinessLauncher", "processOnActivityResultForCameraIntent", "launchImageCropper", "cropLauncher", "processOnActivityResultForAnanasLibrary", "processedFilePath", "isImageEdit", "compressImage", "iCompressImageTaskListenerResult", "Lpk/gov/nadra/oneapp/commonutils/utils/ImageCompressor$ICompressImageTaskListener;", "convertFileToBase64", "file", "Ljava/io/File;", "verifyApplicantWithFacial", "base64", "handleFingerprintExist", "handleLivenessControlLaunch", "dispatchCameraIntentForPhotoCapture", "cameraLauncher", "checkLivenessControl", "launchUnikrewFacial", "unikrewFacialLauncher", "isMySelfProcess", "handleMySelfChecks", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class NewApplicationFragment extends Fragment {
    private NewApplicationFragmentBinding _binding;
    private CRCActivity activity;
    public ProcessingFeeAdapter adapter;
    private final ActivityResultLauncher<Intent> cameraLauncher;
    private final ActivityResultLauncher<String> cameraPermissionLauncher;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;
    private final ActivityResultLauncher<Intent> cropLauncher;
    private final ActivityResultLauncher<Intent> fingerprintLauncher;
    private ImageCompressor.ICompressImageTaskListener iCompressImageTaskListenerResult;
    private LicenseValidationCallback licenseValidationCallback;
    private final ActivityResultLauncher<Intent> livelinessLauncher;
    private final ActivityResultLauncher<Intent> startForResult;
    private final ActivityResultLauncher<Intent> unikrewFacialLauncher;
    private ArrayList<String> applicationTypeArray = new ArrayList<>();
    private ArrayList<String> documentTypeArray = new ArrayList<>();
    private GetConfigurations configurations = new GetConfigurations(null, 1, null);
    private GetConfigurations.DocumentType.ApplicationType selectedApplicationType = new GetConfigurations.DocumentType.ApplicationType(null, null, null, 7, null);
    private GetConfigurations.DocumentType selectedDocumentType = new GetConfigurations.DocumentType(null, null, null, 7, null);
    private ArrayList<String> valueAddedArray = CollectionsKt.arrayListOf("SMS", "Email");
    private ArrayList<LibraryResponse> applicantCountriesList = new ArrayList<>();
    private LibraryResponse selectedApplicantCountry = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private ArrayList<LibraryResponse> mobileOperatorsList = new ArrayList<>();
    private LibraryResponse selectedOperator = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private String priorityType = "";
    private MethodName dropdownCalling = MethodName.COUNTRY;

    /* renamed from: fieldToViewMap$delegate, reason: from kotlin metadata */
    private final Lazy fieldToViewMap = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return NewApplicationFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
        }
    });
    private VerifyFingerprintResponse verifyFingerprintResponse = new VerifyFingerprintResponse(null, false, false, null, null, false, null, null, null, null, null, null, null, false, null, null, 65535, null);
    private String sourceImagePath = "";

    /* compiled from: NewApplicationFragment.kt */
    @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[MethodName.values().length];
            try {
                iArr[MethodName.APPLICATION_TYPE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[MethodName.DOCUMENT_TYPE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[MethodName.VALUE_ADDED_SERVICE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[MethodName.MOBILE_OPERATOR.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[MethodName.COUNTRY.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public NewApplicationFragment() {
        final NewApplicationFragment newApplicationFragment = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(newApplicationFragment, Reflection.getOrCreateKotlinClass(CRCSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = newApplicationFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = newApplicationFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = newApplicationFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda5
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                NewApplicationFragment.startForResult$lambda$15(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.startForResult = activityResultLauncherRegisterForActivityResult;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult2 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda6
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) throws JsonSyntaxException {
                NewApplicationFragment.fingerprintLauncher$lambda$18(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult2, "registerForActivityResult(...)");
        this.fingerprintLauncher = activityResultLauncherRegisterForActivityResult2;
        ActivityResultLauncher<String> activityResultLauncherRegisterForActivityResult3 = registerForActivityResult(new ActivityResultContracts.RequestPermission(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda7
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                NewApplicationFragment.cameraPermissionLauncher$lambda$54(this.f$0, (Boolean) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult3, "registerForActivityResult(...)");
        this.cameraPermissionLauncher = activityResultLauncherRegisterForActivityResult3;
        this.licenseValidationCallback = new LicenseValidationCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$licenseValidationCallback$1
            @Override // pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback
            public void onSuccess() {
                LoaderManager loaderManager = LoaderManager.INSTANCE;
                CRCActivity cRCActivity = this.this$0.activity;
                if (cRCActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    cRCActivity = null;
                }
                loaderManager.hideLoader(cRCActivity);
                this.this$0.processLicenseSuccess();
            }

            @Override // pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback
            public void onError() {
                LoaderManager loaderManager = LoaderManager.INSTANCE;
                CRCActivity cRCActivity = this.this$0.activity;
                CRCActivity cRCActivity2 = null;
                if (cRCActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    cRCActivity = null;
                }
                loaderManager.hideLoader(cRCActivity);
                BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
                CRCActivity cRCActivity3 = this.this$0.activity;
                if (cRCActivity3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                } else {
                    cRCActivity2 = cRCActivity3;
                }
                String string = this.this$0.getString(R.string.face_liveness_failed);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                String string2 = this.this$0.getString(R.string.face_liveness_failed_urdu);
                Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) cRCActivity2, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
            }
        };
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult4 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda8
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                NewApplicationFragment.livelinessLauncher$lambda$55(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult4, "registerForActivityResult(...)");
        this.livelinessLauncher = activityResultLauncherRegisterForActivityResult4;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult5 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda9
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                NewApplicationFragment.cropLauncher$lambda$57(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult5, "registerForActivityResult(...)");
        this.cropLauncher = activityResultLauncherRegisterForActivityResult5;
        this.iCompressImageTaskListenerResult = new ImageCompressor.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$iCompressImageTaskListenerResult$1
            @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
            public void onComplete(File compressed) {
                Intrinsics.checkNotNullParameter(compressed, "compressed");
                String strConvertFileToBase64 = this.this$0.convertFileToBase64(compressed);
                if (Constant.INSTANCE.getDEBUG()) {
                    Log.d("Compressed (30KB)", strConvertFileToBase64);
                }
                this.this$0.verifyApplicantWithFacial(strConvertFileToBase64);
            }

            @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
            public void onError() {
                Util util = Util.INSTANCE;
                CRCActivity cRCActivity = this.this$0.activity;
                if (cRCActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    cRCActivity = null;
                }
                util.showToast(cRCActivity, "Failed");
            }
        };
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult6 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda10
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                NewApplicationFragment.cameraLauncher$lambda$59(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult6, "registerForActivityResult(...)");
        this.cameraLauncher = activityResultLauncherRegisterForActivityResult6;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult7 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda12
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                NewApplicationFragment.unikrewFacialLauncher$lambda$60(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult7, "registerForActivityResult(...)");
        this.unikrewFacialLauncher = activityResultLauncherRegisterForActivityResult7;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final CRCSharedViewModel getCrcSharedViewModel() {
        return (CRCSharedViewModel) this.crcSharedViewModel.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final NewApplicationFragmentBinding getBinding() {
        NewApplicationFragmentBinding newApplicationFragmentBinding = this._binding;
        Intrinsics.checkNotNull(newApplicationFragmentBinding);
        return newApplicationFragmentBinding;
    }

    public final ProcessingFeeAdapter getAdapter() {
        ProcessingFeeAdapter processingFeeAdapter = this.adapter;
        if (processingFeeAdapter != null) {
            return processingFeeAdapter;
        }
        Intrinsics.throwUninitializedPropertyAccessException("adapter");
        return null;
    }

    public final void setAdapter(ProcessingFeeAdapter processingFeeAdapter) {
        Intrinsics.checkNotNullParameter(processingFeeAdapter, "<set-?>");
        this.adapter = processingFeeAdapter;
    }

    private final Map<String, TextInputLayout> getFieldToViewMap() {
        return (Map) this.fieldToViewMap.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Map fieldToViewMap_delegate$lambda$0(NewApplicationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        return MapsKt.mapOf(TuplesKt.to("citizenNumber", this$0.getBinding().applicantCnicLayout.maskedCnicTextInputLayout), TuplesKt.to("countryOfStay", this$0.getBinding().countryResidentLayout.textInputLayout));
    }

    public final String getSourceImagePath() {
        return this.sourceImagePath;
    }

    public final void setSourceImagePath(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.sourceImagePath = str;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.crc.views.CRCActivity");
        this.activity = (CRCActivity) fragmentActivityRequireActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = NewApplicationFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        attachLayoutViews();
    }

    private final void attachLayoutViews() throws Resources.NotFoundException {
        final NewApplicationFragmentBinding binding = getBinding();
        binding.crcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                NewApplicationFragment.attachLayoutViews$lambda$11$lambda$1(this.f$0, view);
            }
        });
        binding.crcHeaderLayout.iconInfo.setVisibility(0);
        binding.crcHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda21
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                NewApplicationFragment.attachLayoutViews$lambda$11$lambda$2(this.f$0, view);
            }
        });
        binding.crcHeaderLayout.iconHome.setVisibility(8);
        binding.crcHeaderLayout.tvHeaderTrackingId.setVisibility(8);
        binding.crcHeaderLayout.tvHeaderTrackingIdHeading.setVisibility(8);
        binding.crcHeaderLayout.tvHeaderFee.setVisibility(8);
        binding.crcHeaderLayout.viewHeaderSeparator.setVisibility(8);
        binding.crcHeaderLayout.textTitle.setText(getCrcSharedViewModel().getReactNativeData().getAppType());
        TextView textView = binding.crcHeaderLayout.textTitle;
        String upperCase = getCrcSharedViewModel().getDocumentTypeValue().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(String.valueOf(upperCase));
        TextView textView2 = binding.crcHeaderLayout.textBackUr;
        CRCActivity cRCActivity = this.activity;
        CRCActivity cRCActivity2 = null;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        textView2.setTypeface(ResourcesCompat.getFont(cRCActivity, R.font.nadra_nastaleeq));
        binding.applicationDetailHeadingLayout.tvStepHeading.setText(getString(R.string.application_details));
        binding.applicationDetailHeadingLayout.tvStepHeadingUrdu.setText("(درخواست کی تفصیلات)");
        TextView textView3 = binding.applicationDetailHeadingLayout.tvStepHeadingUrdu;
        CRCActivity cRCActivity3 = this.activity;
        if (cRCActivity3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity3 = null;
        }
        textView3.setTypeface(ResourcesCompat.getFont(cRCActivity3, R.font.nadra_nastaleeq));
        binding.contactDetailHeadingLayout.tvStepHeading.setText(getString(R.string.contact_detail));
        binding.contactDetailHeadingLayout.tvStepHeadingUrdu.setText("(رابطہ کی تفصیلات)");
        TextView textView4 = binding.contactDetailHeadingLayout.tvStepHeadingUrdu;
        CRCActivity cRCActivity4 = this.activity;
        if (cRCActivity4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity4 = null;
        }
        textView4.setTypeface(ResourcesCompat.getFont(cRCActivity4, R.font.nadra_nastaleeq));
        binding.contactDetailHeadingLayout.getRoot().setVisibility(8);
        TextInputLayout textInputLayout = binding.applicantCnicLayout.maskedCnicTextInputLayout;
        Util util = Util.INSTANCE;
        CRCActivity cRCActivity5 = this.activity;
        if (cRCActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity5 = null;
        }
        String string = getString(R.string.applicant_citizen_number);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textInputLayout.setHint(Util.setEnglishTextSpan$default(util, cRCActivity5, string, " (شناختی کارڈ نمبر) ", 0, false, 12, null));
        binding.applicantCnicLayout.maskedCnicEditText.addTextChangedListener(new CnicMaskWatcher("#####-#######-#"));
        binding.applicantCnicLayout.maskedCnicEditText.setText(getCrcSharedViewModel().getReactNativeData().getCitizenNumber());
        binding.applicantCnicLayout.maskedCnicEditText.setEnabled(false);
        TextInputEditText textInputEditText = binding.applicantCnicLayout.maskedCnicEditText;
        CRCActivity cRCActivity6 = this.activity;
        if (cRCActivity6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity6 = null;
        }
        textInputEditText.setBackgroundTintList(ColorStateList.valueOf(cRCActivity6.getResources().getColor(R.color.card_background_color)));
        ConfigurableButton configurableButton = binding.verifyApplicantFingerprintButtonLayout.commonButton;
        Util util2 = Util.INSTANCE;
        CRCActivity cRCActivity7 = this.activity;
        if (cRCActivity7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity7 = null;
        }
        String string2 = getString(R.string.verify_applicant_facial);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util2, cRCActivity7, string2, "\nبرائے کرم درخواست گزار کے چہرے کی تصدیق کریں۔", 0, false, 12, null));
        binding.verifyApplicantFingerprintButtonLayout.commonButton.setFilled(true);
        binding.verifyApplicantFingerprintButtonLayout.commonButton.setInsetTop(0);
        binding.verifyApplicantFingerprintButtonLayout.commonButton.setInsetBottom(0);
        binding.verifyApplicantFingerprintButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda22
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                NewApplicationFragment.attachLayoutViews$lambda$11$lambda$3(this.f$0, binding, view);
            }
        });
        TextInputLayout textInputLayout2 = binding.applicationTypeLayout.textInputLayout;
        Util util3 = Util.INSTANCE;
        CRCActivity cRCActivity8 = this.activity;
        if (cRCActivity8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity8 = null;
        }
        String string3 = getString(R.string.application_type);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        textInputLayout2.setHint(Util.setEnglishTextSpan$default(util3, cRCActivity8, string3, " (درخواست کی نوعیت) ", 0, true, 4, null));
        binding.applicationTypeLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda23
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                NewApplicationFragment.attachLayoutViews$lambda$11$lambda$4(this.f$0, view);
            }
        });
        Util util4 = Util.INSTANCE;
        CRCActivity cRCActivity9 = this.activity;
        if (cRCActivity9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity9 = null;
        }
        MaterialAutoCompleteTextView autoCompleteTextView = binding.applicationTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        TextInputLayout textInputLayout3 = binding.applicationTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout3, "textInputLayout");
        util4.removeErrorOnAutoCompleteTextChanged(cRCActivity9, autoCompleteTextView, textInputLayout3);
        TextInputLayout textInputLayout4 = binding.documentTypeLayout.textInputLayout;
        Util util5 = Util.INSTANCE;
        CRCActivity cRCActivity10 = this.activity;
        if (cRCActivity10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity10 = null;
        }
        CRCActivity cRCActivity11 = cRCActivity10;
        String string4 = getString(R.string.document_type);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        textInputLayout4.setHint(Util.setEnglishTextSpan$default(util5, cRCActivity11, string4, " (دستاویز کی نوعیت) ", 0, true, 4, null));
        binding.documentTypeLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda24
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                NewApplicationFragment.attachLayoutViews$lambda$11$lambda$5(this.f$0, view);
            }
        });
        TextInputLayout textInputLayout5 = binding.valueAddedServicesLayout.textInputLayout;
        Util util6 = Util.INSTANCE;
        CRCActivity cRCActivity12 = this.activity;
        if (cRCActivity12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity12 = null;
        }
        CRCActivity cRCActivity13 = cRCActivity12;
        String string5 = getString(R.string.value_added_services);
        Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
        textInputLayout5.setHint(Util.setEnglishTextSpan$default(util6, cRCActivity13, string5, " (متفرق  خدمات) ", 0, true, 4, null));
        binding.valueAddedServicesLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda25
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                NewApplicationFragment.attachLayoutViews$lambda$11$lambda$6(this.f$0, view);
            }
        });
        TextInputLayout textInputLayout6 = binding.emailLayout.textInputLayout;
        Util util7 = Util.INSTANCE;
        CRCActivity cRCActivity14 = this.activity;
        if (cRCActivity14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity14 = null;
        }
        CRCActivity cRCActivity15 = cRCActivity14;
        String string6 = getString(R.string.email);
        Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
        textInputLayout6.setHint(Util.setEnglishTextSpan$default(util7, cRCActivity15, string6, " (ای میل) ", 0, true, 4, null));
        Util util8 = Util.INSTANCE;
        CRCActivity cRCActivity16 = this.activity;
        if (cRCActivity16 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity16 = null;
        }
        TextInputEditText textInputEditText2 = binding.emailLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        TextInputLayout textInputLayout7 = binding.emailLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout7, "textInputLayout");
        util8.removeErrorOnTextChanged(cRCActivity16, textInputEditText2, textInputLayout7);
        binding.emailLayout.textInputEditText.setText(getCrcSharedViewModel().getReactNativeData().getEmail());
        binding.emailLayout.textInputEditText.setEnabled(false);
        TextInputEditText textInputEditText3 = binding.emailLayout.textInputEditText;
        CRCActivity cRCActivity17 = this.activity;
        if (cRCActivity17 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity17 = null;
        }
        textInputEditText3.setBackgroundTintList(ColorStateList.valueOf(cRCActivity17.getResources().getColor(R.color.card_background_color)));
        binding.emailLayout.getRoot().setVisibility(8);
        TextInputLayout textInputLayout8 = binding.contactNumberLayout;
        Util util9 = Util.INSTANCE;
        CRCActivity cRCActivity18 = this.activity;
        if (cRCActivity18 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity18 = null;
        }
        CRCActivity cRCActivity19 = cRCActivity18;
        String string7 = getString(R.string.contact_number);
        Intrinsics.checkNotNullExpressionValue(string7, "getString(...)");
        textInputLayout8.setHint(Util.setEnglishTextSpan$default(util9, cRCActivity19, string7, " (رابطہ نمبر) ", 0, true, 4, null));
        Util util10 = Util.INSTANCE;
        CRCActivity cRCActivity20 = this.activity;
        if (cRCActivity20 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity20 = null;
        }
        TextInputEditText phoneNumberTextInputEditText = binding.phoneNumberTextInputEditText;
        Intrinsics.checkNotNullExpressionValue(phoneNumberTextInputEditText, "phoneNumberTextInputEditText");
        TextInputLayout contactNumberLayout = binding.contactNumberLayout;
        Intrinsics.checkNotNullExpressionValue(contactNumberLayout, "contactNumberLayout");
        util10.removeErrorOnTextChanged(cRCActivity20, phoneNumberTextInputEditText, contactNumberLayout);
        binding.phoneNumberTextInputEditText.setText(getCrcSharedViewModel().getReactNativeData().getMobileNumber());
        binding.phoneNumberTextInputEditText.setEnabled(false);
        TextInputEditText textInputEditText4 = binding.phoneNumberTextInputEditText;
        CRCActivity cRCActivity21 = this.activity;
        if (cRCActivity21 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity21 = null;
        }
        textInputEditText4.setBackgroundTintList(ColorStateList.valueOf(cRCActivity21.getResources().getColor(R.color.card_background_color)));
        binding.contactNumberLayout.setVisibility(8);
        String strValueOf = String.valueOf(binding.phoneNumberTextInputEditText.getText());
        if (strValueOf != null && strValueOf.length() != 0) {
            if (StringsKt.startsWith$default(String.valueOf(binding.phoneNumberTextInputEditText.getText()), "+92", false, 2, (Object) null)) {
                getBinding().phoneNumberOperatorLayout.getRoot().setVisibility(0);
            } else {
                getBinding().phoneNumberOperatorLayout.getRoot().setVisibility(8);
                getBinding().phoneNumberTextInputEditText.setVisibility(8);
            }
        }
        TextInputLayout textInputLayout9 = binding.phoneNumberOperatorLayout.textInputLayout;
        Util util11 = Util.INSTANCE;
        CRCActivity cRCActivity22 = this.activity;
        if (cRCActivity22 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity22 = null;
        }
        CRCActivity cRCActivity23 = cRCActivity22;
        String string8 = getString(R.string.operator);
        Intrinsics.checkNotNullExpressionValue(string8, "getString(...)");
        textInputLayout9.setHint(Util.setEnglishTextSpan$default(util11, cRCActivity23, string8, " (موبائل آپریٹر) ", 0, true, 4, null));
        Util util12 = Util.INSTANCE;
        CRCActivity cRCActivity24 = this.activity;
        if (cRCActivity24 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity24 = null;
        }
        MaterialAutoCompleteTextView autoCompleteTextView2 = binding.phoneNumberOperatorLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView2, "autoCompleteTextView");
        TextInputLayout textInputLayout10 = binding.phoneNumberOperatorLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout10, "textInputLayout");
        util12.removeErrorOnAutoCompleteTextChanged(cRCActivity24, autoCompleteTextView2, textInputLayout10);
        binding.phoneNumberOperatorLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda26
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                NewApplicationFragment.attachLayoutViews$lambda$11$lambda$7(this.f$0, view);
            }
        });
        handlePhoneNumberOperatorData();
        TextInputLayout textInputLayout11 = binding.countryResidentLayout.textInputLayout;
        Util util13 = Util.INSTANCE;
        CRCActivity cRCActivity25 = this.activity;
        if (cRCActivity25 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity25 = null;
        }
        CRCActivity cRCActivity26 = cRCActivity25;
        String string9 = getString(R.string.country_stay);
        Intrinsics.checkNotNullExpressionValue(string9, "getString(...)");
        textInputLayout11.setHint(Util.setEnglishTextSpan$default(util13, cRCActivity26, string9, " (رہائشی ملک) ", 0, true, 4, null));
        Util util14 = Util.INSTANCE;
        CRCActivity cRCActivity27 = this.activity;
        if (cRCActivity27 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity27 = null;
        }
        MaterialAutoCompleteTextView autoCompleteTextView3 = binding.countryResidentLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView3, "autoCompleteTextView");
        TextInputLayout textInputLayout12 = binding.countryResidentLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout12, "textInputLayout");
        util14.removeErrorOnAutoCompleteTextChanged(cRCActivity27, autoCompleteTextView3, textInputLayout12);
        binding.countryResidentLayout.autoCompleteTextView.setText("Pakistan");
        binding.countryResidentLayout.autoCompleteTextView.setEnabled(false);
        MaterialAutoCompleteTextView materialAutoCompleteTextView = binding.countryResidentLayout.autoCompleteTextView;
        CRCActivity cRCActivity28 = this.activity;
        if (cRCActivity28 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity28 = null;
        }
        materialAutoCompleteTextView.setBackgroundTintList(ColorStateList.valueOf(cRCActivity28.getResources().getColor(R.color.card_background_color)));
        binding.countryResidentLayout.getRoot().setVisibility(8);
        TextView textView5 = binding.tvPriorityHeading;
        Util util15 = Util.INSTANCE;
        CRCActivity cRCActivity29 = this.activity;
        if (cRCActivity29 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity29 = null;
        }
        String string10 = getString(R.string.application_processing_priority);
        Intrinsics.checkNotNullExpressionValue(string10, "getString(...)");
        textView5.setText(Util.setEnglishTextSpan$default(util15, cRCActivity29, string10, "\n (درخواست کی پراسیسنگ کی ترجیح)", 0, false, 12, null));
        TextView textView6 = binding.tvDurationNoteHeading;
        Util util16 = Util.INSTANCE;
        CRCActivity cRCActivity30 = this.activity;
        if (cRCActivity30 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity30 = null;
        }
        String string11 = getString(pk.gov.nadra.oneapp.crc.R.string.printing_duration);
        Intrinsics.checkNotNullExpressionValue(string11, "getString(...)");
        textView6.setText(util16.setSpannableText(cRCActivity30, string11, R.color.green_button, 64, 71));
        CRCActivity cRCActivity31 = this.activity;
        if (cRCActivity31 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity31 = null;
        }
        binding.priorityProcessingRecyclerView.setLayoutManager(new GridLayoutManager(cRCActivity31, 1));
        Context contextRequireContext = requireContext();
        Intrinsics.checkNotNullExpressionValue(contextRequireContext, "requireContext(...)");
        setAdapter(new ProcessingFeeAdapter(contextRequireContext, this.selectedApplicationType.getPriorityTypeList(), new Function2() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return NewApplicationFragment.attachLayoutViews$lambda$11$lambda$8(this.f$0, ((Integer) obj).intValue(), (GetConfigurations.DocumentType.ApplicationType.PriorityType) obj2);
            }
        }));
        binding.priorityProcessingRecyclerView.setAdapter(getAdapter());
        getBinding().categoryFeeCardView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda2
            @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
            public final void onGlobalLayout() {
                NewApplicationFragment.attachLayoutViews$lambda$11$lambda$9(this.f$0);
            }
        });
        ConfigurableButton configurableButton2 = binding.startApplicationButtonLayout.commonButton;
        Util util17 = Util.INSTANCE;
        CRCActivity cRCActivity32 = this.activity;
        if (cRCActivity32 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            cRCActivity2 = cRCActivity32;
        }
        String string12 = getString(R.string.start_application);
        Intrinsics.checkNotNullExpressionValue(string12, "getString(...)");
        configurableButton2.setText(Util.setEnglishTextSpan$default(util17, cRCActivity2, string12, " (درخواست شروع کریں) ", 0, false, 12, null));
        binding.startApplicationButtonLayout.commonButton.setFilled(true);
        binding.startApplicationButtonLayout.commonButton.setInsetTop(0);
        binding.startApplicationButtonLayout.commonButton.setInsetBottom(0);
        binding.startApplicationButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                NewApplicationFragment.attachLayoutViews$lambda$11$lambda$10(this.f$0, view);
            }
        });
        handleFingerprintExist();
        if (isMySelfProcess()) {
            getBinding().verifyApplicantFingerprintButtonLayout.getRoot().setVisibility(8);
            getConfigurations();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$11$lambda$1(NewApplicationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        CRCActivity cRCActivity = this$0.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        cRCActivity.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$11$lambda$2(NewApplicationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        CRCActivity cRCActivity = this$0.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        String string = this$0.getString(R.string.crc_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(cRCActivity, string, Constant.CRC_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$11$lambda$3(NewApplicationFragment this$0, NewApplicationFragmentBinding this_apply, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        Util util = Util.INSTANCE;
        CRCActivity cRCActivity = this$0.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        TextInputLayout maskedCnicTextInputLayout = this_apply.applicantCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        TextInputEditText maskedCnicEditText = this_apply.applicantCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        if (util.validateEditText(cRCActivity, maskedCnicTextInputLayout, maskedCnicEditText)) {
            this$0.priorityType = "";
            this$0.getConfigurations();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$11$lambda$4(NewApplicationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.APPLICATION_TYPE;
        ArrayList<String> arrayList = this$0.applicationTypeArray;
        if (arrayList == null || arrayList.isEmpty()) {
            return;
        }
        this$0.launchStringPickerActivity(this$0.applicationTypeArray);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$11$lambda$5(NewApplicationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.DOCUMENT_TYPE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$11$lambda$6(NewApplicationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.VALUE_ADDED_SERVICE;
        this$0.launchStringPickerActivity(this$0.valueAddedArray);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$11$lambda$7(NewApplicationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.MOBILE_OPERATOR;
        this$0.getMobileOperatorsList();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit attachLayoutViews$lambda$11$lambda$8(NewApplicationFragment this$0, int i, GetConfigurations.DocumentType.ApplicationType.PriorityType feeData) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(feeData, "feeData");
        this$0.priorityType = feeData.getCode();
        this$0.processFeeCalculation();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$11$lambda$9(NewApplicationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.scrollToBottomIfNeeded();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$11$lambda$10(NewApplicationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.processStartApplicationButtonClickAction();
    }

    private final void launchStringPickerActivity(ArrayList<String> arrayList) {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        Intent intent = new Intent(cRCActivity, (Class<?>) StringPickerActivity.class);
        intent.putStringArrayListExtra("INTENT_STRING_LIST", arrayList);
        this.startForResult.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startForResult$lambda$15(NewApplicationFragment this$0, ActivityResult result) {
        Intent data;
        String stringExtra;
        Object next;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || (data = result.getData()) == null || !data.hasExtra("INTENT_STRING_ITEM") || (stringExtra = data.getStringExtra("INTENT_STRING_ITEM")) == null) {
            return;
        }
        int i = WhenMappings.$EnumSwitchMapping$0[this$0.dropdownCalling.ordinal()];
        Object obj = null;
        if (i != 1) {
            if (i == 2) {
                this$0.getBinding().documentTypeLayout.autoCompleteTextView.setText(stringExtra);
                return;
            }
            if (i == 3) {
                this$0.getBinding().valueAddedServicesLayout.autoCompleteTextView.setText(stringExtra);
                this$0.addChip(stringExtra);
                return;
            }
            if (i != 4) {
                if (i != 5) {
                    return;
                }
                Iterator<T> it = this$0.applicantCountriesList.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    Object next2 = it.next();
                    if (Intrinsics.areEqual(((LibraryResponse) next2).getValue(), stringExtra)) {
                        obj = next2;
                        break;
                    }
                }
                Intrinsics.checkNotNull(obj);
                this$0.selectedApplicantCountry = (LibraryResponse) obj;
                this$0.getBinding().countryResidentLayout.autoCompleteTextView.setText(stringExtra);
                return;
            }
            Iterator<T> it2 = this$0.mobileOperatorsList.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    break;
                }
                Object next3 = it2.next();
                String lowerCase = ((LibraryResponse) next3).getValue().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                String lowerCase2 = stringExtra.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                if (Intrinsics.areEqual(lowerCase, lowerCase2)) {
                    obj = next3;
                    break;
                }
            }
            Intrinsics.checkNotNull(obj);
            this$0.selectedOperator = (LibraryResponse) obj;
            this$0.getBinding().phoneNumberOperatorLayout.autoCompleteTextView.setText(stringExtra);
            return;
        }
        this$0.priorityType = "";
        this$0.getBinding().categoryFeeCardView.setVisibility(8);
        this$0.getBinding().categoryTypeTextView.setText("");
        this$0.getBinding().applicationFeeTextView.setText("");
        this$0.getBinding().deliveryFeeTextView.setText("");
        this$0.getBinding().totalFeeTextView.setText("");
        this$0.getCrcSharedViewModel().setAmount("");
        this$0.getAdapter().setSelectedPosition(-1);
        this$0.getAdapter().setError(false);
        this$0.getAdapter().updatePriorityTypeList(new ArrayList());
        MaterialAutoCompleteTextView materialAutoCompleteTextView = this$0.getBinding().applicationTypeLayout.autoCompleteTextView;
        String upperCase = stringExtra.toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        materialAutoCompleteTextView.setText(upperCase);
        Iterator<T> it3 = this$0.selectedDocumentType.getApplicationTypeList().iterator();
        while (true) {
            if (!it3.hasNext()) {
                next = null;
                break;
            }
            next = it3.next();
            String lowerCase3 = ((GetConfigurations.DocumentType.ApplicationType) next).getDescription().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
            String lowerCase4 = stringExtra.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase4, "toLowerCase(...)");
            if (Intrinsics.areEqual(lowerCase3, lowerCase4)) {
                break;
            }
        }
        Intrinsics.checkNotNull(next);
        GetConfigurations.DocumentType.ApplicationType applicationType = (GetConfigurations.DocumentType.ApplicationType) next;
        this$0.selectedApplicationType = applicationType;
        int i2 = applicationType.getPriorityTypeList().size() == 3 ? 3 : 2;
        CRCActivity cRCActivity = this$0.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            obj = cRCActivity;
        }
        this$0.getBinding().priorityProcessingRecyclerView.setLayoutManager(new GridLayoutManager((Context) obj, i2));
        this$0.getAdapter().updatePriorityTypeList(this$0.selectedApplicationType.getPriorityTypeList());
        this$0.getCrcSharedViewModel().setApplicationType(this$0.selectedApplicationType.getCode());
    }

    private final void addChip(String s) {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        final Chip chip = new Chip(cRCActivity);
        chip.setText(s);
        chip.setChipCornerRadius(20.0f);
        chip.setCloseIconVisible(true);
        chip.setOnCloseIconClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                NewApplicationFragment.addChip$lambda$17$lambda$16(this.f$0, chip, view);
            }
        });
        chip.setChipBackgroundColorResource(pk.gov.nadra.oneapp.crc.R.color.chip_background);
        chip.setTextColor(-1);
        chip.setCloseIconResource(pk.gov.nadra.oneapp.crc.R.drawable.ic_close_circle);
        chip.setCloseIconTint(ColorStateList.valueOf(-1));
        chip.setChipMinHeight(100.0f);
        getBinding().valueAddedServiceChipGroup.addView(chip);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addChip$lambda$17$lambda$16(NewApplicationFragment this$0, Chip this_apply, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        this$0.getBinding().valueAddedServiceChipGroup.removeView(this_apply);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void fingerprintLauncher$lambda$18(NewApplicationFragment this$0, ActivityResult result) throws JsonSyntaxException {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1 && result.getData() != null) {
            Intent data = result.getData();
            Intrinsics.checkNotNull(data);
            if (data.hasExtra(Constant.CAPTURE_SUCCESS)) {
                this$0.handleCaptureSuccess();
                return;
            }
        }
        result.getResultCode();
    }

    private final boolean validateViews() {
        boolean z;
        String string;
        String string2 = getBinding().applicationTypeLayout.autoCompleteTextView.getText().toString();
        if (string2 == null || string2.length() == 0) {
            getBinding().applicationTypeLayout.textInputLayout.setError("Select application type");
            getBinding().applicationTypeLayout.textInputLayout.setErrorEnabled(true);
            z = false;
        } else {
            z = true;
        }
        String strValueOf = String.valueOf(getBinding().phoneNumberTextInputEditText.getText());
        if (strValueOf != null && strValueOf.length() != 0 && ((StringsKt.startsWith$default(String.valueOf(getBinding().phoneNumberTextInputEditText.getText()), "+92", false, 2, (Object) null) || StringsKt.startsWith$default(String.valueOf(getBinding().phoneNumberTextInputEditText.getText()), ExifInterface.GPS_MEASUREMENT_3D, false, 2, (Object) null)) && ((string = getBinding().phoneNumberOperatorLayout.autoCompleteTextView.getText().toString()) == null || string.length() == 0))) {
            getBinding().phoneNumberOperatorLayout.textInputLayout.setError("Select phone operator");
            getBinding().phoneNumberOperatorLayout.textInputLayout.setErrorEnabled(true);
            z = false;
        }
        String str = this.priorityType;
        if (str != null && str.length() != 0) {
            return z;
        }
        getAdapter().isErrorEnabled(true);
        return false;
    }

    /* compiled from: NewApplicationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$getConfigurations$1", f = "NewApplicationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$getConfigurations$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return NewApplicationFragment.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                CRCActivity cRCActivity = NewApplicationFragment.this.activity;
                if (cRCActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    cRCActivity = null;
                }
                APIRequests aPIRequests = new APIRequests(cRCActivity);
                final NewApplicationFragment newApplicationFragment = NewApplicationFragment.this;
                aPIRequests.getConfigurations(new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$getConfigurations$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        return NewApplicationFragment.AnonymousClass1.invokeSuspend$lambda$0(newApplicationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                    }
                });
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(NewApplicationFragment newApplicationFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            CRCActivity cRCActivity = newApplicationFragment.activity;
            if (cRCActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                cRCActivity = null;
            }
            loaderManager.hideLoader(cRCActivity);
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getConfigurations() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                newApplicationFragment.processConfigurationResponse(jsonObject);
            } else {
                newApplicationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getConfigurations() {
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        loaderManager.showLoader(cRCActivity);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(null), 3, null);
    }

    private final void processStartApplicationButtonClickAction() {
        if (validateViews()) {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            CRCActivity cRCActivity = this.activity;
            if (cRCActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                cRCActivity = null;
            }
            loaderManager.showLoader(cRCActivity);
            BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12401(null), 3, null);
        }
    }

    /* compiled from: NewApplicationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$processStartApplicationButtonClickAction$1", f = "NewApplicationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$processStartApplicationButtonClickAction$1, reason: invalid class name and case insensitive filesystem */
    static final class C12401 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12401(Continuation<? super C12401> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return NewApplicationFragment.this.new C12401(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12401) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                CRCActivity cRCActivity = NewApplicationFragment.this.activity;
                if (cRCActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    cRCActivity = null;
                }
                APIRequests aPIRequests = new APIRequests(cRCActivity);
                TrackingIDDataUpdationReqeust tIDDataUpdationRequest = NewApplicationFragment.this.getTIDDataUpdationRequest();
                final NewApplicationFragment newApplicationFragment = NewApplicationFragment.this;
                aPIRequests.tIDDataUpdation(tIDDataUpdationRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$processStartApplicationButtonClickAction$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        return NewApplicationFragment.C12401.invokeSuspend$lambda$0(newApplicationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                    }
                });
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(NewApplicationFragment newApplicationFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            CRCActivity cRCActivity = newApplicationFragment.activity;
            if (cRCActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                cRCActivity = null;
            }
            loaderManager.hideLoader(cRCActivity);
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("tIDDataUpdation() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                newApplicationFragment.processTIDDataUpdationSuccessResponse(jsonObject);
            } else {
                newApplicationFragment.priorityType = "";
                newApplicationFragment.getBinding().categoryFeeCardView.setVisibility(8);
                newApplicationFragment.getBinding().categoryTypeTextView.setText("Category: " + newApplicationFragment.priorityType);
                newApplicationFragment.getBinding().applicationFeeTextView.setText("");
                newApplicationFragment.getBinding().deliveryFeeTextView.setText("");
                newApplicationFragment.getBinding().totalFeeTextView.setText("");
                newApplicationFragment.getCrcSharedViewModel().setAmount("");
                newApplicationFragment.getAdapter().setSelectedPosition(-1);
                newApplicationFragment.getAdapter().notifyDataSetChanged();
                newApplicationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) throws JsonSyntaxException {
        Object element = new Gson().fromJson(jsonResponse.toString(), (Class<Object>) ErrorResponse.class);
        CRCActivity cRCActivity = null;
        if (responseCode == 400 || responseCode == 500) {
            CRCActivity cRCActivity2 = null;
            ErrorResponse errorResponse = (ErrorResponse) element;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors == null) {
                    NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                    CRCActivity cRCActivity3 = this.activity;
                    if (cRCActivity3 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("activity");
                    } else {
                        cRCActivity2 = cRCActivity3;
                    }
                    Intrinsics.checkNotNullExpressionValue(element, "element");
                    NetworkErrorHandler.handleError$default(networkErrorHandler, cRCActivity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda16
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return NewApplicationFragment.handleFailureCase$lambda$23$lambda$22(this.f$0);
                        }
                    }, 8, null);
                    return;
                }
                for (ErrorResponse.Error error : errors) {
                    TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                    if (textInputLayout != null) {
                        textInputLayout.setError(String.valueOf(error.getMessage()));
                        textInputLayout.setErrorEnabled(true);
                    }
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            CRCActivity cRCActivity4 = this.activity;
            if (cRCActivity4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                cRCActivity2 = cRCActivity4;
            }
            Intrinsics.checkNotNullExpressionValue(element, "element");
            NetworkErrorHandler.handleError$default(networkErrorHandler2, cRCActivity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda17
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return NewApplicationFragment.handleFailureCase$lambda$24(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        CRCActivity cRCActivity5 = this.activity;
        if (cRCActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            cRCActivity = cRCActivity5;
        }
        Intrinsics.checkNotNullExpressionValue(element, "element");
        NetworkErrorHandler.handleError$default(networkErrorHandler3, cRCActivity, (ErrorResponse) element, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda18
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return NewApplicationFragment.handleFailureCase$lambda$25(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$23$lambda$22(NewApplicationFragment this_run) {
        Intrinsics.checkNotNullParameter(this_run, "$this_run");
        CRCActivity cRCActivity = this_run.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        cRCActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$24(NewApplicationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        CRCActivity cRCActivity = this$0.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        cRCActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$25(NewApplicationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        CRCActivity cRCActivity = this$0.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        cRCActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final TrackingIDDataUpdationReqeust getTIDDataUpdationRequest() {
        TrackingIDDataUpdationReqeust trackingIDDataUpdationReqeust = new TrackingIDDataUpdationReqeust(null, null, null, null, null, null, false, null, null, null, null, false, null, null, null, null, null, false, null, null, null, null, false, null, null, null, null, null, 0, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, -1, 4095, null);
        Editable text = getBinding().applicationTypeLayout.autoCompleteTextView.getText();
        Intrinsics.checkNotNullExpressionValue(text, "getText(...)");
        String upperCase = StringsKt.trim(text).toString().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        trackingIDDataUpdationReqeust.setApplicationType(upperCase);
        Editable text2 = getBinding().documentTypeLayout.autoCompleteTextView.getText();
        Intrinsics.checkNotNullExpressionValue(text2, "getText(...)");
        String upperCase2 = StringsKt.trim(text2).toString().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
        trackingIDDataUpdationReqeust.setDocumentType(upperCase2);
        trackingIDDataUpdationReqeust.setContactCountry("pak");
        trackingIDDataUpdationReqeust.setContactMobileOperator(this.selectedOperator.getId() != 0 ? String.valueOf(this.selectedOperator.getId()) : "6");
        trackingIDDataUpdationReqeust.setContactMobileNumber(getNumberAfterDash(String.valueOf(getBinding().phoneNumberTextInputEditText.getText())));
        trackingIDDataUpdationReqeust.setCountryOfStay("pak");
        trackingIDDataUpdationReqeust.setCitizenNumber(StringsKt.replace$default(String.valueOf(getBinding().applicantCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null));
        trackingIDDataUpdationReqeust.setPriorityCode(this.priorityType);
        trackingIDDataUpdationReqeust.setTrackingId(getCrcSharedViewModel().getTrackingId());
        trackingIDDataUpdationReqeust.setTokenNumber(0);
        trackingIDDataUpdationReqeust.setApplicantName(getCrcSharedViewModel().getReactNativeData().getFullName());
        trackingIDDataUpdationReqeust.setAppTypeCode(this.selectedApplicationType.getCode());
        trackingIDDataUpdationReqeust.setDocumentCode(this.selectedDocumentType.getCode());
        return trackingIDDataUpdationReqeust;
    }

    private final String getNumberAfterDash(String mobileNumber) {
        List listSplit$default = StringsKt.split$default((CharSequence) mobileNumber, new String[]{"-"}, false, 0, 6, (Object) null);
        return listSplit$default.size() > 1 ? (String) listSplit$default.get(1) : mobileNumber;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processConfigurationResponse(JsonObject jSonObject) {
        CRCActivity cRCActivity;
        Object next;
        Object next2;
        GetConfigurations getConfigurations = (GetConfigurations) new Gson().fromJson(jSonObject.toString(), GetConfigurations.class);
        Log.d("processConfigResp", getConfigurations.toString());
        this.configurations = getConfigurations;
        Iterator<T> it = getConfigurations.getDocumentTypeList().iterator();
        while (true) {
            cRCActivity = null;
            if (it.hasNext()) {
                next = it.next();
                if (Intrinsics.areEqual(((GetConfigurations.DocumentType) next).getCode(), "CRC")) {
                    break;
                }
            } else {
                next = null;
                break;
            }
        }
        GetConfigurations.DocumentType documentType = (GetConfigurations.DocumentType) next;
        if (documentType != null) {
            this.selectedDocumentType = documentType;
            if (!documentType.getApplicationTypeList().isEmpty()) {
                List listListOf = CollectionsKt.listOf((Object[]) new String[]{"CANCEL_DEATH", "CANCEL_DIVORCED", "CANCEL", "FAMILY", "DUP_CLEARANCE"});
                List<GetConfigurations.DocumentType.ApplicationType> applicationTypeList = documentType.getApplicationTypeList();
                ArrayList arrayList = new ArrayList();
                for (Object obj : applicationTypeList) {
                    if (!listListOf.contains(((GetConfigurations.DocumentType.ApplicationType) obj).getCode())) {
                        arrayList.add(obj);
                    }
                }
                ArrayList arrayList2 = arrayList;
                ArrayList<String> arrayList3 = new ArrayList<>(CollectionsKt.collectionSizeOrDefault(arrayList2, 10));
                Iterator it2 = arrayList2.iterator();
                while (it2.hasNext()) {
                    String description = ((GetConfigurations.DocumentType.ApplicationType) it2.next()).getDescription();
                    if (description.length() > 0) {
                        StringBuilder sb = new StringBuilder();
                        String strValueOf = String.valueOf(description.charAt(0));
                        Intrinsics.checkNotNull(strValueOf, "null cannot be cast to non-null type java.lang.String");
                        String upperCase = strValueOf.toUpperCase(Locale.ROOT);
                        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                        StringBuilder sbAppend = sb.append((Object) upperCase);
                        String strSubstring = description.substring(1);
                        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                        description = sbAppend.append(strSubstring).toString();
                    }
                    arrayList3.add(description);
                }
                this.applicationTypeArray = arrayList3;
            }
            if (this.applicationTypeArray.size() == 1) {
                Iterator<T> it3 = documentType.getApplicationTypeList().iterator();
                while (true) {
                    if (it3.hasNext()) {
                        next2 = it3.next();
                        if (Intrinsics.areEqual(((GetConfigurations.DocumentType.ApplicationType) next2).getCode(), "NEW")) {
                            break;
                        }
                    } else {
                        next2 = null;
                        break;
                    }
                }
                GetConfigurations.DocumentType.ApplicationType applicationType = (GetConfigurations.DocumentType.ApplicationType) next2;
                if (applicationType != null) {
                    this.selectedApplicationType = applicationType;
                    int i = applicationType.getPriorityTypeList().size() == 3 ? 3 : 2;
                    CRCActivity cRCActivity2 = this.activity;
                    if (cRCActivity2 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("activity");
                        cRCActivity2 = null;
                    }
                    getBinding().priorityProcessingRecyclerView.setLayoutManager(new GridLayoutManager(cRCActivity2, i));
                    getAdapter().updatePriorityTypeList(applicationType.getPriorityTypeList());
                    getCrcSharedViewModel().setApplicationType(this.selectedApplicationType.getCode());
                    MaterialAutoCompleteTextView materialAutoCompleteTextView = getBinding().applicationTypeLayout.autoCompleteTextView;
                    String upperCase2 = this.selectedApplicationType.getDescription().toUpperCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
                    materialAutoCompleteTextView.setText(upperCase2);
                    getBinding().applicationTypeLayout.autoCompleteTextView.setEnabled(false);
                    getBinding().applicationTypeLayout.getRoot().setVisibility(8);
                    MaterialAutoCompleteTextView materialAutoCompleteTextView2 = getBinding().applicationTypeLayout.autoCompleteTextView;
                    CRCActivity cRCActivity3 = this.activity;
                    if (cRCActivity3 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("activity");
                        cRCActivity3 = null;
                    }
                    materialAutoCompleteTextView2.setBackgroundTintList(ColorStateList.valueOf(cRCActivity3.getResources().getColor(R.color.card_background_color)));
                }
            }
        }
        getCrcSharedViewModel().setDocumentType(this.selectedDocumentType.getCode());
        MaterialAutoCompleteTextView materialAutoCompleteTextView3 = getBinding().documentTypeLayout.autoCompleteTextView;
        String upperCase3 = this.selectedDocumentType.getDescription().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase3, "toUpperCase(...)");
        materialAutoCompleteTextView3.setText(upperCase3);
        getBinding().documentTypeLayout.autoCompleteTextView.setEnabled(false);
        getBinding().documentTypeLayout.getRoot().setVisibility(8);
        MaterialAutoCompleteTextView materialAutoCompleteTextView4 = getBinding().documentTypeLayout.autoCompleteTextView;
        CRCActivity cRCActivity4 = this.activity;
        if (cRCActivity4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity4 = null;
        }
        materialAutoCompleteTextView4.setBackgroundTintList(ColorStateList.valueOf(cRCActivity4.getResources().getColor(R.color.card_background_color)));
        if (isMySelfProcess()) {
            handleMySelfChecks();
            return;
        }
        Util util = Util.INSTANCE;
        CRCActivity cRCActivity5 = this.activity;
        if (cRCActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            cRCActivity = cRCActivity5;
        }
        TextInputLayout maskedCnicTextInputLayout = getBinding().applicantCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        TextInputEditText maskedCnicEditText = getBinding().applicantCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        if (util.validateEditText(cRCActivity, maskedCnicTextInputLayout, maskedCnicEditText)) {
            String verificationMode = this.verifyFingerprintResponse.getVerificationMode();
            if (verificationMode == null) {
                verificationMode = "FINGER";
            }
            int iHashCode = verificationMode.hashCode();
            if (iHashCode == 2402104) {
                verificationMode.equals("NONE");
                return;
            }
            if (iHashCode == 2066137676) {
                if (verificationMode.equals("FACIAL")) {
                    requestCameraPermissionIfNeeded();
                }
            } else if (iHashCode == 2073851753 && verificationMode.equals("FINGER")) {
                launchFingerprintActivity();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processTIDDataUpdationSuccessResponse(JsonObject jSonObject) {
        TrackingIDDataUpdationResponse trackingIDDataUpdationResponse = (TrackingIDDataUpdationResponse) new Gson().fromJson(jSonObject.toString(), TrackingIDDataUpdationResponse.class);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("processTIDataSuccessRes", trackingIDDataUpdationResponse.toString());
        }
        getCrcSharedViewModel().setStartApplicationResponse(trackingIDDataUpdationResponse);
        getCrcSharedViewModel().setTrackingId(trackingIDDataUpdationResponse.getTrackingId());
        getCrcSharedViewModel().setApplicationTypeValue(Util.INSTANCE.capitalizeWords(this.selectedApplicationType.getDescription()));
        getCrcSharedViewModel().setDocumentTypeValue(Util.INSTANCE.capitalizeWords(this.selectedDocumentType.getDescription()));
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        cRCActivity.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.minorListFragment);
    }

    /* compiled from: NewApplicationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$processFeeCalculation$1", f = "NewApplicationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$processFeeCalculation$1, reason: invalid class name and case insensitive filesystem */
    static final class C12391 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12391(Continuation<? super C12391> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return NewApplicationFragment.this.new C12391(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12391) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                CRCActivity cRCActivity = NewApplicationFragment.this.activity;
                if (cRCActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    cRCActivity = null;
                }
                APIRequests aPIRequests = new APIRequests(cRCActivity);
                FeeCalculationRequest feeCalculationRequest = NewApplicationFragment.this.getFeeCalculationRequest();
                final NewApplicationFragment newApplicationFragment = NewApplicationFragment.this;
                aPIRequests.feeCalculation(feeCalculationRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$processFeeCalculation$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        return NewApplicationFragment.C12391.invokeSuspend$lambda$0(newApplicationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                    }
                });
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(NewApplicationFragment newApplicationFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            CRCActivity cRCActivity = newApplicationFragment.activity;
            if (cRCActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                cRCActivity = null;
            }
            loaderManager.hideLoader(cRCActivity);
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("feeCalculation() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                newApplicationFragment.processFeeCalculationSuccessResponse(jsonObject);
            } else {
                newApplicationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void processFeeCalculation() {
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        loaderManager.showLoader(cRCActivity);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12391(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final FeeCalculationRequest getFeeCalculationRequest() {
        FeeCalculationRequest feeCalculationRequest = new FeeCalculationRequest(null, null, null, null, null, null, null, null, null, null, null, 2047, null);
        feeCalculationRequest.setCountryOfStay("pak");
        feeCalculationRequest.setCardDeliveryCountry("pak");
        feeCalculationRequest.setPriorityCode(this.priorityType);
        feeCalculationRequest.setAppTypeCode(this.selectedApplicationType.getCode());
        feeCalculationRequest.setDocumentCode(this.selectedDocumentType.getCode());
        return feeCalculationRequest;
    }

    /* compiled from: NewApplicationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$getMobileOperatorsList$1", f = "NewApplicationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$getMobileOperatorsList$1, reason: invalid class name and case insensitive filesystem */
    static final class C12381 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12381(Continuation<? super C12381> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return NewApplicationFragment.this.new C12381(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12381) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                CRCActivity cRCActivity = NewApplicationFragment.this.activity;
                if (cRCActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    cRCActivity = null;
                }
                APIRequests aPIRequests = new APIRequests(cRCActivity);
                final NewApplicationFragment newApplicationFragment = NewApplicationFragment.this;
                aPIRequests.getMobileOperator(new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$getMobileOperatorsList$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        return NewApplicationFragment.C12381.invokeSuspend$lambda$0(newApplicationFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                    }
                });
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(NewApplicationFragment newApplicationFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            CRCActivity cRCActivity = newApplicationFragment.activity;
            if (cRCActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                cRCActivity = null;
            }
            loaderManager.hideLoader(cRCActivity);
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getMobileOperatorsList() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                newApplicationFragment.processLibrarySuccessResponse(jsonArray, MethodName.CERTIFICATE_TYPE);
            } else {
                newApplicationFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getMobileOperatorsList() {
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        loaderManager.showLoader(cRCActivity);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12381(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processFeeCalculationSuccessResponse(JsonObject jSonObject) {
        String str;
        FeeCalculationResponse feeCalculationResponse = (FeeCalculationResponse) new Gson().fromJson(jSonObject.toString(), FeeCalculationResponse.class);
        Log.d("processFeeCalSuccessRes", feeCalculationResponse.toString());
        getBinding().categoryFeeCardView.setVisibility(0);
        String lowerCase = this.priorityType.toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        if (Intrinsics.areEqual(lowerCase, "normal")) {
            str = "\nنارمل";
        } else {
            String lowerCase2 = this.priorityType.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
            if (Intrinsics.areEqual(lowerCase2, "urgent")) {
                str = "\nارجنٹ";
            } else {
                String lowerCase3 = this.priorityType.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
                if (!Intrinsics.areEqual(lowerCase3, "executive")) {
                    str = "";
                } else {
                    str = "\nایگزیکٹو";
                }
            }
        }
        String str2 = str;
        getBinding().categoryTypeTextView.setVisibility(8);
        TextView textView = getBinding().categoryTypeTextView;
        StringBuilder sb = new StringBuilder();
        Util util = Util.INSTANCE;
        CRCActivity cRCActivity = this.activity;
        CRCActivity cRCActivity2 = null;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        StringBuilder sbAppend = sb.append((Object) Util.setEnglishTextSpan$default(util, cRCActivity, "Category", " (نوعیت) ", 0, false, 12, null)).append('\n');
        Util util2 = Util.INSTANCE;
        CRCActivity cRCActivity3 = this.activity;
        if (cRCActivity3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity3 = null;
        }
        textView.setText(sbAppend.append((Object) Util.setEnglishTextSpan$default(util2, cRCActivity3, this.priorityType, str2, 0, false, 12, null)).toString());
        TextView textView2 = getBinding().applicationFeeHeadingTextView;
        Util util3 = Util.INSTANCE;
        CRCActivity cRCActivity4 = this.activity;
        if (cRCActivity4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity4 = null;
        }
        textView2.setText(Util.setEnglishTextSpan$default(util3, cRCActivity4, "Application Fee", " (درخواست کی فیس) ", com.intuit.sdp.R.dimen._10sdp, false, 8, null));
        TextView textView3 = getBinding().deliveryFeeHeadingTextView;
        Util util4 = Util.INSTANCE;
        CRCActivity cRCActivity5 = this.activity;
        if (cRCActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity5 = null;
        }
        textView3.setText(Util.setEnglishTextSpan$default(util4, cRCActivity5, "Card Delivery Fee", " (کارڈ کی ترسیل کی فیس) ", com.intuit.sdp.R.dimen._10sdp, false, 8, null));
        TextView textView4 = getBinding().totalHeadingTextView;
        Util util5 = Util.INSTANCE;
        CRCActivity cRCActivity6 = this.activity;
        if (cRCActivity6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            cRCActivity2 = cRCActivity6;
        }
        textView4.setText(Util.setEnglishTextSpan$default(util5, cRCActivity2, "Payable Fee", " (قابلِ ادائیگی فیس) ", com.intuit.sdp.R.dimen._10sdp, false, 8, null));
        TextView textView5 = getBinding().applicationFeeTextView;
        StringBuilder sb2 = new StringBuilder();
        String upperCase = feeCalculationResponse.getCurrency().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView5.setText(sb2.append(upperCase).append(' ').append(feeCalculationResponse.getApplicationFeeFormatted()).toString());
        TextView textView6 = getBinding().deliveryFeeTextView;
        StringBuilder sb3 = new StringBuilder();
        String upperCase2 = feeCalculationResponse.getCurrency().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
        textView6.setText(sb3.append(upperCase2).append(' ').append(feeCalculationResponse.getCardDeliveryFeeFormatted()).toString());
        TextView textView7 = getBinding().totalFeeTextView;
        StringBuilder sb4 = new StringBuilder();
        String upperCase3 = feeCalculationResponse.getCurrency().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase3, "toUpperCase(...)");
        textView7.setText(sb4.append(upperCase3).append(' ').append(feeCalculationResponse.getTotalFeeFormatted()).toString());
        CRCSharedViewModel crcSharedViewModel = getCrcSharedViewModel();
        StringBuilder sb5 = new StringBuilder();
        String upperCase4 = feeCalculationResponse.getCurrency().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase4, "toUpperCase(...)");
        crcSharedViewModel.setAmount(sb5.append(upperCase4).append(' ').append(feeCalculationResponse.getApplicationFeeFormatted()).toString());
    }

    private final void launchFingerprintActivity() {
        Util util = Util.INSTANCE;
        CRCActivity cRCActivity = this.activity;
        CRCActivity cRCActivity2 = null;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        TextInputLayout maskedCnicTextInputLayout = getBinding().applicantCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        TextInputEditText maskedCnicEditText = getBinding().applicantCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        if (util.validateEditText(cRCActivity, maskedCnicTextInputLayout, maskedCnicEditText)) {
            getBinding().applicantCnicLayout.maskedCnicTextInputLayout.setError(null);
            getBinding().applicantCnicLayout.maskedCnicTextInputLayout.setErrorEnabled(false);
            CRCActivity cRCActivity3 = this.activity;
            if (cRCActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                cRCActivity2 = cRCActivity3;
            }
            Intent intent = new Intent(cRCActivity2, (Class<?>) FingerprintScanSelectionActivityUnikrew.class);
            intent.putExtra(Constant.CAPTURE_TYPE, "VERIFICATION");
            this.fingerprintLauncher.launch(intent);
        }
    }

    private final void handleCaptureSuccess() throws JsonSyntaxException {
        String str;
        String strName;
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        String fingerprints = AppPreferences.getInstance(cRCActivity).getFingerprints();
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d(Constant.TAG, fingerprints);
        }
        Object objFromJson = new Gson().fromJson(fingerprints, (Class<Object>) FingerPreference[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List listAsList = ArraysKt.asList((Object[]) objFromJson);
        VerifyFingerprintRequest verifyFingerprintRequest = new VerifyFingerprintRequest(null, null, 0, null, null, false, null, false, false, false, false, false, false, null, false, false, false, null, 262143, null);
        verifyFingerprintRequest.setApplicantName(getCrcSharedViewModel().getReactNativeData().getFullName());
        verifyFingerprintRequest.setCitizenNumber(StringsKt.replace$default(String.valueOf(getBinding().applicantCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null));
        ArrayList arrayList = new ArrayList();
        Iterator it = listAsList.iterator();
        while (true) {
            str = "";
            if (!it.hasNext()) {
                break;
            }
            FingerPreference fingerPreference = (FingerPreference) it.next();
            VerifyFingerprintRequest.Finger finger = new VerifyFingerprintRequest.Finger(null, null, 0, null, 15, null);
            FingerIndexEnum fingerIndexEnumFromId = FingerIndexEnum.INSTANCE.fromId(Integer.parseInt(fingerPreference.getFingerIndex()));
            if (fingerIndexEnumFromId != null && (strName = fingerIndexEnumFromId.name()) != null) {
                str = strName;
            }
            finger.setIndexName(str);
            finger.setWsq(fingerPreference.getBase64());
            arrayList.add(finger);
        }
        verifyFingerprintRequest.setFingerList(arrayList);
        String trackingId = this.verifyFingerprintResponse.getTrackingId();
        verifyFingerprintRequest.setTrackingId(trackingId != null ? trackingId : "");
        verifyApplicantFingerprint(verifyFingerprintRequest);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processLibrarySuccessResponse(JsonArray jSonObject, MethodName methodName) throws JsonSyntaxException {
        Object objFromJson = new Gson().fromJson(jSonObject.toString(), (Class<Object>) LibraryResponse[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List list = ArraysKt.toList((Object[]) objFromJson);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("LibraryResponse", methodName + " :: Response: " + list);
        }
        ArrayList arrayList = new ArrayList<>();
        int i = WhenMappings.$EnumSwitchMapping$0[this.dropdownCalling.ordinal()];
        if (i == 4) {
            this.mobileOperatorsList = new ArrayList<>();
            Intrinsics.checkNotNull(list, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
            ArrayList<LibraryResponse> arrayList2 = (ArrayList) list;
            this.mobileOperatorsList = arrayList2;
            ArrayList<LibraryResponse> arrayList3 = arrayList2;
            ArrayList arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList3, 10));
            Iterator<T> it = arrayList3.iterator();
            while (it.hasNext()) {
                String value = ((LibraryResponse) it.next()).getValue();
                if (value.length() > 0) {
                    StringBuilder sb = new StringBuilder();
                    String strValueOf = String.valueOf(value.charAt(0));
                    Intrinsics.checkNotNull(strValueOf, "null cannot be cast to non-null type java.lang.String");
                    String upperCase = strValueOf.toUpperCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                    StringBuilder sbAppend = sb.append((Object) upperCase);
                    String strSubstring = value.substring(1);
                    Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                    value = sbAppend.append(strSubstring).toString();
                }
                arrayList4.add(value);
            }
            arrayList = arrayList4;
        } else if (i == 5) {
            this.applicantCountriesList = new ArrayList<>();
            Intrinsics.checkNotNull(list, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
            ArrayList<LibraryResponse> arrayList5 = (ArrayList) list;
            this.applicantCountriesList = arrayList5;
            ArrayList<LibraryResponse> arrayList6 = arrayList5;
            ArrayList arrayList7 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList6, 10));
            Iterator<T> it2 = arrayList6.iterator();
            while (it2.hasNext()) {
                arrayList7.add(((LibraryResponse) it2.next()).getValue());
            }
            arrayList = arrayList7;
        }
        if (arrayList.isEmpty()) {
            return;
        }
        launchStringPickerActivity(arrayList);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCaseJsonArray(JsonArray jsonResponse, int responseCode) throws JsonSyntaxException {
        Object element = new Gson().fromJson((JsonElement) jsonResponse.get(0).getAsJsonObject(), (Class<Object>) ErrorResponse.class);
        CRCActivity cRCActivity = null;
        if (responseCode == 400 || responseCode == 500) {
            CRCActivity cRCActivity2 = null;
            ErrorResponse errorResponse = (ErrorResponse) element;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors == null) {
                    NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                    CRCActivity cRCActivity3 = this.activity;
                    if (cRCActivity3 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("activity");
                    } else {
                        cRCActivity2 = cRCActivity3;
                    }
                    Intrinsics.checkNotNullExpressionValue(element, "element");
                    NetworkErrorHandler.handleError$default(networkErrorHandler, cRCActivity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return NewApplicationFragment.handleFailureCaseJsonArray$lambda$46$lambda$45(this.f$0);
                        }
                    }, 8, null);
                    return;
                }
                for (ErrorResponse.Error error : errors) {
                    TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                    if (textInputLayout != null) {
                        textInputLayout.setError(String.valueOf(error.getMessage()));
                        textInputLayout.setErrorEnabled(true);
                    }
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            CRCActivity cRCActivity4 = this.activity;
            if (cRCActivity4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                cRCActivity2 = cRCActivity4;
            }
            Intrinsics.checkNotNullExpressionValue(element, "element");
            NetworkErrorHandler.handleError$default(networkErrorHandler2, cRCActivity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda11
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return NewApplicationFragment.handleFailureCaseJsonArray$lambda$47(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        CRCActivity cRCActivity5 = this.activity;
        if (cRCActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            cRCActivity = cRCActivity5;
        }
        Intrinsics.checkNotNullExpressionValue(element, "element");
        NetworkErrorHandler.handleError$default(networkErrorHandler3, cRCActivity, (ErrorResponse) element, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda19
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return NewApplicationFragment.handleFailureCaseJsonArray$lambda$48(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$46$lambda$45(NewApplicationFragment this_run) {
        Intrinsics.checkNotNullParameter(this_run, "$this_run");
        CRCActivity cRCActivity = this_run.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        cRCActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$47(NewApplicationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        CRCActivity cRCActivity = this$0.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        cRCActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$48(NewApplicationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        CRCActivity cRCActivity = this$0.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        cRCActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final void verifyApplicantFingerprint(VerifyFingerprintRequest verifyFingerprintRequest) {
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        loaderManager.showLoader(cRCActivity);
        String json = new Gson().toJson(verifyFingerprintRequest);
        if (Constant.INSTANCE.getDEBUG()) {
            System.out.println((Object) ("Fingerprint Json: " + json));
        }
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12411(verifyFingerprintRequest, null), 3, null);
    }

    /* compiled from: NewApplicationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$verifyApplicantFingerprint$1", f = "NewApplicationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$verifyApplicantFingerprint$1, reason: invalid class name and case insensitive filesystem */
    static final class C12411 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ VerifyFingerprintRequest $verifyFingerprintRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12411(VerifyFingerprintRequest verifyFingerprintRequest, Continuation<? super C12411> continuation) {
            super(2, continuation);
            this.$verifyFingerprintRequest = verifyFingerprintRequest;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return NewApplicationFragment.this.new C12411(this.$verifyFingerprintRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12411) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                CRCActivity cRCActivity = NewApplicationFragment.this.activity;
                if (cRCActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    cRCActivity = null;
                }
                APIRequests aPIRequests = new APIRequests(cRCActivity);
                VerifyFingerprintRequest verifyFingerprintRequest = this.$verifyFingerprintRequest;
                final NewApplicationFragment newApplicationFragment = NewApplicationFragment.this;
                aPIRequests.verifyApplicantFingerprint(verifyFingerprintRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$verifyApplicantFingerprint$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        return NewApplicationFragment.C12411.invokeSuspend$lambda$0(newApplicationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                    }
                });
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(NewApplicationFragment newApplicationFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            CRCActivity cRCActivity = newApplicationFragment.activity;
            if (cRCActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                cRCActivity = null;
            }
            loaderManager.hideLoader(cRCActivity);
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("processUpdateChildDetails() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                newApplicationFragment.processVerifyApplicantSuccessResponse(jsonObject);
            } else {
                newApplicationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00e5  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0162  */
    /* JADX WARN: Type inference failed for: r1v7, types: [pk.gov.nadra.oneapp.crc.views.CRCActivity] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void processVerifyApplicantSuccessResponse(com.google.gson.JsonObject r18) {
        /*
            Method dump skipped, instructions count: 400
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment.processVerifyApplicantSuccessResponse(com.google.gson.JsonObject):void");
    }

    private final void handleSuccessfulVerification(VerifyFingerprintResponse response) {
        CRCActivity cRCActivity = null;
        if (response.getTrackingId() != null) {
            CRCSharedViewModel crcSharedViewModel = getCrcSharedViewModel();
            String trackingId = response.getTrackingId();
            Intrinsics.checkNotNull(trackingId);
            crcSharedViewModel.setTrackingId(trackingId);
            Util util = Util.INSTANCE;
            CRCActivity cRCActivity2 = this.activity;
            if (cRCActivity2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                cRCActivity = cRCActivity2;
            }
            TextInputLayout maskedCnicTextInputLayout = getBinding().applicantCnicLayout.maskedCnicTextInputLayout;
            Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
            TextInputEditText maskedCnicEditText = getBinding().applicantCnicLayout.maskedCnicEditText;
            Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
            util.disableTextInputEditText((Context) cRCActivity, maskedCnicTextInputLayout, maskedCnicEditText, true);
            getBinding().verifyApplicantFingerprintButtonLayout.getRoot().setVisibility(8);
            getBinding().applicantDetailLayout.setVisibility(0);
            getBinding().startApplicationButtonLayout.getRoot().setVisibility(0);
            return;
        }
        CRCActivity cRCActivity3 = null;
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity cRCActivity4 = this.activity;
        if (cRCActivity4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            cRCActivity3 = cRCActivity4;
        }
        String string = getString(R.string.request_processing_failed);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = getString(R.string.request_processing_failed_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) cRCActivity3, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }

    private final void scrollToBottomIfNeeded() {
        getBinding().newApplicationScrollView.post(new Runnable() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda15
            @Override // java.lang.Runnable
            public final void run() {
                NewApplicationFragment.scrollToBottomIfNeeded$lambda$51(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void scrollToBottomIfNeeded$lambda$51(NewApplicationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getBinding().newApplicationScrollView.smoothScrollTo(0, this$0.getBinding().newApplicationScrollView.getBottom());
    }

    private final void handlePhoneNumberOperatorData() {
        ReactNativeData.MobileOperator mobileOperator = getCrcSharedViewModel().getReactNativeData().getMobileOperator();
        this.selectedOperator.setId(mobileOperator.getKey());
        getBinding().phoneNumberOperatorLayout.autoCompleteTextView.setText(mobileOperator.getValue());
        String value = mobileOperator.getValue();
        if (value == null || value.length() == 0) {
            return;
        }
        getBinding().phoneNumberOperatorLayout.getRoot().setVisibility(8);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void cameraPermissionLauncher$lambda$54(NewApplicationFragment this$0, Boolean isGranted) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(isGranted, "isGranted");
        if (isGranted.booleanValue()) {
            this$0.handleLivenessControlLaunch();
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity cRCActivity = this$0.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        String string = this$0.getString(R.string.permission_denied);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.permission_denied_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) cRCActivity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }

    private final void requestCameraPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(requireContext(), "android.permission.CAMERA") != 0) {
            this.cameraPermissionLauncher.launch("android.permission.CAMERA");
        } else {
            handleLivenessControlLaunch();
        }
    }

    private final void checkIdemiaLicenseActivation() {
        Object[] objArr = {Constant.IDEMIA_VALUE_1, Constant.IDEMIA_VALUE_2, Constant.IDEMIA_VALUE_3};
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        CRCActivity cRCActivity = this.activity;
        CRCActivity cRCActivity2 = null;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        loaderManager.showLoader(cRCActivity);
        LicenseValidationCallback licenseValidationCallback = this.licenseValidationCallback;
        CRCActivity cRCActivity3 = this.activity;
        if (cRCActivity3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            cRCActivity2 = cRCActivity3;
        }
        new ValidateLicenseService(licenseValidationCallback, cRCActivity2, objArr).validateLicense();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processLicenseSuccess() {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        this.livelinessLauncher.launch(new Intent(cRCActivity, (Class<?>) ChallengeActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void livelinessLauncher$lambda$55(NewApplicationFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || result.getData() == null) {
            return;
        }
        Intent data = result.getData();
        Intrinsics.checkNotNull(data);
        String stringExtra = data.getStringExtra("CAPTURE_RESULT_FACE");
        if (stringExtra != null && new File(stringExtra).length() > 0) {
            this$0.sourceImagePath = stringExtra;
            this$0.processOnActivityResultForCameraIntent();
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        CRCActivity cRCActivity = this$0.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        String string = this$0.getString(R.string.unable_to_detect_face);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.unable_to_detect_face_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) cRCActivity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }

    private final void processOnActivityResultForCameraIntent() {
        if (new File(this.sourceImagePath).length() < 0) {
            return;
        }
        launchImageCropper();
    }

    private final void launchImageCropper() {
        try {
            String str = this.sourceImagePath;
            Util util = Util.INSTANCE;
            CRCActivity cRCActivity = this.activity;
            CRCActivity cRCActivity2 = null;
            if (cRCActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                cRCActivity = null;
            }
            File fileCreatePhotoFile = util.createPhotoFile(cRCActivity);
            Intrinsics.checkNotNull(fileCreatePhotoFile);
            String absolutePath = fileCreatePhotoFile.getAbsolutePath();
            CRCActivity cRCActivity3 = this.activity;
            if (cRCActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                cRCActivity2 = cRCActivity3;
            }
            Intent intent = new Intent(cRCActivity2, (Class<?>) ImageCropper.class);
            intent.putExtra(ImageCropper.EXTRA_INPUT_PATH, str);
            intent.putExtra("output_path", absolutePath);
            this.cropLauncher.launch(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void cropLauncher$lambda$57(NewApplicationFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1) {
            Intent data = result.getData();
            String stringExtra = data != null ? data.getStringExtra("output_path") : null;
            boolean booleanExtra = data != null ? data.getBooleanExtra(ImageCropper.RESULT_IMAGE_EDITED, false) : false;
            if (stringExtra != null) {
                this$0.processOnActivityResultForAnanasLibrary(stringExtra, booleanExtra);
            }
        }
    }

    private final void processOnActivityResultForAnanasLibrary(String processedFilePath, boolean isImageEdit) {
        if (isImageEdit) {
            compressImage(processedFilePath);
        } else {
            compressImage(this.sourceImagePath);
        }
    }

    private final void compressImage(String sourceImagePath) {
        File fileCreatePhotoFile;
        CRCActivity cRCActivity = null;
        try {
            Util util = Util.INSTANCE;
            CRCActivity cRCActivity2 = this.activity;
            if (cRCActivity2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                cRCActivity2 = null;
            }
            fileCreatePhotoFile = util.createPhotoFile(cRCActivity2);
        } catch (Exception e) {
            e.printStackTrace();
            Util util2 = Util.INSTANCE;
            CRCActivity cRCActivity3 = this.activity;
            if (cRCActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                cRCActivity3 = null;
            }
            util2.showToast(cRCActivity3, String.valueOf(e.getMessage()));
            fileCreatePhotoFile = null;
        }
        if (fileCreatePhotoFile == null) {
            return;
        }
        Object[] objArr = {sourceImagePath, fileCreatePhotoFile.getAbsolutePath()};
        CRCActivity cRCActivity4 = this.activity;
        if (cRCActivity4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            cRCActivity = cRCActivity4;
        }
        new ImageCompressor(cRCActivity, this.iCompressImageTaskListenerResult).execute(Arrays.copyOf(objArr, 2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String convertFileToBase64(File file) {
        String strEncodeToString = Base64.encodeToString(FilesKt.readBytes(file), 0);
        Intrinsics.checkNotNullExpressionValue(strEncodeToString, "encodeToString(...)");
        return strEncodeToString;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void verifyApplicantWithFacial(String base64) {
        VerifyFingerprintRequest verifyFingerprintRequest = new VerifyFingerprintRequest(null, null, 0, null, null, false, null, false, false, false, false, false, false, null, false, false, false, null, 262143, null);
        verifyFingerprintRequest.setApplicantName(getCrcSharedViewModel().getReactNativeData().getFullName());
        verifyFingerprintRequest.setCitizenNumber(StringsKt.replace$default(String.valueOf(getBinding().applicantCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null));
        verifyFingerprintRequest.setPhotograph(base64);
        String trackingId = this.verifyFingerprintResponse.getTrackingId();
        if (trackingId == null) {
            trackingId = "";
        }
        verifyFingerprintRequest.setTrackingId(trackingId);
        verifyApplicantFingerprint(verifyFingerprintRequest);
    }

    private final void handleFingerprintExist() {
        if (getCrcSharedViewModel().getReactNativeData().getApplicantFingerprintsExist()) {
            return;
        }
        this.verifyFingerprintResponse.setVerificationMode("FACIAL");
        ConfigurableButton configurableButton = getBinding().verifyApplicantFingerprintButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        String string = getString(R.string.verify_applicant_facial);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        configurableButton.setButtonText(Util.setEnglishTextSpan$default(util, cRCActivity, string, "\nبرائے کرم درخواست گزار کے چہرے کی تصدیق کریں۔", 0, false, 12, null));
    }

    private final void handleLivenessControlLaunch() {
        if (getCrcSharedViewModel().getReactNativeData().getLivelinessControl()) {
            checkLivenessControl();
        } else {
            dispatchCameraIntentForPhotoCapture();
        }
    }

    private final void dispatchCameraIntentForPhotoCapture() {
        Util util = Util.INSTANCE;
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        util.createCameraUri(cRCActivity, new Function2() { // from class: pk.gov.nadra.oneapp.crc.fragments.NewApplicationFragment$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return NewApplicationFragment.dispatchCameraIntentForPhotoCapture$lambda$58(this.f$0, (String) obj, (Intent) obj2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit dispatchCameraIntentForPhotoCapture$lambda$58(NewApplicationFragment this$0, String photoPath, Intent intent) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(photoPath, "photoPath");
        Intrinsics.checkNotNullParameter(intent, "intent");
        this$0.sourceImagePath = photoPath;
        try {
            this$0.cameraLauncher.launch(intent);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void cameraLauncher$lambda$59(NewApplicationFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1) {
            this$0.processOnActivityResultForCameraIntent();
        }
    }

    private final void checkLivenessControl() {
        CRCActivity cRCActivity = this.activity;
        CRCActivity cRCActivity2 = null;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        if (!Intrinsics.areEqual(new SharedPreferencesTokenProvider(cRCActivity).getUserCredentials().getLivenessControl(), Constant.UNIKREW)) {
            CRCActivity cRCActivity3 = this.activity;
            if (cRCActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                cRCActivity2 = cRCActivity3;
            }
            if (!Intrinsics.areEqual(new SharedPreferencesTokenProvider(cRCActivity2).getUserCredentials().getLivenessControl(), Constant.UNIKREW_CLOUD)) {
                checkIdemiaLicenseActivation();
                return;
            }
        }
        launchUnikrewFacial();
    }

    private final void launchUnikrewFacial() {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        Intent intent = new Intent(cRCActivity, (Class<?>) UnikrewFacialActivity.class);
        intent.putExtra(Constant.UNIKREW_CAMERA_MODE, "FRONT");
        intent.putExtra(Constant.UNIKREW_ICAO, true);
        this.unikrewFacialLauncher.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void unikrewFacialLauncher$lambda$60(NewApplicationFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1 && result.getData() != null) {
            Intent data = result.getData();
            Intrinsics.checkNotNull(data);
            if (data.hasExtra(Constant.UNIKREW_PROCESSED_IMAGE_PATH)) {
                Intent data2 = result.getData();
                Intrinsics.checkNotNull(data2);
                String stringExtra = data2.getStringExtra(Constant.UNIKREW_PROCESSED_IMAGE_PATH);
                Intrinsics.checkNotNull(stringExtra);
                this$0.sourceImagePath = stringExtra;
                this$0.processOnActivityResultForCameraIntent();
                return;
            }
        }
        result.getResultCode();
    }

    private final boolean isMySelfProcess() {
        String trackingId;
        if (Intrinsics.areEqual(getCrcSharedViewModel().getReactNativeData().getAccountHolderCnic(), getCrcSharedViewModel().getReactNativeData().getCitizenNumber())) {
            return ((getCrcSharedViewModel().getReactNativeData().getDocType().length() <= 0 && !Intrinsics.areEqual(getCrcSharedViewModel().getReactNativeData().getAppType(), "CRC")) || (trackingId = getCrcSharedViewModel().getReactNativeData().getVerifyFingerprintResponse().getTrackingId()) == null || trackingId.length() == 0) ? false : true;
        }
        return false;
    }

    private final void handleMySelfChecks() {
        this.verifyFingerprintResponse = getCrcSharedViewModel().getReactNativeData().getVerifyFingerprintResponse();
        CRCSharedViewModel crcSharedViewModel = getCrcSharedViewModel();
        String trackingId = getCrcSharedViewModel().getReactNativeData().getVerifyFingerprintResponse().getTrackingId();
        if (trackingId == null) {
            trackingId = "";
        }
        crcSharedViewModel.setTrackingId(trackingId);
        getBinding().verifyApplicantFingerprintButtonLayout.getRoot().setVisibility(8);
        getBinding().applicantDetailLayout.setVisibility(0);
        getBinding().startApplicationButtonLayout.getRoot().setVisibility(0);
        Util util = Util.INSTANCE;
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            cRCActivity = null;
        }
        TextInputLayout maskedCnicTextInputLayout = getBinding().applicantCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        TextInputEditText maskedCnicEditText = getBinding().applicantCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        util.disableTextInputEditText((Context) cRCActivity, maskedCnicTextInputLayout, maskedCnicEditText, true);
    }
}