package pk.gov.nadra.oneapp.crc.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableString;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.farrakhj.stringpickerlibrary.views.StringPickerActivity;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.adapter.ActionType;
import pk.gov.nadra.oneapp.crc.adapter.MinorListAdapter;
import pk.gov.nadra.oneapp.crc.adapter.viewmodel.CRCSharedViewModel;
import pk.gov.nadra.oneapp.crc.databinding.MinorListFragmentBinding;
import pk.gov.nadra.oneapp.crc.fragments.MinorListFragment;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.SaveMinorDetailsRequest;
import pk.gov.nadra.oneapp.models.crc.SaveMinorDetailsResponse;
import pk.gov.nadra.oneapp.models.crc.certificateType.CertificateTypeResponse;
import pk.gov.nadra.oneapp.models.crc.minor.ChildDataResponse;
import pk.gov.nadra.oneapp.models.crc.minor.MinorDataResponse;
import pk.gov.nadra.oneapp.models.crc.newChildDetails.NewChildDetailsRequest;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: MinorListFragment.kt */
@Metadata(d1 = {"\u0000¸\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0016\u0010'\u001a\u00020(2\f\u0010)\u001a\b\u0012\u0004\u0012\u00020*0\u001dH\u0002J\u0010\u0010+\u001a\u00020(2\u0006\u0010,\u001a\u00020-H\u0016J$\u0010.\u001a\u00020/2\u0006\u00100\u001a\u0002012\b\u00102\u001a\u0004\u0018\u0001032\b\u00104\u001a\u0004\u0018\u000105H\u0016J\u001a\u00106\u001a\u00020(2\u0006\u00107\u001a\u00020/2\b\u00104\u001a\u0004\u0018\u000105H\u0016J\b\u00108\u001a\u00020(H\u0002J\u0010\u00109\u001a\u00020(2\u0006\u0010:\u001a\u00020;H\u0002J\b\u0010<\u001a\u00020(H\u0002J\b\u0010=\u001a\u00020>H\u0002J\u0010\u0010?\u001a\u00020(2\u0006\u0010@\u001a\u00020\"H\u0002J\b\u0010A\u001a\u00020(H\u0002J\b\u0010B\u001a\u00020CH\u0002J\b\u0010D\u001a\u00020(H\u0002J\u0018\u0010E\u001a\u00020(2\u0006\u0010@\u001a\u00020\"2\u0006\u0010F\u001a\u00020\"H\u0002J\u0018\u0010G\u001a\u00020(2\u0006\u0010H\u001a\u00020\u00172\u0006\u0010@\u001a\u00020\"H\u0002J\u0010\u0010I\u001a\u00020(2\u0006\u0010:\u001a\u00020JH\u0002J\u0010\u0010K\u001a\u00020(2\u0006\u0010:\u001a\u00020;H\u0002J\u0010\u0010L\u001a\u00020(2\u0006\u0010:\u001a\u00020;H\u0002J\u0010\u0010M\u001a\u00020(2\u0006\u0010:\u001a\u00020;H\u0002J\u0018\u0010N\u001a\u00020(2\u0006\u0010:\u001a\u00020;2\u0006\u0010H\u001a\u00020\u0017H\u0002J\u0018\u0010O\u001a\u00020(2\u0006\u0010P\u001a\u00020;2\u0006\u0010Q\u001a\u00020RH\u0002J\u0018\u0010S\u001a\u00020(2\u0006\u0010P\u001a\u00020J2\u0006\u0010Q\u001a\u00020RH\u0002J%\u0010T\u001a\u00020(2\u0016\u0010U\u001a\u0012\u0012\u0004\u0012\u00020\"0\u0018j\b\u0012\u0004\u0012\u00020\"`\u0016H\u0002¢\u0006\u0002\u0010VJ\b\u0010[\u001a\u00020(H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R \u0010\u0015\u001a\u0012\u0012\u0004\u0012\u00020\u00170\u0018j\b\u0012\u0004\u0012\u00020\u0017`\u0016X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u0019R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082.¢\u0006\u0002\n\u0000R\u0014\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R'\u0010 \u001a\u000e\u0012\u0004\u0012\u00020\"\u0012\u0004\u0012\u00020#0!8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b&\u0010\t\u001a\u0004\b$\u0010%R\u001c\u0010W\u001a\u0010\u0012\f\u0012\n Z*\u0004\u0018\u00010Y0Y0XX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\\"}, d2 = {"Lpk/gov/nadra/oneapp/crc/fragments/MinorListFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/crc/databinding/MinorListFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/MinorListFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/crc/views/CRCActivity;)V", "minorList", "Lkotlin/collections/ArrayList;", "Lpk/gov/nadra/oneapp/models/crc/minor/MinorDataResponse;", "Ljava/util/ArrayList;", "Ljava/util/ArrayList;", "minorListAdapter", "Lpk/gov/nadra/oneapp/crc/adapter/MinorListAdapter;", "certificateTypeList", "", "Lpk/gov/nadra/oneapp/models/crc/certificateType/CertificateTypeResponse;", "selectedValueObject", "fieldToViewMap", "", "", "Lcom/google/android/material/textfield/TextInputLayout;", "getFieldToViewMap", "()Ljava/util/Map;", "fieldToViewMap$delegate", "displayErrors", "", "errors", "Lpk/gov/nadra/oneapp/models/crc/ErrorResponse$Error;", "onAttach", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "submitMinorDetails", "processSaveMinorDetailSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "handleFragmentNavigationLogic", "validateViews", "", "getMinorDataList", "trackingId", "getBirthCertificateType", "getNewChildDetailsRequest", "Lpk/gov/nadra/oneapp/models/crc/newChildDetails/NewChildDetailsRequest;", "getNewChildDetails", "getChildDetails", "childId", "deleteChildFromMinorList", "minorDataResponse", "processBirthCertificateTypeSuccessResponse", "Lcom/google/gson/JsonArray;", "processMinorDataListSuccessResponse", "processNewChildDetailsSuccessResponse", "processChildDetailsSuccessResponse", "processDeleteChildSuccessResponse", "handleFailureCase", "jsonResponse", "responseCode", "", "handleFailureCaseJsonArray", "launchStringPickerActivity", "arrayList", "(Ljava/util/ArrayList;)V", "startForResult", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "initFooterView", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class MinorListFragment extends Fragment {
    private MinorListFragmentBinding _binding;
    public CRCActivity activity;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;
    private MinorListAdapter minorListAdapter;
    private final ActivityResultLauncher<Intent> startForResult;
    private ArrayList<MinorDataResponse> minorList = new ArrayList<>();
    private List<CertificateTypeResponse> certificateTypeList = new ArrayList();
    private CertificateTypeResponse selectedValueObject = new CertificateTypeResponse(null, null, 3, null);

    /* renamed from: fieldToViewMap$delegate, reason: from kotlin metadata */
    private final Lazy fieldToViewMap = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return MinorListFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
        }
    });

    /* compiled from: MinorListFragment.kt */
    @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[ActionType.values().length];
            try {
                iArr[ActionType.EDIT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[ActionType.CANCEL.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public MinorListFragment() {
        final MinorListFragment minorListFragment = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(minorListFragment, Reflection.getOrCreateKotlinClass(CRCSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = minorListFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = minorListFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = minorListFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda4
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                MinorListFragment.startForResult$lambda$31(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.startForResult = activityResultLauncherRegisterForActivityResult;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final CRCSharedViewModel getCrcSharedViewModel() {
        return (CRCSharedViewModel) this.crcSharedViewModel.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final MinorListFragmentBinding getBinding() {
        MinorListFragmentBinding minorListFragmentBinding = this._binding;
        Intrinsics.checkNotNull(minorListFragmentBinding);
        return minorListFragmentBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final CRCActivity getActivity() {
        CRCActivity cRCActivity = this.activity;
        if (cRCActivity != null) {
            return cRCActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(CRCActivity cRCActivity) {
        Intrinsics.checkNotNullParameter(cRCActivity, "<set-?>");
        this.activity = cRCActivity;
    }

    private final Map<String, TextInputLayout> getFieldToViewMap() {
        return (Map) this.fieldToViewMap.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Map fieldToViewMap_delegate$lambda$0(MinorListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        return MapsKt.mapOf(TuplesKt.to("birthCertificateNumber", this$0.getBinding().certificateNumberLayout.textInputLayout), TuplesKt.to("birthCertificateType", this$0.getBinding().certificateTypeLayout.textInputLayout));
    }

    private final void displayErrors(List<ErrorResponse.Error> errors) {
        List<ErrorResponse.Error> list = errors;
        if (list == null || list.isEmpty()) {
            return;
        }
        for (ErrorResponse.Error error : errors) {
            TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
            if (textInputLayout != null) {
                textInputLayout.setError(String.valueOf(error.getMessage()));
                textInputLayout.setErrorEnabled(true);
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.crc.views.CRCActivity");
        setActivity((CRCActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = MinorListFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        final MinorListFragmentBinding binding = getBinding();
        TextView textView = binding.crcHeaderLayout.textTitle;
        String upperCase = getCrcSharedViewModel().getDocumentTypeValue().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(String.valueOf(upperCase));
        binding.crcHeaderLayout.textSubtitle.setText(String.valueOf(getCrcSharedViewModel().getApplicationTypeValue()));
        binding.crcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.roboto_medium));
        binding.crcHeaderLayout.iconHome.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                MinorListFragment.onViewCreated$lambda$13$lambda$3(this.f$0, view2);
            }
        });
        binding.crcHeaderLayout.iconInfo.setVisibility(0);
        binding.crcHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                MinorListFragment.onViewCreated$lambda$13$lambda$4(this.f$0, view2);
            }
        });
        binding.crcHeaderLayout.tvHeaderTrackingId.setText(getCrcSharedViewModel().getTrackingId());
        binding.crcHeaderLayout.tvHeaderFee.setText(String.valueOf(getCrcSharedViewModel().getAmount()));
        binding.crcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                MinorListFragment.onViewCreated$lambda$13$lambda$5(this.f$0, view2);
            }
        });
        binding.stepTitleHeadingLayout.tvStepTitleHeading.setText("Minor List");
        binding.stepTitleHeadingLayout.tvStepTitleHeadingUrdu.setText("بچوں کی فہرست");
        TextInputLayout textInputLayout = binding.certificateNumberLayout.textInputLayout;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.birth_certificate_number);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textInputLayout.setHint(Util.setEnglishTextSpan$default(util, activity, string, " (پیدائشی سرٹیفیکیٹ نمبر) ", 0, true, 4, null));
        binding.certificateNumberLayout.textInputEditText.setSingleLine();
        binding.certificateNumberLayout.textInputEditText.setImeOptions(6);
        Util util2 = Util.INSTANCE;
        CRCActivity activity2 = getActivity();
        TextInputEditText textInputEditText = binding.certificateNumberLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        TextInputLayout textInputLayout2 = binding.certificateNumberLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        util2.removeErrorOnTextChanged(activity2, textInputEditText, textInputLayout2);
        AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding = getBinding().certificateTypeLayout;
        TextInputLayout textInputLayout3 = autocompletetextviewLayoutBinding.textInputLayout;
        Util util3 = Util.INSTANCE;
        CRCActivity activity3 = getActivity();
        String string2 = getString(R.string.certificate_type);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textInputLayout3.setHint(Util.setEnglishTextSpan$default(util3, activity3, string2, " (سرٹیفیکیٹ کی نوعیت) ", 0, true, 4, null));
        Util util4 = Util.INSTANCE;
        CRCActivity activity4 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView = autocompletetextviewLayoutBinding.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        TextInputLayout textInputLayout4 = autocompletetextviewLayoutBinding.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout4, "textInputLayout");
        util4.removeErrorOnAutoCompleteTextChanged(activity4, autoCompleteTextView, textInputLayout4);
        autocompletetextviewLayoutBinding.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                MinorListFragment.onViewCreated$lambda$13$lambda$7$lambda$6(this.f$0, view2);
            }
        });
        binding.addChildButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Add New Child", "\n(نیا بچہ شامل کریں)", 0, false, 12, null));
        binding.addChildButtonLayout.commonButton.setFilled(false);
        binding.addChildButtonLayout.commonButton.setInsetTop(0);
        binding.addChildButtonLayout.commonButton.setInsetBottom(0);
        binding.addChildButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                MinorListFragment.onViewCreated$lambda$13$lambda$8(this.f$0, view2);
            }
        });
        binding.minorsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.minorListAdapter = new MinorListAdapter(getActivity(), this.minorList, new Function2() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return MinorListFragment.onViewCreated$lambda$13$lambda$10(this.f$0, (ActionType) obj, (MinorDataResponse) obj2);
            }
        });
        RecyclerView recyclerView = binding.minorsRecyclerView;
        MinorListAdapter minorListAdapter = this.minorListAdapter;
        if (minorListAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("minorListAdapter");
            minorListAdapter = null;
        }
        recyclerView.setAdapter(minorListAdapter);
        binding.minorsSwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda15
            @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
            public final void onRefresh() {
                MinorListFragment.onViewCreated$lambda$13$lambda$11(this.f$0, binding);
            }
        });
        binding.minorsListTryAgainLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                MinorListFragment.onViewCreated$lambda$13$lambda$12(this.f$0, view2);
            }
        });
        initFooterView();
        getMinorDataList(getCrcSharedViewModel().getTrackingId());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$13$lambda$3(MinorListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$13$lambda$4(MinorListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        CRCActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.crc_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.CRC_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$13$lambda$5(MinorListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$13$lambda$7$lambda$6(MinorListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getBirthCertificateType();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$13$lambda$8(MinorListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getCrcSharedViewModel().setErrorResponse(new ErrorResponse(null, null, null, null, null, null, null, null, null, null, null, null, null, null, 16383, null));
        if (this$0.validateViews()) {
            this$0.getNewChildDetails();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$13$lambda$10(final MinorListFragment this$0, ActionType actionType, final MinorDataResponse minor) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(actionType, "actionType");
        Intrinsics.checkNotNullParameter(minor, "minor");
        int i = WhenMappings.$EnumSwitchMapping$0[actionType.ordinal()];
        if (i == 1) {
            this$0.getCrcSharedViewModel().setChildPhotoPath("");
            this$0.getChildDetails(this$0.getCrcSharedViewModel().getTrackingId(), String.valueOf(minor.getChildId()));
            this$0.getCrcSharedViewModel().setErrorResponse(new ErrorResponse(null, null, null, null, null, null, null, null, null, null, null, null, null, null, 16383, null));
        } else {
            if (i != 2) {
                throw new NoWhenBranchMatchedException();
            }
            BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
            CRCActivity activity = this$0.getActivity();
            String string = this$0.getString(R.string.delete_child_confirm);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            SpannableString englishTextSpan$default = Util.setEnglishTextSpan$default(Util.INSTANCE, this$0.getActivity(), "Delete", " (حذف کریں)", 0, false, 12, null);
            String string2 = this$0.getString(R.string.delete_child_confirm_urdu);
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Delete Child", string, true, (CharSequence) englishTextSpan$default, true, string2, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return MinorListFragment.onViewCreated$lambda$13$lambda$10$lambda$9(this.f$0, minor);
                }
            }, (Function0) null, 256, (Object) null);
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$13$lambda$10$lambda$9(MinorListFragment this$0, MinorDataResponse minor) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(minor, "$minor");
        this$0.deleteChildFromMinorList(minor, this$0.getCrcSharedViewModel().getTrackingId());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$13$lambda$11(MinorListFragment this$0, MinorListFragmentBinding this_apply) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        this$0.getMinorDataList(this$0.getCrcSharedViewModel().getTrackingId());
        this_apply.minorsSwipeRefresh.setRefreshing(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$13$lambda$12(MinorListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getMinorDataList(this$0.getCrcSharedViewModel().getTrackingId());
    }

    /* compiled from: MinorListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$submitMinorDetails$1", f = "MinorListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$submitMinorDetails$1, reason: invalid class name and case insensitive filesystem */
    static final class C12371 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12371(Continuation<? super C12371> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MinorListFragment.this.new C12371(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12371) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(MinorListFragment.this.getActivity());
            SaveMinorDetailsRequest saveMinorDetailsRequest = new SaveMinorDetailsRequest(MinorListFragment.this.getCrcSharedViewModel().getTrackingId());
            final MinorListFragment minorListFragment = MinorListFragment.this;
            aPIRequests.saveMinorDetails(saveMinorDetailsRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$submitMinorDetails$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return MinorListFragment.C12371.invokeSuspend$lambda$0(minorListFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(MinorListFragment minorListFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(minorListFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getMinorDataList() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                minorListFragment.processSaveMinorDetailSuccessResponse(jsonObject);
            } else {
                minorListFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void submitMinorDetails() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12371(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processSaveMinorDetailSuccessResponse(JsonObject jSonObject) {
        SaveMinorDetailsResponse saveMinorDetailsResponse = (SaveMinorDetailsResponse) new Gson().fromJson(jSonObject.toString(), SaveMinorDetailsResponse.class);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("processMinorDataRes", saveMinorDetailsResponse.toString());
        }
        handleFragmentNavigationLogic();
    }

    private final void handleFragmentNavigationLogic() {
        if (getCrcSharedViewModel().getAttestationP()) {
            getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.spouseListFragment);
        } else if (getCrcSharedViewModel().getUploadDocumentP()) {
            getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.supportingDocumentsFragment);
        } else {
            getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.reviewFragment);
        }
    }

    private final boolean validateViews() {
        boolean z;
        MinorListFragmentBinding binding = getBinding();
        String strValueOf = String.valueOf(binding.certificateNumberLayout.textInputEditText.getText());
        if (strValueOf == null || strValueOf.length() == 0) {
            binding.certificateNumberLayout.textInputLayout.setError("Enter " + getString(R.string.birth_certificate_number));
            binding.certificateNumberLayout.textInputLayout.setErrorEnabled(true);
            z = false;
        } else {
            z = true;
        }
        String string = binding.certificateTypeLayout.autoCompleteTextView.getText().toString();
        if (string != null && string.length() != 0) {
            return z;
        }
        binding.certificateTypeLayout.textInputLayout.setError("Select " + getString(R.string.certificate_type));
        binding.certificateTypeLayout.textInputLayout.setErrorEnabled(true);
        return false;
    }

    private final void getMinorDataList(String trackingId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        getBinding().minorsListTryAgainLayout.setVisibility(8);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12351(trackingId, null), 3, null);
    }

    /* compiled from: MinorListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getMinorDataList$1", f = "MinorListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getMinorDataList$1, reason: invalid class name and case insensitive filesystem */
    static final class C12351 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12351(String str, Continuation<? super C12351> continuation) {
            super(2, continuation);
            this.$trackingId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MinorListFragment.this.new C12351(this.$trackingId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12351) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(MinorListFragment.this.getActivity());
            String str = this.$trackingId;
            final MinorListFragment minorListFragment = MinorListFragment.this;
            aPIRequests.minorDataList(str, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getMinorDataList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return MinorListFragment.C12351.invokeSuspend$lambda$0(minorListFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(MinorListFragment minorListFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(minorListFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getMinorDataList() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                minorListFragment.processMinorDataListSuccessResponse(jsonObject);
            } else {
                minorListFragment.getBinding().minorsListTryAgainLayout.setVisibility(0);
                minorListFragment.getBinding().crcFooterLayout.getRoot().setVisibility(8);
                minorListFragment.getBinding().minorListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_try_again);
                minorListFragment.getBinding().minorsListTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, minorListFragment.getActivity(), "Try Again", "\nدوبارہ کوشش کریں", 0, false, 12, null));
                minorListFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getBirthCertificateType() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12331(null), 3, null);
    }

    /* compiled from: MinorListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getBirthCertificateType$1", f = "MinorListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getBirthCertificateType$1, reason: invalid class name and case insensitive filesystem */
    static final class C12331 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12331(Continuation<? super C12331> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MinorListFragment.this.new C12331(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12331) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(MinorListFragment.this.getActivity());
            final MinorListFragment minorListFragment = MinorListFragment.this;
            aPIRequests.birthCertificateType(new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getBirthCertificateType$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return MinorListFragment.C12331.invokeSuspend$lambda$0(minorListFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(MinorListFragment minorListFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(minorListFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getBirthCertificateType() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                minorListFragment.processBirthCertificateTypeSuccessResponse(jsonArray);
            } else {
                minorListFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final NewChildDetailsRequest getNewChildDetailsRequest() {
        NewChildDetailsRequest newChildDetailsRequest = new NewChildDetailsRequest(null, null, null, 7, null);
        String upperCase = StringsKt.trim((CharSequence) String.valueOf(getBinding().certificateNumberLayout.textInputEditText.getText())).toString().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        newChildDetailsRequest.setBirthCertificateNumber(upperCase);
        Editable text = getBinding().certificateTypeLayout.autoCompleteTextView.getText();
        Intrinsics.checkNotNullExpressionValue(text, "getText(...)");
        String upperCase2 = StringsKt.trim(text).toString().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
        newChildDetailsRequest.setCertificateType(upperCase2);
        newChildDetailsRequest.setTrackingId(getCrcSharedViewModel().getTrackingId());
        return newChildDetailsRequest;
    }

    private final void getNewChildDetails() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12361(null), 3, null);
    }

    /* compiled from: MinorListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getNewChildDetails$1", f = "MinorListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getNewChildDetails$1, reason: invalid class name and case insensitive filesystem */
    static final class C12361 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C12361(Continuation<? super C12361> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MinorListFragment.this.new C12361(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12361) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(MinorListFragment.this.getActivity());
            NewChildDetailsRequest newChildDetailsRequest = MinorListFragment.this.getNewChildDetailsRequest();
            final MinorListFragment minorListFragment = MinorListFragment.this;
            aPIRequests.newChildDetails(newChildDetailsRequest, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getNewChildDetails$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return MinorListFragment.C12361.invokeSuspend$lambda$0(minorListFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(MinorListFragment minorListFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(minorListFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getNewChildDetails() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                minorListFragment.processNewChildDetailsSuccessResponse(jsonObject);
            } else {
                minorListFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getChildDetails(String trackingId, String childId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12341(trackingId, childId, null), 3, null);
    }

    /* compiled from: MinorListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getChildDetails$1", f = "MinorListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getChildDetails$1, reason: invalid class name and case insensitive filesystem */
    static final class C12341 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $childId;
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12341(String str, String str2, Continuation<? super C12341> continuation) {
            super(2, continuation);
            this.$trackingId = str;
            this.$childId = str2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MinorListFragment.this.new C12341(this.$trackingId, this.$childId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12341) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(MinorListFragment.this.getActivity());
            String str = this.$trackingId;
            String str2 = this.$childId;
            final MinorListFragment minorListFragment = MinorListFragment.this;
            aPIRequests.getChildDetails(str, str2, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$getChildDetails$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return MinorListFragment.C12341.invokeSuspend$lambda$0(minorListFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(MinorListFragment minorListFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(minorListFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getChildDetails() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                minorListFragment.processChildDetailsSuccessResponse(jsonObject);
            } else {
                minorListFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void deleteChildFromMinorList(MinorDataResponse minorDataResponse, String trackingId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(trackingId, minorDataResponse, null), 3, null);
    }

    /* compiled from: MinorListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$deleteChildFromMinorList$1", f = "MinorListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$deleteChildFromMinorList$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ MinorDataResponse $minorDataResponse;
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, MinorDataResponse minorDataResponse, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$trackingId = str;
            this.$minorDataResponse = minorDataResponse;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MinorListFragment.this.new AnonymousClass1(this.$trackingId, this.$minorDataResponse, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(MinorListFragment.this.getActivity());
            String str = this.$trackingId;
            String strValueOf = String.valueOf(this.$minorDataResponse.getChildId());
            final MinorListFragment minorListFragment = MinorListFragment.this;
            final MinorDataResponse minorDataResponse = this.$minorDataResponse;
            aPIRequests.deleteChildFromMinorList(str, strValueOf, new Function3() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$deleteChildFromMinorList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return MinorListFragment.AnonymousClass1.invokeSuspend$lambda$0(minorListFragment, minorDataResponse, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(MinorListFragment minorListFragment, MinorDataResponse minorDataResponse, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(minorListFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getNewChildDetails() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                minorListFragment.processDeleteChildSuccessResponse(jsonObject, minorDataResponse);
            } else {
                minorListFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processBirthCertificateTypeSuccessResponse(JsonArray jSonObject) throws JsonSyntaxException {
        Object objFromJson = new Gson().fromJson(jSonObject.toString(), (Class<Object>) CertificateTypeResponse[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List list = ArraysKt.toList((Object[]) objFromJson);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("processBirthCertRes", list.toString());
        }
        this.certificateTypeList = new ArrayList();
        Intrinsics.checkNotNull(list, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.certificateType.CertificateTypeResponse>");
        ArrayList arrayList = (ArrayList) list;
        this.certificateTypeList = arrayList;
        if (arrayList.isEmpty()) {
            return;
        }
        List<CertificateTypeResponse> list2 = this.certificateTypeList;
        ArrayList arrayList2 = new ArrayList();
        for (Object obj : list2) {
            String lowerCase = ((CertificateTypeResponse) obj).getKey().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (!Intrinsics.areEqual(lowerCase, "other")) {
                arrayList2.add(obj);
            }
        }
        ArrayList arrayList3 = arrayList2;
        ArrayList arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList3, 10));
        Iterator it = arrayList3.iterator();
        while (it.hasNext()) {
            arrayList4.add(((CertificateTypeResponse) it.next()).getKey());
        }
        launchStringPickerActivity(arrayList4);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processMinorDataListSuccessResponse(JsonObject jSonObject) {
        ChildDataResponse childDataResponse = (ChildDataResponse) new Gson().fromJson(jSonObject.toString(), ChildDataResponse.class);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("processMinorDataRes", childDataResponse.toString());
        }
        List<MinorDataResponse> minorDataResponse = childDataResponse.getMinorDataResponse();
        Intrinsics.checkNotNull(minorDataResponse, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.minor.MinorDataResponse>");
        this.minorList = (ArrayList) minorDataResponse;
        CRCSharedViewModel crcSharedViewModel = getCrcSharedViewModel();
        StringBuilder sb = new StringBuilder();
        String upperCase = childDataResponse.getPaymentResponse().getCurrency().getKey().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        crcSharedViewModel.setAmount(sb.append(upperCase).append(' ').append(childDataResponse.getPaymentResponse().getPaymentAmount()).toString());
        getBinding().crcHeaderLayout.tvHeaderTrackingId.setText(childDataResponse.getTrackingId());
        TextView textView = getBinding().crcHeaderLayout.tvHeaderFee;
        StringBuilder sb2 = new StringBuilder();
        String upperCase2 = childDataResponse.getPaymentResponse().getCurrency().getKey().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
        textView.setText(sb2.append(upperCase2).append(' ').append(childDataResponse.getPaymentResponse().getPaymentAmount()).toString());
        if (!this.minorList.isEmpty()) {
            getBinding().crcFooterLayout.getRoot().setVisibility(0);
            MinorListAdapter minorListAdapter = this.minorListAdapter;
            if (minorListAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("minorListAdapter");
                minorListAdapter = null;
            }
            minorListAdapter.updateMinorList(this.minorList);
            return;
        }
        getBinding().crcFooterLayout.getRoot().setVisibility(8);
        getBinding().minorsListTryAgainLayout.setVisibility(0);
        getBinding().minorListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_documents);
        getBinding().minorsListTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "No Registered Child data exists", "\nکوئی بھی رجسڑڈ بچہ نہیں ہے", 0, false, 12, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processNewChildDetailsSuccessResponse(JsonObject jSonObject) {
        MinorDataResponse minorDataResponse = (MinorDataResponse) new Gson().fromJson(jSonObject.toString(), MinorDataResponse.class);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("processNewChildRes", minorDataResponse.toString());
        }
        getCrcSharedViewModel().setChildDetails(minorDataResponse);
        getCrcSharedViewModel().getChildDetails().setBirthCertificateNumber(String.valueOf(getBinding().certificateNumberLayout.textInputEditText.getText()));
        getCrcSharedViewModel().getChildDetails().getCertificateType().setKey(this.selectedValueObject.getKey());
        getCrcSharedViewModel().getChildDetails().getCertificateType().setValue(this.selectedValueObject.getValue());
        getCrcSharedViewModel().getChildDetails().getMeta().getCertificateType().setDisable(true);
        getCrcSharedViewModel().getChildDetails().getMeta().getBirthCertificateNumber().setDisable(true);
        getCrcSharedViewModel().getChildDetails().getMeta().getName().setDisable(true);
        getCrcSharedViewModel().getChildDetails().getMeta().getNameLocal().setDisable(true);
        getCrcSharedViewModel().setChildPhotoPath("");
        getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.childDetailFragment);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processChildDetailsSuccessResponse(JsonObject jSonObject) {
        MinorDataResponse minorDataResponse = (MinorDataResponse) new Gson().fromJson(jSonObject.toString(), MinorDataResponse.class);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("processNewChildRes", minorDataResponse.toString());
        }
        getCrcSharedViewModel().setChildDetails(minorDataResponse);
        getActivity().navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.childDetailFragment);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processDeleteChildSuccessResponse(JsonObject jSonObject, MinorDataResponse minorDataResponse) {
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("processDelChildRes", jSonObject.toString());
        }
        this.minorList.remove(minorDataResponse);
        MinorListAdapter minorListAdapter = this.minorListAdapter;
        if (minorListAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("minorListAdapter");
            minorListAdapter = null;
        }
        minorListAdapter.updateMinorList(this.minorList);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                if (errorResponse.getErrors() != null) {
                    List<ErrorResponse.Error> errors = errorResponse.getErrors();
                    Intrinsics.checkNotNull(errors);
                    List<ErrorResponse.Error> list = errors;
                    if ((list instanceof Collection) && list.isEmpty()) {
                        return;
                    }
                    for (ErrorResponse.Error error : list) {
                        if (Intrinsics.areEqual(error.getField(), "birthCertificateNumber") || Intrinsics.areEqual(error.getField(), "birthCertificateType")) {
                            List<ErrorResponse.Error> errors2 = errorResponse.getErrors();
                            Intrinsics.checkNotNull(errors2);
                            displayErrors(errors2);
                            return;
                        }
                    }
                    return;
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            CRCActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return MinorListFragment.handleFailureCase$lambda$23(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return MinorListFragment.handleFailureCase$lambda$24(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$23(MinorListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$24(MinorListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCaseJsonArray(JsonArray jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson((JsonElement) jsonResponse.get(0).getAsJsonObject(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    for (ErrorResponse.Error error : errors) {
                        TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                        if (textInputLayout != null) {
                            textInputLayout.setError(String.valueOf(error.getMessage()));
                            textInputLayout.setErrorEnabled(true);
                        }
                    }
                    return;
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            CRCActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return MinorListFragment.handleFailureCaseJsonArray$lambda$28(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        CRCActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return MinorListFragment.handleFailureCaseJsonArray$lambda$29(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$28(MinorListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$29(MinorListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final void launchStringPickerActivity(ArrayList<String> arrayList) {
        Intent intent = new Intent(getActivity(), (Class<?>) StringPickerActivity.class);
        intent.putStringArrayListExtra("INTENT_STRING_LIST", arrayList);
        this.startForResult.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startForResult$lambda$31(MinorListFragment this$0, ActivityResult result) {
        Intent data;
        String stringExtra;
        Object next;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || (data = result.getData()) == null || !data.hasExtra("INTENT_STRING_ITEM") || (stringExtra = data.getStringExtra("INTENT_STRING_ITEM")) == null) {
            return;
        }
        String str = stringExtra;
        this$0.getBinding().certificateTypeLayout.autoCompleteTextView.setText(str);
        Iterator<T> it = this$0.certificateTypeList.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (((CertificateTypeResponse) next).getKey().contentEquals(str)) {
                    break;
                }
            }
        }
        Intrinsics.checkNotNull(next);
        this$0.selectedValueObject = (CertificateTypeResponse) next;
    }

    private final void initFooterView() {
        MinorListFragmentBinding binding = getBinding();
        binding.crcFooterLayout.backButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MinorListFragment.initFooterView$lambda$34$lambda$32(this.f$0, view);
            }
        });
        binding.crcFooterLayout.backButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Back", "\n(واپس جائیں)", 0, false, 12, null));
        MaterialButton materialButton = binding.crcFooterLayout.nextButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        CRCActivity activity = getActivity();
        String string = getString(R.string.next);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        materialButton.setText(Util.setEnglishTextSpan$default(util, activity, string, "\n(آگے بڑھیں)", 0, false, 12, null));
        binding.crcFooterLayout.nextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.fragments.MinorListFragment$$ExternalSyntheticLambda8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MinorListFragment.initFooterView$lambda$34$lambda$33(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$34$lambda$32(MinorListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initFooterView$lambda$34$lambda$33(MinorListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.submitMinorDetails();
    }
}