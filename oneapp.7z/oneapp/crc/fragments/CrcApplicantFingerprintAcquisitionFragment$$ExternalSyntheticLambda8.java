package pk.gov.nadra.oneapp.crc.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import com.google.gson.JsonSyntaxException;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda8 implements ActivityResultCallback {
    public /* synthetic */ CrcApplicantFingerprintAcquisitionFragment$$ExternalSyntheticLambda8() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) throws JsonSyntaxException {
        CrcApplicantFingerprintAcquisitionFragment.fingerprintLauncher$lambda$5(this.f$0, (ActivityResult) obj);
    }
}