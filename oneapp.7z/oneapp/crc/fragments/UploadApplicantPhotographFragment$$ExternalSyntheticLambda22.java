package pk.gov.nadra.oneapp.crc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class UploadApplicantPhotographFragment$$ExternalSyntheticLambda22 implements Function0 {
    public /* synthetic */ UploadApplicantPhotographFragment$$ExternalSyntheticLambda22() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return UploadApplicantPhotographFragment.handleFailureCaseJsonArray$lambda$25(this.f$0);
    }
}