package pk.gov.nadra.oneapp.crc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class SupportingDocumentsFragment$$ExternalSyntheticLambda11 implements View.OnClickListener {
    public /* synthetic */ SupportingDocumentsFragment$$ExternalSyntheticLambda11() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        SupportingDocumentsFragment.onViewCreated$lambda$11$lambda$0(this.f$0, view);
    }
}