package pk.gov.nadra.oneapp.crc.views;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CRCActivity$$ExternalSyntheticLambda5 implements Function0 {
    public /* synthetic */ CRCActivity$$ExternalSyntheticLambda5() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return CRCActivity.handleHomeIconClick$lambda$18(this.f$0);
    }
}