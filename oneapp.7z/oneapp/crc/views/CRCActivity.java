package pk.gov.nadra.oneapp.crc.views;

import android.R;
import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.util.Log;
import android.view.View;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcherKt;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.fragment.NavHostFragment;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Permissions;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crc.adapter.viewmodel.CRCSharedViewModel;
import pk.gov.nadra.oneapp.crc.databinding.CrcActivityBinding;
import pk.gov.nadra.oneapp.crc.fragments.SignatureAcquisitionFragment;
import pk.gov.nadra.oneapp.crc.fragments.UploadApplicantPhotographFragment;
import pk.gov.nadra.oneapp.crc.fragments.UploadPhotographFragment;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.models.crc.CrcTabsResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.models.crc.minor.ApplicationStatus;
import pk.gov.nadra.oneapp.models.crc.minor.ChildDataResponse;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: CRCActivity.kt */
@Metadata(d1 = {"\u0000\u0082\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0011\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u00104\u001a\u0002052\b\u00106\u001a\u0004\u0018\u000107H\u0014J\b\u00108\u001a\u000205H\u0002J\b\u00109\u001a\u000205H\u0002J\u000e\u0010:\u001a\u0002052\u0006\u0010;\u001a\u00020<J\u0006\u0010=\u001a\u000205J\b\u0010>\u001a\u000205H\u0016J\b\u0010?\u001a\u000205H\u0002J\u0010\u0010@\u001a\u0002052\u0006\u0010\"\u001a\u00020#H\u0002J\"\u0010A\u001a\u0002052\u0006\u0010B\u001a\u00020<2\u0006\u0010C\u001a\u00020<2\b\u0010D\u001a\u0004\u0018\u00010EH\u0014J\b\u0010F\u001a\u000205H\u0002J\u0010\u0010G\u001a\u0002052\u0006\u00101\u001a\u00020#H\u0002J\u0010\u0010H\u001a\u0002052\u0006\u0010I\u001a\u00020JH\u0002J\u0018\u0010K\u001a\u0002052\u0006\u0010L\u001a\u00020J2\u0006\u0010M\u001a\u00020<H\u0002J\u0010\u0010N\u001a\u0002052\u0006\u0010O\u001a\u00020PH\u0002J\u000e\u0010Q\u001a\u0002052\u0006\u0010R\u001a\u00020#J\b\u0010S\u001a\u000205H\u0014J\u0006\u0010T\u001a\u000205J\u0010\u0010U\u001a\u0002052\u0006\u00101\u001a\u00020#H\u0002J\u0010\u0010V\u001a\u0002052\u0006\u0010I\u001a\u00020WH\u0002J\u0018\u0010X\u001a\u0002052\u0006\u0010L\u001a\u00020W2\u0006\u0010M\u001a\u00020<H\u0002J\u0014\u0010Y\u001a\u00020Z2\f\u0010[\u001a\b\u0012\u0004\u0012\u00020]0\\R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001b\u0010\n\u001a\u00020\u000b8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\f\u0010\rR\u001a\u0010\u0010\u001a\u00020\u0011X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u001a\u0010\u0016\u001a\u00020\u0017X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001bR\u001a\u0010\u001c\u001a\u00020\u001dX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R\u001a\u0010\"\u001a\u00020#X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b$\u0010%\"\u0004\b&\u0010'R\u001a\u0010(\u001a\u00020#X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b)\u0010%\"\u0004\b*\u0010'R\u001a\u0010+\u001a\u00020#X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b,\u0010%\"\u0004\b-\u0010'R\u001a\u0010.\u001a\u00020#X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b/\u0010%\"\u0004\b0\u0010'R\u001c\u00101\u001a\u0004\u0018\u00010#X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b2\u0010%\"\u0004\b3\u0010'¨\u0006^"}, d2 = {"Lpk/gov/nadra/oneapp/crc/views/CRCActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "binding", "Lpk/gov/nadra/oneapp/crc/databinding/CrcActivityBinding;", "getBinding", "()Lpk/gov/nadra/oneapp/crc/databinding/CrcActivityBinding;", "setBinding", "(Lpk/gov/nadra/oneapp/crc/databinding/CrcActivityBinding;)V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/crc/adapter/viewmodel/CRCSharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "navController", "Landroidx/navigation/NavController;", "getNavController", "()Landroidx/navigation/NavController;", "setNavController", "(Landroidx/navigation/NavController;)V", "navHostFragment", "Landroidx/navigation/fragment/NavHostFragment;", "getNavHostFragment", "()Landroidx/navigation/fragment/NavHostFragment;", "setNavHostFragment", "(Landroidx/navigation/fragment/NavHostFragment;)V", "permissions", "Lpk/gov/nadra/oneapp/commonutils/utils/Permissions;", "getPermissions", "()Lpk/gov/nadra/oneapp/commonutils/utils/Permissions;", "setPermissions", "(Lpk/gov/nadra/oneapp/commonutils/utils/Permissions;)V", "callingFor", "", "getCallingFor", "()Ljava/lang/String;", "setCallingFor", "(Ljava/lang/String;)V", "CAMERA", "getCAMERA", "setCAMERA", "GALLERY", "getGALLERY", "setGALLERY", "fragmentName", "getFragmentName", "setFragmentName", "trackingId", "getTrackingId", "setTrackingId", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "initView", "getIntentData", "navigateToFragment", "resourceId", "", "popupFromNavHost", "onBackPressed", "initPermissions", "callPermissionSuccess", "onActivityResult", "requestCode", "resultCode", "data", "Landroid/content/Intent;", "fetchTabData", "getTrackingData", "processTrackingDataSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "handleFailureCase", "jsonResponse", "responseCode", "handleTabSequence", "applicationStatus", "Lpk/gov/nadra/oneapp/models/crc/minor/ApplicationStatus;", "navigateToReactNativeInbox", "responseToReactNative", "onDestroy", "handleHomeIconClick", "getCrcTabs", "processCrcTabsResponse", "Lcom/google/gson/JsonArray;", "handleFailureCaseJsonArray", "hasIdTwoAndFingerprints", "", "crcTabsList", "", "Lpk/gov/nadra/oneapp/models/crc/CrcTabsResponse;", "crc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class CRCActivity extends AppCompatActivity {
    public CrcActivityBinding binding;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;
    public NavController navController;
    public NavHostFragment navHostFragment;
    public Permissions permissions;
    private String trackingId;
    private String callingFor = "";
    private String CAMERA = "CAMERA";
    private String GALLERY = "GALLERY";
    private String fragmentName = "";

    public CRCActivity() {
        final CRCActivity cRCActivity = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = new ViewModelLazy(Reflection.getOrCreateKotlinClass(CRCSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$special$$inlined$viewModels$default$2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                return cRCActivity.getViewModelStore();
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$special$$inlined$viewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                return cRCActivity.getDefaultViewModelProviderFactory();
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$special$$inlined$viewModels$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                return (function02 == null || (creationExtras = (CreationExtras) function02.invoke()) == null) ? cRCActivity.getDefaultViewModelCreationExtras() : creationExtras;
            }
        });
    }

    public final CrcActivityBinding getBinding() {
        CrcActivityBinding crcActivityBinding = this.binding;
        if (crcActivityBinding != null) {
            return crcActivityBinding;
        }
        Intrinsics.throwUninitializedPropertyAccessException("binding");
        return null;
    }

    public final void setBinding(CrcActivityBinding crcActivityBinding) {
        Intrinsics.checkNotNullParameter(crcActivityBinding, "<set-?>");
        this.binding = crcActivityBinding;
    }

    private final CRCSharedViewModel getCrcSharedViewModel() {
        return (CRCSharedViewModel) this.crcSharedViewModel.getValue();
    }

    public final NavController getNavController() {
        NavController navController = this.navController;
        if (navController != null) {
            return navController;
        }
        Intrinsics.throwUninitializedPropertyAccessException("navController");
        return null;
    }

    public final void setNavController(NavController navController) {
        Intrinsics.checkNotNullParameter(navController, "<set-?>");
        this.navController = navController;
    }

    public final NavHostFragment getNavHostFragment() {
        NavHostFragment navHostFragment = this.navHostFragment;
        if (navHostFragment != null) {
            return navHostFragment;
        }
        Intrinsics.throwUninitializedPropertyAccessException("navHostFragment");
        return null;
    }

    public final void setNavHostFragment(NavHostFragment navHostFragment) {
        Intrinsics.checkNotNullParameter(navHostFragment, "<set-?>");
        this.navHostFragment = navHostFragment;
    }

    public final Permissions getPermissions() {
        Permissions permissions = this.permissions;
        if (permissions != null) {
            return permissions;
        }
        Intrinsics.throwUninitializedPropertyAccessException("permissions");
        return null;
    }

    public final void setPermissions(Permissions permissions) {
        Intrinsics.checkNotNullParameter(permissions, "<set-?>");
        this.permissions = permissions;
    }

    public final String getCallingFor() {
        return this.callingFor;
    }

    public final void setCallingFor(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.callingFor = str;
    }

    public final String getCAMERA() {
        return this.CAMERA;
    }

    public final void setCAMERA(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.CAMERA = str;
    }

    public final String getGALLERY() {
        return this.GALLERY;
    }

    public final void setGALLERY(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.GALLERY = str;
    }

    public final String getFragmentName() {
        return this.fragmentName;
    }

    public final void setFragmentName(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.fragmentName = str;
    }

    public final String getTrackingId() {
        return this.trackingId;
    }

    public final void setTrackingId(String str) {
        this.trackingId = str;
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setBinding(CrcActivityBinding.inflate(getLayoutInflater()));
        setContentView(getBinding().getRoot());
        CRCActivity cRCActivity = this;
        getWindow().setStatusBarColor(ContextCompat.getColor(cRCActivity, R.color.white));
        new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
        CrcActivityBinding binding = getBinding();
        binding.crcHeaderLayout.textTitle.setText("CRC");
        binding.crcHeaderLayout.textSubtitle.setText("New");
        binding.crcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(cRCActivity, pk.gov.nadra.oneapp.commonui.R.font.roboto_medium));
        binding.crcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                CRCActivity.onCreate$lambda$1$lambda$0(this.f$0, view);
            }
        });
        getIntentData();
        initPermissions();
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        Application application = getApplication();
        Intrinsics.checkNotNullExpressionValue(application, "getApplication(...)");
        loaderManager.initialize(application);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$1$lambda$0(CRCActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
    }

    private final void initView() {
        Fragment fragmentFindFragmentById = getSupportFragmentManager().findFragmentById(pk.gov.nadra.oneapp.crc.R.id.nav_host_fragment);
        Intrinsics.checkNotNull(fragmentFindFragmentById, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
        setNavHostFragment((NavHostFragment) fragmentFindFragmentById);
        setNavController(getNavHostFragment().getNavController());
        getNavController().setGraph(getNavController().getNavInflater().inflate(pk.gov.nadra.oneapp.crc.R.navigation.nav_graph));
        if (!LoaderManager.INSTANCE.isLoaderVisible()) {
            OnBackPressedDispatcherKt.addCallback$default(getOnBackPressedDispatcher(), this, false, new Function1() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return CRCActivity.initView$lambda$2(this.f$0, (OnBackPressedCallback) obj);
                }
            }, 2, null);
        }
        getBinding().crcHeaderLayout.iconBack.setClickable(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initView$lambda$2(CRCActivity this$0, OnBackPressedCallback addCallback) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(addCallback, "$this$addCallback");
        if (!LoaderManager.INSTANCE.isLoaderVisible()) {
            NavDestination currentDestination = this$0.getNavController().getCurrentDestination();
            Integer numValueOf = currentDestination != null ? Integer.valueOf(currentDestination.getId()) : null;
            int i = pk.gov.nadra.oneapp.crc.R.id.uploadApplicantPhotographFragment;
            if (numValueOf != null && numValueOf.intValue() == i) {
                this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
            } else {
                int i2 = pk.gov.nadra.oneapp.crc.R.id.applicantFingerprintAcquisitionFragment;
                if (numValueOf != null && numValueOf.intValue() == i2) {
                    this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_applicant_fp_acquisition_to_applicant_photograph);
                } else {
                    int i3 = pk.gov.nadra.oneapp.crc.R.id.signatureAcquisitionFragment;
                    if (numValueOf != null && numValueOf.intValue() == i3) {
                        if (this$0.hasIdTwoAndFingerprints(this$0.getCrcSharedViewModel().getCrcTabsList())) {
                            this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_applicant_signature_to_applicant_fp_acquisition);
                        } else {
                            this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_applicant_signature_to_applicant_photograph);
                        }
                    } else {
                        int i4 = pk.gov.nadra.oneapp.crc.R.id.minorListFragment;
                        if (numValueOf != null && numValueOf.intValue() == i4) {
                            this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
                        } else {
                            int i5 = pk.gov.nadra.oneapp.crc.R.id.childDetailFragment;
                            if (numValueOf != null && numValueOf.intValue() == i5) {
                                this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_child_detail_to_minor_list);
                            } else {
                                int i6 = pk.gov.nadra.oneapp.crc.R.id.childParentDetailFragment;
                                if (numValueOf != null && numValueOf.intValue() == i6) {
                                    this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_parent_detail_to_child_detail);
                                } else {
                                    int i7 = pk.gov.nadra.oneapp.crc.R.id.childDisabilityDetailFragment;
                                    if (numValueOf != null && numValueOf.intValue() == i7) {
                                        this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_disability_to_parent_detail);
                                    } else {
                                        int i8 = pk.gov.nadra.oneapp.crc.R.id.uploadPhotographFragment;
                                        if (numValueOf != null && numValueOf.intValue() == i8) {
                                            this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_photograph_to_child_disability);
                                        } else {
                                            int i9 = pk.gov.nadra.oneapp.crc.R.id.fingerprintAcquisitionFragment;
                                            if (numValueOf != null && numValueOf.intValue() == i9) {
                                                this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_fingerprint_to_child_photograph);
                                            } else {
                                                int i10 = pk.gov.nadra.oneapp.crc.R.id.reviewFragment;
                                                if (numValueOf != null && numValueOf.intValue() == i10) {
                                                    if (this$0.getCrcSharedViewModel().getUploadDocumentP()) {
                                                        this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_review_fragment_to_supporting_document);
                                                    } else if (this$0.getCrcSharedViewModel().getAttestationP()) {
                                                        this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_review_fragment_to_spouse_list);
                                                    } else {
                                                        this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_review_fragment_to_minor_list);
                                                    }
                                                } else {
                                                    int i11 = pk.gov.nadra.oneapp.crc.R.id.supportingDocumentsFragment;
                                                    if (numValueOf != null && numValueOf.intValue() == i11) {
                                                        if (this$0.getCrcSharedViewModel().getDataEntryP()) {
                                                            if (this$0.getCrcSharedViewModel().getAttestationP()) {
                                                                this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_supporting_document_to_spouse_list);
                                                            } else {
                                                                this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_supporting_document_to_minor_list);
                                                            }
                                                        } else if (this$0.getCrcSharedViewModel().getAttestationP()) {
                                                            this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_supporting_document_to_spouse_list);
                                                        } else {
                                                            this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
                                                        }
                                                    } else {
                                                        int i12 = pk.gov.nadra.oneapp.crc.R.id.spouseListFragment;
                                                        if (numValueOf != null && numValueOf.intValue() == i12 && this$0.getCrcSharedViewModel().getDataEntryP()) {
                                                            this$0.navigateToFragment(pk.gov.nadra.oneapp.crc.R.id.action_spouse_list_to_minor_list);
                                                        } else {
                                                            this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return Unit.INSTANCE;
    }

    private final void getIntentData() {
        if (getIntent() != null && getIntent().hasExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA)) {
            Bundle extras = getIntent().getExtras();
            Intrinsics.checkNotNull(extras);
            getCrcSharedViewModel().setReactNativeData((ReactNativeData) new Gson().fromJson(extras.getString(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA), ReactNativeData.class));
            this.trackingId = getCrcSharedViewModel().getReactNativeData().getTrackingId();
            getCrcSharedViewModel().setAttestationP(getCrcSharedViewModel().getReactNativeData().getAttestationP());
            getCrcSharedViewModel().setUploadDocumentP(getCrcSharedViewModel().getReactNativeData().getUploadDocumentP());
            getCrcSharedViewModel().setDataEntryP(getCrcSharedViewModel().getReactNativeData().getDataentryP());
            getCrcSharedViewModel().setDocumentTypeValue(Util.INSTANCE.capitalizeWords(getCrcSharedViewModel().getReactNativeData().getAppType()));
            getCrcSharedViewModel().setApplicationTypeValue(Util.INSTANCE.capitalizeWords("New"));
            getBinding().crcHeaderLayout.textTitle.setText("CRC");
            getBinding().crcHeaderLayout.textSubtitle.setText("New");
            getBinding().crcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(this, pk.gov.nadra.oneapp.commonui.R.font.roboto_medium));
        }
        SharedPreferencesTokenProvider sharedPreferencesTokenProvider = new SharedPreferencesTokenProvider(this);
        sharedPreferencesTokenProvider.saveToken(getCrcSharedViewModel().getReactNativeData().getToken());
        sharedPreferencesTokenProvider.saveRefreshToken(getCrcSharedViewModel().getReactNativeData().getRefreshToken());
        sharedPreferencesTokenProvider.saveAesKey(getCrcSharedViewModel().getReactNativeData().getSessionKey());
        sharedPreferencesTokenProvider.saveDeviceId(getCrcSharedViewModel().getReactNativeData().getDeviceId());
        sharedPreferencesTokenProvider.saveEncryptionEnabled(getCrcSharedViewModel().getReactNativeData().getEncryptionEnabled());
        String str = this.trackingId;
        if (str == null || str.length() == 0) {
            initView();
        } else {
            fetchTabData();
        }
    }

    public final void navigateToFragment(int resourceId) {
        getNavController().navigate(resourceId);
    }

    public final void popupFromNavHost() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }

    private final void initPermissions() {
        setPermissions(new Permissions(this));
        getPermissions().registerPermissionLauncher();
        getPermissions().setPermissionResult(new Function1() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return CRCActivity.initPermissions$lambda$3(this.f$0, ((Boolean) obj).booleanValue());
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initPermissions$lambda$3(CRCActivity this$0, boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (z) {
            if (Intrinsics.areEqual(this$0.callingFor, this$0.GALLERY)) {
                this$0.callPermissionSuccess(this$0.callingFor);
            }
            if (Intrinsics.areEqual(this$0.callingFor, this$0.CAMERA)) {
                this$0.callPermissionSuccess(this$0.callingFor);
            }
        } else {
            String string = this$0.getString(pk.gov.nadra.oneapp.commonui.R.string.permission_denied);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            String string2 = this$0.getString(pk.gov.nadra.oneapp.commonui.R.string.permission_denied_urdu);
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            BottomSheetUtils.showMessageBottomSheet$default(BottomSheetUtils.INSTANCE, (FragmentActivity) this$0, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
        }
        return Unit.INSTANCE;
    }

    private final void callPermissionSuccess(String callingFor) {
        Object next;
        Object next2;
        Object next3;
        if (Intrinsics.areEqual(this.fragmentName, "ApplicantPhotograph")) {
            List<Fragment> fragments = getNavHostFragment().getChildFragmentManager().getFragments();
            Intrinsics.checkNotNullExpressionValue(fragments, "getFragments(...)");
            Iterator<T> it = fragments.iterator();
            while (true) {
                if (!it.hasNext()) {
                    next3 = null;
                    break;
                } else {
                    next3 = it.next();
                    if (((Fragment) next3) instanceof UploadApplicantPhotographFragment) {
                        break;
                    }
                }
            }
            Fragment fragment = (Fragment) next3;
            UploadApplicantPhotographFragment uploadApplicantPhotographFragment = fragment instanceof UploadApplicantPhotographFragment ? (UploadApplicantPhotographFragment) fragment : null;
            if (uploadApplicantPhotographFragment != null) {
                uploadApplicantPhotographFragment.launchGalleryOrCameraIntent(callingFor);
            }
        }
        if (Intrinsics.areEqual(this.fragmentName, "ChildPhotograph")) {
            List<Fragment> fragments2 = getNavHostFragment().getChildFragmentManager().getFragments();
            Intrinsics.checkNotNullExpressionValue(fragments2, "getFragments(...)");
            Iterator<T> it2 = fragments2.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    next2 = null;
                    break;
                } else {
                    next2 = it2.next();
                    if (((Fragment) next2) instanceof UploadPhotographFragment) {
                        break;
                    }
                }
            }
            Fragment fragment2 = (Fragment) next2;
            UploadPhotographFragment uploadPhotographFragment = fragment2 instanceof UploadPhotographFragment ? (UploadPhotographFragment) fragment2 : null;
            if (uploadPhotographFragment != null) {
                uploadPhotographFragment.launchGalleryOrCameraIntent(callingFor);
            }
        }
        if (Intrinsics.areEqual(this.fragmentName, "SignatureAcquisition")) {
            List<Fragment> fragments3 = getNavHostFragment().getChildFragmentManager().getFragments();
            Intrinsics.checkNotNullExpressionValue(fragments3, "getFragments(...)");
            Iterator<T> it3 = fragments3.iterator();
            while (true) {
                if (!it3.hasNext()) {
                    next = null;
                    break;
                } else {
                    next = it3.next();
                    if (((Fragment) next) instanceof SignatureAcquisitionFragment) {
                        break;
                    }
                }
            }
            Fragment fragment3 = (Fragment) next;
            SignatureAcquisitionFragment signatureAcquisitionFragment = fragment3 instanceof SignatureAcquisitionFragment ? (SignatureAcquisitionFragment) fragment3 : null;
            if (signatureAcquisitionFragment != null) {
                signatureAcquisitionFragment.launchGalleryOrCameraIntent(callingFor);
            }
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Object next;
        Object next2;
        Object next3;
        super.onActivityResult(requestCode, resultCode, data);
        if (Intrinsics.areEqual(this.fragmentName, "ApplicantPhotograph")) {
            List<Fragment> fragments = getNavHostFragment().getChildFragmentManager().getFragments();
            Intrinsics.checkNotNullExpressionValue(fragments, "getFragments(...)");
            Iterator<T> it = fragments.iterator();
            while (true) {
                if (!it.hasNext()) {
                    next3 = null;
                    break;
                } else {
                    next3 = it.next();
                    if (((Fragment) next3) instanceof UploadApplicantPhotographFragment) {
                        break;
                    }
                }
            }
            Fragment fragment = (Fragment) next3;
            UploadApplicantPhotographFragment uploadApplicantPhotographFragment = fragment instanceof UploadApplicantPhotographFragment ? (UploadApplicantPhotographFragment) fragment : null;
            if (uploadApplicantPhotographFragment != null) {
                uploadApplicantPhotographFragment.onActivityResult(requestCode, resultCode, data);
            }
        }
        if (Intrinsics.areEqual(this.fragmentName, "ChildPhotograph")) {
            List<Fragment> fragments2 = getNavHostFragment().getChildFragmentManager().getFragments();
            Intrinsics.checkNotNullExpressionValue(fragments2, "getFragments(...)");
            Iterator<T> it2 = fragments2.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    next2 = null;
                    break;
                } else {
                    next2 = it2.next();
                    if (((Fragment) next2) instanceof UploadPhotographFragment) {
                        break;
                    }
                }
            }
            Fragment fragment2 = (Fragment) next2;
            UploadPhotographFragment uploadPhotographFragment = fragment2 instanceof UploadPhotographFragment ? (UploadPhotographFragment) fragment2 : null;
            if (uploadPhotographFragment != null) {
                uploadPhotographFragment.onActivityResult(requestCode, resultCode, data);
            }
        }
        if (Intrinsics.areEqual(this.fragmentName, "SignatureAcquisition")) {
            List<Fragment> fragments3 = getNavHostFragment().getChildFragmentManager().getFragments();
            Intrinsics.checkNotNullExpressionValue(fragments3, "getFragments(...)");
            Iterator<T> it3 = fragments3.iterator();
            while (true) {
                if (!it3.hasNext()) {
                    next = null;
                    break;
                } else {
                    next = it3.next();
                    if (((Fragment) next) instanceof SignatureAcquisitionFragment) {
                        break;
                    }
                }
            }
            Fragment fragment3 = (Fragment) next;
            SignatureAcquisitionFragment signatureAcquisitionFragment = fragment3 instanceof SignatureAcquisitionFragment ? (SignatureAcquisitionFragment) fragment3 : null;
            if (signatureAcquisitionFragment != null) {
                signatureAcquisitionFragment.onActivityResult(requestCode, resultCode, data);
            }
        }
    }

    private final void fetchTabData() {
        String str = this.trackingId;
        if (str == null) {
            return;
        }
        Intrinsics.checkNotNull(str);
        getCrcTabs(str);
    }

    /* compiled from: CRCActivity.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.views.CRCActivity$getTrackingData$1", f = "CRCActivity.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.views.CRCActivity$getTrackingData$1, reason: invalid class name and case insensitive filesystem */
    static final class C12591 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C12591(String str, Continuation<? super C12591> continuation) {
            super(2, continuation);
            this.$trackingId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return CRCActivity.this.new C12591(this.$trackingId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C12591) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(CRCActivity.this);
            APIRequests aPIRequests = new APIRequests(CRCActivity.this);
            String str = this.$trackingId;
            final CRCActivity cRCActivity = CRCActivity.this;
            aPIRequests.minorDataList(str, new Function3() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$getTrackingData$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return CRCActivity.C12591.invokeSuspend$lambda$0(cRCActivity, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(CRCActivity cRCActivity, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(cRCActivity);
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getTrackingDataRes: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                cRCActivity.processTrackingDataSuccessResponse(jsonObject);
            } else {
                cRCActivity.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getTrackingData(String trackingId) {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C12591(trackingId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processTrackingDataSuccessResponse(JsonObject jSonObject) {
        ChildDataResponse childDataResponse = (ChildDataResponse) new Gson().fromJson(jSonObject.toString(), ChildDataResponse.class);
        Log.d("processTrackingDataRes", childDataResponse.toString());
        getCrcSharedViewModel().setTrackingId(childDataResponse.getTrackingId());
        CRCSharedViewModel crcSharedViewModel = getCrcSharedViewModel();
        StringBuilder sb = new StringBuilder();
        String upperCase = childDataResponse.getPaymentResponse().getCurrency().getKey().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        crcSharedViewModel.setAmount(sb.append(upperCase).append(' ').append(childDataResponse.getPaymentResponse().getPaymentAmount()).toString());
        getCrcSharedViewModel().setChildDataResponse(childDataResponse);
        getCrcSharedViewModel().setApplicationType(childDataResponse.getApplicationStatus().getApplicationType().getKey());
        getCrcSharedViewModel().setDocumentType(childDataResponse.getApplicationStatus().getDocumentType().getKey());
        getCrcSharedViewModel().setApplicationTypeValue(Util.INSTANCE.capitalizeWords(childDataResponse.getApplicationStatus().getApplicationType().getValue()));
        getCrcSharedViewModel().setDocumentTypeValue(Util.INSTANCE.capitalizeWords(childDataResponse.getApplicationStatus().getDocumentType().getValue()));
        getCrcSharedViewModel().setLivelinessControl(getCrcSharedViewModel().getChildDataResponse().getLivelinessControl());
        handleTabSequence(childDataResponse.getApplicationStatus());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(NetworkErrorHandler.INSTANCE, this, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return CRCActivity.handleFailureCase$lambda$17(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$17(CRCActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final void handleTabSequence(ApplicationStatus applicationStatus) {
        int i;
        if (applicationStatus != null) {
            initView();
            int activeTab = applicationStatus.getActiveTab();
            applicationStatus.getCompletedTab();
            if (getCrcSharedViewModel().getDataEntryP()) {
                if (activeTab == 1) {
                    i = pk.gov.nadra.oneapp.crc.R.id.uploadApplicantPhotographFragment;
                } else if (activeTab == 2) {
                    i = pk.gov.nadra.oneapp.crc.R.id.applicantFingerprintAcquisitionFragment;
                } else if (activeTab == 4) {
                    i = pk.gov.nadra.oneapp.crc.R.id.signatureAcquisitionFragment;
                } else if (activeTab >= 4) {
                    i = pk.gov.nadra.oneapp.crc.R.id.minorListFragment;
                } else {
                    i = pk.gov.nadra.oneapp.crc.R.id.uploadApplicantPhotographFragment;
                }
            } else if (getCrcSharedViewModel().getAttestationP()) {
                i = pk.gov.nadra.oneapp.crc.R.id.spouseListFragment;
            } else if (getCrcSharedViewModel().getUploadDocumentP()) {
                i = pk.gov.nadra.oneapp.crc.R.id.supportingDocumentsFragment;
            } else {
                navigateToReactNativeInbox(Constant.GO_TO_INBOX);
                return;
            }
            navigateToFragment(i);
        }
    }

    public final void navigateToReactNativeInbox(String responseToReactNative) {
        Intrinsics.checkNotNullParameter(responseToReactNative, "responseToReactNative");
        Intent intent = new Intent();
        intent.putExtra("RESPONSE_TO_REACT_NATIVE", responseToReactNative);
        setResult(-1, intent);
        finish();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        CRCActivity cRCActivity = this;
        Util.INSTANCE.deleteTempPhotoDirectory(cRCActivity, cRCActivity);
    }

    public final void handleHomeIconClick() {
        String string = getString(pk.gov.nadra.oneapp.commonui.R.string.do_you_want_exit);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        SpannableString englishTextSpan$default = Util.setEnglishTextSpan$default(Util.INSTANCE, this, "Confirm", " (تصدیق کریں)", 0, false, 12, null);
        String string2 = getString(pk.gov.nadra.oneapp.commonui.R.string.do_you_want_exit_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.INSTANCE.showMessageBottomSheet((FragmentActivity) this, "Alert", string, true, (CharSequence) englishTextSpan$default, true, string2, new Function0() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return CRCActivity.handleHomeIconClick$lambda$18(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleHomeIconClick$lambda$18(CRCActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
        return Unit.INSTANCE;
    }

    /* compiled from: CRCActivity.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.crc.views.CRCActivity$getCrcTabs$1", f = "CRCActivity.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.crc.views.CRCActivity$getCrcTabs$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$trackingId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return CRCActivity.this.new AnonymousClass1(this.$trackingId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(CRCActivity.this);
            APIRequests aPIRequests = new APIRequests(CRCActivity.this);
            String str = this.$trackingId;
            final CRCActivity cRCActivity = CRCActivity.this;
            aPIRequests.getCrcTabs(str, new Function3() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$getCrcTabs$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return CRCActivity.AnonymousClass1.invokeSuspend$lambda$0(cRCActivity, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(CRCActivity cRCActivity, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(cRCActivity);
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                cRCActivity.processCrcTabsResponse(jsonArray);
            } else {
                cRCActivity.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getCrcTabs(String trackingId) {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(trackingId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processCrcTabsResponse(JsonArray jSonObject) throws JsonSyntaxException {
        Object objFromJson = new Gson().fromJson(jSonObject.toString(), (Class<Object>) CrcTabsResponse[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        getCrcSharedViewModel().setCrcTabsList(ArraysKt.toList((Object[]) objFromJson));
        String str = this.trackingId;
        Intrinsics.checkNotNull(str);
        getTrackingData(str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCaseJsonArray(JsonArray jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson((JsonElement) jsonResponse.get(0).getAsJsonObject(), ErrorResponse.class);
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(NetworkErrorHandler.INSTANCE, this, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.crc.views.CRCActivity$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return CRCActivity.handleFailureCaseJsonArray$lambda$21(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$21(CRCActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    public final boolean hasIdTwoAndFingerprints(List<CrcTabsResponse> crcTabsList) {
        Intrinsics.checkNotNullParameter(crcTabsList, "crcTabsList");
        List<CrcTabsResponse> list = crcTabsList;
        if ((list instanceof Collection) && list.isEmpty()) {
            return false;
        }
        for (CrcTabsResponse crcTabsResponse : list) {
            if (crcTabsResponse.getId() == 2 && Intrinsics.areEqual(crcTabsResponse.getValue(), "Fingerprints")) {
                return true;
            }
        }
        return false;
    }
}