package pk.gov.nadra.oneapp.crc.views;

import com.google.gson.JsonArray;
import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.crc.views.CRCActivity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CRCActivity$getCrcTabs$1$$ExternalSyntheticLambda0 implements Function3 {
    public /* synthetic */ CRCActivity$getCrcTabs$1$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return CRCActivity.AnonymousClass1.invokeSuspend$lambda$0(cRCActivity, (JsonArray) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}