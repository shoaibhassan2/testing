package pk.gov.nadra.oneapp.crc.views;

import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CRCActivity$$ExternalSyntheticLambda4 implements Function1 {
    public /* synthetic */ CRCActivity$$ExternalSyntheticLambda4() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return CRCActivity.initPermissions$lambda$3(this.f$0, ((Boolean) obj).booleanValue());
    }
}