package pk.gov.nadra.oneapp.etdTransfer.views;

import android.R;
import android.app.Application;
import android.os.Bundle;
import android.view.View;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcherKt;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.NavGraph;
import androidx.navigation.fragment.NavHostFragment;
import com.google.gson.Gson;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import pk.gov.nadra.oneapp.commonutils.BaseActivity;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.etdTransfer.databinding.ActivityEtdTransferBinding;
import pk.gov.nadra.oneapp.etdTransfer.viewmodel.EtdTransferSharedViewModel;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.models.vehicleCard.VehicleCardListReponse;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;

/* compiled from: EtdTransferActivity.kt */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0014J\b\u0010\u0018\u001a\u00020\u0015H\u0002J\b\u0010\u0019\u001a\u00020\u0015H\u0002J\u0006\u0010\u001a\u001a\u00020\u0015J\b\u0010\u001b\u001a\u00020\u0015H\u0016J\b\u0010\u001c\u001a\u00020\u0015H\u0014R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001b\u0010\n\u001a\u00020\u000b8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\f\u0010\rR\u000e\u0010\u0010\u001a\u00020\u0011X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000¨\u0006\u001d"}, d2 = {"Lpk/gov/nadra/oneapp/etdTransfer/views/EtdTransferActivity;", "Lpk/gov/nadra/oneapp/commonutils/BaseActivity;", "<init>", "()V", "binding", "Lpk/gov/nadra/oneapp/etdTransfer/databinding/ActivityEtdTransferBinding;", "getBinding", "()Lpk/gov/nadra/oneapp/etdTransfer/databinding/ActivityEtdTransferBinding;", "setBinding", "(Lpk/gov/nadra/oneapp/etdTransfer/databinding/ActivityEtdTransferBinding;)V", "etdSharedViewModel", "Lpk/gov/nadra/oneapp/etdTransfer/viewmodel/EtdTransferSharedViewModel;", "getEtdSharedViewModel", "()Lpk/gov/nadra/oneapp/etdTransfer/viewmodel/EtdTransferSharedViewModel;", "etdSharedViewModel$delegate", "Lkotlin/Lazy;", "navController", "Landroidx/navigation/NavController;", "navHostFragment", "Landroidx/navigation/fragment/NavHostFragment;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "initView", "getIntentData", "popupFromNavHost", "onBackPressed", "onDestroy", "etdTransfer_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class EtdTransferActivity extends BaseActivity {
    public ActivityEtdTransferBinding binding;

    /* renamed from: etdSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy etdSharedViewModel;
    private NavController navController;
    private NavHostFragment navHostFragment;

    public EtdTransferActivity() {
        final EtdTransferActivity etdTransferActivity = this;
        final Function0 function0 = null;
        this.etdSharedViewModel = new ViewModelLazy(Reflection.getOrCreateKotlinClass(EtdTransferSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.etdTransfer.views.EtdTransferActivity$special$$inlined$viewModels$default$2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                return etdTransferActivity.getViewModelStore();
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.etdTransfer.views.EtdTransferActivity$special$$inlined$viewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                return etdTransferActivity.getDefaultViewModelProviderFactory();
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.etdTransfer.views.EtdTransferActivity$special$$inlined$viewModels$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                return (function02 == null || (creationExtras = (CreationExtras) function02.invoke()) == null) ? etdTransferActivity.getDefaultViewModelCreationExtras() : creationExtras;
            }
        });
    }

    public final ActivityEtdTransferBinding getBinding() {
        ActivityEtdTransferBinding activityEtdTransferBinding = this.binding;
        if (activityEtdTransferBinding != null) {
            return activityEtdTransferBinding;
        }
        Intrinsics.throwUninitializedPropertyAccessException("binding");
        return null;
    }

    public final void setBinding(ActivityEtdTransferBinding activityEtdTransferBinding) {
        Intrinsics.checkNotNullParameter(activityEtdTransferBinding, "<set-?>");
        this.binding = activityEtdTransferBinding;
    }

    private final EtdTransferSharedViewModel getEtdSharedViewModel() {
        return (EtdTransferSharedViewModel) this.etdSharedViewModel.getValue();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setBinding(ActivityEtdTransferBinding.inflate(getLayoutInflater()));
        setContentView(getBinding().getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.white));
        new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
        ActivityEtdTransferBinding binding = getBinding();
        binding.etdHeaderLayout.tvHeaderTitle.setText("ETD Transfer");
        binding.etdHeaderLayout.ivHeaderClose.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.etdTransfer.views.EtdTransferActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EtdTransferActivity.onCreate$lambda$1$lambda$0(this.f$0, view);
            }
        });
        setFragmentId(pk.gov.nadra.oneapp.etdTransfer.R.id.etdTransferSubmitSuccessFragment);
        getIntentData();
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        Application application = getApplication();
        Intrinsics.checkNotNullExpressionValue(application, "getApplication(...)");
        loaderManager.initialize(application);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$1$lambda$0(EtdTransferActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
    }

    private final void initView() {
        Fragment fragmentFindFragmentById = getSupportFragmentManager().findFragmentById(pk.gov.nadra.oneapp.etdTransfer.R.id.etd_transfer_nav_host_fragment);
        Intrinsics.checkNotNull(fragmentFindFragmentById, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
        NavHostFragment navHostFragment = (NavHostFragment) fragmentFindFragmentById;
        this.navHostFragment = navHostFragment;
        NavController navController = null;
        if (navHostFragment == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navHostFragment");
            navHostFragment = null;
        }
        NavController navController2 = navHostFragment.getNavController();
        this.navController = navController2;
        if (navController2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
            navController2 = null;
        }
        NavGraph navGraphInflate = navController2.getNavInflater().inflate(pk.gov.nadra.oneapp.etdTransfer.R.navigation.etd_transfer_nav_graph);
        NavController navController3 = this.navController;
        if (navController3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
            navController3 = null;
        }
        navController3.setGraph(navGraphInflate);
        NavController navController4 = this.navController;
        if (navController4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
        } else {
            navController = navController4;
        }
        initBaseView(navController);
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        OnBackPressedDispatcherKt.addCallback$default(getOnBackPressedDispatcher(), this, false, new Function1() { // from class: pk.gov.nadra.oneapp.etdTransfer.views.EtdTransferActivity$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return EtdTransferActivity.initView$lambda$2(this.f$0, (OnBackPressedCallback) obj);
            }
        }, 2, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initView$lambda$2(EtdTransferActivity this$0, OnBackPressedCallback addCallback) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(addCallback, "$this$addCallback");
        if (!LoaderManager.INSTANCE.isLoaderVisible()) {
            NavController navController = this$0.navController;
            if (navController == null) {
                Intrinsics.throwUninitializedPropertyAccessException("navController");
                navController = null;
            }
            NavDestination currentDestination = navController.getCurrentDestination();
            Integer numValueOf = currentDestination != null ? Integer.valueOf(currentDestination.getId()) : null;
            int i = pk.gov.nadra.oneapp.etdTransfer.R.id.startApplicationEtdTransferFragment;
            if (numValueOf != null && numValueOf.intValue() == i) {
                this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
            } else {
                int i2 = pk.gov.nadra.oneapp.etdTransfer.R.id.etdTransferSubmitSuccessFragment;
                if (numValueOf != null && numValueOf.intValue() == i2) {
                    this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
                }
            }
        }
        return Unit.INSTANCE;
    }

    private final void getIntentData() {
        if (getIntent() != null && getIntent().hasExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA)) {
            Bundle extras = getIntent().getExtras();
            Intrinsics.checkNotNull(extras);
            getEtdSharedViewModel().setReactNativeData((ReactNativeData) new Gson().fromJson(extras.getString(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA), ReactNativeData.class));
            getSharedViewModel().setReactNativeData(getEtdSharedViewModel().getReactNativeData());
        }
        if (getIntent() != null && getIntent().hasExtra("VEHICLE_DATA")) {
            Bundle extras2 = getIntent().getExtras();
            Intrinsics.checkNotNull(extras2);
            getEtdSharedViewModel().setVehicleData((VehicleCardListReponse.RegVehicleData) new Gson().fromJson(extras2.getString("VEHICLE_DATA"), VehicleCardListReponse.RegVehicleData.class));
        }
        SharedPreferencesTokenProvider sharedPreferencesTokenProvider = new SharedPreferencesTokenProvider(this);
        sharedPreferencesTokenProvider.saveToken(getEtdSharedViewModel().getReactNativeData().getToken());
        sharedPreferencesTokenProvider.saveRefreshToken(getEtdSharedViewModel().getReactNativeData().getRefreshToken());
        sharedPreferencesTokenProvider.saveAesKey(getEtdSharedViewModel().getReactNativeData().getSessionKey());
        sharedPreferencesTokenProvider.saveDeviceId(getEtdSharedViewModel().getReactNativeData().getDeviceId());
        sharedPreferencesTokenProvider.saveEncryptionEnabled(getEtdSharedViewModel().getReactNativeData().getEncryptionEnabled());
        initView();
    }

    public final void popupFromNavHost() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        EtdTransferActivity etdTransferActivity = this;
        Util.INSTANCE.deleteTempPhotoDirectory(etdTransferActivity, etdTransferActivity);
    }
}