package pk.gov.nadra.oneapp.etdTransfer.views;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class EtdVerificationActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public /* synthetic */ EtdVerificationActivity$$ExternalSyntheticLambda0() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        EtdVerificationActivity.onCreate$lambda$1$lambda$0(this.f$0, view);
    }
}