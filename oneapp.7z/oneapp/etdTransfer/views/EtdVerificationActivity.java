package pk.gov.nadra.oneapp.etdTransfer.views;

import android.R;
import android.app.Application;
import android.os.Bundle;
import android.view.View;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcherKt;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.NavGraph;
import androidx.navigation.fragment.NavHostFragment;
import com.google.gson.Gson;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import pk.gov.nadra.oneapp.commonutils.BaseActivity;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.etdTransfer.databinding.ActivityEtdVerificationBinding;
import pk.gov.nadra.oneapp.etdTransfer.viewmodel.EtdTransferSharedViewModel;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;

/* compiled from: EtdVerificationActivity.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0013H\u0014J\b\u0010\u0014\u001a\u00020\u0011H\u0002J\b\u0010\u0015\u001a\u00020\u0011H\u0002J\u0006\u0010\u0016\u001a\u00020\u0011J\b\u0010\u0017\u001a\u00020\u0011H\u0016J\b\u0010\u0018\u001a\u00020\u0011H\u0014R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u001b\u0010\u0006\u001a\u00020\u00078BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\n\u0010\u000b\u001a\u0004\b\b\u0010\tR\u000e\u0010\f\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082.¢\u0006\u0002\n\u0000¨\u0006\u0019"}, d2 = {"Lpk/gov/nadra/oneapp/etdTransfer/views/EtdVerificationActivity;", "Lpk/gov/nadra/oneapp/commonutils/BaseActivity;", "<init>", "()V", "binding", "Lpk/gov/nadra/oneapp/etdTransfer/databinding/ActivityEtdVerificationBinding;", "etdSharedViewModel", "Lpk/gov/nadra/oneapp/etdTransfer/viewmodel/EtdTransferSharedViewModel;", "getEtdSharedViewModel", "()Lpk/gov/nadra/oneapp/etdTransfer/viewmodel/EtdTransferSharedViewModel;", "etdSharedViewModel$delegate", "Lkotlin/Lazy;", "navController", "Landroidx/navigation/NavController;", "navHostFragment", "Landroidx/navigation/fragment/NavHostFragment;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "initView", "getIntentData", "popupFromNavHost", "onBackPressed", "onDestroy", "etdTransfer_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class EtdVerificationActivity extends BaseActivity {
    private ActivityEtdVerificationBinding binding;

    /* renamed from: etdSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy etdSharedViewModel;
    private NavController navController;
    private NavHostFragment navHostFragment;

    public EtdVerificationActivity() {
        final EtdVerificationActivity etdVerificationActivity = this;
        final Function0 function0 = null;
        this.etdSharedViewModel = new ViewModelLazy(Reflection.getOrCreateKotlinClass(EtdTransferSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.etdTransfer.views.EtdVerificationActivity$special$$inlined$viewModels$default$2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                return etdVerificationActivity.getViewModelStore();
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.etdTransfer.views.EtdVerificationActivity$special$$inlined$viewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                return etdVerificationActivity.getDefaultViewModelProviderFactory();
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.etdTransfer.views.EtdVerificationActivity$special$$inlined$viewModels$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                return (function02 == null || (creationExtras = (CreationExtras) function02.invoke()) == null) ? etdVerificationActivity.getDefaultViewModelCreationExtras() : creationExtras;
            }
        });
    }

    private final EtdTransferSharedViewModel getEtdSharedViewModel() {
        return (EtdTransferSharedViewModel) this.etdSharedViewModel.getValue();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityEtdVerificationBinding activityEtdVerificationBindingInflate = ActivityEtdVerificationBinding.inflate(getLayoutInflater());
        this.binding = activityEtdVerificationBindingInflate;
        ActivityEtdVerificationBinding activityEtdVerificationBinding = null;
        if (activityEtdVerificationBindingInflate == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityEtdVerificationBindingInflate = null;
        }
        setContentView(activityEtdVerificationBindingInflate.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.white));
        new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
        ActivityEtdVerificationBinding activityEtdVerificationBinding2 = this.binding;
        if (activityEtdVerificationBinding2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        } else {
            activityEtdVerificationBinding = activityEtdVerificationBinding2;
        }
        activityEtdVerificationBinding.etdVerificationHeaderLayout.ivHeaderClose.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.etdTransfer.views.EtdVerificationActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EtdVerificationActivity.onCreate$lambda$1$lambda$0(this.f$0, view);
            }
        });
        getIntentData();
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        Application application = getApplication();
        Intrinsics.checkNotNullExpressionValue(application, "getApplication(...)");
        loaderManager.initialize(application);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$1$lambda$0(EtdVerificationActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
    }

    private final void initView() {
        Fragment fragmentFindFragmentById = getSupportFragmentManager().findFragmentById(pk.gov.nadra.oneapp.etdTransfer.R.id.etd_verification_nav_host_fragment);
        Intrinsics.checkNotNull(fragmentFindFragmentById, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
        NavHostFragment navHostFragment = (NavHostFragment) fragmentFindFragmentById;
        this.navHostFragment = navHostFragment;
        ActivityEtdVerificationBinding activityEtdVerificationBinding = null;
        if (navHostFragment == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navHostFragment");
            navHostFragment = null;
        }
        NavController navController = navHostFragment.getNavController();
        this.navController = navController;
        if (navController == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
            navController = null;
        }
        NavGraph navGraphInflate = navController.getNavInflater().inflate(pk.gov.nadra.oneapp.etdTransfer.R.navigation.etd_verificaiton_nav_graph);
        NavController navController2 = this.navController;
        if (navController2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
            navController2 = null;
        }
        navController2.setGraph(navGraphInflate);
        NavController navController3 = this.navController;
        if (navController3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
            navController3 = null;
        }
        initBaseView(navController3);
        if (!LoaderManager.INSTANCE.isLoaderVisible()) {
            OnBackPressedDispatcherKt.addCallback$default(getOnBackPressedDispatcher(), this, false, new Function1() { // from class: pk.gov.nadra.oneapp.etdTransfer.views.EtdVerificationActivity$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return EtdVerificationActivity.initView$lambda$2(this.f$0, (OnBackPressedCallback) obj);
                }
            }, 2, null);
        }
        ActivityEtdVerificationBinding activityEtdVerificationBinding2 = this.binding;
        if (activityEtdVerificationBinding2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        } else {
            activityEtdVerificationBinding = activityEtdVerificationBinding2;
        }
        activityEtdVerificationBinding.etdVerificationHeaderLayout.ivHeaderClose.setClickable(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initView$lambda$2(EtdVerificationActivity this$0, OnBackPressedCallback addCallback) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(addCallback, "$this$addCallback");
        if (!LoaderManager.INSTANCE.isLoaderVisible()) {
            NavController navController = this$0.navController;
            if (navController == null) {
                Intrinsics.throwUninitializedPropertyAccessException("navController");
                navController = null;
            }
            NavDestination currentDestination = navController.getCurrentDestination();
            Integer numValueOf = currentDestination != null ? Integer.valueOf(currentDestination.getId()) : null;
            int i = pk.gov.nadra.oneapp.etdTransfer.R.id.etdVerificationStartApplicationFragment;
            if (numValueOf != null && numValueOf.intValue() == i) {
                this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
            }
        }
        return Unit.INSTANCE;
    }

    private final void getIntentData() {
        if (getIntent() != null && getIntent().hasExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA)) {
            Bundle extras = getIntent().getExtras();
            Intrinsics.checkNotNull(extras);
            getEtdSharedViewModel().setReactNativeData((ReactNativeData) new Gson().fromJson(extras.getString(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA), ReactNativeData.class));
            setTrackingId(getEtdSharedViewModel().getReactNativeData().getTrackingId());
            getSharedViewModel().setReactNativeData(getEtdSharedViewModel().getReactNativeData());
            ActivityEtdVerificationBinding activityEtdVerificationBinding = this.binding;
            ActivityEtdVerificationBinding activityEtdVerificationBinding2 = null;
            if (activityEtdVerificationBinding == null) {
                Intrinsics.throwUninitializedPropertyAccessException("binding");
                activityEtdVerificationBinding = null;
            }
            activityEtdVerificationBinding.etdVerificationHeaderLayout.tvHeaderTitle.setText("Verification");
            ActivityEtdVerificationBinding activityEtdVerificationBinding3 = this.binding;
            if (activityEtdVerificationBinding3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("binding");
                activityEtdVerificationBinding3 = null;
            }
            activityEtdVerificationBinding3.etdVerificationHeaderLayout.tvSupHeaderTitle.setVisibility(0);
            ActivityEtdVerificationBinding activityEtdVerificationBinding4 = this.binding;
            if (activityEtdVerificationBinding4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("binding");
            } else {
                activityEtdVerificationBinding2 = activityEtdVerificationBinding4;
            }
            activityEtdVerificationBinding2.etdVerificationHeaderLayout.tvSupHeaderTitle.setText("Vehicle Transfer");
        }
        SharedPreferencesTokenProvider sharedPreferencesTokenProvider = new SharedPreferencesTokenProvider(this);
        sharedPreferencesTokenProvider.saveToken(getEtdSharedViewModel().getReactNativeData().getToken());
        sharedPreferencesTokenProvider.saveRefreshToken(getEtdSharedViewModel().getReactNativeData().getRefreshToken());
        sharedPreferencesTokenProvider.saveAesKey(getEtdSharedViewModel().getReactNativeData().getSessionKey());
        sharedPreferencesTokenProvider.saveDeviceId(getEtdSharedViewModel().getReactNativeData().getDeviceId());
        sharedPreferencesTokenProvider.saveEncryptionEnabled(getEtdSharedViewModel().getReactNativeData().getEncryptionEnabled());
        initView();
    }

    public final void popupFromNavHost() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
    }
}