package pk.gov.nadra.oneapp.etdTransfer.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class EtdVerificationFragment$$ExternalSyntheticLambda13 implements Function0 {
    public /* synthetic */ EtdVerificationFragment$$ExternalSyntheticLambda13() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return EtdVerificationFragment.processVerifyApplicantSuccessResponse$lambda$27(this.f$0);
    }
}