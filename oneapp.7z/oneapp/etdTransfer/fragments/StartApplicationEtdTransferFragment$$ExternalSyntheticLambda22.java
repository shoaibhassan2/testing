package pk.gov.nadra.oneapp.etdTransfer.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class StartApplicationEtdTransferFragment$$ExternalSyntheticLambda22 implements Function0 {
    public /* synthetic */ StartApplicationEtdTransferFragment$$ExternalSyntheticLambda22() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return StartApplicationEtdTransferFragment.callBiometricAction$lambda$36(this.f$0);
    }
}