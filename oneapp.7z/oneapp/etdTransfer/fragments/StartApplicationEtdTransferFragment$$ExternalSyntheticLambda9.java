package pk.gov.nadra.oneapp.etdTransfer.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class StartApplicationEtdTransferFragment$$ExternalSyntheticLambda9 implements View.OnClickListener {
    public /* synthetic */ StartApplicationEtdTransferFragment$$ExternalSyntheticLambda9() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        StartApplicationEtdTransferFragment.attachLayoutViews$lambda$10$lambda$2(this.f$0, view);
    }
}