package pk.gov.nadra.oneapp.etdTransfer.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import com.google.gson.JsonSyntaxException;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class EtdVerificationFragment$$ExternalSyntheticLambda11 implements ActivityResultCallback {
    public /* synthetic */ EtdVerificationFragment$$ExternalSyntheticLambda11() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) throws JsonSyntaxException {
        EtdVerificationFragment.fingerprintLauncher$lambda$21(this.f$0, (ActivityResult) obj);
    }
}