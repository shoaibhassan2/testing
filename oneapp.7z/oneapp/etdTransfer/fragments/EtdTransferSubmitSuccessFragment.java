package pk.gov.nadra.oneapp.etdTransfer.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.etdTransfer.databinding.EtdTransferSubmitSuccessFragmentBinding;
import pk.gov.nadra.oneapp.etdTransfer.viewmodel.EtdTransferSharedViewModel;
import pk.gov.nadra.oneapp.etdTransfer.views.EtdTransferActivity;

/* compiled from: EtdTransferSubmitSuccessFragment.kt */
@Metadata(d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0016J$\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cH\u0016J\u001a\u0010\u001d\u001a\u00020\u00122\u0006\u0010\u001e\u001a\u00020\u00162\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cH\u0016R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u000e\u0010\u000f\u001a\u00020\u0010X\u0082.¢\u0006\u0002\n\u0000¨\u0006\u001f"}, d2 = {"Lpk/gov/nadra/oneapp/etdTransfer/fragments/EtdTransferSubmitSuccessFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "etdSharedViewModel", "Lpk/gov/nadra/oneapp/etdTransfer/viewmodel/EtdTransferSharedViewModel;", "getEtdSharedViewModel", "()Lpk/gov/nadra/oneapp/etdTransfer/viewmodel/EtdTransferSharedViewModel;", "etdSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/etdTransfer/databinding/EtdTransferSubmitSuccessFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/etdTransfer/databinding/EtdTransferSubmitSuccessFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/etdTransfer/views/EtdTransferActivity;", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "etdTransfer_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class EtdTransferSubmitSuccessFragment extends Fragment {
    private EtdTransferSubmitSuccessFragmentBinding _binding;
    private EtdTransferActivity activity;

    /* renamed from: etdSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy etdSharedViewModel;

    public EtdTransferSubmitSuccessFragment() {
        final EtdTransferSubmitSuccessFragment etdTransferSubmitSuccessFragment = this;
        final Function0 function0 = null;
        this.etdSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(etdTransferSubmitSuccessFragment, Reflection.getOrCreateKotlinClass(EtdTransferSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.etdTransfer.fragments.EtdTransferSubmitSuccessFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = etdTransferSubmitSuccessFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.etdTransfer.fragments.EtdTransferSubmitSuccessFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = etdTransferSubmitSuccessFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.etdTransfer.fragments.EtdTransferSubmitSuccessFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = etdTransferSubmitSuccessFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    private final EtdTransferSharedViewModel getEtdSharedViewModel() {
        return (EtdTransferSharedViewModel) this.etdSharedViewModel.getValue();
    }

    private final EtdTransferSubmitSuccessFragmentBinding getBinding() {
        EtdTransferSubmitSuccessFragmentBinding etdTransferSubmitSuccessFragmentBinding = this._binding;
        Intrinsics.checkNotNull(etdTransferSubmitSuccessFragmentBinding);
        return etdTransferSubmitSuccessFragmentBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.etdTransfer.views.EtdTransferActivity");
        this.activity = (EtdTransferActivity) fragmentActivityRequireActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = EtdTransferSubmitSuccessFragmentBinding.inflate(inflater, container, false);
        ScrollView root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        EtdTransferSubmitSuccessFragmentBinding binding = getBinding();
        ConfigurableButton configurableButton = binding.startApplicationButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        EtdTransferActivity etdTransferActivity = this.activity;
        EtdTransferActivity etdTransferActivity2 = null;
        if (etdTransferActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            etdTransferActivity = null;
        }
        configurableButton.setText(Util.setEnglishTextSpan$default(util, etdTransferActivity, "Ok", " (ٹھیک ہے)", 0, false, 12, null));
        binding.startApplicationButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.etdTransfer.fragments.EtdTransferSubmitSuccessFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                EtdTransferSubmitSuccessFragment.onViewCreated$lambda$1$lambda$0(this.f$0, view2);
            }
        });
        TextView textView = binding.submittedSuccessfullyUrduTextView;
        EtdTransferActivity etdTransferActivity3 = this.activity;
        if (etdTransferActivity3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            etdTransferActivity3 = null;
        }
        textView.setTypeface(ResourcesCompat.getFont(etdTransferActivity3, R.font.nadra_nastaleeq));
        TextView textView2 = binding.submittedSuccessfullyDetailUrduTextView;
        EtdTransferActivity etdTransferActivity4 = this.activity;
        if (etdTransferActivity4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            etdTransferActivity4 = null;
        }
        textView2.setTypeface(ResourcesCompat.getFont(etdTransferActivity4, R.font.nadra_nastaleeq));
        Util util2 = Util.INSTANCE;
        EtdTransferActivity etdTransferActivity5 = this.activity;
        if (etdTransferActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            etdTransferActivity2 = etdTransferActivity5;
        }
        util2.showInAppReview(etdTransferActivity2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$1$lambda$0(EtdTransferSubmitSuccessFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        EtdTransferActivity etdTransferActivity = this$0.activity;
        if (etdTransferActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            etdTransferActivity = null;
        }
        etdTransferActivity.popupFromNavHost();
    }
}