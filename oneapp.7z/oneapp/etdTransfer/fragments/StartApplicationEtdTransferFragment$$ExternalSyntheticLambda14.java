package pk.gov.nadra.oneapp.etdTransfer.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class StartApplicationEtdTransferFragment$$ExternalSyntheticLambda14 implements View.OnClickListener {
    public /* synthetic */ StartApplicationEtdTransferFragment$$ExternalSyntheticLambda14() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        StartApplicationEtdTransferFragment.attachLayoutViews$lambda$10$lambda$8(this.f$0, view);
    }
}