package pk.gov.nadra.oneapp.etdTransfer;

/* loaded from: classes5.dex */
public final class R {

    public static final class id {
        public static int applicant_cnic_layout = 0x7f0a0129;
        public static int applicant_detail_layout = 0x7f0a012b;
        public static int application_detail_heading_layout = 0x7f0a0134;
        public static int application_fee_heading_textView = 0x7f0a0136;
        public static int application_fee_textView = 0x7f0a0137;
        public static int application_type_layout = 0x7f0a0139;
        public static int card_id = 0x7f0a0296;
        public static int category_fee_cardView = 0x7f0a029f;
        public static int category_line_view = 0x7f0a02a0;
        public static int category_type_textView = 0x7f0a02a3;
        public static int delivery_fee_heading_textView = 0x7f0a0475;
        public static int delivery_fee_textView = 0x7f0a0476;
        public static int document_type_layout = 0x7f0a0519;
        public static int etdTransferSubmitSuccessFragment = 0x7f0a057e;
        public static int etdVerificationStartApplicationFragment = 0x7f0a057f;
        public static int etd_header_layout = 0x7f0a0580;
        public static int etd_transfer_nav_host_fragment = 0x7f0a0582;
        public static int etd_verification_header_layout = 0x7f0a0583;
        public static int etd_verification_nav_host_fragment = 0x7f0a0584;
        public static int etd_verification_start_application_button_layout = 0x7f0a0585;
        public static int guideline2 = 0x7f0a06d1;
        public static int heading_tv = 0x7f0a06f2;
        public static int nav_graph = 0x7f0a0959;
        public static int new_application_scrollView = 0x7f0a096d;
        public static int priority_processing_recyclerView = 0x7f0a0a97;
        public static int product_id = 0x7f0a0aa3;
        public static int registration_date = 0x7f0a0b11;
        public static int registration_no = 0x7f0a0b15;
        public static int startApplicationEtdTransferFragment = 0x7f0a0c67;
        public static int start_application_button_layout = 0x7f0a0c6f;
        public static int submitted_successfully_detail_textView = 0x7f0a0c84;
        public static int submitted_successfully_detail_urdu_textView = 0x7f0a0c86;
        public static int submitted_successfully_textView = 0x7f0a0c87;
        public static int submitted_successfully_urdu_textView = 0x7f0a0c89;
        public static int success_icon_imageView = 0x7f0a0c8a;
        public static int total_fee_textView = 0x7f0a0d29;
        public static int total_heading_textView = 0x7f0a0d2a;
        public static int tracking_id_layout = 0x7f0a0d32;
        public static int tracking_pin_layout = 0x7f0a0d36;
        public static int transfer_cnic_layout = 0x7f0a0d38;
        public static int transfer_date = 0x7f0a0d39;
        public static int tv_priority_heading = 0x7f0a0dad;
        public static int verify_applicant_fingerprint_button_layout = 0x7f0a0e4c;
        public static int verify_etd_verification_button_layout = 0x7f0a0e55;

        private id() {
        }
    }

    public static final class layout {
        public static int activity_etd_transfer = 0x7f0d0036;
        public static int activity_etd_verification = 0x7f0d0037;
        public static int etd_transfer_submit_success_fragment = 0x7f0d00f8;
        public static int etd_verfication_fragment = 0x7f0d00f9;
        public static int start_application_etd_transfer_fragment = 0x7f0d0244;

        private layout() {
        }
    }

    public static final class navigation {
        public static int etd_transfer_nav_graph = 0x7f11000a;
        public static int etd_verificaiton_nav_graph = 0x7f11000b;

        private navigation() {
        }
    }

    private R() {
    }
}