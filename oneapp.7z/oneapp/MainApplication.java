package pk.gov.nadra.oneapp;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import java.io.IOException;
import java.security.GeneralSecurityException;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.auth.main.ApplicationContextHelper;
import pk.gov.nadra.oneapp.commonutils.utils.EncryptedPrefs;
import pk.gov.nadra.oneapp.commonutils.utils.RSAKeyPair;
import pk.gov.nadra.oneapp.digitalvault.core.DeepUtils;
import pk.gov.nadra.rahbar.android.app.AppPreferences;
import pk.gov.nadra.rahbar.android.data.InternetConnectionManager;
import pk.gov.nadra.rahbar.android.location.LocationService;

/* compiled from: MainApplication.kt */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\u0018\u0000 \u00072\u00020\u0001:\u0001\u0007B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0016J\b\u0010\u0006\u001a\u00020\u0005H\u0002¨\u0006\b"}, d2 = {"Lpk/gov/nadra/oneapp/MainApplication;", "Landroid/app/Application;", "<init>", "()V", "onCreate", "", "initRahbarConfigurations", "Companion", "app_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class MainApplication extends Application {

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private static Activity foregroundActivity;

    /* compiled from: MainApplication.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u001c\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Lpk/gov/nadra/oneapp/MainApplication$Companion;", "", "<init>", "()V", "foregroundActivity", "Landroid/app/Activity;", "getForegroundActivity", "()Landroid/app/Activity;", "setForegroundActivity", "(Landroid/app/Activity;)V", "app_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final Activity getForegroundActivity() {
            return MainApplication.foregroundActivity;
        }

        public final void setForegroundActivity(Activity activity) {
            MainApplication.foregroundActivity = activity;
        }
    }

    @Override // android.app.Application
    public void onCreate() throws GeneralSecurityException, IOException {
        super.onCreate();
        ApplicationContextHelper.INSTANCE.init(this);
        MainApplication mainApplication = this;
        EncryptedPrefs.INSTANCE.init(mainApplication);
        if (RSAKeyPair.INSTANCE.generateRSAKeysAtOnce(mainApplication)) {
            DeepUtils.INSTANCE.deleteDigitalIdDb(mainApplication);
        }
        registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() { // from class: pk.gov.nadra.oneapp.MainApplication.onCreate.1
            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
                Intrinsics.checkNotNullParameter(activity, "activity");
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityDestroyed(Activity activity) {
                Intrinsics.checkNotNullParameter(activity, "activity");
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
                Intrinsics.checkNotNullParameter(activity, "activity");
                Intrinsics.checkNotNullParameter(outState, "outState");
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityStarted(Activity activity) {
                Intrinsics.checkNotNullParameter(activity, "activity");
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityStopped(Activity activity) {
                Intrinsics.checkNotNullParameter(activity, "activity");
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityResumed(Activity activity) {
                Intrinsics.checkNotNullParameter(activity, "activity");
                MainApplication.INSTANCE.setForegroundActivity(activity);
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityPaused(Activity activity) {
                Intrinsics.checkNotNullParameter(activity, "activity");
                if (Intrinsics.areEqual(MainApplication.INSTANCE.getForegroundActivity(), activity)) {
                    MainApplication.INSTANCE.setForegroundActivity(null);
                }
            }
        });
        initRahbarConfigurations();
    }

    private final void initRahbarConfigurations() {
        AppPreferences sharedInstance = AppPreferences.getSharedInstance();
        Intrinsics.checkNotNullExpressionValue(sharedInstance, "getSharedInstance(...)");
        MainApplication mainApplication = this;
        sharedInstance.init(mainApplication);
        sharedInstance.setSelectedTabIndex(0);
        sharedInstance.setSelectedCityIndex(0);
        InternetConnectionManager.getInstance().init(mainApplication);
        LocationService.getInstance().init(mainApplication);
    }
}