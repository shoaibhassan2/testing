package pk.gov.nadra.oneapp.downloadcert.views;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DownloadCertificateActivity$$ExternalSyntheticLambda2 implements Function0 {
    public /* synthetic */ DownloadCertificateActivity$$ExternalSyntheticLambda2() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return DownloadCertificateActivity.handleFailureCase$lambda$5(this.f$0);
    }
}