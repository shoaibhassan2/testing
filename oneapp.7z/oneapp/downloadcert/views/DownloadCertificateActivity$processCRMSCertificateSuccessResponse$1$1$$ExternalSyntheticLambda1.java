package pk.gov.nadra.oneapp.downloadcert.views;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1$$ExternalSyntheticLambda1 implements Function0 {
    public /* synthetic */ DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1$$ExternalSyntheticLambda1() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1.invokeSuspend$lambda$1(downloadCertificateActivity3);
    }
}