package pk.gov.nadra.oneapp.downloadcert.views;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DownloadCertificateActivity$processTrackingDataSuccessResponse$1$1$$ExternalSyntheticLambda0 implements Function0 {
    public /* synthetic */ DownloadCertificateActivity$processTrackingDataSuccessResponse$1$1$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return DownloadCertificateActivity$processTrackingDataSuccessResponse$1$1.invokeSuspend$lambda$0(downloadCertificateActivity2);
    }
}