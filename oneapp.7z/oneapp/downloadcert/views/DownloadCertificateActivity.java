package pk.gov.nadra.oneapp.downloadcert.views;

import android.R;
import android.app.Application;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.view.GravityCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Locale;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import org.apache.commons.lang3.StringUtils;
import pk.gov.nadra.oneapp.commonutils.BaseActivity;
import pk.gov.nadra.oneapp.commonutils.utils.AESEncryptionManager;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.downloadcert.databinding.ActivityDownloadCertificateBinding;
import pk.gov.nadra.oneapp.downloadcert.viewmodel.DownloadCertificateSharedViewModel;
import pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity;
import pk.gov.nadra.oneapp.models.certificate.Document;
import pk.gov.nadra.oneapp.models.certificate.DownloadCRMSCertificate;
import pk.gov.nadra.oneapp.models.certificate.DownloadCertificate;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.models.crc.TabUpdateRequest;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: DownloadCertificateActivity.kt */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0014J\b\u0010\u0010\u001a\u00020\rH\u0002J\b\u0010\u0011\u001a\u00020\rH\u0002J\u0010\u0010\u0012\u001a\u00020\r2\u0006\u0010\u0013\u001a\u00020\u0014H\u0002J\u0010\u0010\u0015\u001a\u00020\r2\u0006\u0010\u0013\u001a\u00020\u0014H\u0002J\u0010\u0010\u0016\u001a\u00020\r2\u0006\u0010\u0017\u001a\u00020\u0018H\u0002J\u0010\u0010\u0019\u001a\u00020\r2\u0006\u0010\u0017\u001a\u00020\u0018H\u0002J\u0018\u0010\u001a\u001a\u00020\r2\u0006\u0010\u001b\u001a\u00020\u00182\u0006\u0010\u001c\u001a\u00020\u001dH\u0002J\b\u0010\u001e\u001a\u00020\rH\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u001b\u0010\u0006\u001a\u00020\u00078BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\n\u0010\u000b\u001a\u0004\b\b\u0010\t¨\u0006\u001f"}, d2 = {"Lpk/gov/nadra/oneapp/downloadcert/views/DownloadCertificateActivity;", "Lpk/gov/nadra/oneapp/commonutils/BaseActivity;", "<init>", "()V", "binding", "Lpk/gov/nadra/oneapp/downloadcert/databinding/ActivityDownloadCertificateBinding;", "downloadCertificateSharedViewModel", "Lpk/gov/nadra/oneapp/downloadcert/viewmodel/DownloadCertificateSharedViewModel;", "getDownloadCertificateSharedViewModel", "()Lpk/gov/nadra/oneapp/downloadcert/viewmodel/DownloadCertificateSharedViewModel;", "downloadCertificateSharedViewModel$delegate", "Lkotlin/Lazy;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "getIntentData", "attachLayoutViews", "downloadCertificate", "trackingId", "", "downloadCRMSCertificate", "processTrackingDataSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "processCRMSCertificateSuccessResponse", "handleFailureCase", "jsonResponse", "responseCode", "", "onBackPressed", "downloadCert_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DownloadCertificateActivity extends BaseActivity {
    private ActivityDownloadCertificateBinding binding;

    /* renamed from: downloadCertificateSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy downloadCertificateSharedViewModel;

    public DownloadCertificateActivity() {
        final DownloadCertificateActivity downloadCertificateActivity = this;
        final Function0 function0 = null;
        this.downloadCertificateSharedViewModel = new ViewModelLazy(Reflection.getOrCreateKotlinClass(DownloadCertificateSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$special$$inlined$viewModels$default$2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                return downloadCertificateActivity.getViewModelStore();
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$special$$inlined$viewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                return downloadCertificateActivity.getDefaultViewModelProviderFactory();
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$special$$inlined$viewModels$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                return (function02 == null || (creationExtras = (CreationExtras) function02.invoke()) == null) ? downloadCertificateActivity.getDefaultViewModelCreationExtras() : creationExtras;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final DownloadCertificateSharedViewModel getDownloadCertificateSharedViewModel() {
        return (DownloadCertificateSharedViewModel) this.downloadCertificateSharedViewModel.getValue();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityDownloadCertificateBinding activityDownloadCertificateBindingInflate = ActivityDownloadCertificateBinding.inflate(getLayoutInflater());
        this.binding = activityDownloadCertificateBindingInflate;
        if (activityDownloadCertificateBindingInflate == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityDownloadCertificateBindingInflate = null;
        }
        setContentView(activityDownloadCertificateBindingInflate.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.white));
        new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        Application application = getApplication();
        Intrinsics.checkNotNullExpressionValue(application, "getApplication(...)");
        loaderManager.initialize(application);
        getIntentData();
    }

    private final void getIntentData() {
        if (getIntent() != null && getIntent().hasExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA)) {
            Bundle extras = getIntent().getExtras();
            Intrinsics.checkNotNull(extras);
            getDownloadCertificateSharedViewModel().setReactNativeData((ReactNativeData) new Gson().fromJson(extras.getString(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA), ReactNativeData.class));
            setTrackingId(getDownloadCertificateSharedViewModel().getReactNativeData().getTrackingId());
        }
        ActivityDownloadCertificateBinding activityDownloadCertificateBinding = this.binding;
        ActivityDownloadCertificateBinding activityDownloadCertificateBinding2 = null;
        if (activityDownloadCertificateBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityDownloadCertificateBinding = null;
        }
        activityDownloadCertificateBinding.downloadCertificateHeaderLayout.tvHeaderTrackingIdHeading.setText("Tracking ID");
        ActivityDownloadCertificateBinding activityDownloadCertificateBinding3 = this.binding;
        if (activityDownloadCertificateBinding3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        } else {
            activityDownloadCertificateBinding2 = activityDownloadCertificateBinding3;
        }
        activityDownloadCertificateBinding2.downloadCertificateHeaderLayout.tvHeaderTrackingId.setText(getTrackingId());
        SharedPreferencesTokenProvider sharedPreferencesTokenProvider = new SharedPreferencesTokenProvider(this);
        sharedPreferencesTokenProvider.saveToken(getDownloadCertificateSharedViewModel().getReactNativeData().getToken());
        sharedPreferencesTokenProvider.saveRefreshToken(getDownloadCertificateSharedViewModel().getReactNativeData().getRefreshToken());
        sharedPreferencesTokenProvider.saveAesKey(getDownloadCertificateSharedViewModel().getReactNativeData().getSessionKey());
        sharedPreferencesTokenProvider.saveDeviceId(getDownloadCertificateSharedViewModel().getReactNativeData().getDeviceId());
        sharedPreferencesTokenProvider.saveEncryptionEnabled(getDownloadCertificateSharedViewModel().getReactNativeData().getEncryptionEnabled());
        attachLayoutViews();
    }

    private final void attachLayoutViews() {
        ActivityDownloadCertificateBinding activityDownloadCertificateBinding = this.binding;
        if (activityDownloadCertificateBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityDownloadCertificateBinding = null;
        }
        activityDownloadCertificateBinding.downloadCertificateHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                DownloadCertificateActivity.attachLayoutViews$lambda$2$lambda$0(this.f$0, view);
            }
        });
        activityDownloadCertificateBinding.downloadCertificateHeaderLayout.iconHome.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                DownloadCertificateActivity.attachLayoutViews$lambda$2$lambda$1(this.f$0, view);
            }
        });
        activityDownloadCertificateBinding.downloadCertificateHeaderLayout.iconBack.setVisibility(0);
        activityDownloadCertificateBinding.downloadCertificateHeaderLayout.iconHome.setVisibility(8);
        activityDownloadCertificateBinding.downloadCertificateHeaderLayout.textTitle.setText("DIGITALCARD");
        activityDownloadCertificateBinding.downloadCertificateHeaderLayout.textSubtitle.setText("DOWNLOAD");
        activityDownloadCertificateBinding.downloadCertificateHeaderLayout.textSubtitle.setGravity(GravityCompat.START);
        activityDownloadCertificateBinding.downloadCertificateHeaderLayout.textBackUr.setTypeface(ResourcesCompat.getFont(this, pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        if (Intrinsics.areEqual(StringsKt.trim((CharSequence) getDownloadCertificateSharedViewModel().getReactNativeData().getDocType()).toString(), "birth") || Intrinsics.areEqual(StringsKt.trim((CharSequence) getDownloadCertificateSharedViewModel().getReactNativeData().getDocType()).toString(), CrmsConstants.S1_FORM_EVENT) || Intrinsics.areEqual(StringsKt.trim((CharSequence) getDownloadCertificateSharedViewModel().getReactNativeData().getDocType()).toString(), "marriage") || Intrinsics.areEqual(StringsKt.trim((CharSequence) getDownloadCertificateSharedViewModel().getReactNativeData().getDocType()).toString(), "death") || Intrinsics.areEqual(StringsKt.trim((CharSequence) getDownloadCertificateSharedViewModel().getReactNativeData().getDocType()).toString(), "divorce")) {
            activityDownloadCertificateBinding.downloadCertificateHeaderLayout.textTitle.setText(Util.INSTANCE.capitalizeWords(getDownloadCertificateSharedViewModel().getReactNativeData().getDocType()) + " Certificate");
        } else {
            TextView textView = activityDownloadCertificateBinding.downloadCertificateHeaderLayout.textTitle;
            String upperCase = getDownloadCertificateSharedViewModel().getReactNativeData().getDocType().toUpperCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            textView.setText(StringsKt.replace$default(upperCase, "_", StringUtils.SPACE, false, 4, (Object) null));
        }
        activityDownloadCertificateBinding.downloadCertificateHeaderLayout.textSubtitle.setVisibility(0);
        activityDownloadCertificateBinding.downloadCertificateHeaderLayout.tvHeaderFee.setText("");
        String trackingId = getTrackingId();
        if (trackingId == null || trackingId.length() == 0) {
            navigateToReactNativeInbox(Constant.GO_TO_INBOX);
            return;
        }
        if (Intrinsics.areEqual(StringsKt.trim((CharSequence) getDownloadCertificateSharedViewModel().getReactNativeData().getDocType()).toString(), "birth") || Intrinsics.areEqual(StringsKt.trim((CharSequence) getDownloadCertificateSharedViewModel().getReactNativeData().getDocType()).toString(), CrmsConstants.S1_FORM_EVENT) || Intrinsics.areEqual(StringsKt.trim((CharSequence) getDownloadCertificateSharedViewModel().getReactNativeData().getDocType()).toString(), "marriage") || Intrinsics.areEqual(StringsKt.trim((CharSequence) getDownloadCertificateSharedViewModel().getReactNativeData().getDocType()).toString(), "death") || Intrinsics.areEqual(StringsKt.trim((CharSequence) getDownloadCertificateSharedViewModel().getReactNativeData().getDocType()).toString(), "divorce")) {
            String trackingId2 = getTrackingId();
            downloadCRMSCertificate(trackingId2 != null ? trackingId2 : "");
        } else {
            String trackingId3 = getTrackingId();
            downloadCertificate(trackingId3 != null ? trackingId3 : "");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$2$lambda$0(DownloadCertificateActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$2$lambda$1(DownloadCertificateActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
    }

    /* compiled from: DownloadCertificateActivity.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$downloadCertificate$1", f = "DownloadCertificateActivity.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$downloadCertificate$1, reason: invalid class name and case insensitive filesystem */
    static final class C14501 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Ref.ObjectRef<TabUpdateRequest> $tabUpdateRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C14501(Ref.ObjectRef<TabUpdateRequest> objectRef, Continuation<? super C14501> continuation) {
            super(2, continuation);
            this.$tabUpdateRequest = objectRef;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return DownloadCertificateActivity.this.new C14501(this.$tabUpdateRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C14501) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(DownloadCertificateActivity.this);
            APIRequests aPIRequests = new APIRequests(DownloadCertificateActivity.this);
            TabUpdateRequest tabUpdateRequest = this.$tabUpdateRequest.element;
            final DownloadCertificateActivity downloadCertificateActivity = DownloadCertificateActivity.this;
            aPIRequests.downloadCertificates(tabUpdateRequest, new Function3() { // from class: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$downloadCertificate$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return DownloadCertificateActivity.C14501.invokeSuspend$lambda$0(downloadCertificateActivity, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(DownloadCertificateActivity downloadCertificateActivity, JsonObject jsonObject, String str, int i) {
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("DownloadCertificateRes: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getIO()), null, null, new DownloadCertificateActivity$downloadCertificate$1$1$1(downloadCertificateActivity, jsonObject, null), 3, null);
            } else {
                LoaderManager.INSTANCE.hideLoader(downloadCertificateActivity);
                downloadCertificateActivity.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [T, pk.gov.nadra.oneapp.models.crc.TabUpdateRequest] */
    private final void downloadCertificate(String trackingId) {
        Ref.ObjectRef objectRef = new Ref.ObjectRef();
        objectRef.element = new TabUpdateRequest(trackingId, null, 2, null);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C14501(objectRef, null), 3, null);
    }

    /* compiled from: DownloadCertificateActivity.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$downloadCRMSCertificate$1", f = "DownloadCertificateActivity.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$downloadCRMSCertificate$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$trackingId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return DownloadCertificateActivity.this.new AnonymousClass1(this.$trackingId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(DownloadCertificateActivity.this);
            APIRequests aPIRequests = new APIRequests(DownloadCertificateActivity.this);
            String str = this.$trackingId;
            final DownloadCertificateActivity downloadCertificateActivity = DownloadCertificateActivity.this;
            aPIRequests.downloadCRMSCertificates(str, new Function3() { // from class: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$downloadCRMSCertificate$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return DownloadCertificateActivity.AnonymousClass1.invokeSuspend$lambda$0(downloadCertificateActivity, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(DownloadCertificateActivity downloadCertificateActivity, JsonObject jsonObject, String str, int i) {
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("DownloadCertificateRes: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getIO()), null, null, new DownloadCertificateActivity$downloadCRMSCertificate$1$1$1(downloadCertificateActivity, jsonObject, null), 3, null);
            } else {
                LoaderManager.INSTANCE.hideLoader(downloadCertificateActivity);
                downloadCertificateActivity.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void downloadCRMSCertificate(String trackingId) {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(trackingId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processTrackingDataSuccessResponse(JsonObject jSonObject) throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, InvalidAlgorithmParameterException {
        String certificate;
        DownloadCertificate downloadCertificate = (DownloadCertificate) new Gson().fromJson(jSonObject.toString(), DownloadCertificate.class);
        if (Intrinsics.areEqual(getDownloadCertificateSharedViewModel().getReactNativeData().getDocType(), "DIGITALCARD")) {
            certificate = AESEncryptionManager.INSTANCE.encrypt(downloadCertificate.getCertificate(), this);
        } else {
            certificate = downloadCertificate.getCertificate();
        }
        String json = new Gson().toJson(new Document(Util.INSTANCE.getCurrentDateTime(), getDownloadCertificateSharedViewModel().getReactNativeData().getAccountHolderCnic(), getDownloadCertificateSharedViewModel().getReactNativeData().getDocType(), getTrackingId(), certificate, "Encrypted Certificate", true));
        String str = "myDownloads/" + (getDownloadCertificateSharedViewModel().getReactNativeData().getAccountHolderCnic() + '_' + getDownloadCertificateSharedViewModel().getReactNativeData().getDocType() + '_' + getDownloadCertificateSharedViewModel().getReactNativeData().getTrackingId()) + ".txt";
        Intrinsics.checkNotNull(json);
        Util.INSTANCE.writeToFile(this, str, json);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new DownloadCertificateActivity$processTrackingDataSuccessResponse$1$1(this, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processCRMSCertificateSuccessResponse(JsonObject jSonObject) {
        DownloadCRMSCertificate downloadCRMSCertificate = (DownloadCRMSCertificate) new Gson().fromJson(jSonObject.toString(), DownloadCRMSCertificate.class);
        if (Intrinsics.areEqual(downloadCRMSCertificate.getCode(), "200")) {
            String json = new Gson().toJson(new Document(Util.INSTANCE.getCurrentDateTime(), getDownloadCertificateSharedViewModel().getReactNativeData().getAccountHolderCnic(), getDownloadCertificateSharedViewModel().getReactNativeData().getDocType(), getTrackingId(), downloadCRMSCertificate.getBase64(), "Encrypted Certificate", true));
            String str = "myDownloads/" + (getDownloadCertificateSharedViewModel().getReactNativeData().getAccountHolderCnic() + '_' + getDownloadCertificateSharedViewModel().getReactNativeData().getDocType() + '_' + getDownloadCertificateSharedViewModel().getReactNativeData().getTrackingId()) + ".txt";
            Intrinsics.checkNotNull(json);
            Util.INSTANCE.writeToFile(this, str, json);
            BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1(this, null), 3, null);
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        DownloadCertificateActivity downloadCertificateActivity = this;
        String message = downloadCRMSCertificate.getMessage();
        if (message == null) {
            message = getString(pk.gov.nadra.oneapp.commonui.R.string.request_processing_failed);
            Intrinsics.checkNotNullExpressionValue(message, "getString(...)");
        }
        String str2 = message;
        String message_local = downloadCRMSCertificate.getMessage_local();
        boolean z = !(message_local == null || message_local.length() == 0);
        String message_local2 = downloadCRMSCertificate.getMessage_local();
        if (message_local2 == null) {
            message_local2 = getString(pk.gov.nadra.oneapp.commonui.R.string.request_processing_failed_urdu);
            Intrinsics.checkNotNullExpressionValue(message_local2, "getString(...)");
        }
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) downloadCertificateActivity, "Alert", str2, false, z, message_local2, (Function1) null, 72, (Object) null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(NetworkErrorHandler.INSTANCE, this, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return DownloadCertificateActivity.handleFailureCase$lambda$5(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$5(DownloadCertificateActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }
}