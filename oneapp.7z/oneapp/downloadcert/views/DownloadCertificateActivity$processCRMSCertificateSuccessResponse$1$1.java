package pk.gov.nadra.oneapp.downloadcert.views;

import android.content.Intent;
import android.text.SpannableString;
import androidx.fragment.app.FragmentActivity;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.documentwallet.views.DocumentFoldersActivity;

/* compiled from: DownloadCertificateActivity.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@DebugMetadata(c = "pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1", f = "DownloadCertificateActivity.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* loaded from: classes5.dex */
final class DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    int label;
    final /* synthetic */ DownloadCertificateActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1(DownloadCertificateActivity downloadCertificateActivity, Continuation<? super DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1> continuation) {
        super(2, continuation);
        this.this$0 = downloadCertificateActivity;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1(this.this$0, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object obj) {
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        ResultKt.throwOnFailure(obj);
        LoaderManager.INSTANCE.hideLoader(this.this$0);
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        DownloadCertificateActivity downloadCertificateActivity = this.this$0;
        SpannableString englishTextSpan$default = Util.setEnglishTextSpan$default(Util.INSTANCE, this.this$0, "Go to ID Vault", " (آئی ڈی والٹ پر جائیں)", 0, false, 12, null);
        final DownloadCertificateActivity downloadCertificateActivity2 = this.this$0;
        Function0<Unit> function0 = new Function0() { // from class: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1.invokeSuspend$lambda$0(downloadCertificateActivity2);
            }
        };
        final DownloadCertificateActivity downloadCertificateActivity3 = this.this$0;
        bottomSheetUtils.showMessageBottomSheet((FragmentActivity) downloadCertificateActivity, "Info", "Certificate downloaded successfully. You can view in ID Vault", true, (CharSequence) englishTextSpan$default, true, "سرٹیفیکیٹ کامیابی کے ساتھ ڈاؤن لوڈ ہو گیا۔ آپ آئی ڈی والٹ میں دیکھ سکتے ہیں۔", function0, new Function0() { // from class: pk.gov.nadra.oneapp.downloadcert.views.DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return DownloadCertificateActivity$processCRMSCertificateSuccessResponse$1$1.invokeSuspend$lambda$1(downloadCertificateActivity3);
            }
        });
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit invokeSuspend$lambda$0(DownloadCertificateActivity downloadCertificateActivity) {
        String str = "{\"citizenNumber\":\"" + downloadCertificateActivity.getDownloadCertificateSharedViewModel().getReactNativeData().getAccountHolderCnic() + "\"}";
        Intent intent = new Intent(downloadCertificateActivity, (Class<?>) DocumentFoldersActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, str);
        downloadCertificateActivity.startActivity(intent);
        downloadCertificateActivity.finish();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit invokeSuspend$lambda$1(DownloadCertificateActivity downloadCertificateActivity) {
        downloadCertificateActivity.finish();
        return Unit.INSTANCE;
    }
}