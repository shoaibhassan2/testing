package pk.gov.nadra.oneapp.downloadcert;

/* loaded from: classes5.dex */
public final class R {

    public static final class id {
        public static int download_certificate_header_layout = 0x7f0a0537;

        private id() {
        }
    }

    public static final class layout {
        public static int activity_download_certificate = 0x7f0d0032;

        private layout() {
        }
    }

    public static final class style {
        public static int TransparentActivityTheme = 0x7f15034b;

        private style() {
        }
    }

    private R() {
    }
}