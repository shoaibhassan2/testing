package pk.gov.nadra.oneapp.downloadcert.viewmodel;

import androidx.lifecycle.ViewModel;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;

/* compiled from: DownloadCertificateSharedViewModel.kt */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Lpk/gov/nadra/oneapp/downloadcert/viewmodel/DownloadCertificateSharedViewModel;", "Landroidx/lifecycle/ViewModel;", "<init>", "()V", "reactNativeData", "Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "getReactNativeData", "()Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "setReactNativeData", "(Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;)V", "downloadCert_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DownloadCertificateSharedViewModel extends ViewModel {
    private ReactNativeData reactNativeData = new ReactNativeData(null, null, null, null, null, null, null, false, false, false, null, null, false, null, null, null, false, null, false, false, false, false, null, null, false, false, false, null, false, false, null, null, null, false, null, null, null, false, false, null, null, null, null, false, null, null, null, null, null, null, -1, 262143, null);

    public final ReactNativeData getReactNativeData() {
        return this.reactNativeData;
    }

    public final void setReactNativeData(ReactNativeData reactNativeData) {
        Intrinsics.checkNotNullParameter(reactNativeData, "<set-?>");
        this.reactNativeData = reactNativeData;
    }
}