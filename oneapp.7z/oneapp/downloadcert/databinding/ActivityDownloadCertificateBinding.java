package pk.gov.nadra.oneapp.downloadcert.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBinding;
import pk.gov.nadra.oneapp.downloadcert.R;

/* loaded from: classes5.dex */
public final class ActivityDownloadCertificateBinding implements ViewBinding {
    public final UpdatedHeaderLayoutBinding downloadCertificateHeaderLayout;
    private final ConstraintLayout rootView;

    private ActivityDownloadCertificateBinding(ConstraintLayout constraintLayout, UpdatedHeaderLayoutBinding updatedHeaderLayoutBinding) {
        this.rootView = constraintLayout;
        this.downloadCertificateHeaderLayout = updatedHeaderLayoutBinding;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivityDownloadCertificateBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivityDownloadCertificateBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_download_certificate, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivityDownloadCertificateBinding bind(View view) {
        int i = R.id.download_certificate_header_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            return new ActivityDownloadCertificateBinding((ConstraintLayout) view, UpdatedHeaderLayoutBinding.bind(viewFindChildViewById));
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}