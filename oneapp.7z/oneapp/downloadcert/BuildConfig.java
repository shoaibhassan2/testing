package pk.gov.nadra.oneapp.downloadcert;

/* loaded from: classes5.dex */
public final class BuildConfig {
    public static final String BASE_URL = "https://shanakht.nadra.gov.pk";
    public static final String BASE_URL_IAM = "https://accounts.nadra.gov.pk";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "Production";
    public static final String LIBRARY_PACKAGE_NAME = "pk.gov.nadra.oneapp.downloadcert";
}