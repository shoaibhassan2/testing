package pk.gov.nadra.oneapp.polc.viewmodel;

import androidx.lifecycle.ViewModel;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;

/* compiled from: PolcSharedViewModel.kt */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001a\u0010\n\u001a\u00020\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000f¨\u0006\u0010"}, d2 = {"Lpk/gov/nadra/oneapp/polc/viewmodel/PolcSharedViewModel;", "Landroidx/lifecycle/ViewModel;", "<init>", "()V", "reactNativeData", "Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "getReactNativeData", "()Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "setReactNativeData", "(Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;)V", "trackingId", "", "getTrackingId", "()Ljava/lang/String;", "setTrackingId", "(Ljava/lang/String;)V", "polc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes6.dex */
public final class PolcSharedViewModel extends ViewModel {
    private ReactNativeData reactNativeData = new ReactNativeData(null, null, null, null, null, null, null, false, false, false, null, null, false, null, null, null, false, null, false, false, false, false, null, null, false, false, false, null, false, false, null, null, null, false, null, null, null, false, false, null, null, null, null, false, null, null, null, null, null, null, -1, 262143, null);
    private String trackingId = "";

    public final ReactNativeData getReactNativeData() {
        return this.reactNativeData;
    }

    public final void setReactNativeData(ReactNativeData reactNativeData) {
        Intrinsics.checkNotNullParameter(reactNativeData, "<set-?>");
        this.reactNativeData = reactNativeData;
    }

    public final String getTrackingId() {
        return this.trackingId;
    }

    public final void setTrackingId(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.trackingId = str;
    }
}