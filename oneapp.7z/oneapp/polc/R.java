package pk.gov.nadra.oneapp.polc;

/* loaded from: classes6.dex */
public final class R {

    public static final class id {
        public static int applicant_cnic_layout = 0x7f0a0129;
        public static int applicant_detail_layout = 0x7f0a012b;
        public static int application_detail_heading_layout = 0x7f0a0134;
        public static int application_fee_heading_textView = 0x7f0a0136;
        public static int application_fee_textView = 0x7f0a0137;
        public static int application_type_layout = 0x7f0a0139;
        public static int category_fee_cardView = 0x7f0a029f;
        public static int category_line_view = 0x7f0a02a0;
        public static int category_type_textView = 0x7f0a02a3;
        public static int contact_detail_heading_layout = 0x7f0a0372;
        public static int contact_number_layout = 0x7f0a0373;
        public static int delivery_fee_heading_textView = 0x7f0a0475;
        public static int delivery_fee_textView = 0x7f0a0476;
        public static int document_type_layout = 0x7f0a0519;
        public static int email_layout = 0x7f0a0565;
        public static int guideline2 = 0x7f0a06d1;
        public static int nav_graph = 0x7f0a0959;
        public static int new_application_scrollView = 0x7f0a096d;
        public static int phone_number_textInputEditText = 0x7f0a0a4f;
        public static int polcSubmitSuccessFragment = 0x7f0a0a7d;
        public static int polc_header_layout = 0x7f0a0a7e;
        public static int polc_nav_host_fragment = 0x7f0a0a7f;
        public static int priority_processing_recyclerView = 0x7f0a0a97;
        public static int startApplicationPolcFragment = 0x7f0a0c6a;
        public static int start_application_button_layout = 0x7f0a0c6f;
        public static int submitted_successfully_detail_textView = 0x7f0a0c84;
        public static int submitted_successfully_detail_urdu_textView = 0x7f0a0c86;
        public static int submitted_successfully_textView = 0x7f0a0c87;
        public static int submitted_successfully_urdu_textView = 0x7f0a0c89;
        public static int success_icon_imageView = 0x7f0a0c8a;
        public static int total_fee_textView = 0x7f0a0d29;
        public static int total_heading_textView = 0x7f0a0d2a;
        public static int tv_duration_note_heading = 0x7f0a0d74;
        public static int tv_priority_heading = 0x7f0a0dad;
        public static int verify_applicant_fingerprint_button_layout = 0x7f0a0e4c;

        private id() {
        }
    }

    public static final class layout {
        public static int activity_polc = 0x7f0d0051;
        public static int polc_submit_success_fragment = 0x7f0d01f5;
        public static int start_application_polc_fragment = 0x7f0d0247;

        private layout() {
        }
    }

    public static final class navigation {
        public static int polc_nav_graph = 0x7f110015;

        private navigation() {
        }
    }

    private R() {
    }
}