package pk.gov.nadra.oneapp.polc.views;

import android.R;
import android.app.Application;
import android.os.Bundle;
import android.view.View;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcherKt;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.fragment.NavHostFragment;
import com.google.gson.Gson;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import pk.gov.nadra.oneapp.commonutils.BaseActivity;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.polc.databinding.ActivityPolcBinding;
import pk.gov.nadra.oneapp.polc.viewmodel.PolcSharedViewModel;

/* compiled from: PolcActivity.kt */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u001c\u001a\u00020\u001d2\b\u0010\u001e\u001a\u0004\u0018\u00010\u001fH\u0014J\b\u0010 \u001a\u00020\u001dH\u0002J\b\u0010!\u001a\u00020\u001dH\u0002J\u0006\u0010\"\u001a\u00020\u001dJ\b\u0010#\u001a\u00020\u001dH\u0016J\b\u0010$\u001a\u00020\u001dH\u0014R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001b\u0010\n\u001a\u00020\u000b8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\f\u0010\rR\u001a\u0010\u0010\u001a\u00020\u0011X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u001a\u0010\u0016\u001a\u00020\u0017X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001b¨\u0006%"}, d2 = {"Lpk/gov/nadra/oneapp/polc/views/PolcActivity;", "Lpk/gov/nadra/oneapp/commonutils/BaseActivity;", "<init>", "()V", "binding", "Lpk/gov/nadra/oneapp/polc/databinding/ActivityPolcBinding;", "getBinding", "()Lpk/gov/nadra/oneapp/polc/databinding/ActivityPolcBinding;", "setBinding", "(Lpk/gov/nadra/oneapp/polc/databinding/ActivityPolcBinding;)V", "polcSharedViewModel", "Lpk/gov/nadra/oneapp/polc/viewmodel/PolcSharedViewModel;", "getPolcSharedViewModel", "()Lpk/gov/nadra/oneapp/polc/viewmodel/PolcSharedViewModel;", "polcSharedViewModel$delegate", "Lkotlin/Lazy;", "navController", "Landroidx/navigation/NavController;", "getNavController", "()Landroidx/navigation/NavController;", "setNavController", "(Landroidx/navigation/NavController;)V", "navHostFragment", "Landroidx/navigation/fragment/NavHostFragment;", "getNavHostFragment", "()Landroidx/navigation/fragment/NavHostFragment;", "setNavHostFragment", "(Landroidx/navigation/fragment/NavHostFragment;)V", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "initView", "getIntentData", "popupFromNavHost", "onBackPressed", "onDestroy", "polc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes6.dex */
public final class PolcActivity extends BaseActivity {
    public ActivityPolcBinding binding;
    public NavController navController;
    public NavHostFragment navHostFragment;

    /* renamed from: polcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy polcSharedViewModel;

    public PolcActivity() {
        final PolcActivity polcActivity = this;
        final Function0 function0 = null;
        this.polcSharedViewModel = new ViewModelLazy(Reflection.getOrCreateKotlinClass(PolcSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.polc.views.PolcActivity$special$$inlined$viewModels$default$2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                return polcActivity.getViewModelStore();
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.polc.views.PolcActivity$special$$inlined$viewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                return polcActivity.getDefaultViewModelProviderFactory();
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.polc.views.PolcActivity$special$$inlined$viewModels$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                return (function02 == null || (creationExtras = (CreationExtras) function02.invoke()) == null) ? polcActivity.getDefaultViewModelCreationExtras() : creationExtras;
            }
        });
    }

    public final ActivityPolcBinding getBinding() {
        ActivityPolcBinding activityPolcBinding = this.binding;
        if (activityPolcBinding != null) {
            return activityPolcBinding;
        }
        Intrinsics.throwUninitializedPropertyAccessException("binding");
        return null;
    }

    public final void setBinding(ActivityPolcBinding activityPolcBinding) {
        Intrinsics.checkNotNullParameter(activityPolcBinding, "<set-?>");
        this.binding = activityPolcBinding;
    }

    private final PolcSharedViewModel getPolcSharedViewModel() {
        return (PolcSharedViewModel) this.polcSharedViewModel.getValue();
    }

    public final NavController getNavController() {
        NavController navController = this.navController;
        if (navController != null) {
            return navController;
        }
        Intrinsics.throwUninitializedPropertyAccessException("navController");
        return null;
    }

    public final void setNavController(NavController navController) {
        Intrinsics.checkNotNullParameter(navController, "<set-?>");
        this.navController = navController;
    }

    public final NavHostFragment getNavHostFragment() {
        NavHostFragment navHostFragment = this.navHostFragment;
        if (navHostFragment != null) {
            return navHostFragment;
        }
        Intrinsics.throwUninitializedPropertyAccessException("navHostFragment");
        return null;
    }

    public final void setNavHostFragment(NavHostFragment navHostFragment) {
        Intrinsics.checkNotNullParameter(navHostFragment, "<set-?>");
        this.navHostFragment = navHostFragment;
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setBinding(ActivityPolcBinding.inflate(getLayoutInflater()));
        setContentView(getBinding().getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.white));
        new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
        ActivityPolcBinding binding = getBinding();
        binding.polcHeaderLayout.tvHeaderTitle.setText("Proof of Life");
        binding.polcHeaderLayout.ivHeaderClose.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.polc.views.PolcActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                PolcActivity.onCreate$lambda$1$lambda$0(this.f$0, view);
            }
        });
        setFragmentId(pk.gov.nadra.oneapp.polc.R.id.polcSubmitSuccessFragment);
        getIntentData();
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        Application application = getApplication();
        Intrinsics.checkNotNullExpressionValue(application, "getApplication(...)");
        loaderManager.initialize(application);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$1$lambda$0(PolcActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
    }

    private final void initView() {
        Fragment fragmentFindFragmentById = getSupportFragmentManager().findFragmentById(pk.gov.nadra.oneapp.polc.R.id.polc_nav_host_fragment);
        Intrinsics.checkNotNull(fragmentFindFragmentById, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
        setNavHostFragment((NavHostFragment) fragmentFindFragmentById);
        setNavController(getNavHostFragment().getNavController());
        getNavController().setGraph(getNavController().getNavInflater().inflate(pk.gov.nadra.oneapp.polc.R.navigation.polc_nav_graph));
        initBaseView(getNavController());
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        OnBackPressedDispatcherKt.addCallback$default(getOnBackPressedDispatcher(), this, false, new Function1() { // from class: pk.gov.nadra.oneapp.polc.views.PolcActivity$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return PolcActivity.initView$lambda$2(this.f$0, (OnBackPressedCallback) obj);
            }
        }, 2, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initView$lambda$2(PolcActivity this$0, OnBackPressedCallback addCallback) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(addCallback, "$this$addCallback");
        if (!LoaderManager.INSTANCE.isLoaderVisible()) {
            NavDestination currentDestination = this$0.getNavController().getCurrentDestination();
            Integer numValueOf = currentDestination != null ? Integer.valueOf(currentDestination.getId()) : null;
            int i = pk.gov.nadra.oneapp.polc.R.id.startApplicationPolcFragment;
            if (numValueOf != null && numValueOf.intValue() == i) {
                this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
            } else {
                int i2 = pk.gov.nadra.oneapp.polc.R.id.polcSubmitSuccessFragment;
                if (numValueOf != null && numValueOf.intValue() == i2) {
                    this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
                }
            }
        }
        return Unit.INSTANCE;
    }

    private final void getIntentData() {
        if (getIntent() != null && getIntent().hasExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA)) {
            Bundle extras = getIntent().getExtras();
            Intrinsics.checkNotNull(extras);
            getPolcSharedViewModel().setReactNativeData((ReactNativeData) new Gson().fromJson(extras.getString(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA), ReactNativeData.class));
            getSharedViewModel().setReactNativeData(getPolcSharedViewModel().getReactNativeData());
        }
        SharedPreferencesTokenProvider sharedPreferencesTokenProvider = new SharedPreferencesTokenProvider(this);
        sharedPreferencesTokenProvider.saveToken(getPolcSharedViewModel().getReactNativeData().getToken());
        sharedPreferencesTokenProvider.saveRefreshToken(getPolcSharedViewModel().getReactNativeData().getRefreshToken());
        sharedPreferencesTokenProvider.saveAesKey(getPolcSharedViewModel().getReactNativeData().getSessionKey());
        sharedPreferencesTokenProvider.saveDeviceId(getPolcSharedViewModel().getReactNativeData().getDeviceId());
        sharedPreferencesTokenProvider.saveEncryptionEnabled(getPolcSharedViewModel().getReactNativeData().getEncryptionEnabled());
        initView();
    }

    public final void popupFromNavHost() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        PolcActivity polcActivity = this;
        Util.INSTANCE.deleteTempPhotoDirectory(polcActivity, polcActivity);
    }
}