package pk.gov.nadra.oneapp.polc.views;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class PolcActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public /* synthetic */ PolcActivity$$ExternalSyntheticLambda0() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        PolcActivity.onCreate$lambda$1$lambda$0(this.f$0, view);
    }
}