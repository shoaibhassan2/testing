package pk.gov.nadra.oneapp.polc.views;

import androidx.activity.OnBackPressedCallback;
import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class PolcActivity$$ExternalSyntheticLambda1 implements Function1 {
    public /* synthetic */ PolcActivity$$ExternalSyntheticLambda1() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return PolcActivity.initView$lambda$2(this.f$0, (OnBackPressedCallback) obj);
    }
}