package pk.gov.nadra.oneapp.polc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentContainerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.PartialHeaderLayoutBinding;
import pk.gov.nadra.oneapp.polc.R;

/* loaded from: classes6.dex */
public final class ActivityPolcBinding implements ViewBinding {
    public final PartialHeaderLayoutBinding polcHeaderLayout;
    public final FragmentContainerView polcNavHostFragment;
    private final ConstraintLayout rootView;

    private ActivityPolcBinding(ConstraintLayout constraintLayout, PartialHeaderLayoutBinding partialHeaderLayoutBinding, FragmentContainerView fragmentContainerView) {
        this.rootView = constraintLayout;
        this.polcHeaderLayout = partialHeaderLayoutBinding;
        this.polcNavHostFragment = fragmentContainerView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivityPolcBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivityPolcBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_polc, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivityPolcBinding bind(View view) {
        int i = R.id.polc_header_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            PartialHeaderLayoutBinding partialHeaderLayoutBindingBind = PartialHeaderLayoutBinding.bind(viewFindChildViewById);
            int i2 = R.id.polc_nav_host_fragment;
            FragmentContainerView fragmentContainerView = (FragmentContainerView) ViewBindings.findChildViewById(view, i2);
            if (fragmentContainerView != null) {
                return new ActivityPolcBinding((ConstraintLayout) view, partialHeaderLayoutBindingBind, fragmentContainerView);
            }
            i = i2;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}