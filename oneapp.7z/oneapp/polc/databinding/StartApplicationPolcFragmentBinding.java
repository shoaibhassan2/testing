package pk.gov.nadra.oneapp.polc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Guideline;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepActionLayoutBinding;
import pk.gov.nadra.oneapp.polc.R;

/* loaded from: classes6.dex */
public final class StartApplicationPolcFragmentBinding implements ViewBinding {
    public final MaskedEdittextLayoutBinding applicantCnicLayout;
    public final ConstraintLayout applicantDetailLayout;
    public final UpdatedStepActionLayoutBinding applicationDetailHeadingLayout;
    public final TextView applicationFeeHeadingTextView;
    public final TextView applicationFeeTextView;
    public final AutocompletetextviewLayoutBinding applicationTypeLayout;
    public final MaterialCardView categoryFeeCardView;
    public final View categoryLineView;
    public final TextView categoryTypeTextView;
    public final UpdatedStepActionLayoutBinding contactDetailHeadingLayout;
    public final TextInputLayout contactNumberLayout;
    public final TextView deliveryFeeHeadingTextView;
    public final TextView deliveryFeeTextView;
    public final AutocompletetextviewLayoutBinding documentTypeLayout;
    public final EdittextLayoutBinding emailLayout;
    public final Guideline guideline2;
    public final ScrollView newApplicationScrollView;
    public final TextInputEditText phoneNumberTextInputEditText;
    public final UpdatedHeaderLayoutBackTitleBinding polcHeaderLayout;
    public final RecyclerView priorityProcessingRecyclerView;
    private final ConstraintLayout rootView;
    public final TextView totalFeeTextView;
    public final TextView totalHeadingTextView;
    public final TextView tvDurationNoteHeading;
    public final TextView tvPriorityHeading;
    public final ButtonLayoutBinding verifyApplicantFingerprintButtonLayout;

    private StartApplicationPolcFragmentBinding(ConstraintLayout constraintLayout, MaskedEdittextLayoutBinding maskedEdittextLayoutBinding, ConstraintLayout constraintLayout2, UpdatedStepActionLayoutBinding updatedStepActionLayoutBinding, TextView textView, TextView textView2, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding, MaterialCardView materialCardView, View view, TextView textView3, UpdatedStepActionLayoutBinding updatedStepActionLayoutBinding2, TextInputLayout textInputLayout, TextView textView4, TextView textView5, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding2, EdittextLayoutBinding edittextLayoutBinding, Guideline guideline, ScrollView scrollView, TextInputEditText textInputEditText, UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBinding, RecyclerView recyclerView, TextView textView6, TextView textView7, TextView textView8, TextView textView9, ButtonLayoutBinding buttonLayoutBinding) {
        this.rootView = constraintLayout;
        this.applicantCnicLayout = maskedEdittextLayoutBinding;
        this.applicantDetailLayout = constraintLayout2;
        this.applicationDetailHeadingLayout = updatedStepActionLayoutBinding;
        this.applicationFeeHeadingTextView = textView;
        this.applicationFeeTextView = textView2;
        this.applicationTypeLayout = autocompletetextviewLayoutBinding;
        this.categoryFeeCardView = materialCardView;
        this.categoryLineView = view;
        this.categoryTypeTextView = textView3;
        this.contactDetailHeadingLayout = updatedStepActionLayoutBinding2;
        this.contactNumberLayout = textInputLayout;
        this.deliveryFeeHeadingTextView = textView4;
        this.deliveryFeeTextView = textView5;
        this.documentTypeLayout = autocompletetextviewLayoutBinding2;
        this.emailLayout = edittextLayoutBinding;
        this.guideline2 = guideline;
        this.newApplicationScrollView = scrollView;
        this.phoneNumberTextInputEditText = textInputEditText;
        this.polcHeaderLayout = updatedHeaderLayoutBackTitleBinding;
        this.priorityProcessingRecyclerView = recyclerView;
        this.totalFeeTextView = textView6;
        this.totalHeadingTextView = textView7;
        this.tvDurationNoteHeading = textView8;
        this.tvPriorityHeading = textView9;
        this.verifyApplicantFingerprintButtonLayout = buttonLayoutBinding;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static StartApplicationPolcFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static StartApplicationPolcFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.start_application_polc_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static StartApplicationPolcFragmentBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        View viewFindChildViewById4;
        View viewFindChildViewById5;
        View viewFindChildViewById6;
        View viewFindChildViewById7;
        int i = R.id.applicant_cnic_layout;
        View viewFindChildViewById8 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById8 != null) {
            MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById8);
            i = R.id.applicant_detail_layout;
            ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(view, i);
            if (constraintLayout != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.application_detail_heading_layout))) != null) {
                UpdatedStepActionLayoutBinding updatedStepActionLayoutBindingBind = UpdatedStepActionLayoutBinding.bind(viewFindChildViewById);
                i = R.id.application_fee_heading_textView;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    i = R.id.application_fee_textView;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView2 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.application_type_layout))) != null) {
                        AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById2);
                        i = R.id.category_fee_cardView;
                        MaterialCardView materialCardView = (MaterialCardView) ViewBindings.findChildViewById(view, i);
                        if (materialCardView != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(view, (i = R.id.category_line_view))) != null) {
                            i = R.id.category_type_textView;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView3 != null && (viewFindChildViewById4 = ViewBindings.findChildViewById(view, (i = R.id.contact_detail_heading_layout))) != null) {
                                UpdatedStepActionLayoutBinding updatedStepActionLayoutBindingBind2 = UpdatedStepActionLayoutBinding.bind(viewFindChildViewById4);
                                i = R.id.contact_number_layout;
                                TextInputLayout textInputLayout = (TextInputLayout) ViewBindings.findChildViewById(view, i);
                                if (textInputLayout != null) {
                                    i = R.id.delivery_fee_heading_textView;
                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView4 != null) {
                                        i = R.id.delivery_fee_textView;
                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                        if (textView5 != null && (viewFindChildViewById5 = ViewBindings.findChildViewById(view, (i = R.id.document_type_layout))) != null) {
                                            AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind2 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById5);
                                            i = R.id.email_layout;
                                            View viewFindChildViewById9 = ViewBindings.findChildViewById(view, i);
                                            if (viewFindChildViewById9 != null) {
                                                EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById9);
                                                i = R.id.guideline2;
                                                Guideline guideline = (Guideline) ViewBindings.findChildViewById(view, i);
                                                if (guideline != null) {
                                                    i = R.id.new_application_scrollView;
                                                    ScrollView scrollView = (ScrollView) ViewBindings.findChildViewById(view, i);
                                                    if (scrollView != null) {
                                                        i = R.id.phone_number_textInputEditText;
                                                        TextInputEditText textInputEditText = (TextInputEditText) ViewBindings.findChildViewById(view, i);
                                                        if (textInputEditText != null && (viewFindChildViewById6 = ViewBindings.findChildViewById(view, (i = R.id.polc_header_layout))) != null) {
                                                            UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById6);
                                                            i = R.id.priority_processing_recyclerView;
                                                            RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
                                                            if (recyclerView != null) {
                                                                i = R.id.total_fee_textView;
                                                                TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                if (textView6 != null) {
                                                                    i = R.id.total_heading_textView;
                                                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                    if (textView7 != null) {
                                                                        i = R.id.tv_duration_note_heading;
                                                                        TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                        if (textView8 != null) {
                                                                            i = R.id.tv_priority_heading;
                                                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                            if (textView9 != null && (viewFindChildViewById7 = ViewBindings.findChildViewById(view, (i = R.id.verify_applicant_fingerprint_button_layout))) != null) {
                                                                                return new StartApplicationPolcFragmentBinding((ConstraintLayout) view, maskedEdittextLayoutBindingBind, constraintLayout, updatedStepActionLayoutBindingBind, textView, textView2, autocompletetextviewLayoutBindingBind, materialCardView, viewFindChildViewById3, textView3, updatedStepActionLayoutBindingBind2, textInputLayout, textView4, textView5, autocompletetextviewLayoutBindingBind2, edittextLayoutBindingBind, guideline, scrollView, textInputEditText, updatedHeaderLayoutBackTitleBindingBind, recyclerView, textView6, textView7, textView8, textView9, ButtonLayoutBinding.bind(viewFindChildViewById7));
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}