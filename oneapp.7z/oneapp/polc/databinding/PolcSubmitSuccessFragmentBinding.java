package pk.gov.nadra.oneapp.polc.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.polc.R;

/* loaded from: classes6.dex */
public final class PolcSubmitSuccessFragmentBinding implements ViewBinding {
    private final ConstraintLayout rootView;
    public final ButtonLayoutBinding startApplicationButtonLayout;
    public final TextView submittedSuccessfullyDetailTextView;
    public final TextView submittedSuccessfullyDetailUrduTextView;
    public final TextView submittedSuccessfullyTextView;
    public final TextView submittedSuccessfullyUrduTextView;
    public final ImageView successIconImageView;

    private PolcSubmitSuccessFragmentBinding(ConstraintLayout constraintLayout, ButtonLayoutBinding buttonLayoutBinding, TextView textView, TextView textView2, TextView textView3, TextView textView4, ImageView imageView) {
        this.rootView = constraintLayout;
        this.startApplicationButtonLayout = buttonLayoutBinding;
        this.submittedSuccessfullyDetailTextView = textView;
        this.submittedSuccessfullyDetailUrduTextView = textView2;
        this.submittedSuccessfullyTextView = textView3;
        this.submittedSuccessfullyUrduTextView = textView4;
        this.successIconImageView = imageView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static PolcSubmitSuccessFragmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static PolcSubmitSuccessFragmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.polc_submit_success_fragment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static PolcSubmitSuccessFragmentBinding bind(View view) {
        int i = R.id.start_application_button_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById);
            i = R.id.submitted_successfully_detail_textView;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView != null) {
                i = R.id.submitted_successfully_detail_urdu_textView;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView2 != null) {
                    i = R.id.submitted_successfully_textView;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView3 != null) {
                        i = R.id.submitted_successfully_urdu_textView;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView4 != null) {
                            i = R.id.success_icon_imageView;
                            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                            if (imageView != null) {
                                return new PolcSubmitSuccessFragmentBinding((ConstraintLayout) view, buttonLayoutBindingBind, textView, textView2, textView3, textView4, imageView);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}