package pk.gov.nadra.oneapp.polc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class PolcSubmitSuccessFragment$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public /* synthetic */ PolcSubmitSuccessFragment$$ExternalSyntheticLambda0() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        PolcSubmitSuccessFragment.onViewCreated$lambda$1$lambda$0(this.f$0, view);
    }
}