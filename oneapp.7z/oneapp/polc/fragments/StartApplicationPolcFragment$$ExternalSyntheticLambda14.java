package pk.gov.nadra.oneapp.polc.fragments;

import android.view.ViewTreeObserver;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class StartApplicationPolcFragment$$ExternalSyntheticLambda14 implements ViewTreeObserver.OnGlobalLayoutListener {
    public /* synthetic */ StartApplicationPolcFragment$$ExternalSyntheticLambda14() {
    }

    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
    public final void onGlobalLayout() {
        StartApplicationPolcFragment.attachLayoutViews$lambda$9$lambda$5(this.f$0);
    }
}