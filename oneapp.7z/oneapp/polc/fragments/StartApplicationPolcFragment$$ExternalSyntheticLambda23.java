package pk.gov.nadra.oneapp.polc.fragments;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class StartApplicationPolcFragment$$ExternalSyntheticLambda23 implements Runnable {
    public /* synthetic */ StartApplicationPolcFragment$$ExternalSyntheticLambda23() {
    }

    @Override // java.lang.Runnable
    public final void run() {
        StartApplicationPolcFragment.scrollToBottomIfNeeded$lambda$54(this.f$0);
    }
}