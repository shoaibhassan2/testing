package pk.gov.nadra.oneapp.polc.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.commonutils.viewmodel.SharedViewModel;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.documentwallet.views.DocumentWalletActivity;
import pk.gov.nadra.oneapp.polc.databinding.PolcSubmitSuccessFragmentBinding;
import pk.gov.nadra.oneapp.polc.viewmodel.PolcSharedViewModel;
import pk.gov.nadra.oneapp.polc.views.PolcActivity;

/* compiled from: PolcSubmitSuccessFragment.kt */
@Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001dH\u0016J\u0010\u0010\u001e\u001a\u00020\u001b2\u0006\u0010\u001f\u001a\u00020 H\u0016J$\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020$2\b\u0010%\u001a\u0004\u0018\u00010&2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001dH\u0016J\u001a\u0010'\u001a\u00020\u001b2\u0006\u0010(\u001a\u00020\"2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001dH\u0016R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u001b\u0010\n\u001a\u00020\u000b8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000e\u0010\t\u001a\u0004\b\f\u0010\rR\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\u00020\u00108BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\u0015X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019¨\u0006)"}, d2 = {"Lpk/gov/nadra/oneapp/polc/fragments/PolcSubmitSuccessFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "polcSharedViewModel", "Lpk/gov/nadra/oneapp/polc/viewmodel/PolcSharedViewModel;", "getPolcSharedViewModel", "()Lpk/gov/nadra/oneapp/polc/viewmodel/PolcSharedViewModel;", "polcSharedViewModel$delegate", "Lkotlin/Lazy;", "sharedViewModel", "Lpk/gov/nadra/oneapp/commonutils/viewmodel/SharedViewModel;", "getSharedViewModel", "()Lpk/gov/nadra/oneapp/commonutils/viewmodel/SharedViewModel;", "sharedViewModel$delegate", "_binding", "Lpk/gov/nadra/oneapp/polc/databinding/PolcSubmitSuccessFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/polc/databinding/PolcSubmitSuccessFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/polc/views/PolcActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/polc/views/PolcActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/polc/views/PolcActivity;)V", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onAttach", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "onViewCreated", Promotion.ACTION_VIEW, "polc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes6.dex */
public final class PolcSubmitSuccessFragment extends Fragment {
    private PolcSubmitSuccessFragmentBinding _binding;
    public PolcActivity activity;

    /* renamed from: polcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy polcSharedViewModel;

    /* renamed from: sharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy sharedViewModel;

    public PolcSubmitSuccessFragment() {
        final PolcSubmitSuccessFragment polcSubmitSuccessFragment = this;
        final Function0 function0 = null;
        this.polcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(polcSubmitSuccessFragment, Reflection.getOrCreateKotlinClass(PolcSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.polc.fragments.PolcSubmitSuccessFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = polcSubmitSuccessFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.polc.fragments.PolcSubmitSuccessFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = polcSubmitSuccessFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.polc.fragments.PolcSubmitSuccessFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = polcSubmitSuccessFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        this.sharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(polcSubmitSuccessFragment, Reflection.getOrCreateKotlinClass(SharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.polc.fragments.PolcSubmitSuccessFragment$special$$inlined$activityViewModels$default$4
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = polcSubmitSuccessFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.polc.fragments.PolcSubmitSuccessFragment$special$$inlined$activityViewModels$default$5
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = polcSubmitSuccessFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.polc.fragments.PolcSubmitSuccessFragment$special$$inlined$activityViewModels$default$6
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = polcSubmitSuccessFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    private final PolcSharedViewModel getPolcSharedViewModel() {
        return (PolcSharedViewModel) this.polcSharedViewModel.getValue();
    }

    private final SharedViewModel getSharedViewModel() {
        return (SharedViewModel) this.sharedViewModel.getValue();
    }

    private final PolcSubmitSuccessFragmentBinding getBinding() {
        PolcSubmitSuccessFragmentBinding polcSubmitSuccessFragmentBinding = this._binding;
        Intrinsics.checkNotNull(polcSubmitSuccessFragmentBinding);
        return polcSubmitSuccessFragmentBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final PolcActivity getActivity() {
        PolcActivity polcActivity = this.activity;
        if (polcActivity != null) {
            return polcActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(PolcActivity polcActivity) {
        Intrinsics.checkNotNullParameter(polcActivity, "<set-?>");
        this.activity = polcActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getPolcSharedViewModel().setTrackingId(getSharedViewModel().getTrackingId());
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.polc.views.PolcActivity");
        setActivity((PolcActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = PolcSubmitSuccessFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        PolcSubmitSuccessFragmentBinding binding = getBinding();
        binding.startApplicationButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Go to ID Vault", " (آئی ڈی والٹ پر جائیں)", 0, false, 12, null));
        binding.startApplicationButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.polc.fragments.PolcSubmitSuccessFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                PolcSubmitSuccessFragment.onViewCreated$lambda$1$lambda$0(this.f$0, view2);
            }
        });
        binding.submittedSuccessfullyDetailTextView.setText(getString(R.string.submitted_successfully_two, getPolcSharedViewModel().getTrackingId()));
        binding.submittedSuccessfullyDetailUrduTextView.setText(getString(R.string.submitted_successfully_two_urdu, getPolcSharedViewModel().getTrackingId()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$1$lambda$0(PolcSubmitSuccessFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
        String str = "{\"citizenNumber\":\"" + this$0.getPolcSharedViewModel().getReactNativeData().getAccountHolderCnic() + "\"}";
        Intent intent = new Intent(this$0.getActivity(), (Class<?>) DocumentWalletActivity.class);
        intent.putExtra("FOLDER_NAME", "POLC");
        intent.putExtra("VISIBLE_NAME", "POLC");
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, str);
        this$0.startActivity(intent);
    }
}