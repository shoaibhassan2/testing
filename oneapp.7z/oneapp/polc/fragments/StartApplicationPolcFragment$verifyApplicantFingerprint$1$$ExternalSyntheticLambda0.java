package pk.gov.nadra.oneapp.polc.fragments;

import com.google.gson.JsonObject;
import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class StartApplicationPolcFragment$verifyApplicantFingerprint$1$$ExternalSyntheticLambda0 implements Function3 {
    public /* synthetic */ StartApplicationPolcFragment$verifyApplicantFingerprint$1$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return StartApplicationPolcFragment.C15971.invokeSuspend$lambda$0(startApplicationPolcFragment, (JsonObject) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}