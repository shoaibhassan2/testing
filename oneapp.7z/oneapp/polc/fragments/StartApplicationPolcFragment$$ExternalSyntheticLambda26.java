package pk.gov.nadra.oneapp.polc.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import com.google.gson.JsonSyntaxException;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class StartApplicationPolcFragment$$ExternalSyntheticLambda26 implements ActivityResultCallback {
    public /* synthetic */ StartApplicationPolcFragment$$ExternalSyntheticLambda26() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) throws JsonSyntaxException {
        StartApplicationPolcFragment.fingerprintLauncher$lambda$15(this.f$0, (ActivityResult) obj);
    }
}