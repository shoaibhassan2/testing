package pk.gov.nadra.oneapp.polc.fragments;

import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class StartApplicationPolcFragment$$ExternalSyntheticLambda16 implements Function1 {
    public /* synthetic */ StartApplicationPolcFragment$$ExternalSyntheticLambda16() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return StartApplicationPolcFragment.initPermissions$lambda$60(this.f$0, ((Boolean) obj).booleanValue());
    }
}