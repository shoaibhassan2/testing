package pk.gov.nadra.oneapp.polc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class StartApplicationPolcFragment$$ExternalSyntheticLambda6 implements Function0 {
    public /* synthetic */ StartApplicationPolcFragment$$ExternalSyntheticLambda6() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return StartApplicationPolcFragment.handleFailureCaseJsonArray$lambda$44$lambda$43(this.f$0);
    }
}