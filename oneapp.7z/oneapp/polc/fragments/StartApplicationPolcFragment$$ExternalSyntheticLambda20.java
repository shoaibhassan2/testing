package pk.gov.nadra.oneapp.polc.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class StartApplicationPolcFragment$$ExternalSyntheticLambda20 implements Function0 {
    public /* synthetic */ StartApplicationPolcFragment$$ExternalSyntheticLambda20() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return StartApplicationPolcFragment.callBiometricAction$lambda$11(this.f$0);
    }
}