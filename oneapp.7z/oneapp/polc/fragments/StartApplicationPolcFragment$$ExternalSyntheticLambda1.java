package pk.gov.nadra.oneapp.polc.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class StartApplicationPolcFragment$$ExternalSyntheticLambda1 implements ActivityResultCallback {
    public /* synthetic */ StartApplicationPolcFragment$$ExternalSyntheticLambda1() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        StartApplicationPolcFragment.unikrewFacialLauncher$lambda$67(this.f$0, (ActivityResult) obj);
    }
}