package pk.gov.nadra.oneapp.polc.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.SpannableString;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.GridLayoutManager;
import com.farrakhj.stringpickerlibrary.views.StringPickerActivity;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.morpho.lkms.android.sdk.lkms_core.content_provider.LkmsStoreContract;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.io.FilesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import org.apache.commons.imaging.formats.jpeg.iptc.IptcConstants;
import pk.gov.nadra.oneapp.commonui.CnicMaskWatcher;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.BaseActivity;
import pk.gov.nadra.oneapp.commonutils.adapter.ProcessingFeeAdapter;
import pk.gov.nadra.oneapp.commonutils.fingerprint.FingerprintScanSelectionActivityUnikrew;
import pk.gov.nadra.oneapp.commonutils.idemialiveness.ChallengeActivity;
import pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback;
import pk.gov.nadra.oneapp.commonutils.preferences.AppPreferences;
import pk.gov.nadra.oneapp.commonutils.service.ValidateLicenseService;
import pk.gov.nadra.oneapp.commonutils.unikrewliveness.UnikrewFacialActivity;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.FingerIndexEnum;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor;
import pk.gov.nadra.oneapp.commonutils.utils.ImageCropper;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.MethodName;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Permissions;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data;
import pk.gov.nadra.oneapp.commonutils.viewmodel.SharedViewModel;
import pk.gov.nadra.oneapp.models.FeeCalculationRequest;
import pk.gov.nadra.oneapp.models.FeeCalculationResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.GeneratePdfResponse;
import pk.gov.nadra.oneapp.models.crc.TrackingIDDataUpdationReqeust;
import pk.gov.nadra.oneapp.models.crc.TrackingIDDataUpdationResponse;
import pk.gov.nadra.oneapp.models.crc.configuration.GetConfigurations;
import pk.gov.nadra.oneapp.models.crc.fingerprint.FingerPreference;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintRequest;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintResponse;
import pk.gov.nadra.oneapp.models.crc.library.LibraryResponse;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;
import pk.gov.nadra.oneapp.polc.databinding.StartApplicationPolcFragmentBinding;
import pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment;

/* compiled from: StartApplicationPolcFragment.kt */
@Metadata(d1 = {"\u0000\u0082\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010a\u001a\u00020b2\u0006\u0010c\u001a\u00020dH\u0016J$\u0010e\u001a\u00020f2\u0006\u0010g\u001a\u00020h2\b\u0010i\u001a\u0004\u0018\u00010j2\b\u0010k\u001a\u0004\u0018\u00010lH\u0016J\u001a\u0010m\u001a\u00020b2\u0006\u0010n\u001a\u00020f2\b\u0010k\u001a\u0004\u0018\u00010lH\u0016J\b\u0010o\u001a\u00020bH\u0002J\b\u0010p\u001a\u00020bH\u0002J%\u0010q\u001a\u00020b2\u0016\u0010r\u001a\u0012\u0012\u0004\u0012\u00020\u00130\u0010j\b\u0012\u0004\u0012\u00020\u0013`sH\u0002¢\u0006\u0002\u0010\u0017J\b\u0010y\u001a\u00020NH\u0002J\b\u0010\u001f\u001a\u00020bH\u0002J\b\u0010z\u001a\u00020bH\u0002J\u0018\u0010{\u001a\u00020b2\u0006\u0010|\u001a\u00020}2\u0006\u0010~\u001a\u00020\u007fH\u0002J\n\u0010\u0080\u0001\u001a\u00030\u0081\u0001H\u0002J\u0012\u0010\u0082\u0001\u001a\u00020\u00132\u0007\u0010\u0083\u0001\u001a\u00020\u0013H\u0002J\u0012\u0010\u0084\u0001\u001a\u00020b2\u0007\u0010\u0085\u0001\u001a\u00020}H\u0002J\t\u0010\u0086\u0001\u001a\u00020bH\u0002J\t\u0010\u0087\u0001\u001a\u00020bH\u0002J\t\u0010\u0088\u0001\u001a\u00020bH\u0002J\u0012\u0010\u0089\u0001\u001a\u00020b2\u0007\u0010\u0085\u0001\u001a\u00020}H\u0002J\t\u0010\u008a\u0001\u001a\u00020bH\u0002J\n\u0010\u008b\u0001\u001a\u00030\u008c\u0001H\u0002J\b\u00103\u001a\u00020bH\u0002J\u0012\u0010\u008d\u0001\u001a\u00020b2\u0007\u0010\u0085\u0001\u001a\u00020}H\u0002J\t\u0010\u008e\u0001\u001a\u00020bH\u0002J\u0013\u0010\u008f\u0001\u001a\u00020b2\b\u0010\u0085\u0001\u001a\u00030\u0090\u0001H\u0002J\u001a\u0010\u0091\u0001\u001a\u00020b2\u0007\u0010|\u001a\u00030\u0090\u00012\u0006\u0010~\u001a\u00020\u007fH\u0002J\u0013\u0010\u0092\u0001\u001a\u00020b2\b\u0010\u0093\u0001\u001a\u00030\u0094\u0001H\u0002J\u0012\u0010\u0095\u0001\u001a\u00020b2\u0007\u0010\u0085\u0001\u001a\u00020}H\u0002J\t\u0010\u0096\u0001\u001a\u00020bH\u0002J\u0012\u0010\u0097\u0001\u001a\u00020b2\u0007\u0010\u0098\u0001\u001a\u00020\u0013H\u0002J\u001b\u0010\u0099\u0001\u001a\u00020b2\u0007\u0010\u009a\u0001\u001a\u00020\u00132\u0007\u0010\u009b\u0001\u001a\u00020NH\u0002J\t\u0010\u009c\u0001\u001a\u00020bH\u0002J\t\u0010\u009d\u0001\u001a\u00020bH\u0002J\t\u0010 \u0001\u001a\u00020bH\u0002J\t\u0010¢\u0001\u001a\u00020bH\u0002J\t\u0010£\u0001\u001a\u00020bH\u0002J\u001b\u0010¥\u0001\u001a\u00020b2\u0007\u0010¦\u0001\u001a\u00020\u00132\u0007\u0010§\u0001\u001a\u00020NH\u0002J\u0011\u0010¨\u0001\u001a\u00020b2\u0006\u0010^\u001a\u00020\u0013H\u0002J\u0013\u0010«\u0001\u001a\u00020\u00132\b\u0010¬\u0001\u001a\u00030\u00ad\u0001H\u0002J\u0012\u0010®\u0001\u001a\u00020b2\u0007\u0010¯\u0001\u001a\u00020\u0013H\u0002J\u0012\u0010°\u0001\u001a\u00020b2\u0007\u0010±\u0001\u001a\u00020\u0013H\u0002J\u0012\u0010²\u0001\u001a\u00020b2\u0007\u0010\u0085\u0001\u001a\u00020}H\u0002J\u0012\u0010³\u0001\u001a\u00020b2\u0007\u0010´\u0001\u001a\u00020\u0013H\u0002J\t\u0010·\u0001\u001a\u00020bH\u0002J\t\u0010¸\u0001\u001a\u00020bH\u0002J\t\u0010¹\u0001\u001a\u00020bH\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00130\u0010X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00190\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00130\u0010X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u0015\"\u0004\b\u001c\u0010\u0017R\u001a\u0010\u001d\u001a\u00020\u001eX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010 \"\u0004\b!\u0010\"R\u001a\u0010#\u001a\u00020\u0011X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b$\u0010%\"\u0004\b&\u0010'R\u001a\u0010(\u001a\u00020\u0019X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b)\u0010*\"\u0004\b+\u0010,R \u0010-\u001a\b\u0012\u0004\u0012\u00020.0\u0010X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b/\u0010\u0015\"\u0004\b0\u0010\u0017R\u000e\u00101\u001a\u00020.X\u0082\u000e¢\u0006\u0002\n\u0000R \u00102\u001a\b\u0012\u0004\u0012\u00020.0\u0010X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b3\u0010\u0015\"\u0004\b4\u0010\u0017R\u000e\u00105\u001a\u00020.X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u00106\u001a\u00020\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b7\u00108\"\u0004\b9\u0010:R\u001a\u0010;\u001a\u00020<X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b=\u0010>\"\u0004\b?\u0010@R\u001a\u0010A\u001a\u00020BX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\bC\u0010D\"\u0004\bE\u0010FR\u001a\u0010G\u001a\u00020HX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\bI\u0010J\"\u0004\bK\u0010LR\u000e\u0010M\u001a\u00020NX\u0082\u000e¢\u0006\u0002\n\u0000R'\u0010O\u001a\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020Q0P8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\bT\u0010\t\u001a\u0004\bR\u0010SR\u0010\u0010U\u001a\u0004\u0018\u00010\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010V\u001a\u00020WX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010X\u001a\u00020YX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\bZ\u0010[\"\u0004\b\\\u0010]R\u000e\u0010^\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010_\u001a\u00020NX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010`\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010t\u001a\u0010\u0012\f\u0012\n w*\u0004\u0018\u00010v0v0uX\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010x\u001a\u0010\u0012\f\u0012\n w*\u0004\u0018\u00010v0v0uX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u009e\u0001\u001a\u00030\u009f\u0001X\u0082\u000e¢\u0006\u0002\n\u0000R\u001d\u0010¡\u0001\u001a\u0010\u0012\f\u0012\n w*\u0004\u0018\u00010v0v0uX\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010¤\u0001\u001a\u0010\u0012\f\u0012\n w*\u0004\u0018\u00010v0v0uX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010©\u0001\u001a\u00030ª\u0001X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010µ\u0001\u001a\u00030¶\u0001X\u0082\u000e¢\u0006\u0002\n\u0000R\u001d\u0010º\u0001\u001a\u0010\u0012\f\u0012\n w*\u0004\u0018\u00010v0v0uX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006»\u0001"}, d2 = {"Lpk/gov/nadra/oneapp/polc/fragments/StartApplicationPolcFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "crcSharedViewModel", "Lpk/gov/nadra/oneapp/commonutils/viewmodel/SharedViewModel;", "getCrcSharedViewModel", "()Lpk/gov/nadra/oneapp/commonutils/viewmodel/SharedViewModel;", "crcSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/polc/databinding/StartApplicationPolcFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/polc/databinding/StartApplicationPolcFragmentBinding;", "filteredAppTypeList", "Ljava/util/ArrayList;", "Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations$DocumentType$ApplicationType;", "applicationTypeArray", "", "getApplicationTypeArray", "()Ljava/util/ArrayList;", "setApplicationTypeArray", "(Ljava/util/ArrayList;)V", "filteredDocumentTypeList", "Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations$DocumentType;", "documentTypeArray", "getDocumentTypeArray", "setDocumentTypeArray", "configurations", "Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations;", "getConfigurations", "()Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations;", "setConfigurations", "(Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations;)V", "selectedApplicationType", "getSelectedApplicationType", "()Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations$DocumentType$ApplicationType;", "setSelectedApplicationType", "(Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations$DocumentType$ApplicationType;)V", "selectedDocumentType", "getSelectedDocumentType", "()Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations$DocumentType;", "setSelectedDocumentType", "(Lpk/gov/nadra/oneapp/models/crc/configuration/GetConfigurations$DocumentType;)V", "applicantCountriesList", "Lpk/gov/nadra/oneapp/models/crc/library/LibraryResponse;", "getApplicantCountriesList", "setApplicantCountriesList", "selectedApplicantCountry", "mobileOperatorsList", "getMobileOperatorsList", "setMobileOperatorsList", "selectedOperator", "priorityType", "getPriorityType", "()Ljava/lang/String;", "setPriorityType", "(Ljava/lang/String;)V", "dropdownCalling", "Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;", "getDropdownCalling", "()Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;", "setDropdownCalling", "(Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;)V", "activity", "Lpk/gov/nadra/oneapp/commonutils/BaseActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/commonutils/BaseActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/commonutils/BaseActivity;)V", "adapter", "Lpk/gov/nadra/oneapp/commonutils/adapter/ProcessingFeeAdapter;", "getAdapter", "()Lpk/gov/nadra/oneapp/commonutils/adapter/ProcessingFeeAdapter;", "setAdapter", "(Lpk/gov/nadra/oneapp/commonutils/adapter/ProcessingFeeAdapter;)V", "isFeeCalculated", "", "fieldToViewMap", "", "Lcom/google/android/material/textfield/TextInputLayout;", "getFieldToViewMap", "()Ljava/util/Map;", "fieldToViewMap$delegate", "selectedCardDelivery", "verifyFingerprintResponse", "Lpk/gov/nadra/oneapp/models/crc/fingerprint/VerifyFingerprintResponse;", "permissions", "Lpk/gov/nadra/oneapp/commonutils/utils/Permissions;", "getPermissions", "()Lpk/gov/nadra/oneapp/commonutils/utils/Permissions;", "setPermissions", "(Lpk/gov/nadra/oneapp/commonutils/utils/Permissions;)V", "sourceImagePath", "showUserGuidanceOnce", "traceId", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "attachLayoutViews", "callBiometricAction", "launchStringPickerActivity", "arrayList", "Lkotlin/collections/ArrayList;", "startForResult", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "fingerprintLauncher", "validateViews", "processStartApplicationButtonClickAction", "handleFailureCase", "jsonResponse", "Lcom/google/gson/JsonObject;", "responseCode", "", "getTIDDataUpdationRequest", "Lpk/gov/nadra/oneapp/models/crc/TrackingIDDataUpdationReqeust;", "getNumberAfterDash", "mobileNumber", "processConfigurationResponse", "jSonObject", "launchFingerprintActivity", "disableDocumentType", "setAppTypeForCancellation", "processTIDDataUpdationSuccessResponse", "processFeeCalculation", "getFeeCalculationRequest", "Lpk/gov/nadra/oneapp/models/FeeCalculationRequest;", "processFeeCalculationSuccessResponse", "handleCaptureSuccess", "processLibrarySuccessResponse", "Lcom/google/gson/JsonArray;", "handleFailureCaseJsonArray", "verifyApplicantFingerprint", "verifyFingerprintRequest", "Lpk/gov/nadra/oneapp/models/crc/fingerprint/VerifyFingerprintRequest;", "processVerifyApplicantSuccessResponse", "scrollToBottomIfNeeded", "setDocumentTypes", "documentType", "setApplicationType", "type", "isDisable", "initPermissions", "checkIdemiaLicenseActivation", "licenseValidationCallback", "Lpk/gov/nadra/oneapp/commonutils/interfaces/LicenseValidationCallback;", "processLicenseSuccess", "livelinessLauncher", "processOnActivityResultForCameraIntent", "launchImageCropper", "cropLauncher", "processOnActivityResultForAnanasLibrary", "processedFilePath", "isImageEdit", "compressImage", "iCompressImageTaskListenerResult", "Lpk/gov/nadra/oneapp/commonutils/utils/ImageCompressor$ICompressImageTaskListener;", "convertFileToBase64", "file", "Ljava/io/File;", "verifyApplicantWithFacial", "base64", "generateTokenPdf", "trackingId", "processGeneratePdfSuccessResponse", "writePdfBase64Data", "photoBase64", "iwritePdfBase64DataServiceResult", "Lpk/gov/nadra/oneapp/commonutils/utils/WritePhotoBase64Data$ICompressImageTaskListener;", "handlePhoneNumberOperatorData", "checkLivenessControl", "launchUnikrewFacial", "unikrewFacialLauncher", "polc_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes6.dex */
public final class StartApplicationPolcFragment extends Fragment {
    private StartApplicationPolcFragmentBinding _binding;
    public BaseActivity activity;
    public ProcessingFeeAdapter adapter;

    /* renamed from: crcSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy crcSharedViewModel;
    private final ActivityResultLauncher<Intent> cropLauncher;
    private final ActivityResultLauncher<Intent> fingerprintLauncher;
    private ImageCompressor.ICompressImageTaskListener iCompressImageTaskListenerResult;
    private boolean isFeeCalculated;
    private WritePhotoBase64Data.ICompressImageTaskListener iwritePdfBase64DataServiceResult;
    private LicenseValidationCallback licenseValidationCallback;
    private final ActivityResultLauncher<Intent> livelinessLauncher;
    public Permissions permissions;
    private String selectedCardDelivery;
    private boolean showUserGuidanceOnce;
    private final ActivityResultLauncher<Intent> startForResult;
    private final ActivityResultLauncher<Intent> unikrewFacialLauncher;
    private ArrayList<GetConfigurations.DocumentType.ApplicationType> filteredAppTypeList = new ArrayList<>();
    private ArrayList<String> applicationTypeArray = new ArrayList<>();
    private ArrayList<GetConfigurations.DocumentType> filteredDocumentTypeList = new ArrayList<>();
    private ArrayList<String> documentTypeArray = new ArrayList<>();
    private GetConfigurations configurations = new GetConfigurations(null, 1, null);
    private GetConfigurations.DocumentType.ApplicationType selectedApplicationType = new GetConfigurations.DocumentType.ApplicationType(null, null, null, 7, null);
    private GetConfigurations.DocumentType selectedDocumentType = new GetConfigurations.DocumentType(null, null, null, 7, null);
    private ArrayList<LibraryResponse> applicantCountriesList = new ArrayList<>();
    private LibraryResponse selectedApplicantCountry = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private ArrayList<LibraryResponse> mobileOperatorsList = new ArrayList<>();
    private LibraryResponse selectedOperator = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private String priorityType = "";
    private MethodName dropdownCalling = MethodName.COUNTRY;

    /* renamed from: fieldToViewMap$delegate, reason: from kotlin metadata */
    private final Lazy fieldToViewMap = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda24
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return StartApplicationPolcFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
        }
    });
    private VerifyFingerprintResponse verifyFingerprintResponse = new VerifyFingerprintResponse(null, false, false, null, null, false, null, null, null, null, null, null, null, false, null, null, 65535, null);
    private String sourceImagePath = "";
    private String traceId = "";

    /* compiled from: StartApplicationPolcFragment.kt */
    @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[MethodName.values().length];
            try {
                iArr[MethodName.APPLICATION_TYPE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[MethodName.DOCUMENT_TYPE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[MethodName.COUNTRY.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[MethodName.MOBILE_OPERATOR.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public StartApplicationPolcFragment() {
        final StartApplicationPolcFragment startApplicationPolcFragment = this;
        final Function0 function0 = null;
        this.crcSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(startApplicationPolcFragment, Reflection.getOrCreateKotlinClass(SharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = startApplicationPolcFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = startApplicationPolcFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = startApplicationPolcFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda25
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                StartApplicationPolcFragment.startForResult$lambda$14(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.startForResult = activityResultLauncherRegisterForActivityResult;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult2 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda26
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) throws JsonSyntaxException {
                StartApplicationPolcFragment.fingerprintLauncher$lambda$15(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult2, "registerForActivityResult(...)");
        this.fingerprintLauncher = activityResultLauncherRegisterForActivityResult2;
        this.licenseValidationCallback = new LicenseValidationCallback() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$licenseValidationCallback$1
            @Override // pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback
            public void onSuccess() {
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
                this.this$0.processLicenseSuccess();
            }

            @Override // pk.gov.nadra.oneapp.commonutils.interfaces.LicenseValidationCallback
            public void onError() {
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
                BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
                BaseActivity activity = this.this$0.getActivity();
                String string = this.this$0.getString(R.string.face_liveness_failed);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                String string2 = this.this$0.getString(R.string.face_liveness_failed_urdu);
                Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
            }
        };
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult3 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda27
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                StartApplicationPolcFragment.livelinessLauncher$lambda$61(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult3, "registerForActivityResult(...)");
        this.livelinessLauncher = activityResultLauncherRegisterForActivityResult3;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult4 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda28
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                StartApplicationPolcFragment.cropLauncher$lambda$63(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult4, "registerForActivityResult(...)");
        this.cropLauncher = activityResultLauncherRegisterForActivityResult4;
        this.iCompressImageTaskListenerResult = new ImageCompressor.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$iCompressImageTaskListenerResult$1
            @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
            public void onComplete(File compressed) {
                Intrinsics.checkNotNullParameter(compressed, "compressed");
                String strConvertFileToBase64 = this.this$0.convertFileToBase64(compressed);
                if (Constant.INSTANCE.getDEBUG()) {
                    Log.d("Compressed (30KB)", strConvertFileToBase64);
                }
                this.this$0.verifyApplicantWithFacial(strConvertFileToBase64);
            }

            @Override // pk.gov.nadra.oneapp.commonutils.utils.ImageCompressor.ICompressImageTaskListener
            public void onError() {
                Util.INSTANCE.showToast(this.this$0.getActivity(), "Failed");
            }
        };
        this.iwritePdfBase64DataServiceResult = new WritePhotoBase64Data.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$iwritePdfBase64DataServiceResult$1
            @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
            public void onComplete(File compressed) {
                Intrinsics.checkNotNullParameter(compressed, "compressed");
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
                if (this.this$0.getActivity().getFragmentId() != null) {
                    BaseActivity activity = this.this$0.getActivity();
                    Integer fragmentId = this.this$0.getActivity().getFragmentId();
                    Intrinsics.checkNotNull(fragmentId);
                    activity.navigateToFragment(fragmentId.intValue());
                }
            }

            @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
            public void onError() {
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
            }
        };
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult5 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda1
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                StartApplicationPolcFragment.unikrewFacialLauncher$lambda$67(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult5, "registerForActivityResult(...)");
        this.unikrewFacialLauncher = activityResultLauncherRegisterForActivityResult5;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final SharedViewModel getCrcSharedViewModel() {
        return (SharedViewModel) this.crcSharedViewModel.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final StartApplicationPolcFragmentBinding getBinding() {
        StartApplicationPolcFragmentBinding startApplicationPolcFragmentBinding = this._binding;
        Intrinsics.checkNotNull(startApplicationPolcFragmentBinding);
        return startApplicationPolcFragmentBinding;
    }

    public final ArrayList<String> getApplicationTypeArray() {
        return this.applicationTypeArray;
    }

    public final void setApplicationTypeArray(ArrayList<String> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.applicationTypeArray = arrayList;
    }

    public final ArrayList<String> getDocumentTypeArray() {
        return this.documentTypeArray;
    }

    public final void setDocumentTypeArray(ArrayList<String> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.documentTypeArray = arrayList;
    }

    public final GetConfigurations getConfigurations() {
        return this.configurations;
    }

    public final void setConfigurations(GetConfigurations getConfigurations) {
        Intrinsics.checkNotNullParameter(getConfigurations, "<set-?>");
        this.configurations = getConfigurations;
    }

    public final GetConfigurations.DocumentType.ApplicationType getSelectedApplicationType() {
        return this.selectedApplicationType;
    }

    public final void setSelectedApplicationType(GetConfigurations.DocumentType.ApplicationType applicationType) {
        Intrinsics.checkNotNullParameter(applicationType, "<set-?>");
        this.selectedApplicationType = applicationType;
    }

    public final GetConfigurations.DocumentType getSelectedDocumentType() {
        return this.selectedDocumentType;
    }

    public final void setSelectedDocumentType(GetConfigurations.DocumentType documentType) {
        Intrinsics.checkNotNullParameter(documentType, "<set-?>");
        this.selectedDocumentType = documentType;
    }

    public final ArrayList<LibraryResponse> getApplicantCountriesList() {
        return this.applicantCountriesList;
    }

    public final void setApplicantCountriesList(ArrayList<LibraryResponse> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.applicantCountriesList = arrayList;
    }

    /* renamed from: getMobileOperatorsList, reason: collision with other method in class */
    public final ArrayList<LibraryResponse> m10179getMobileOperatorsList() {
        return this.mobileOperatorsList;
    }

    public final void setMobileOperatorsList(ArrayList<LibraryResponse> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.mobileOperatorsList = arrayList;
    }

    public final String getPriorityType() {
        return this.priorityType;
    }

    public final void setPriorityType(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.priorityType = str;
    }

    public final MethodName getDropdownCalling() {
        return this.dropdownCalling;
    }

    public final void setDropdownCalling(MethodName methodName) {
        Intrinsics.checkNotNullParameter(methodName, "<set-?>");
        this.dropdownCalling = methodName;
    }

    @Override // androidx.fragment.app.Fragment
    public final BaseActivity getActivity() {
        BaseActivity baseActivity = this.activity;
        if (baseActivity != null) {
            return baseActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(BaseActivity baseActivity) {
        Intrinsics.checkNotNullParameter(baseActivity, "<set-?>");
        this.activity = baseActivity;
    }

    public final ProcessingFeeAdapter getAdapter() {
        ProcessingFeeAdapter processingFeeAdapter = this.adapter;
        if (processingFeeAdapter != null) {
            return processingFeeAdapter;
        }
        Intrinsics.throwUninitializedPropertyAccessException("adapter");
        return null;
    }

    public final void setAdapter(ProcessingFeeAdapter processingFeeAdapter) {
        Intrinsics.checkNotNullParameter(processingFeeAdapter, "<set-?>");
        this.adapter = processingFeeAdapter;
    }

    private final Map<String, TextInputLayout> getFieldToViewMap() {
        return (Map) this.fieldToViewMap.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Map fieldToViewMap_delegate$lambda$0(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        return MapsKt.mapOf(TuplesKt.to("citizenNumber", this$0.getBinding().applicantCnicLayout.maskedCnicTextInputLayout));
    }

    public final Permissions getPermissions() {
        Permissions permissions = this.permissions;
        if (permissions != null) {
            return permissions;
        }
        Intrinsics.throwUninitializedPropertyAccessException("permissions");
        return null;
    }

    public final void setPermissions(Permissions permissions) {
        Intrinsics.checkNotNullParameter(permissions, "<set-?>");
        this.permissions = permissions;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.commonutils.BaseActivity");
        setActivity((BaseActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = StartApplicationPolcFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        initPermissions();
        attachLayoutViews();
    }

    private final void attachLayoutViews() throws Resources.NotFoundException {
        StartApplicationPolcFragmentBinding binding = getBinding();
        binding.polcHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                StartApplicationPolcFragment.attachLayoutViews$lambda$9$lambda$1(this.f$0, view);
            }
        });
        binding.polcHeaderLayout.textTitle.setText("Proof of Life");
        binding.polcHeaderLayout.textSubtitle.setText("(سرٹیفیکیٹ برائے حیات)");
        binding.polcHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.nadra_nastaleeq));
        binding.applicationDetailHeadingLayout.tvStepHeading.setText(getString(R.string.application_details));
        binding.applicationDetailHeadingLayout.tvStepHeadingUrdu.setText("(درخواست کی تفصیلات)");
        binding.applicationDetailHeadingLayout.tvStepHeadingUrdu.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.nadra_nastaleeq));
        binding.polcHeaderLayout.textBackUr.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.nadra_nastaleeq));
        binding.contactDetailHeadingLayout.tvStepHeading.setText(getString(R.string.contact_detail));
        binding.contactDetailHeadingLayout.tvStepHeadingUrdu.setText("رابطہ کی تفصیلات");
        binding.contactDetailHeadingLayout.tvStepHeadingUrdu.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.nadra_nastaleeq));
        binding.contactDetailHeadingLayout.getRoot().setVisibility(8);
        TextInputLayout textInputLayout = binding.applicantCnicLayout.maskedCnicTextInputLayout;
        Util util = Util.INSTANCE;
        BaseActivity activity = getActivity();
        String string = getString(R.string.applicant_citizen_number);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textInputLayout.setHint(Util.setEnglishTextSpan$default(util, activity, string, " (شناختی کارڈ نمبر) ", 0, false, 12, null));
        binding.applicantCnicLayout.maskedCnicEditText.addTextChangedListener(new CnicMaskWatcher("#####-#######-#"));
        binding.applicantCnicLayout.maskedCnicEditText.setText(getCrcSharedViewModel().getReactNativeData().getCitizenNumber());
        binding.applicantCnicLayout.maskedCnicEditText.setEnabled(false);
        binding.applicantCnicLayout.maskedCnicEditText.setBackgroundTintList(ColorStateList.valueOf(getActivity().getResources().getColor(R.color.card_background_color)));
        TextInputLayout textInputLayout2 = binding.applicationTypeLayout.textInputLayout;
        Util util2 = Util.INSTANCE;
        BaseActivity activity2 = getActivity();
        String string2 = getString(R.string.application_type);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textInputLayout2.setHint(Util.setEnglishTextSpan$default(util2, activity2, string2, " (درخواست کی نوعیت) ", 0, true, 4, null));
        Util util3 = Util.INSTANCE;
        BaseActivity activity3 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView = binding.applicationTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        TextInputLayout textInputLayout3 = binding.applicationTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout3, "textInputLayout");
        util3.removeErrorOnAutoCompleteTextChanged(activity3, autoCompleteTextView, textInputLayout3);
        binding.applicationTypeLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                StartApplicationPolcFragment.attachLayoutViews$lambda$9$lambda$2(this.f$0, view);
            }
        });
        Util util4 = Util.INSTANCE;
        BaseActivity activity4 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView2 = binding.applicationTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView2, "autoCompleteTextView");
        TextInputLayout textInputLayout4 = binding.applicationTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout4, "textInputLayout");
        util4.removeErrorOnAutoCompleteTextChanged(activity4, autoCompleteTextView2, textInputLayout4);
        TextInputLayout textInputLayout5 = binding.documentTypeLayout.textInputLayout;
        Util util5 = Util.INSTANCE;
        BaseActivity activity5 = getActivity();
        String string3 = getString(R.string.document_type);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        textInputLayout5.setHint(Util.setEnglishTextSpan$default(util5, activity5, string3, " (دستاویز کی نوعیت) ", 0, true, 4, null));
        Util util6 = Util.INSTANCE;
        BaseActivity activity6 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView3 = binding.documentTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView3, "autoCompleteTextView");
        TextInputLayout textInputLayout6 = binding.documentTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout6, "textInputLayout");
        util6.removeErrorOnAutoCompleteTextChanged(activity6, autoCompleteTextView3, textInputLayout6);
        binding.documentTypeLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                StartApplicationPolcFragment.attachLayoutViews$lambda$9$lambda$3(this.f$0, view);
            }
        });
        TextInputLayout textInputLayout7 = binding.emailLayout.textInputLayout;
        Util util7 = Util.INSTANCE;
        BaseActivity activity7 = getActivity();
        String string4 = getString(R.string.email);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        textInputLayout7.setHint(Util.setEnglishTextSpan$default(util7, activity7, string4, " (ای میل) ", 0, true, 4, null));
        Util util8 = Util.INSTANCE;
        BaseActivity activity8 = getActivity();
        TextInputEditText textInputEditText = binding.emailLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        TextInputLayout textInputLayout8 = binding.emailLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout8, "textInputLayout");
        util8.removeErrorOnTextChanged(activity8, textInputEditText, textInputLayout8);
        binding.emailLayout.textInputEditText.setText(getCrcSharedViewModel().getReactNativeData().getEmail());
        binding.emailLayout.textInputEditText.setEnabled(false);
        binding.emailLayout.textInputEditText.setBackgroundTintList(ColorStateList.valueOf(getActivity().getResources().getColor(R.color.card_background_color)));
        TextInputLayout textInputLayout9 = binding.contactNumberLayout;
        Util util9 = Util.INSTANCE;
        BaseActivity activity9 = getActivity();
        String string5 = getString(R.string.contact_number);
        Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
        textInputLayout9.setHint(Util.setEnglishTextSpan$default(util9, activity9, string5, " (رابطہ نمبر) ", 0, true, 4, null));
        Util util10 = Util.INSTANCE;
        BaseActivity activity10 = getActivity();
        TextInputEditText phoneNumberTextInputEditText = binding.phoneNumberTextInputEditText;
        Intrinsics.checkNotNullExpressionValue(phoneNumberTextInputEditText, "phoneNumberTextInputEditText");
        TextInputLayout contactNumberLayout = binding.contactNumberLayout;
        Intrinsics.checkNotNullExpressionValue(contactNumberLayout, "contactNumberLayout");
        util10.removeErrorOnTextChanged(activity10, phoneNumberTextInputEditText, contactNumberLayout);
        binding.phoneNumberTextInputEditText.setText(getCrcSharedViewModel().getReactNativeData().getMobileNumber());
        binding.phoneNumberTextInputEditText.setEnabled(false);
        binding.phoneNumberTextInputEditText.setBackgroundTintList(ColorStateList.valueOf(getActivity().getResources().getColor(R.color.card_background_color)));
        String strValueOf = String.valueOf(binding.phoneNumberTextInputEditText.getText());
        if (strValueOf != null && strValueOf.length() != 0 && !StringsKt.startsWith$default(String.valueOf(binding.phoneNumberTextInputEditText.getText()), "+92", false, 2, (Object) null) && !StringsKt.startsWith$default(String.valueOf(binding.phoneNumberTextInputEditText.getText()), ExifInterface.GPS_MEASUREMENT_3D, false, 2, (Object) null)) {
            getBinding().phoneNumberTextInputEditText.setVisibility(8);
        }
        handlePhoneNumberOperatorData();
        TextView textView = binding.tvPriorityHeading;
        Util util11 = Util.INSTANCE;
        BaseActivity activity11 = getActivity();
        String string6 = getString(R.string.application_processing_priority);
        Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util11, activity11, string6, "\n (درخواست کی پراسیسنگ کی ترجیح)", 0, false, 12, null));
        binding.priorityProcessingRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 1));
        Context contextRequireContext = requireContext();
        Intrinsics.checkNotNullExpressionValue(contextRequireContext, "requireContext(...)");
        setAdapter(new ProcessingFeeAdapter(contextRequireContext, this.selectedApplicationType.getPriorityTypeList(), new Function2() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda13
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return StartApplicationPolcFragment.attachLayoutViews$lambda$9$lambda$4(this.f$0, ((Integer) obj).intValue(), (GetConfigurations.DocumentType.ApplicationType.PriorityType) obj2);
            }
        }));
        binding.priorityProcessingRecyclerView.setAdapter(getAdapter());
        getBinding().categoryFeeCardView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda14
            @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
            public final void onGlobalLayout() {
                StartApplicationPolcFragment.attachLayoutViews$lambda$9$lambda$5(this.f$0);
            }
        });
        ConfigurableButton configurableButton = binding.verifyApplicantFingerprintButtonLayout.commonButton;
        Util util12 = Util.INSTANCE;
        BaseActivity activity12 = getActivity();
        String string7 = getString(R.string.verify_applicant_facial);
        Intrinsics.checkNotNullExpressionValue(string7, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util12, activity12, string7, "\n(برائے کرم درخواست گزار کے چہرے کی تصدیق کریں۔)", 0, false, 12, null));
        binding.verifyApplicantFingerprintButtonLayout.commonButton.setFilled(true);
        binding.verifyApplicantFingerprintButtonLayout.commonButton.setInsetTop(0);
        binding.verifyApplicantFingerprintButtonLayout.commonButton.setInsetBottom(0);
        binding.verifyApplicantFingerprintButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda15
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                StartApplicationPolcFragment.attachLayoutViews$lambda$9$lambda$8(this.f$0, view);
            }
        });
        this.verifyFingerprintResponse.setVerificationMode("FACIAL");
        getConfigurations();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$9$lambda$1(StartApplicationPolcFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_INBOX);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$9$lambda$2(StartApplicationPolcFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.APPLICATION_TYPE;
        ArrayList<String> arrayList = this$0.applicationTypeArray;
        if (arrayList == null || arrayList.isEmpty()) {
            return;
        }
        this$0.launchStringPickerActivity(this$0.applicationTypeArray);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$9$lambda$3(StartApplicationPolcFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.DOCUMENT_TYPE;
        ArrayList<String> arrayList = this$0.documentTypeArray;
        if (arrayList == null || arrayList.isEmpty()) {
            return;
        }
        this$0.launchStringPickerActivity(this$0.documentTypeArray);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit attachLayoutViews$lambda$9$lambda$4(StartApplicationPolcFragment this$0, int i, GetConfigurations.DocumentType.ApplicationType.PriorityType feeData) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(feeData, "feeData");
        if (!this$0.isFeeCalculated) {
            this$0.priorityType = feeData.getCode();
            this$0.processFeeCalculation();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$9$lambda$5(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.scrollToBottomIfNeeded();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$9$lambda$8(final StartApplicationPolcFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (!this$0.showUserGuidanceOnce) {
            this$0.showUserGuidanceOnce = true;
            BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
            BaseActivity activity = this$0.getActivity();
            String string = this$0.getString(R.string.facial_then_fingerprint_required);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            SpannableString englishTextSpan$default = Util.setEnglishTextSpan$default(Util.INSTANCE, this$0.getActivity(), "Proceed", " (آگے بڑھیں)", 0, false, 12, null);
            String string2 = this$0.getString(R.string.facial_then_fingerprint_required_urdu);
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            bottomSheetUtils.showMessageBottomSheet((FragmentActivity) activity, "Alert", string, true, (CharSequence) englishTextSpan$default, true, string2, new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda17
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return StartApplicationPolcFragment.attachLayoutViews$lambda$9$lambda$8$lambda$6(this.f$0);
                }
            }, new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda18
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return Unit.INSTANCE;
                }
            });
            return;
        }
        this$0.callBiometricAction();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit attachLayoutViews$lambda$9$lambda$8$lambda$6(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.callBiometricAction();
        return Unit.INSTANCE;
    }

    private final void callBiometricAction() {
        String verificationMode = this.verifyFingerprintResponse.getVerificationMode();
        int iHashCode = verificationMode.hashCode();
        if (iHashCode != 2402104) {
            if (iHashCode == 2066137676) {
                if (verificationMode.equals("FACIAL")) {
                    getPermissions().requestPermission("android.permission.CAMERA");
                    return;
                }
                return;
            } else {
                if (iHashCode == 2073851753 && verificationMode.equals("FINGER")) {
                    launchFingerprintActivity();
                    return;
                }
                return;
            }
        }
        if (verificationMode.equals("NONE")) {
            BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
            BaseActivity activity = getActivity();
            String string = getString(R.string.facial_attempts_max);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            SpannableString englishTextSpan$default = Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Back to home", " (مرکزی صفحہ پر جائيں)", 0, false, 12, null);
            String string2 = getString(R.string.facial_attempts_max_urdu);
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            bottomSheetUtils.showMessageBottomSheet((FragmentActivity) activity, "Alert", string, true, (CharSequence) englishTextSpan$default, true, string2, new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda19
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return StartApplicationPolcFragment.callBiometricAction$lambda$10(this.f$0);
                }
            }, new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda20
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return StartApplicationPolcFragment.callBiometricAction$lambda$11(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit callBiometricAction$lambda$10(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_INBOX);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit callBiometricAction$lambda$11(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_INBOX);
        return Unit.INSTANCE;
    }

    private final void launchStringPickerActivity(ArrayList<String> arrayList) {
        Intent intent = new Intent(getActivity(), (Class<?>) StringPickerActivity.class);
        intent.putStringArrayListExtra("INTENT_STRING_LIST", arrayList);
        this.startForResult.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startForResult$lambda$14(StartApplicationPolcFragment this$0, ActivityResult result) {
        Intent data;
        String stringExtra;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || (data = result.getData()) == null || !data.hasExtra("INTENT_STRING_ITEM") || (stringExtra = data.getStringExtra("INTENT_STRING_ITEM")) == null) {
            return;
        }
        int i = WhenMappings.$EnumSwitchMapping$0[this$0.dropdownCalling.ordinal()];
        Object obj = null;
        if (i == 1) {
            Iterator<T> it = this$0.filteredAppTypeList.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                String lowerCase = ((GetConfigurations.DocumentType.ApplicationType) next).getDescription().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                String lowerCase2 = stringExtra.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                if (Intrinsics.areEqual(lowerCase, lowerCase2)) {
                    obj = next;
                    break;
                }
            }
            Intrinsics.checkNotNull(obj);
            this$0.setApplicationType(((GetConfigurations.DocumentType.ApplicationType) obj).getCode(), false);
            return;
        }
        if (i != 2) {
            return;
        }
        this$0.getBinding().documentTypeLayout.autoCompleteTextView.setText(stringExtra);
        Iterator<T> it2 = this$0.configurations.getDocumentTypeList().iterator();
        while (true) {
            if (!it2.hasNext()) {
                break;
            }
            Object next2 = it2.next();
            String lowerCase3 = ((GetConfigurations.DocumentType) next2).getDescription().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
            String lowerCase4 = stringExtra.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase4, "toLowerCase(...)");
            if (Intrinsics.areEqual(lowerCase3, lowerCase4)) {
                obj = next2;
                break;
            }
        }
        Intrinsics.checkNotNull(obj);
        GetConfigurations.DocumentType documentType = (GetConfigurations.DocumentType) obj;
        this$0.selectedDocumentType = documentType;
        this$0.setDocumentTypes(documentType.getCode());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void fingerprintLauncher$lambda$15(StartApplicationPolcFragment this$0, ActivityResult result) throws JsonSyntaxException {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1 && result.getData() != null) {
            Intent data = result.getData();
            Intrinsics.checkNotNull(data);
            if (data.hasExtra(Constant.CAPTURE_SUCCESS)) {
                this$0.handleCaptureSuccess();
                return;
            }
        }
        result.getResultCode();
    }

    private final boolean validateViews() {
        boolean z;
        String string = getBinding().documentTypeLayout.autoCompleteTextView.getText().toString();
        if (string == null || string.length() == 0) {
            getBinding().documentTypeLayout.textInputLayout.setError("Select document type");
            getBinding().documentTypeLayout.textInputLayout.setErrorEnabled(true);
            z = false;
        } else {
            z = true;
        }
        String string2 = getBinding().applicationTypeLayout.autoCompleteTextView.getText().toString();
        if (string2 == null || string2.length() == 0) {
            getBinding().applicationTypeLayout.textInputLayout.setError("Select application type");
            getBinding().applicationTypeLayout.textInputLayout.setErrorEnabled(true);
            z = false;
        }
        String str = this.priorityType;
        if (str != null && str.length() != 0) {
            return z;
        }
        getAdapter().isErrorEnabled(true);
        return false;
    }

    /* compiled from: StartApplicationPolcFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$getConfigurations$1", f = "StartApplicationPolcFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$getConfigurations$1, reason: invalid class name and case insensitive filesystem */
    static final class C15931 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C15931(Continuation<? super C15931> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StartApplicationPolcFragment.this.new C15931(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C15931) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(StartApplicationPolcFragment.this.getActivity());
            final StartApplicationPolcFragment startApplicationPolcFragment = StartApplicationPolcFragment.this;
            aPIRequests.getConfigurations(new Function3() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$getConfigurations$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return StartApplicationPolcFragment.C15931.invokeSuspend$lambda$0(startApplicationPolcFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(StartApplicationPolcFragment startApplicationPolcFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(startApplicationPolcFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getConfigurations() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                startApplicationPolcFragment.processConfigurationResponse(jsonObject);
            } else {
                startApplicationPolcFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getConfigurations() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C15931(null), 3, null);
    }

    private final void processStartApplicationButtonClickAction() {
        if (validateViews()) {
            LoaderManager.INSTANCE.showLoader(getActivity());
            BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C15961(null), 3, null);
        }
    }

    /* compiled from: StartApplicationPolcFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$processStartApplicationButtonClickAction$1", f = "StartApplicationPolcFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$processStartApplicationButtonClickAction$1, reason: invalid class name and case insensitive filesystem */
    static final class C15961 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C15961(Continuation<? super C15961> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StartApplicationPolcFragment.this.new C15961(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C15961) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(StartApplicationPolcFragment.this.getActivity());
            TrackingIDDataUpdationReqeust tIDDataUpdationRequest = StartApplicationPolcFragment.this.getTIDDataUpdationRequest();
            final StartApplicationPolcFragment startApplicationPolcFragment = StartApplicationPolcFragment.this;
            aPIRequests.tIDDataUpdation(tIDDataUpdationRequest, new Function3() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$processStartApplicationButtonClickAction$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return StartApplicationPolcFragment.C15961.invokeSuspend$lambda$0(startApplicationPolcFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(StartApplicationPolcFragment startApplicationPolcFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(startApplicationPolcFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("tIDDataUpdation() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                startApplicationPolcFragment.processTIDDataUpdationSuccessResponse(jsonObject);
            } else {
                startApplicationPolcFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) throws JsonSyntaxException {
        Object element = new Gson().fromJson(jsonResponse.toString(), (Class<Object>) ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            ErrorResponse errorResponse = (ErrorResponse) element;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors == null) {
                    NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                    BaseActivity activity = getActivity();
                    Intrinsics.checkNotNullExpressionValue(element, "element");
                    NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return StartApplicationPolcFragment.handleFailureCase$lambda$22$lambda$21(this.f$0);
                        }
                    }, 8, null);
                    return;
                }
                for (ErrorResponse.Error error : errors) {
                    TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                    if (textInputLayout != null) {
                        textInputLayout.setError(String.valueOf(error.getMessage()));
                        textInputLayout.setErrorEnabled(true);
                    } else {
                        if (error.getMessage() != null) {
                            errorResponse.setMessage(((ErrorResponse) new Gson().fromJson(error.getMessage(), ErrorResponse.class)).getMessage());
                        }
                        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
                        BaseActivity activity2 = getActivity();
                        Intrinsics.checkNotNullExpressionValue(element, "element");
                        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return StartApplicationPolcFragment.handleFailureCase$lambda$20$lambda$19$lambda$18$lambda$17(this.f$0);
                            }
                        }, 8, null);
                    }
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
            BaseActivity activity3 = getActivity();
            Intrinsics.checkNotNullExpressionValue(element, "element");
            NetworkErrorHandler.handleError$default(networkErrorHandler3, activity3, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda21
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return StartApplicationPolcFragment.handleFailureCase$lambda$23(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler4 = NetworkErrorHandler.INSTANCE;
        BaseActivity activity4 = getActivity();
        Intrinsics.checkNotNullExpressionValue(element, "element");
        NetworkErrorHandler.handleError$default(networkErrorHandler4, activity4, (ErrorResponse) element, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda22
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return StartApplicationPolcFragment.handleFailureCase$lambda$24(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$20$lambda$19$lambda$18$lambda$17(StartApplicationPolcFragment this_run) {
        Intrinsics.checkNotNullParameter(this_run, "$this_run");
        this_run.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$22$lambda$21(StartApplicationPolcFragment this_run) {
        Intrinsics.checkNotNullParameter(this_run, "$this_run");
        this_run.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$23(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$24(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final TrackingIDDataUpdationReqeust getTIDDataUpdationRequest() {
        TrackingIDDataUpdationReqeust trackingIDDataUpdationReqeust = new TrackingIDDataUpdationReqeust(null, null, null, null, null, null, false, null, null, null, null, false, null, null, null, null, null, false, null, null, null, null, false, null, null, null, null, null, 0, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, -1, 4095, null);
        trackingIDDataUpdationReqeust.setApplicationType(this.selectedApplicationType.getDescription());
        trackingIDDataUpdationReqeust.setDocumentType(this.selectedDocumentType.getDescription());
        trackingIDDataUpdationReqeust.setContactCountry(this.selectedApplicantCountry.getKey());
        trackingIDDataUpdationReqeust.setContactMobileOperator(this.selectedOperator.getId() != 0 ? String.valueOf(this.selectedOperator.getId()) : "6");
        trackingIDDataUpdationReqeust.setContactMobileNumber(getNumberAfterDash(String.valueOf(getBinding().phoneNumberTextInputEditText.getText())));
        trackingIDDataUpdationReqeust.setCountryOfStay(this.selectedApplicantCountry.getKey());
        trackingIDDataUpdationReqeust.setCitizenNumber(StringsKt.replace$default(String.valueOf(getBinding().applicantCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null));
        trackingIDDataUpdationReqeust.setPriorityCode(this.priorityType);
        trackingIDDataUpdationReqeust.setTrackingId(getCrcSharedViewModel().getTrackingId());
        trackingIDDataUpdationReqeust.setTokenNumber(0);
        trackingIDDataUpdationReqeust.setApplicantName(getCrcSharedViewModel().getReactNativeData().getFullName());
        trackingIDDataUpdationReqeust.setAppTypeCode(this.selectedApplicationType.getCode());
        trackingIDDataUpdationReqeust.setDocumentCode(this.selectedDocumentType.getCode());
        return trackingIDDataUpdationReqeust;
    }

    private final String getNumberAfterDash(String mobileNumber) {
        List listSplit$default = StringsKt.split$default((CharSequence) mobileNumber, new String[]{"-"}, false, 0, 6, (Object) null);
        return listSplit$default.size() > 1 ? (String) listSplit$default.get(1) : mobileNumber;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processConfigurationResponse(JsonObject jSonObject) {
        String code;
        GetConfigurations getConfigurations = (GetConfigurations) new Gson().fromJson(jSonObject.toString(), GetConfigurations.class);
        Log.d("processConfigResp", getConfigurations.toString());
        this.configurations = getConfigurations;
        Object obj = null;
        if (Intrinsics.areEqual(getCrcSharedViewModel().getReactNativeData().getAppType(), "BIOMETRIC_VERIFY")) {
            List<GetConfigurations.DocumentType> documentTypeList = getConfigurations.getDocumentTypeList();
            ArrayList arrayList = new ArrayList();
            for (Object obj2 : documentTypeList) {
                GetConfigurations.DocumentType documentType = (GetConfigurations.DocumentType) obj2;
                String lowerCase = documentType.getDescription().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                if (!StringsKt.contains$default((CharSequence) lowerCase, (CharSequence) LkmsStoreContract.LicenseContract.LICENSE, false, 2, (Object) null)) {
                    String lowerCase2 = documentType.getDescription().toLowerCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                    if (StringsKt.contains$default((CharSequence) lowerCase2, (CharSequence) "certificate", false, 2, (Object) null)) {
                    }
                }
                arrayList.add(obj2);
            }
            ArrayList arrayList2 = arrayList;
            this.filteredDocumentTypeList = arrayList2;
            ArrayList arrayList3 = arrayList2;
            ArrayList<String> arrayList4 = new ArrayList<>(CollectionsKt.collectionSizeOrDefault(arrayList3, 10));
            Iterator<T> it = arrayList3.iterator();
            while (it.hasNext()) {
                String description = ((GetConfigurations.DocumentType) it.next()).getDescription();
                if (description.length() > 0) {
                    StringBuilder sb = new StringBuilder();
                    String strValueOf = String.valueOf(description.charAt(0));
                    Intrinsics.checkNotNull(strValueOf, "null cannot be cast to non-null type java.lang.String");
                    String upperCase = strValueOf.toUpperCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                    StringBuilder sbAppend = sb.append((Object) upperCase);
                    String strSubstring = description.substring(1);
                    Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                    description = sbAppend.append(strSubstring).toString();
                }
                arrayList4.add(description);
            }
            this.documentTypeArray = arrayList4;
        }
        if (Intrinsics.areEqual(getCrcSharedViewModel().getReactNativeData().getAppType(), "BIOMETRIC_VERIFY")) {
            Iterator<T> it2 = this.configurations.getDocumentTypeList().iterator();
            while (true) {
                if (!it2.hasNext()) {
                    break;
                }
                Object next = it2.next();
                if (Intrinsics.areEqual(((GetConfigurations.DocumentType) next).getCode(), getCrcSharedViewModel().getReactNativeData().getDocType())) {
                    obj = next;
                    break;
                }
            }
            GetConfigurations.DocumentType documentType2 = (GetConfigurations.DocumentType) obj;
            if (documentType2 == null || (code = documentType2.getCode()) == null) {
                code = "";
            }
            setDocumentTypes(code);
        }
    }

    private final void launchFingerprintActivity() {
        Util util = Util.INSTANCE;
        BaseActivity activity = getActivity();
        TextInputLayout maskedCnicTextInputLayout = getBinding().applicantCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        TextInputEditText maskedCnicEditText = getBinding().applicantCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        if (util.validateEditText(activity, maskedCnicTextInputLayout, maskedCnicEditText)) {
            getBinding().applicantCnicLayout.maskedCnicTextInputLayout.setError(null);
            getBinding().applicantCnicLayout.maskedCnicTextInputLayout.setErrorEnabled(false);
            Intent intent = new Intent(getActivity(), (Class<?>) FingerprintScanSelectionActivityUnikrew.class);
            intent.putExtra(Constant.CAPTURE_TYPE, "VERIFICATION");
            this.fingerprintLauncher.launch(intent);
        }
    }

    private final void disableDocumentType() {
        MaterialAutoCompleteTextView materialAutoCompleteTextView = getBinding().documentTypeLayout.autoCompleteTextView;
        String upperCase = this.selectedDocumentType.getDescription().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        materialAutoCompleteTextView.setText(upperCase);
        getBinding().documentTypeLayout.autoCompleteTextView.setEnabled(false);
        getBinding().documentTypeLayout.autoCompleteTextView.setBackgroundTintList(ColorStateList.valueOf(getActivity().getResources().getColor(R.color.card_background_color)));
    }

    private final void setAppTypeForCancellation() {
        Object next;
        Iterator<T> it = this.selectedDocumentType.getApplicationTypeList().iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (Intrinsics.areEqual(((GetConfigurations.DocumentType.ApplicationType) next).getCode(), getCrcSharedViewModel().getReactNativeData().getAppType())) {
                    break;
                }
            }
        }
        GetConfigurations.DocumentType.ApplicationType applicationType = (GetConfigurations.DocumentType.ApplicationType) next;
        if (applicationType != null) {
            this.selectedApplicationType = applicationType;
            setApplicationType(applicationType.getCode(), true);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processTIDDataUpdationSuccessResponse(JsonObject jSonObject) {
        TrackingIDDataUpdationResponse trackingIDDataUpdationResponse = (TrackingIDDataUpdationResponse) new Gson().fromJson(jSonObject.toString(), TrackingIDDataUpdationResponse.class);
        getCrcSharedViewModel().setStartApplicationResponse(trackingIDDataUpdationResponse);
        getCrcSharedViewModel().setTrackingId(trackingIDDataUpdationResponse.getTrackingId());
        getCrcSharedViewModel().setApplicationType(trackingIDDataUpdationResponse.getAppTypeCode());
        getCrcSharedViewModel().setDocumentType(trackingIDDataUpdationResponse.getDocumentCode());
        getCrcSharedViewModel().setApplicationTypeValue(Util.INSTANCE.capitalizeWords(this.selectedApplicationType.getDescription()));
        getCrcSharedViewModel().setDocumentTypeValue(Util.INSTANCE.capitalizeWords(this.selectedDocumentType.getDescription()));
        getCrcSharedViewModel().getReactNativeData().setCitizenNumber(StringsKt.trim((CharSequence) StringsKt.replace$default(String.valueOf(getBinding().applicantCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null)).toString());
        if (Intrinsics.areEqual(getCrcSharedViewModel().getReactNativeData().getAppType(), "BIOMETRIC_VERIFY")) {
            generateTokenPdf(getCrcSharedViewModel().getTrackingId());
        } else if (getActivity().getFragmentId() != null) {
            BaseActivity activity = getActivity();
            Integer fragmentId = getActivity().getFragmentId();
            Intrinsics.checkNotNull(fragmentId);
            activity.navigateToFragment(fragmentId.intValue());
        }
    }

    /* compiled from: StartApplicationPolcFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$processFeeCalculation$1", f = "StartApplicationPolcFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$processFeeCalculation$1, reason: invalid class name and case insensitive filesystem */
    static final class C15951 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C15951(Continuation<? super C15951> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StartApplicationPolcFragment.this.new C15951(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C15951) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(StartApplicationPolcFragment.this.getActivity());
            FeeCalculationRequest feeCalculationRequest = StartApplicationPolcFragment.this.getFeeCalculationRequest();
            final StartApplicationPolcFragment startApplicationPolcFragment = StartApplicationPolcFragment.this;
            aPIRequests.feeCalculation(feeCalculationRequest, new Function3() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$processFeeCalculation$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return StartApplicationPolcFragment.C15951.invokeSuspend$lambda$0(startApplicationPolcFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(StartApplicationPolcFragment startApplicationPolcFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(startApplicationPolcFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("feeCalculation() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                startApplicationPolcFragment.processFeeCalculationSuccessResponse(jsonObject);
            } else {
                startApplicationPolcFragment.setPriorityType("");
                startApplicationPolcFragment.getBinding().categoryFeeCardView.setVisibility(8);
                startApplicationPolcFragment.getBinding().categoryTypeTextView.setText("Category: " + startApplicationPolcFragment.getPriorityType());
                startApplicationPolcFragment.getBinding().applicationFeeTextView.setText("");
                startApplicationPolcFragment.getBinding().deliveryFeeTextView.setText("");
                startApplicationPolcFragment.getBinding().totalFeeTextView.setText("");
                startApplicationPolcFragment.getCrcSharedViewModel().setAmount("");
                startApplicationPolcFragment.getAdapter().setSelectedPosition(-1);
                startApplicationPolcFragment.getAdapter().notifyDataSetChanged();
                startApplicationPolcFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void processFeeCalculation() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C15951(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final FeeCalculationRequest getFeeCalculationRequest() {
        FeeCalculationRequest feeCalculationRequest = new FeeCalculationRequest(null, null, null, null, null, null, null, null, null, null, null, 2047, null);
        feeCalculationRequest.setCountryOfStay(this.selectedApplicantCountry.getKey());
        feeCalculationRequest.setCardDeliveryCountry(this.selectedApplicantCountry.getKey());
        feeCalculationRequest.setPriorityCode(this.priorityType);
        feeCalculationRequest.setAppTypeCode(this.selectedApplicationType.getCode());
        feeCalculationRequest.setDocumentCode(this.selectedDocumentType.getCode());
        feeCalculationRequest.setTrackingId(getCrcSharedViewModel().getTrackingId());
        feeCalculationRequest.setCountryOfStay("pak");
        return feeCalculationRequest;
    }

    /* compiled from: StartApplicationPolcFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$getMobileOperatorsList$1", f = "StartApplicationPolcFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$getMobileOperatorsList$1, reason: invalid class name and case insensitive filesystem */
    static final class C15941 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C15941(Continuation<? super C15941> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StartApplicationPolcFragment.this.new C15941(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C15941) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(StartApplicationPolcFragment.this.getActivity());
            final StartApplicationPolcFragment startApplicationPolcFragment = StartApplicationPolcFragment.this;
            aPIRequests.getMobileOperator(new Function3() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$getMobileOperatorsList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return StartApplicationPolcFragment.C15941.invokeSuspend$lambda$0(startApplicationPolcFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(StartApplicationPolcFragment startApplicationPolcFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(startApplicationPolcFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getMobileOperatorsList() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                startApplicationPolcFragment.processLibrarySuccessResponse(jsonArray);
            } else {
                startApplicationPolcFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getMobileOperatorsList() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C15941(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processFeeCalculationSuccessResponse(JsonObject jSonObject) {
        String str;
        FeeCalculationResponse feeCalculationResponse = (FeeCalculationResponse) new Gson().fromJson(jSonObject.toString(), FeeCalculationResponse.class);
        Log.d("processFeeCalSuccessRes", feeCalculationResponse.toString());
        getBinding().categoryFeeCardView.setVisibility(0);
        String lowerCase = this.priorityType.toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        if (Intrinsics.areEqual(lowerCase, "normal")) {
            str = "\nنارمل";
        } else {
            String lowerCase2 = this.priorityType.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
            if (Intrinsics.areEqual(lowerCase2, "urgent")) {
                str = "\nارجنٹ";
            } else {
                String lowerCase3 = this.priorityType.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
                if (!Intrinsics.areEqual(lowerCase3, "executive")) {
                    str = "";
                } else {
                    str = "\nایگزیکٹو";
                }
            }
        }
        String str2 = str;
        getBinding().categoryTypeTextView.setVisibility(8);
        getBinding().categoryTypeTextView.setText(new StringBuilder().append((Object) Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Category", " (نوعیت) ", 0, false, 12, null)).append('\n').append((Object) Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), this.priorityType, str2, 0, false, 12, null)).toString());
        getBinding().applicationFeeHeadingTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Application Fee", " (درخواست فیس) ", com.intuit.sdp.R.dimen._10sdp, false, 8, null));
        getBinding().deliveryFeeHeadingTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Card Delivery Fee", " (کارڈ کی ترسیل کی فیس) ", com.intuit.sdp.R.dimen._10sdp, false, 8, null));
        getBinding().totalHeadingTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Payable Fee", " (قابلِ ادائیگی فیس) ", com.intuit.sdp.R.dimen._10sdp, false, 8, null));
        TextView textView = getBinding().applicationFeeTextView;
        StringBuilder sb = new StringBuilder();
        String upperCase = feeCalculationResponse.getCurrency().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(sb.append(upperCase).append(' ').append(feeCalculationResponse.getApplicationFeeFormatted()).toString());
        TextView textView2 = getBinding().deliveryFeeTextView;
        StringBuilder sb2 = new StringBuilder();
        String upperCase2 = feeCalculationResponse.getCurrency().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
        textView2.setText(sb2.append(upperCase2).append(' ').append(feeCalculationResponse.getCardDeliveryFeeFormatted()).toString());
        TextView textView3 = getBinding().totalFeeTextView;
        StringBuilder sb3 = new StringBuilder();
        String upperCase3 = feeCalculationResponse.getCurrency().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase3, "toUpperCase(...)");
        textView3.setText(sb3.append(upperCase3).append(' ').append(feeCalculationResponse.getTotalFeeFormatted()).toString());
        SharedViewModel crcSharedViewModel = getCrcSharedViewModel();
        StringBuilder sb4 = new StringBuilder();
        String upperCase4 = feeCalculationResponse.getCurrency().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase4, "toUpperCase(...)");
        crcSharedViewModel.setAmount(sb4.append(upperCase4).append(' ').append(feeCalculationResponse.getTotalFeeFormatted()).toString());
        getBinding().applicantDetailLayout.setVisibility(0);
        getBinding().verifyApplicantFingerprintButtonLayout.getRoot().setVisibility(0);
        getBinding().documentTypeLayout.getRoot().setVisibility(8);
        getBinding().applicationTypeLayout.getRoot().setVisibility(8);
        getAdapter().setSelectedPosition(0);
        getAdapter().notifyDataSetChanged();
        this.isFeeCalculated = true;
    }

    private final void handleCaptureSuccess() throws JsonSyntaxException {
        String str;
        String strName;
        String fingerprints = AppPreferences.getInstance(getActivity()).getFingerprints();
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d(Constant.TAG, fingerprints);
        }
        Object objFromJson = new Gson().fromJson(fingerprints, (Class<Object>) FingerPreference[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List listAsList = ArraysKt.asList((Object[]) objFromJson);
        VerifyFingerprintRequest verifyFingerprintRequest = new VerifyFingerprintRequest(null, null, 0, null, null, false, null, false, false, false, false, false, false, null, false, false, false, null, 262143, null);
        verifyFingerprintRequest.setApplicantName(getCrcSharedViewModel().getReactNativeData().getFullName());
        verifyFingerprintRequest.setCitizenNumber(StringsKt.replace$default(String.valueOf(getBinding().applicantCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null));
        ArrayList arrayList = new ArrayList();
        Iterator it = listAsList.iterator();
        while (true) {
            str = "";
            if (!it.hasNext()) {
                break;
            }
            FingerPreference fingerPreference = (FingerPreference) it.next();
            VerifyFingerprintRequest.Finger finger = new VerifyFingerprintRequest.Finger(null, null, 0, null, 15, null);
            FingerIndexEnum fingerIndexEnumFromId = FingerIndexEnum.INSTANCE.fromId(Integer.parseInt(fingerPreference.getFingerIndex()));
            if (fingerIndexEnumFromId != null && (strName = fingerIndexEnumFromId.name()) != null) {
                str = strName;
            }
            finger.setIndexName(str);
            finger.setWsq(fingerPreference.getBase64());
            arrayList.add(finger);
        }
        verifyFingerprintRequest.setFingerList(arrayList);
        verifyFingerprintRequest.setPolcToken(true);
        String trackingId = this.verifyFingerprintResponse.getTrackingId();
        verifyFingerprintRequest.setTrackingId(trackingId != null ? trackingId : "");
        verifyApplicantFingerprint(verifyFingerprintRequest);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processLibrarySuccessResponse(JsonArray jSonObject) throws JsonSyntaxException {
        Object objFromJson = new Gson().fromJson(jSonObject.toString(), (Class<Object>) LibraryResponse[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List list = ArraysKt.toList((Object[]) objFromJson);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("LibraryResponse", this.dropdownCalling + " :: Response: " + list);
        }
        ArrayList arrayList = new ArrayList<>();
        int i = WhenMappings.$EnumSwitchMapping$0[this.dropdownCalling.ordinal()];
        if (i == 3) {
            this.applicantCountriesList = new ArrayList<>();
            Intrinsics.checkNotNull(list, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
            ArrayList<LibraryResponse> arrayList2 = (ArrayList) list;
            this.applicantCountriesList = arrayList2;
            ArrayList<LibraryResponse> arrayList3 = arrayList2;
            ArrayList arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList3, 10));
            Iterator<T> it = arrayList3.iterator();
            while (it.hasNext()) {
                arrayList4.add(((LibraryResponse) it.next()).getValue());
            }
            arrayList = arrayList4;
        } else if (i == 4) {
            this.mobileOperatorsList = new ArrayList<>();
            Intrinsics.checkNotNull(list, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
            ArrayList<LibraryResponse> arrayList5 = (ArrayList) list;
            this.mobileOperatorsList = arrayList5;
            ArrayList<LibraryResponse> arrayList6 = arrayList5;
            ArrayList arrayList7 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList6, 10));
            Iterator<T> it2 = arrayList6.iterator();
            while (it2.hasNext()) {
                String value = ((LibraryResponse) it2.next()).getValue();
                if (value.length() > 0) {
                    StringBuilder sb = new StringBuilder();
                    String strValueOf = String.valueOf(value.charAt(0));
                    Intrinsics.checkNotNull(strValueOf, "null cannot be cast to non-null type java.lang.String");
                    String upperCase = strValueOf.toUpperCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                    StringBuilder sbAppend = sb.append((Object) upperCase);
                    String strSubstring = value.substring(1);
                    Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                    value = sbAppend.append(strSubstring).toString();
                }
                arrayList7.add(value);
            }
            arrayList = arrayList7;
        }
        if (arrayList.isEmpty()) {
            return;
        }
        launchStringPickerActivity(arrayList);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCaseJsonArray(JsonArray jsonResponse, int responseCode) throws JsonSyntaxException {
        Object element = new Gson().fromJson((JsonElement) jsonResponse.get(0).getAsJsonObject(), (Class<Object>) ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            ErrorResponse errorResponse = (ErrorResponse) element;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors == null) {
                    NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                    BaseActivity activity = getActivity();
                    Intrinsics.checkNotNullExpressionValue(element, "element");
                    NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda6
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return StartApplicationPolcFragment.handleFailureCaseJsonArray$lambda$44$lambda$43(this.f$0);
                        }
                    }, 8, null);
                    return;
                }
                for (ErrorResponse.Error error : errors) {
                    TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                    if (textInputLayout != null) {
                        textInputLayout.setError(String.valueOf(error.getMessage()));
                        textInputLayout.setErrorEnabled(true);
                    }
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            BaseActivity activity2 = getActivity();
            Intrinsics.checkNotNullExpressionValue(element, "element");
            NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return StartApplicationPolcFragment.handleFailureCaseJsonArray$lambda$45(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        BaseActivity activity3 = getActivity();
        Intrinsics.checkNotNullExpressionValue(element, "element");
        NetworkErrorHandler.handleError$default(networkErrorHandler3, activity3, (ErrorResponse) element, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return StartApplicationPolcFragment.handleFailureCaseJsonArray$lambda$46(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$44$lambda$43(StartApplicationPolcFragment this_run) {
        Intrinsics.checkNotNullParameter(this_run, "$this_run");
        this_run.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$45(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$46(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final void verifyApplicantFingerprint(VerifyFingerprintRequest verifyFingerprintRequest) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        if (Constant.INSTANCE.getDEBUG()) {
            Log.e("TAG", "verifyApplicantFingerprint: " + new Gson().toJson(verifyFingerprintRequest));
        }
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C15971(verifyFingerprintRequest, null), 3, null);
    }

    /* compiled from: StartApplicationPolcFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$verifyApplicantFingerprint$1", f = "StartApplicationPolcFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$verifyApplicantFingerprint$1, reason: invalid class name and case insensitive filesystem */
    static final class C15971 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ VerifyFingerprintRequest $verifyFingerprintRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C15971(VerifyFingerprintRequest verifyFingerprintRequest, Continuation<? super C15971> continuation) {
            super(2, continuation);
            this.$verifyFingerprintRequest = verifyFingerprintRequest;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StartApplicationPolcFragment.this.new C15971(this.$verifyFingerprintRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C15971) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(StartApplicationPolcFragment.this.getActivity());
            VerifyFingerprintRequest verifyFingerprintRequest = this.$verifyFingerprintRequest;
            final StartApplicationPolcFragment startApplicationPolcFragment = StartApplicationPolcFragment.this;
            aPIRequests.verifyApplicantFingerprint(verifyFingerprintRequest, new Function3() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$verifyApplicantFingerprint$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return StartApplicationPolcFragment.C15971.invokeSuspend$lambda$0(startApplicationPolcFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(StartApplicationPolcFragment startApplicationPolcFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(startApplicationPolcFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("processUpdateChildDetails() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                startApplicationPolcFragment.processVerifyApplicantSuccessResponse(jsonObject);
            } else {
                startApplicationPolcFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00d7  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x014f  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x01b6  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void processVerifyApplicantSuccessResponse(com.google.gson.JsonObject r22) {
        /*
            Method dump skipped, instructions count: 707
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment.processVerifyApplicantSuccessResponse(com.google.gson.JsonObject):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processVerifyApplicantSuccessResponse$lambda$50(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_INBOX);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processVerifyApplicantSuccessResponse$lambda$51(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_INBOX);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processVerifyApplicantSuccessResponse$lambda$52(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.launchFingerprintActivity();
        return Unit.INSTANCE;
    }

    private final void scrollToBottomIfNeeded() {
        getBinding().newApplicationScrollView.post(new Runnable() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda23
            @Override // java.lang.Runnable
            public final void run() {
                StartApplicationPolcFragment.scrollToBottomIfNeeded$lambda$54(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void scrollToBottomIfNeeded$lambda$54(StartApplicationPolcFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getBinding().newApplicationScrollView.smoothScrollTo(0, this$0.getBinding().newApplicationScrollView.getBottom());
    }

    private final void setDocumentTypes(String documentType) {
        Object next;
        Iterator<T> it = this.configurations.getDocumentTypeList().iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            String lowerCase = ((GetConfigurations.DocumentType) next).getCode().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            String lowerCase2 = documentType.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
            if (Intrinsics.areEqual(lowerCase, lowerCase2)) {
                break;
            }
        }
        GetConfigurations.DocumentType documentType2 = (GetConfigurations.DocumentType) next;
        if (documentType2 != null) {
            this.selectedDocumentType = documentType2;
            if (Intrinsics.areEqual(getCrcSharedViewModel().getReactNativeData().getAppType(), "BIOMETRIC_VERIFY")) {
                disableDocumentType();
                this.selectedApplicationType = new GetConfigurations.DocumentType.ApplicationType(null, null, null, 7, null);
                setAppTypeForCancellation();
            } else {
                if (documentType2.getApplicationTypeList().size() > 1) {
                    List<GetConfigurations.DocumentType.ApplicationType> applicationTypeList = documentType2.getApplicationTypeList();
                    Intrinsics.checkNotNull(applicationTypeList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.configuration.GetConfigurations.DocumentType.ApplicationType>");
                    this.filteredAppTypeList = (ArrayList) applicationTypeList;
                    List<GetConfigurations.DocumentType.ApplicationType> applicationTypeList2 = documentType2.getApplicationTypeList();
                    ArrayList<String> arrayList = new ArrayList<>(CollectionsKt.collectionSizeOrDefault(applicationTypeList2, 10));
                    Iterator<T> it2 = applicationTypeList2.iterator();
                    while (it2.hasNext()) {
                        String description = ((GetConfigurations.DocumentType.ApplicationType) it2.next()).getDescription();
                        if (description.length() > 0) {
                            StringBuilder sb = new StringBuilder();
                            String strValueOf = String.valueOf(description.charAt(0));
                            Intrinsics.checkNotNull(strValueOf, "null cannot be cast to non-null type java.lang.String");
                            String upperCase = strValueOf.toUpperCase(Locale.ROOT);
                            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                            StringBuilder sbAppend = sb.append((Object) upperCase);
                            String strSubstring = description.substring(1);
                            Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                            description = sbAppend.append(strSubstring).toString();
                        }
                        arrayList.add(description);
                    }
                    this.applicationTypeArray = arrayList;
                } else if (!documentType2.getApplicationTypeList().isEmpty()) {
                    GetConfigurations.DocumentType.ApplicationType applicationType = documentType2.getApplicationTypeList().get(0);
                    this.selectedApplicationType = applicationType;
                    setApplicationType(applicationType.getCode(), true);
                }
                disableDocumentType();
            }
        }
        getCrcSharedViewModel().setDocumentType(this.selectedDocumentType.getCode());
    }

    private final void setApplicationType(String type, boolean isDisable) {
        Object next;
        this.priorityType = "";
        getBinding().categoryFeeCardView.setVisibility(8);
        getBinding().categoryTypeTextView.setText("");
        getBinding().applicationFeeTextView.setText("");
        getBinding().deliveryFeeTextView.setText("");
        getBinding().totalFeeTextView.setText("");
        getCrcSharedViewModel().setAmount("");
        getAdapter().setSelectedPosition(-1);
        getAdapter().setError(false);
        getAdapter().updatePriorityTypeList(new ArrayList());
        Iterator<T> it = this.selectedDocumentType.getApplicationTypeList().iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            String lowerCase = ((GetConfigurations.DocumentType.ApplicationType) next).getCode().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            String lowerCase2 = type.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
            if (Intrinsics.areEqual(lowerCase, lowerCase2)) {
                break;
            }
        }
        GetConfigurations.DocumentType.ApplicationType applicationType = (GetConfigurations.DocumentType.ApplicationType) next;
        if (applicationType == null) {
            applicationType = new GetConfigurations.DocumentType.ApplicationType(null, null, null, 7, null);
        }
        this.selectedApplicationType = applicationType;
        MaterialAutoCompleteTextView materialAutoCompleteTextView = getBinding().applicationTypeLayout.autoCompleteTextView;
        String upperCase = this.selectedApplicationType.getDescription().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        materialAutoCompleteTextView.setText(upperCase);
        int size = this.selectedApplicationType.getPriorityTypeList().size();
        int i = 1;
        if (size != 1) {
            i = 3;
            if (size != 3) {
                i = 2;
            }
        }
        getBinding().priorityProcessingRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), i));
        getAdapter().updatePriorityTypeList(this.selectedApplicationType.getPriorityTypeList());
        getCrcSharedViewModel().setApplicationType(this.selectedApplicationType.getCode());
        if (isDisable) {
            getBinding().applicationTypeLayout.autoCompleteTextView.setEnabled(false);
            getBinding().applicationTypeLayout.autoCompleteTextView.setBackgroundTintList(ColorStateList.valueOf(getActivity().getResources().getColor(R.color.card_background_color)));
        }
        if (this.selectedApplicationType.getPriorityTypeList().isEmpty()) {
            return;
        }
        this.priorityType = this.selectedApplicationType.getPriorityTypeList().get(0).getCode();
        processFeeCalculation();
    }

    private final void initPermissions() {
        setPermissions(new Permissions(getActivity()));
        getPermissions().registerPermissionLauncher();
        getPermissions().setPermissionResult(new Function1() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$$ExternalSyntheticLambda16
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return StartApplicationPolcFragment.initPermissions$lambda$60(this.f$0, ((Boolean) obj).booleanValue());
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initPermissions$lambda$60(StartApplicationPolcFragment this$0, boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (z) {
            this$0.checkLivenessControl();
        } else {
            BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
            BaseActivity activity = this$0.getActivity();
            String string = this$0.getString(R.string.permission_denied);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            String string2 = this$0.getString(R.string.permission_denied_urdu);
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
        }
        return Unit.INSTANCE;
    }

    private final void checkIdemiaLicenseActivation() {
        Object[] objArr = {Constant.IDEMIA_VALUE_1, Constant.IDEMIA_VALUE_2, Constant.IDEMIA_VALUE_3};
        LoaderManager.INSTANCE.showLoader(getActivity());
        new ValidateLicenseService(this.licenseValidationCallback, getActivity(), objArr).validateLicense();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processLicenseSuccess() {
        this.livelinessLauncher.launch(new Intent(getActivity(), (Class<?>) ChallengeActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void livelinessLauncher$lambda$61(StartApplicationPolcFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || result.getData() == null) {
            return;
        }
        Intent data = result.getData();
        Intrinsics.checkNotNull(data);
        String stringExtra = data.getStringExtra("CAPTURE_RESULT_FACE");
        if (stringExtra != null && new File(stringExtra).length() > 0) {
            this$0.sourceImagePath = stringExtra;
            this$0.processOnActivityResultForCameraIntent();
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        BaseActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.unable_to_detect_face);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.unable_to_detect_face_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
    }

    private final void processOnActivityResultForCameraIntent() {
        if (new File(this.sourceImagePath).length() < 0) {
            return;
        }
        launchImageCropper();
    }

    private final void launchImageCropper() {
        try {
            String str = this.sourceImagePath;
            File fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
            Intrinsics.checkNotNull(fileCreatePhotoFile);
            String absolutePath = fileCreatePhotoFile.getAbsolutePath();
            Intent intent = new Intent(getActivity(), (Class<?>) ImageCropper.class);
            intent.putExtra(ImageCropper.EXTRA_INPUT_PATH, str);
            intent.putExtra("output_path", absolutePath);
            this.cropLauncher.launch(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void cropLauncher$lambda$63(StartApplicationPolcFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1) {
            Intent data = result.getData();
            String stringExtra = data != null ? data.getStringExtra("output_path") : null;
            boolean booleanExtra = data != null ? data.getBooleanExtra(ImageCropper.RESULT_IMAGE_EDITED, false) : false;
            if (stringExtra != null) {
                this$0.processOnActivityResultForAnanasLibrary(stringExtra, booleanExtra);
            }
        }
    }

    private final void processOnActivityResultForAnanasLibrary(String processedFilePath, boolean isImageEdit) {
        if (isImageEdit) {
            compressImage(processedFilePath);
        } else {
            compressImage(this.sourceImagePath);
        }
    }

    private final void compressImage(String sourceImagePath) {
        File fileCreatePhotoFile;
        try {
            fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
        } catch (Exception e) {
            e.printStackTrace();
            Util.INSTANCE.showToast(getActivity(), String.valueOf(e.getMessage()));
            fileCreatePhotoFile = null;
        }
        if (fileCreatePhotoFile == null) {
            return;
        }
        new ImageCompressor(getActivity(), this.iCompressImageTaskListenerResult).execute(Arrays.copyOf(new Object[]{sourceImagePath, fileCreatePhotoFile.getAbsolutePath()}, 2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String convertFileToBase64(File file) {
        String strEncodeToString = Base64.encodeToString(FilesKt.readBytes(file), 0);
        Intrinsics.checkNotNullExpressionValue(strEncodeToString, "encodeToString(...)");
        return strEncodeToString;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void verifyApplicantWithFacial(String base64) {
        VerifyFingerprintRequest verifyFingerprintRequest = new VerifyFingerprintRequest(null, null, 0, null, null, false, null, false, false, false, false, false, false, null, false, false, false, null, 262143, null);
        verifyFingerprintRequest.setApplicantName(getCrcSharedViewModel().getReactNativeData().getFullName());
        verifyFingerprintRequest.setCitizenNumber(StringsKt.replace$default(String.valueOf(getBinding().applicantCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null));
        verifyFingerprintRequest.setPhotograph(base64);
        verifyFingerprintRequest.setPolcToken(true);
        String trackingId = this.verifyFingerprintResponse.getTrackingId();
        if (trackingId == null) {
            trackingId = "";
        }
        verifyFingerprintRequest.setTrackingId(trackingId);
        verifyFingerprintRequest.setPhotoTraceId(this.traceId);
        verifyApplicantFingerprint(verifyFingerprintRequest);
    }

    /* compiled from: StartApplicationPolcFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$generateTokenPdf$1", f = "StartApplicationPolcFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$generateTokenPdf$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$trackingId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StartApplicationPolcFragment.this.new AnonymousClass1(this.$trackingId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(StartApplicationPolcFragment.this.getActivity());
            String str = this.$trackingId;
            final StartApplicationPolcFragment startApplicationPolcFragment = StartApplicationPolcFragment.this;
            aPIRequests.generateTokenPdf(str, new Function3() { // from class: pk.gov.nadra.oneapp.polc.fragments.StartApplicationPolcFragment$generateTokenPdf$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return StartApplicationPolcFragment.AnonymousClass1.invokeSuspend$lambda$0(startApplicationPolcFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(StartApplicationPolcFragment startApplicationPolcFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(startApplicationPolcFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                startApplicationPolcFragment.processGeneratePdfSuccessResponse(jsonObject);
            } else {
                startApplicationPolcFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void generateTokenPdf(String trackingId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(trackingId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processGeneratePdfSuccessResponse(JsonObject jSonObject) {
        writePdfBase64Data(((GeneratePdfResponse) new Gson().fromJson(jSonObject.toString(), GeneratePdfResponse.class)).getBase64Pdf());
    }

    private final void writePdfBase64Data(String photoBase64) {
        File fileCreatePdfFileInternal;
        try {
            StringBuilder sbAppend = new StringBuilder().append(getCrcSharedViewModel().getReactNativeData().getAccountHolderCnic()).append('_');
            String upperCase = this.selectedDocumentType.getCode().toUpperCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            fileCreatePdfFileInternal = Util.INSTANCE.createPdfFileInternal(getActivity(), sbAppend.append(upperCase).append('_').append(getCrcSharedViewModel().getTrackingId()).toString());
        } catch (Exception e) {
            e.printStackTrace();
            fileCreatePdfFileInternal = null;
        }
        if (fileCreatePdfFileInternal == null) {
            return;
        }
        LoaderManager.INSTANCE.showLoader(getActivity());
        new WritePhotoBase64Data(getActivity(), this.iwritePdfBase64DataServiceResult).execute(new Object[]{photoBase64, fileCreatePdfFileInternal});
    }

    private final void handlePhoneNumberOperatorData() {
        this.selectedOperator.setId(getCrcSharedViewModel().getReactNativeData().getMobileOperator().getKey());
    }

    private final void checkLivenessControl() {
        if (Intrinsics.areEqual(new SharedPreferencesTokenProvider(getActivity()).getUserCredentials().getLivenessControl(), Constant.UNIKREW) || Intrinsics.areEqual(new SharedPreferencesTokenProvider(getActivity()).getUserCredentials().getLivenessControl(), Constant.UNIKREW_CLOUD)) {
            launchUnikrewFacial();
        } else {
            checkIdemiaLicenseActivation();
        }
    }

    private final void launchUnikrewFacial() {
        Intent intent = new Intent(getActivity(), (Class<?>) UnikrewFacialActivity.class);
        intent.putExtra(Constant.UNIKREW_CAMERA_MODE, "FRONT");
        intent.putExtra(Constant.UNIKREW_ICAO, false);
        this.unikrewFacialLauncher.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void unikrewFacialLauncher$lambda$67(StartApplicationPolcFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1 && result.getData() != null) {
            Intent data = result.getData();
            Intrinsics.checkNotNull(data);
            if (data.hasExtra(Constant.UNIKREW_PROCESSED_IMAGE_PATH)) {
                Intent data2 = result.getData();
                Intrinsics.checkNotNull(data2);
                if (data2.hasExtra(Constant.UNIKREW_PROCESSED_IMAGE_TRACE_ID)) {
                    Intent data3 = result.getData();
                    Intrinsics.checkNotNull(data3);
                    String stringExtra = data3.getStringExtra(Constant.UNIKREW_PROCESSED_IMAGE_PATH);
                    Intrinsics.checkNotNull(stringExtra);
                    this$0.sourceImagePath = stringExtra;
                    Intent data4 = result.getData();
                    Intrinsics.checkNotNull(data4);
                    String stringExtra2 = data4.getStringExtra(Constant.UNIKREW_PROCESSED_IMAGE_TRACE_ID);
                    Intrinsics.checkNotNull(stringExtra2);
                    this$0.traceId = stringExtra2;
                    this$0.processOnActivityResultForCameraIntent();
                    return;
                }
            }
        }
        result.getResultCode();
    }
}