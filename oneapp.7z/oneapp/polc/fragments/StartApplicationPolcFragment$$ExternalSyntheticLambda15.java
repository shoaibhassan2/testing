package pk.gov.nadra.oneapp.polc.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class StartApplicationPolcFragment$$ExternalSyntheticLambda15 implements View.OnClickListener {
    public /* synthetic */ StartApplicationPolcFragment$$ExternalSyntheticLambda15() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        StartApplicationPolcFragment.attachLayoutViews$lambda$9$lambda$8(this.f$0, view);
    }
}