package pk.gov.nadra.oneapp.polc.fragments;

import kotlin.jvm.functions.Function2;
import pk.gov.nadra.oneapp.models.crc.configuration.GetConfigurations;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes6.dex */
public final /* synthetic */ class StartApplicationPolcFragment$$ExternalSyntheticLambda13 implements Function2 {
    public /* synthetic */ StartApplicationPolcFragment$$ExternalSyntheticLambda13() {
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return StartApplicationPolcFragment.attachLayoutViews$lambda$9$lambda$4(this.f$0, ((Integer) obj).intValue(), (GetConfigurations.DocumentType.ApplicationType.PriorityType) obj2);
    }
}