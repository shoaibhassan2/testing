package pk.gov.nadra.oneapp.auth.main.deep;

import androidx.biometric.BiometricPrompt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.auth.main.R;

/* compiled from: DeepLocalAuthManager.kt */
@Metadata(d1 = {"\u0000'\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\r\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016J\u0010\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0006H\u0016J\u0018\u0010\u0007\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0016¨\u0006\f"}, d2 = {"pk/gov/nadra/oneapp/auth/main/deep/DeepLocalAuthManager$authenticate$biometricPrompt$1", "Landroidx/biometric/BiometricPrompt$AuthenticationCallback;", "onAuthenticationFailed", "", "onAuthenticationSucceeded", "result", "Landroidx/biometric/BiometricPrompt$AuthenticationResult;", "onAuthenticationError", "errorCode", "", "errString", "", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DeepLocalAuthManager$authenticate$biometricPrompt$1 extends BiometricPrompt.AuthenticationCallback {
    final /* synthetic */ Function1<String, Unit> $onError;
    final /* synthetic */ Function0<Unit> $onSuccess;
    final /* synthetic */ DeepLocalAuthManager this$0;

    /* JADX WARN: Multi-variable type inference failed */
    DeepLocalAuthManager$authenticate$biometricPrompt$1(Function1<? super String, Unit> function1, DeepLocalAuthManager deepLocalAuthManager, Function0<Unit> function0) {
        onError = function1;
        this = deepLocalAuthManager;
        onSuccess = function0;
    }

    @Override // androidx.biometric.BiometricPrompt.AuthenticationCallback
    public void onAuthenticationFailed() {
        super.onAuthenticationFailed();
        Function1<String, Unit> function1 = onError;
        String string = this.context.getString(R.string.authentication_failed_use_alternative_pin_password);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        function1.invoke(string);
    }

    @Override // androidx.biometric.BiometricPrompt.AuthenticationCallback
    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
        Intrinsics.checkNotNullParameter(result, "result");
        super.onAuthenticationSucceeded(result);
        onSuccess.invoke();
    }

    @Override // androidx.biometric.BiometricPrompt.AuthenticationCallback
    public void onAuthenticationError(int errorCode, CharSequence errString) {
        Intrinsics.checkNotNullParameter(errString, "errString");
        super.onAuthenticationError(errorCode, errString);
        onError.invoke(errString.toString());
    }
}