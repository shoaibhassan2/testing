package pk.gov.nadra.oneapp.auth.main.deep;

import kotlin.Metadata;
import kotlin.Result;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CancellableContinuation;

/* compiled from: DeviceRegistrationUtil.kt */
@Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
final class DeviceRegistrationUtil$registerDeviceOnServer$2$1 implements Function3<String, String, Integer, Unit> {
    final /* synthetic */ CancellableContinuation<Boolean> $cont;

    /* JADX WARN: Multi-variable type inference failed */
    DeviceRegistrationUtil$registerDeviceOnServer$2$1(CancellableContinuation<? super Boolean> cancellableContinuation) {
        cancellableContinuationImpl2 = cancellableContinuation;
    }

    @Override // kotlin.jvm.functions.Function3
    public /* bridge */ /* synthetic */ Unit invoke(String str, String str2, Integer num) {
        invoke(str, str2, num.intValue());
        return Unit.INSTANCE;
    }

    public final void invoke(String jsonResponse, String responseType, int i) {
        Intrinsics.checkNotNullParameter(jsonResponse, "jsonResponse");
        Intrinsics.checkNotNullParameter(responseType, "responseType");
        CancellableContinuation<Boolean> cancellableContinuation = cancellableContinuationImpl2;
        Result.Companion companion = Result.INSTANCE;
        cancellableContinuation.resumeWith(Result.m7258constructorimpl(Boolean.valueOf(Intrinsics.areEqual(responseType, "SUCCESS"))));
    }
}