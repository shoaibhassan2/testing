package pk.gov.nadra.oneapp.auth.main.deep;

import kotlin.jvm.functions.Function1;
import pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DeepSSOConsentFragment$generateJwtToken$2$$ExternalSyntheticLambda0 implements Function1 {
    public final /* synthetic */ String f$1;

    public /* synthetic */ DeepSSOConsentFragment$generateJwtToken$2$$ExternalSyntheticLambda0(String str) {
        str = str;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return DeepSSOConsentFragment.AnonymousClass2.invokeSuspend$lambda$0(deepSSOConsentFragment, str, ((Boolean) obj).booleanValue());
    }
}