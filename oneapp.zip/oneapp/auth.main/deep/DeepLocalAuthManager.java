package pk.gov.nadra.oneapp.auth.main.deep;

import android.content.Context;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import java.util.concurrent.Executor;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.auth.main.R;

/* compiled from: DeepLocalAuthManager.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\u0006\u001a\u00020\u0007J0\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\t0\r2\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\t0\u000fR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/deep/DeepLocalAuthManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "isBiometricAvailable", "", "authenticate", "", "activity", "Landroidx/fragment/app/FragmentActivity;", "onSuccess", "Lkotlin/Function0;", "onError", "Lkotlin/Function1;", "", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DeepLocalAuthManager {
    private final Context context;

    public DeepLocalAuthManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public final boolean isBiometricAvailable() {
        BiometricManager biometricManagerFrom = BiometricManager.from(this.context);
        Intrinsics.checkNotNullExpressionValue(biometricManagerFrom, "from(...)");
        return biometricManagerFrom.canAuthenticate(33023) == 0;
    }

    public final void authenticate(FragmentActivity activity, final Function0<Unit> onSuccess, final Function1<? super String, Unit> onError) {
        Intrinsics.checkNotNullParameter(activity, "activity");
        Intrinsics.checkNotNullParameter(onSuccess, "onSuccess");
        Intrinsics.checkNotNullParameter(onError, "onError");
        Executor mainExecutor = ContextCompat.getMainExecutor(activity);
        Intrinsics.checkNotNullExpressionValue(mainExecutor, "getMainExecutor(...)");
        BiometricPrompt biometricPrompt = new BiometricPrompt(activity, mainExecutor, new BiometricPrompt.AuthenticationCallback() { // from class: pk.gov.nadra.oneapp.auth.main.deep.DeepLocalAuthManager$authenticate$biometricPrompt$1
            @Override // androidx.biometric.BiometricPrompt.AuthenticationCallback
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Function1<String, Unit> function1 = onError;
                String string = this.context.getString(R.string.authentication_failed_use_alternative_pin_password);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                function1.invoke(string);
            }

            @Override // androidx.biometric.BiometricPrompt.AuthenticationCallback
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                Intrinsics.checkNotNullParameter(result, "result");
                super.onAuthenticationSucceeded(result);
                onSuccess.invoke();
            }

            @Override // androidx.biometric.BiometricPrompt.AuthenticationCallback
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                Intrinsics.checkNotNullParameter(errString, "errString");
                super.onAuthenticationError(errorCode, errString);
                onError.invoke(errString.toString());
            }
        });
        BiometricPrompt.PromptInfo promptInfoBuild = new BiometricPrompt.PromptInfo.Builder().setTitle(this.context.getString(R.string.enter_your_screen_lock_to_access, this.context.getString(R.string.app_name))).setDescription(this.context.getString(R.string.please_unlock_to_process)).setAllowedAuthenticators(33023).build();
        Intrinsics.checkNotNullExpressionValue(promptInfoBuild, "build(...)");
        biometricPrompt.authenticate(promptInfoBuild);
    }
}