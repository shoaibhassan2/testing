package pk.gov.nadra.oneapp.auth.main.deep;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.core.ServerValues;
import com.google.firebase.messaging.RemoteMessage;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.auth.main.databinding.DeepOssConsentFragmnetBinding;
import pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment;
import pk.gov.nadra.oneapp.auth.main.viewModel.AuthMainSharedViewModel;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.models.sso.SSOAuthRequest;
import pk.gov.nadra.oneapp.models.sso.SSOPushAuthPayload;
import pk.gov.nadra.oneapp.models.sso.SSOPushAuthResponse;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: DeepSSOConsentFragment.kt */
@Metadata(d1 = {"\u0000z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0011\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u0017H\u0016J\u0012\u0010\u0018\u001a\u00020\u00152\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0016J$\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001e2\b\u0010\u001f\u001a\u0004\u0018\u00010 2\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0016J\u001a\u0010%\u001a\u00020\u00152\u0006\u0010&\u001a\u00020\u001c2\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0017J\u0012\u0010'\u001a\u00020\"2\b\u0010(\u001a\u0004\u0018\u00010\"H\u0002J\f\u0010)\u001a\u00020\u0015*\u00020*H\u0002J\f\u0010+\u001a\u00020\u0015*\u00020*H\u0002J\u0012\u0010,\u001a\u00020\u00152\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003H\u0002J\u001e\u0010-\u001a\u00020\u00152\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010.\u001a\u00020/H\u0082@¢\u0006\u0002\u00100J\u0018\u00101\u001a\u00020\u00152\u0006\u00102\u001a\u00020\"2\u0006\u0010.\u001a\u00020/H\u0002J\u001c\u00103\u001a\u0002042\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\"\u0012\u0004\u0012\u00020\"06H\u0002J*\u00107\u001a\u00020\u00152\u0006\u00102\u001a\u00020\"2\u0012\u00108\u001a\u000e\u0012\u0004\u0012\u00020:\u0012\u0004\u0012\u00020\u001509H\u0086@¢\u0006\u0002\u0010;R\u001c\u0010\u0002\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\u0005R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\u00020\n8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\f\u0010\rR\u001b\u0010\u000e\u001a\u00020\u000f8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u0012\u0010\u0013\u001a\u0004\b\u0010\u0010\u0011R\u0014\u0010!\u001a\u00020\"X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b#\u0010$¨\u0006<"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/deep/DeepSSOConsentFragment;", "Landroidx/fragment/app/Fragment;", "remoteMessage", "Lcom/google/firebase/messaging/RemoteMessage;", "<init>", "(Lcom/google/firebase/messaging/RemoteMessage;)V", "getRemoteMessage", "()Lcom/google/firebase/messaging/RemoteMessage;", "setRemoteMessage", "_binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/DeepOssConsentFragmnetBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/auth/main/databinding/DeepOssConsentFragmnetBinding;", "authMainSharedViewModel", "Lpk/gov/nadra/oneapp/auth/main/viewModel/AuthMainSharedViewModel;", "getAuthMainSharedViewModel", "()Lpk/gov/nadra/oneapp/auth/main/viewModel/AuthMainSharedViewModel;", "authMainSharedViewModel$delegate", "Lkotlin/Lazy;", "onAttach", "", "context", "Landroid/content/Context;", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "TAG", "", "getTAG", "()Ljava/lang/String;", "onViewCreated", Promotion.ACTION_VIEW, "getFormattedDate", ServerValues.NAME_OP_TIMESTAMP, "enable", "Lcom/google/android/material/button/MaterialButton;", "disable", "attachLayoutViews", "generateJwtToken", "response", "Lpk/gov/nadra/oneapp/models/sso/SSOPushAuthResponse;", "(Lcom/google/firebase/messaging/RemoteMessage;Lpk/gov/nadra/oneapp/models/sso/SSOPushAuthResponse;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendSSOPushAuth", "jwtToken", "getPushAuthPayload", "Lpk/gov/nadra/oneapp/models/sso/SSOPushAuthPayload;", "data", "", "sendPushAuthResponse", "onSuccess", "Lkotlin/Function1;", "", "(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DeepSSOConsentFragment extends Fragment {
    private final String TAG = "de_deep";
    private DeepOssConsentFragmnetBinding _binding;

    /* renamed from: authMainSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy authMainSharedViewModel;
    private RemoteMessage remoteMessage;

    public DeepSSOConsentFragment(RemoteMessage remoteMessage) {
        this.remoteMessage = remoteMessage;
        final DeepSSOConsentFragment deepSSOConsentFragment = this;
        final Function0 function0 = null;
        this.authMainSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(deepSSOConsentFragment, Reflection.getOrCreateKotlinClass(AuthMainSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = deepSSOConsentFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = deepSSOConsentFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = deepSSOConsentFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    public final RemoteMessage getRemoteMessage() {
        return this.remoteMessage;
    }

    public final void setRemoteMessage(RemoteMessage remoteMessage) {
        this.remoteMessage = remoteMessage;
    }

    private final DeepOssConsentFragmnetBinding getBinding() {
        DeepOssConsentFragmnetBinding deepOssConsentFragmnetBinding = this._binding;
        Intrinsics.checkNotNull(deepOssConsentFragmnetBinding);
        return deepOssConsentFragmnetBinding;
    }

    private final AuthMainSharedViewModel getAuthMainSharedViewModel() {
        return (AuthMainSharedViewModel) this.authMainSharedViewModel.getValue();
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = DeepOssConsentFragmnetBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    public final String getTAG() {
        return this.TAG;
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x008a  */
    @Override // androidx.fragment.app.Fragment
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onViewCreated(android.view.View r5, android.os.Bundle r6) {
        /*
            r4 = this;
            java.lang.String r0 = "view"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            super.onViewCreated(r5, r6)
            com.google.firebase.messaging.RemoteMessage r5 = r4.remoteMessage
            if (r5 != 0) goto L16
            pk.gov.nadra.oneapp.auth.main.viewModel.AuthMainSharedViewModel r5 = r4.getAuthMainSharedViewModel()
            com.google.firebase.messaging.RemoteMessage r5 = r5.getDeepRemoteMessage()
            r4.remoteMessage = r5
        L16:
            com.google.firebase.messaging.RemoteMessage r5 = r4.remoteMessage
            if (r5 == 0) goto Lee
            r4.attachLayoutViews(r5)
            pk.gov.nadra.oneapp.auth.main.databinding.DeepOssConsentFragmnetBinding r6 = r4.getBinding()
            android.widget.TextView r6 = r6.consentUserDataValue2
            android.text.method.LinkMovementMethod r0 = new android.text.method.LinkMovementMethod
            r0.<init>()
            android.text.method.MovementMethod r0 = (android.text.method.MovementMethod) r0
            r6.setMovementMethod(r0)
            android.content.Context r0 = r6.getContext()
            int r1 = pk.gov.nadra.oneapp.auth.main.R.string.sso_login_message
            java.util.Map r2 = r5.getData()
            java.lang.String r3 = "applicationName"
            java.lang.Object r2 = r2.get(r3)
            java.lang.Object[] r2 = new java.lang.Object[]{r2}
            java.lang.String r0 = r0.getString(r1, r2)
            android.text.Spanned r0 = android.text.Html.fromHtml(r0)
            java.lang.CharSequence r0 = (java.lang.CharSequence) r0
            r6.setText(r0)
            pk.gov.nadra.oneapp.auth.main.databinding.DeepOssConsentFragmnetBinding r6 = r4.getBinding()
            android.widget.TextView r6 = r6.consentUserDataValue3
            android.text.method.LinkMovementMethod r0 = new android.text.method.LinkMovementMethod
            r0.<init>()
            android.text.method.MovementMethod r0 = (android.text.method.MovementMethod) r0
            r6.setMovementMethod(r0)
            java.util.Map r0 = r5.getData()
            java.lang.String r1 = "browser"
            java.lang.Object r0 = r0.get(r1)
            java.util.Map r1 = r5.getData()
            java.lang.String r2 = "deviceOS"
            java.lang.Object r1 = r1.get(r2)
            com.google.firebase.messaging.RemoteMessage$Notification r2 = r5.getNotification()
            if (r2 == 0) goto L8a
            java.lang.Long r2 = r2.getEventTime()
            if (r2 == 0) goto L83
            java.lang.String r2 = r2.toString()
            goto L84
        L83:
            r2 = 0
        L84:
            java.lang.String r2 = r4.getFormattedDate(r2)
            if (r2 != 0) goto L9a
        L8a:
            java.util.Map r5 = r5.getData()
            java.lang.String r2 = "timestamp"
            java.lang.Object r5 = r5.get(r2)
            java.lang.String r5 = (java.lang.String) r5
            java.lang.String r2 = r4.getFormattedDate(r5)
        L9a:
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            java.lang.String r3 = "<ul><li><b>\tBrowser: </b>"
            r5.<init>(r3)
            java.lang.StringBuilder r5 = r5.append(r0)
            java.lang.String r0 = "</li><li><b>\tOperating System: </b>"
            java.lang.StringBuilder r5 = r5.append(r0)
            java.lang.StringBuilder r5 = r5.append(r1)
            java.lang.String r0 = "</li><li><b>\tDate & Time: </b>"
            java.lang.StringBuilder r5 = r5.append(r0)
            java.lang.StringBuilder r5 = r5.append(r2)
            java.lang.String r0 = "</li></ul>"
            java.lang.StringBuilder r5 = r5.append(r0)
            java.lang.String r5 = r5.toString()
            android.text.Spanned r5 = android.text.Html.fromHtml(r5)
            java.lang.CharSequence r5 = (java.lang.CharSequence) r5
            r6.setText(r5)
            pk.gov.nadra.oneapp.auth.main.databinding.DeepOssConsentFragmnetBinding r5 = r4.getBinding()
            android.widget.TextView r5 = r5.consentDetailInfo
            int r6 = pk.gov.nadra.oneapp.auth.main.R.string.do_you_want_to_approve_this_request
            java.lang.String r6 = r4.getString(r6)
            java.lang.CharSequence r6 = (java.lang.CharSequence) r6
            r5.setText(r6)
            pk.gov.nadra.oneapp.auth.main.databinding.DeepOssConsentFragmnetBinding r5 = r4.getBinding()
            android.widget.TextView r5 = r5.consentDescText
            int r6 = pk.gov.nadra.oneapp.auth.main.R.string.if_this_doesn_t_look_familiar_please_deny_the_message
            java.lang.String r6 = r4.getString(r6)
            java.lang.CharSequence r6 = (java.lang.CharSequence) r6
            r5.setText(r6)
        Lee:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment.onViewCreated(android.view.View, android.os.Bundle):void");
    }

    private final String getFormattedDate(String timestamp) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM dd, yyyy - h:mm a", Locale.getDefault());
        try {
            if (timestamp != null) {
                String str = simpleDateFormat.format(new Date(Long.parseLong(timestamp)));
                Intrinsics.checkNotNullExpressionValue(str, "format(...)");
                return str;
            }
            DeepSSOConsentFragment deepSSOConsentFragment = this;
            String str2 = simpleDateFormat.format(Calendar.getInstance().getTime());
            Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
            return str2;
        } catch (Exception e) {
            e.printStackTrace();
            String string = Calendar.getInstance().getTime().toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            return string;
        }
    }

    private final void enable(MaterialButton materialButton) {
        materialButton.setEnabled(true);
        materialButton.setAlpha(1.0f);
    }

    private final void disable(MaterialButton materialButton) {
        materialButton.setEnabled(false);
        materialButton.setAlpha(0.7f);
    }

    private final void attachLayoutViews(final RemoteMessage remoteMessage) {
        final DeepOssConsentFragmnetBinding binding = getBinding();
        binding.allowButtonLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                DeepSSOConsentFragment.attachLayoutViews$lambda$10$lambda$8(this.f$0, binding, remoteMessage, view);
            }
        });
        binding.denyButtonLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                DeepSSOConsentFragment.attachLayoutViews$lambda$10$lambda$9(this.f$0, binding, remoteMessage, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$10$lambda$8(DeepSSOConsentFragment this$0, DeepOssConsentFragmnetBinding this_apply, RemoteMessage remoteMessage, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        FragmentActivity fragmentActivityRequireActivity = this$0.requireActivity();
        Intrinsics.checkNotNullExpressionValue(fragmentActivityRequireActivity, "requireActivity(...)");
        loaderManager.showLoader(fragmentActivityRequireActivity);
        MaterialButton allowButtonLayout = this_apply.allowButtonLayout;
        Intrinsics.checkNotNullExpressionValue(allowButtonLayout, "allowButtonLayout");
        this$0.disable(allowButtonLayout);
        MaterialButton denyButtonLayout = this_apply.denyButtonLayout;
        Intrinsics.checkNotNullExpressionValue(denyButtonLayout, "denyButtonLayout");
        this$0.disable(denyButtonLayout);
        if (remoteMessage != null) {
            BuildersKt__Builders_commonKt.launch$default(LifecycleOwnerKt.getLifecycleScope(this$0), null, null, new DeepSSOConsentFragment$attachLayoutViews$1$1$1$1(this$0, remoteMessage, null), 3, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$10$lambda$9(DeepSSOConsentFragment this$0, DeepOssConsentFragmnetBinding this_apply, RemoteMessage remoteMessage, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        FragmentActivity fragmentActivityRequireActivity = this$0.requireActivity();
        Intrinsics.checkNotNullExpressionValue(fragmentActivityRequireActivity, "requireActivity(...)");
        loaderManager.showLoader(fragmentActivityRequireActivity);
        MaterialButton allowButtonLayout = this_apply.allowButtonLayout;
        Intrinsics.checkNotNullExpressionValue(allowButtonLayout, "allowButtonLayout");
        this$0.disable(allowButtonLayout);
        MaterialButton denyButtonLayout = this_apply.denyButtonLayout;
        Intrinsics.checkNotNullExpressionValue(denyButtonLayout, "denyButtonLayout");
        this$0.disable(denyButtonLayout);
        BuildersKt__Builders_commonKt.launch$default(LifecycleOwnerKt.getLifecycleScope(this$0), null, null, new DeepSSOConsentFragment$attachLayoutViews$1$2$1(remoteMessage, this$0, null), 3, null);
    }

    /* compiled from: DeepSSOConsentFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$generateJwtToken$2", f = "DeepSSOConsentFragment.kt", i = {}, l = {175, 196}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$generateJwtToken$2, reason: invalid class name */
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ RemoteMessage $remoteMessage;
        final /* synthetic */ SSOPushAuthResponse $response;
        int label;
        final /* synthetic */ DeepSSOConsentFragment this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(RemoteMessage remoteMessage, DeepSSOConsentFragment deepSSOConsentFragment, SSOPushAuthResponse sSOPushAuthResponse, Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
            this.$remoteMessage = remoteMessage;
            this.this$0 = deepSSOConsentFragment;
            this.$response = sSOPushAuthResponse;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new AnonymousClass2(this.$remoteMessage, this.this$0, this.$response, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code restructure failed: missing block: B:21:0x008b, code lost:
        
            if (r4.sendPushAuthResponse(r11, new pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$generateJwtToken$2$$ExternalSyntheticLambda0(r5, r0), r10) == r1) goto L25;
         */
        /* JADX WARN: Code restructure failed: missing block: B:24:0x00b6, code lost:
        
            if (kotlinx.coroutines.BuildersKt.withContext(kotlinx.coroutines.Dispatchers.getMain(), new pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment.AnonymousClass2.C02032(r10.this$0, null), r10) != r1) goto L26;
         */
        /* JADX WARN: Code restructure failed: missing block: B:25:0x00b8, code lost:
        
            return r1;
         */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r11) {
            /*
                r10 = this;
                java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r0 = r10.label
                r2 = 2
                r3 = 1
                if (r0 == 0) goto L23
                if (r0 == r3) goto L1b
                if (r0 != r2) goto L13
                kotlin.ResultKt.throwOnFailure(r11)
                goto Lb9
            L13:
                java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r11.<init>(r0)
                throw r11
            L1b:
                kotlin.ResultKt.throwOnFailure(r11)     // Catch: java.lang.Exception -> L20
                goto Lc2
            L20:
                r0 = move-exception
                r11 = r0
                goto L8e
            L23:
                kotlin.ResultKt.throwOnFailure(r11)
                com.google.firebase.messaging.RemoteMessage r11 = r10.$remoteMessage
                java.util.Map r11 = r11.getData()
                java.lang.String r0 = "getData(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r11, r0)
                boolean r11 = r11.isEmpty()
                if (r11 != 0) goto Lc2
                pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment r11 = r10.this$0
                com.google.firebase.messaging.RemoteMessage r4 = r10.$remoteMessage
                java.util.Map r4 = r4.getData()
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r0)
                pk.gov.nadra.oneapp.models.sso.SSOPushAuthPayload r11 = pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment.access$getPushAuthPayload(r11, r4)
                java.lang.String r4 = r11.getDeviceId()     // Catch: java.lang.Exception -> L20
                java.lang.String r5 = r11.getPushId()     // Catch: java.lang.Exception -> L20
                java.lang.String r6 = r11.getChallenge()     // Catch: java.lang.Exception -> L20
                pk.gov.nadra.oneapp.models.sso.SSOPushAuthResponse r11 = r10.$response     // Catch: java.lang.Exception -> L20
                java.lang.String r7 = r11.name()     // Catch: java.lang.Exception -> L20
                pk.gov.nadra.oneapp.commonutils.utils.RSAKeyPair r11 = pk.gov.nadra.oneapp.commonutils.utils.RSAKeyPair.INSTANCE     // Catch: java.lang.Exception -> L20
                java.security.PrivateKey r8 = r11.getPrivateKey()     // Catch: java.lang.Exception -> L20
                r9 = 0
                java.lang.String r11 = pk.gov.nadra.oneapp.commonutils.utils.JwtUtil.createPushAuthJwt(r4, r5, r6, r7, r8, r9)     // Catch: java.lang.Exception -> L20
                pk.gov.nadra.oneapp.models.sso.SSOPushAuthResponse r0 = r10.$response     // Catch: java.lang.Exception -> L20
                java.lang.String r0 = r0.name()     // Catch: java.lang.Exception -> L20
                java.lang.String r4 = "APPROVED"
                boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r4)     // Catch: java.lang.Exception -> L20
                if (r0 == 0) goto L74
                java.lang.String r0 = "Approved"
                goto L76
            L74:
                java.lang.String r0 = "Rejected"
            L76:
                pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment r4 = r10.this$0     // Catch: java.lang.Exception -> L20
                kotlin.jvm.internal.Intrinsics.checkNotNull(r11)     // Catch: java.lang.Exception -> L20
                pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment r5 = r10.this$0     // Catch: java.lang.Exception -> L20
                pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$generateJwtToken$2$$ExternalSyntheticLambda0 r6 = new pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$generateJwtToken$2$$ExternalSyntheticLambda0     // Catch: java.lang.Exception -> L20
                r6.<init>()     // Catch: java.lang.Exception -> L20
                r0 = r10
                kotlin.coroutines.Continuation r0 = (kotlin.coroutines.Continuation) r0     // Catch: java.lang.Exception -> L20
                r10.label = r3     // Catch: java.lang.Exception -> L20
                java.lang.Object r11 = r4.sendPushAuthResponse(r11, r6, r0)     // Catch: java.lang.Exception -> L20
                if (r11 != r1) goto Lc2
                goto Lb8
            L8e:
                java.lang.String r0 = r11.getMessage()
                kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
                java.lang.String r3 = "NOTIFICATION"
                android.util.Log.d(r3, r0)
                r11.printStackTrace()
                kotlinx.coroutines.MainCoroutineDispatcher r11 = kotlinx.coroutines.Dispatchers.getMain()
                kotlin.coroutines.CoroutineContext r11 = (kotlin.coroutines.CoroutineContext) r11
                pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$generateJwtToken$2$2 r0 = new pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$generateJwtToken$2$2
                pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment r3 = r10.this$0
                r4 = 0
                r0.<init>(r3, r4)
                kotlin.jvm.functions.Function2 r0 = (kotlin.jvm.functions.Function2) r0
                r3 = r10
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                r10.label = r2
                java.lang.Object r11 = kotlinx.coroutines.BuildersKt.withContext(r11, r0, r3)
                if (r11 != r1) goto Lb9
            Lb8:
                return r1
            Lb9:
                pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment r11 = r10.this$0
                androidx.fragment.app.FragmentActivity r11 = r11.requireActivity()
                r11.finishAndRemoveTask()
            Lc2:
                kotlin.Unit r11 = kotlin.Unit.INSTANCE
                return r11
            */
            throw new UnsupportedOperationException("Method not decompiled: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment.AnonymousClass2.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(DeepSSOConsentFragment deepSSOConsentFragment, String str, boolean z) {
            BuildersKt__Builders_commonKt.launch$default(LifecycleOwnerKt.getLifecycleScope(deepSSOConsentFragment), Dispatchers.getMain(), null, new DeepSSOConsentFragment$generateJwtToken$2$1$1(deepSSOConsentFragment, z, str, null), 2, null);
            return Unit.INSTANCE;
        }

        /* compiled from: DeepSSOConsentFragment.kt */
        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
        @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$generateJwtToken$2$2", f = "DeepSSOConsentFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        /* renamed from: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$generateJwtToken$2$2, reason: invalid class name and collision with other inner class name */
        static final class C02032 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ DeepSSOConsentFragment this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C02032(DeepSSOConsentFragment deepSSOConsentFragment, Continuation<? super C02032> continuation) {
                super(2, continuation);
                this.this$0 = deepSSOConsentFragment;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new C02032(this.this$0, continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return ((C02032) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object obj) {
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                if (this.label != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
                LoaderManager loaderManager = LoaderManager.INSTANCE;
                FragmentActivity fragmentActivityRequireActivity = this.this$0.requireActivity();
                Intrinsics.checkNotNullExpressionValue(fragmentActivityRequireActivity, "requireActivity(...)");
                loaderManager.hideLoader(fragmentActivityRequireActivity);
                Toast.makeText(this.this$0.requireActivity(), "Authenticate Failed", 0).show();
                return Unit.INSTANCE;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object generateJwtToken(RemoteMessage remoteMessage, SSOPushAuthResponse sSOPushAuthResponse, Continuation<? super Unit> continuation) {
        Object objWithContext = BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass2(remoteMessage, this, sSOPushAuthResponse, null), continuation);
        return objWithContext == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : Unit.INSTANCE;
    }

    private final void sendSSOPushAuth(String jwtToken, final SSOPushAuthResponse response) throws IOException {
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNullExpressionValue(fragmentActivityRequireActivity, "requireActivity(...)");
        new APIRequests(fragmentActivityRequireActivity).sendSSOAuthResponse(new SSOAuthRequest(jwtToken), new Function3() { // from class: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return DeepSSOConsentFragment.sendSSOPushAuth$lambda$11(this.f$0, response, (String) obj, (String) obj2, ((Integer) obj3).intValue());
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit sendSSOPushAuth$lambda$11(DeepSSOConsentFragment this$0, SSOPushAuthResponse response, String jsonResponse, String responseType, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(response, "$response");
        Intrinsics.checkNotNullParameter(jsonResponse, "jsonResponse");
        Intrinsics.checkNotNullParameter(responseType, "responseType");
        Log.d(this$0.TAG, "sendSSOPushAuth: " + jsonResponse);
        if (Intrinsics.areEqual(responseType, "SUCCESS")) {
            Intrinsics.areEqual(response.name(), "APPROVED");
        }
        this$0.requireActivity().finishAndRemoveTask();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final SSOPushAuthPayload getPushAuthPayload(Map<String, String> data) {
        SSOPushAuthPayload sSOPushAuthPayload = new SSOPushAuthPayload();
        sSOPushAuthPayload.setApplicationName(data.get("applicationName"));
        sSOPushAuthPayload.setPushId(data.get("pushId"));
        sSOPushAuthPayload.setUserStoreDomain(data.get("userStoreDomain"));
        sSOPushAuthPayload.setUsername(data.get("username"));
        sSOPushAuthPayload.setBrowser(data.get("browser"));
        sSOPushAuthPayload.setDeviceId(data.get("deviceId"));
        sSOPushAuthPayload.setDeviceOS(data.get("deviceOS"));
        sSOPushAuthPayload.setChallenge(data.get("challenge"));
        sSOPushAuthPayload.setNotificationScenario(data.get("notificationScenario"));
        sSOPushAuthPayload.setIpAddress(data.get("ipAddress"));
        sSOPushAuthPayload.setTenantDomain(data.get("tenantDomain"));
        return sSOPushAuthPayload;
    }

    /* compiled from: DeepSSOConsentFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$sendPushAuthResponse$2", f = "DeepSSOConsentFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$sendPushAuthResponse$2, reason: invalid class name and case insensitive filesystem */
    static final class C11162 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $jwtToken;
        final /* synthetic */ Function1<Boolean, Unit> $onSuccess;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C11162(String str, Function1<? super Boolean, Unit> function1, Continuation<? super C11162> continuation) {
            super(2, continuation);
            this.$jwtToken = str;
            this.$onSuccess = function1;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return DeepSSOConsentFragment.this.new C11162(this.$jwtToken, this.$onSuccess, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11162) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            FragmentActivity fragmentActivityRequireActivity = DeepSSOConsentFragment.this.requireActivity();
            Intrinsics.checkNotNullExpressionValue(fragmentActivityRequireActivity, "requireActivity(...)");
            APIRequests aPIRequests = new APIRequests(fragmentActivityRequireActivity);
            SSOAuthRequest sSOAuthRequest = new SSOAuthRequest(this.$jwtToken);
            final Function1<Boolean, Unit> function1 = this.$onSuccess;
            aPIRequests.sendSSOAuth(sSOAuthRequest, new Function3() { // from class: pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$sendPushAuthResponse$2$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return DeepSSOConsentFragment.C11162.invokeSuspend$lambda$0(function1, (String) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(Function1 function1, String str, String str2, int i) {
            if (Intrinsics.areEqual(str2, "SUCCESS")) {
                function1.invoke(true);
            } else {
                function1.invoke(false);
            }
            return Unit.INSTANCE;
        }
    }

    public final Object sendPushAuthResponse(String str, Function1<? super Boolean, Unit> function1, Continuation<? super Unit> continuation) throws IOException {
        Object objWithContext = BuildersKt.withContext(Dispatchers.getIO(), new C11162(str, function1, null), continuation);
        return objWithContext == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : Unit.INSTANCE;
    }
}