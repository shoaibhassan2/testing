package pk.gov.nadra.oneapp.auth.main.deep;

import android.content.Context;
import android.os.Build;
import android.util.Base64;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.morpho.lkms.android.sdk.lkms_core.network.RestParams;
import java.nio.charset.Charset;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CancellableContinuationImpl;
import org.json.JSONException;
import org.json.JSONObject;
import pk.gov.nadra.oneapp.commonutils.utils.JwtUtil;
import pk.gov.nadra.oneapp.commonutils.utils.RSAKeyPair;
import pk.gov.nadra.oneapp.models.sso.DiscoveryData;
import pk.gov.nadra.oneapp.models.sso.PushDeviceRequest;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: DeviceRegistrationUtil.kt */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0086@¢\u0006\u0002\u0010\bJ\"\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0002J@\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0011\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\u0012\u001a\u00020\n2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0086@¢\u0006\u0002\u0010\u0013J*\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0011\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0002J\"\u0010\u0016\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0002J\u001e\u0010\u0017\u001a\u00020\u00102\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0018\u001a\u00020\u0015H\u0082@¢\u0006\u0002\u0010\u0019J\u0010\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u0015H\u0002¨\u0006\u001d"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/deep/DeviceRegistrationUtil;", "", "<init>", "()V", "discoverDevice", "Lpk/gov/nadra/oneapp/models/sso/DiscoveryData;", "context", "Landroid/content/Context;", "(Landroid/content/Context;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "generateAsgardeoSignature", "", "challenge", "deviceToken", "privateKey", "Ljava/security/PrivateKey;", "registerDevice", "", "deviceId", "token", "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/security/PrivateKey;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getPushDeviceRequestPayload", "Lpk/gov/nadra/oneapp/models/sso/PushDeviceRequest;", "getSignature", "registerDeviceOnServer", "pushDeviceRequest", "(Landroid/content/Context;Lpk/gov/nadra/oneapp/models/sso/PushDeviceRequest;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getRequestPayloadJsonObject", "Lorg/json/JSONObject;", "requestPayload", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DeviceRegistrationUtil {
    public static final DeviceRegistrationUtil INSTANCE = new DeviceRegistrationUtil();

    private DeviceRegistrationUtil() {
    }

    private final String generateAsgardeoSignature(String challenge, String deviceToken, PrivateKey privateKey) throws Exception {
        String str = challenge + "." + deviceToken;
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(privateKey);
        Charset charsetForName = Charset.forName("UTF-8");
        Intrinsics.checkNotNullExpressionValue(charsetForName, "forName(...)");
        byte[] bytes = str.getBytes(charsetForName);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        signature.update(bytes);
        String strEncodeToString = Base64.encodeToString(signature.sign(), 2);
        Intrinsics.checkNotNullExpressionValue(strEncodeToString, "encodeToString(...)");
        return strEncodeToString;
    }

    public final Object registerDevice(Context context, String str, String str2, String str3, String str4, PrivateKey privateKey, Continuation<? super Boolean> continuation) {
        return registerDeviceOnServer(context, getPushDeviceRequestPayload(str, str2, str3, privateKey), continuation);
    }

    private final PushDeviceRequest getPushDeviceRequestPayload(String deviceId, String challenge, String deviceToken, PrivateKey privateKey) throws Exception {
        String str = Build.MANUFACTURER;
        String str2 = Build.MODEL;
        String strGeneratePublicKeyBase64 = RSAKeyPair.INSTANCE.generatePublicKeyBase64(RSAKeyPair.INSTANCE.getKeyPair());
        String signature = getSignature(challenge, deviceToken, privateKey);
        String strDeviceUnlinkToken = JwtUtil.deviceUnlinkToken(deviceId, UUID.randomUUID().toString(), challenge, privateKey, null);
        Intrinsics.checkNotNull(str2);
        Intrinsics.checkNotNull(str);
        Intrinsics.checkNotNull(strDeviceUnlinkToken);
        return new PushDeviceRequest(deviceToken, str2, str, deviceToken, strGeneratePublicKeyBase64, signature, strDeviceUnlinkToken, deviceId);
    }

    private final String getSignature(String challenge, String deviceToken, PrivateKey privateKey) {
        return generateAsgardeoSignature(challenge, deviceToken, privateKey);
    }

    private final JSONObject getRequestPayloadJsonObject(PushDeviceRequest requestPayload) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("deviceId", requestPayload.getDeviceId());
        jSONObject.put(RestParams.PARAM_KEY_TERMINAL_MODEL, requestPayload.getModel());
        jSONObject.put("name", requestPayload.getName());
        jSONObject.put("deviceToken", requestPayload.getDeviceToken());
        jSONObject.put("publicKey", requestPayload.getPublicKey());
        jSONObject.put("signature", requestPayload.getSignature());
        jSONObject.put("unlinkToken", requestPayload.getUnlinkToken());
        jSONObject.put("iamDeviceId", requestPayload.getIamDeviceId());
        return jSONObject;
    }

    public final Object discoverDevice(Context context, Continuation<? super DiscoveryData> continuation) {
        CancellableContinuationImpl cancellableContinuationImpl = new CancellableContinuationImpl(IntrinsicsKt.intercepted(continuation), 1);
        cancellableContinuationImpl.initCancellability();
        final CancellableContinuationImpl cancellableContinuationImpl2 = cancellableContinuationImpl;
        new APIRequests(context).discoverDevice(new Function3<JsonObject, String, Integer, Unit>() { // from class: pk.gov.nadra.oneapp.auth.main.deep.DeviceRegistrationUtil$discoverDevice$2$1
            @Override // kotlin.jvm.functions.Function3
            public /* bridge */ /* synthetic */ Unit invoke(JsonObject jsonObject, String str, Integer num) {
                invoke(jsonObject, str, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(JsonObject jsonResponse, String responseType, int i) {
                Intrinsics.checkNotNullParameter(jsonResponse, "jsonResponse");
                Intrinsics.checkNotNullParameter(responseType, "responseType");
                if (Intrinsics.areEqual(responseType, "SUCCESS")) {
                    try {
                        DiscoveryData discoveryData = (DiscoveryData) new Gson().fromJson(jsonResponse.toString(), DiscoveryData.class);
                        CancellableContinuation<DiscoveryData> cancellableContinuation = cancellableContinuationImpl2;
                        Result.Companion companion = Result.INSTANCE;
                        cancellableContinuation.resumeWith(Result.m7258constructorimpl(discoveryData));
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        CancellableContinuation<DiscoveryData> cancellableContinuation2 = cancellableContinuationImpl2;
                        Result.Companion companion2 = Result.INSTANCE;
                        cancellableContinuation2.resumeWith(Result.m7258constructorimpl(null));
                        return;
                    }
                }
                CancellableContinuation<DiscoveryData> cancellableContinuation3 = cancellableContinuationImpl2;
                Result.Companion companion3 = Result.INSTANCE;
                cancellableContinuation3.resumeWith(Result.m7258constructorimpl(null));
            }
        });
        Object result = cancellableContinuationImpl.getResult();
        if (result == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            DebugProbesKt.probeCoroutineSuspended(continuation);
        }
        return result;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object registerDeviceOnServer(Context context, PushDeviceRequest pushDeviceRequest, Continuation<? super Boolean> continuation) {
        CancellableContinuationImpl cancellableContinuationImpl = new CancellableContinuationImpl(IntrinsicsKt.intercepted(continuation), 1);
        cancellableContinuationImpl.initCancellability();
        final CancellableContinuationImpl cancellableContinuationImpl2 = cancellableContinuationImpl;
        new APIRequests(context).registerDevice(pushDeviceRequest, new Function3<String, String, Integer, Unit>() { // from class: pk.gov.nadra.oneapp.auth.main.deep.DeviceRegistrationUtil$registerDeviceOnServer$2$1
            @Override // kotlin.jvm.functions.Function3
            public /* bridge */ /* synthetic */ Unit invoke(String str, String str2, Integer num) {
                invoke(str, str2, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(String jsonResponse, String responseType, int i) {
                Intrinsics.checkNotNullParameter(jsonResponse, "jsonResponse");
                Intrinsics.checkNotNullParameter(responseType, "responseType");
                CancellableContinuation<Boolean> cancellableContinuation = cancellableContinuationImpl2;
                Result.Companion companion = Result.INSTANCE;
                cancellableContinuation.resumeWith(Result.m7258constructorimpl(Boolean.valueOf(Intrinsics.areEqual(responseType, "SUCCESS"))));
            }
        });
        Object result = cancellableContinuationImpl.getResult();
        if (result == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            DebugProbesKt.probeCoroutineSuspended(continuation);
        }
        return result;
    }
}