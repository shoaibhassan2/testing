package pk.gov.nadra.oneapp.auth.main.deep;

import android.widget.Toast;
import androidx.fragment.app.FragmentActivity;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineScope;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;

/* compiled from: DeepSSOConsentFragment.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.deep.DeepSSOConsentFragment$generateJwtToken$2$1$1", f = "DeepSSOConsentFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* loaded from: classes5.dex */
final class DeepSSOConsentFragment$generateJwtToken$2$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ boolean $callback;
    final /* synthetic */ String $result;
    int label;
    final /* synthetic */ DeepSSOConsentFragment this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    DeepSSOConsentFragment$generateJwtToken$2$1$1(DeepSSOConsentFragment deepSSOConsentFragment, boolean z, String str, Continuation<? super DeepSSOConsentFragment$generateJwtToken$2$1$1> continuation) {
        super(2, continuation);
        this.this$0 = deepSSOConsentFragment;
        this.$callback = z;
        this.$result = str;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new DeepSSOConsentFragment$generateJwtToken$2$1$1(this.this$0, this.$callback, this.$result, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((DeepSSOConsentFragment$generateJwtToken$2$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object obj) {
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        ResultKt.throwOnFailure(obj);
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        FragmentActivity fragmentActivityRequireActivity = this.this$0.requireActivity();
        Intrinsics.checkNotNullExpressionValue(fragmentActivityRequireActivity, "requireActivity(...)");
        loaderManager.hideLoader(fragmentActivityRequireActivity);
        if (this.$callback) {
            Toast.makeText(this.this$0.requireActivity(), this.$result, 0).show();
        } else {
            Toast.makeText(this.this$0.requireActivity(), "Authenticate Failed", 0).show();
        }
        this.this$0.requireActivity().finishAndRemoveTask();
        return Unit.INSTANCE;
    }
}