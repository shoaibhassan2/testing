package pk.gov.nadra.oneapp.auth.main.deep;

import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.models.sso.SSOPushAuthResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DeepSSOConsentFragment$$ExternalSyntheticLambda0 implements Function3 {
    public final /* synthetic */ SSOPushAuthResponse f$1;

    public /* synthetic */ DeepSSOConsentFragment$$ExternalSyntheticLambda0(SSOPushAuthResponse sSOPushAuthResponse) {
        response = sSOPushAuthResponse;
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return DeepSSOConsentFragment.sendSSOPushAuth$lambda$11(this.f$0, response, (String) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}