package pk.gov.nadra.oneapp.auth.main.deep;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CancellableContinuation;
import pk.gov.nadra.oneapp.models.sso.DiscoveryData;

/* compiled from: DeviceRegistrationUtil.kt */
@Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
final class DeviceRegistrationUtil$discoverDevice$2$1 implements Function3<JsonObject, String, Integer, Unit> {
    final /* synthetic */ CancellableContinuation<DiscoveryData> $cont;

    /* JADX WARN: Multi-variable type inference failed */
    DeviceRegistrationUtil$discoverDevice$2$1(CancellableContinuation<? super DiscoveryData> cancellableContinuation) {
        cancellableContinuationImpl2 = cancellableContinuation;
    }

    @Override // kotlin.jvm.functions.Function3
    public /* bridge */ /* synthetic */ Unit invoke(JsonObject jsonObject, String str, Integer num) {
        invoke(jsonObject, str, num.intValue());
        return Unit.INSTANCE;
    }

    public final void invoke(JsonObject jsonResponse, String responseType, int i) {
        Intrinsics.checkNotNullParameter(jsonResponse, "jsonResponse");
        Intrinsics.checkNotNullParameter(responseType, "responseType");
        if (Intrinsics.areEqual(responseType, "SUCCESS")) {
            try {
                DiscoveryData discoveryData = (DiscoveryData) new Gson().fromJson(jsonResponse.toString(), DiscoveryData.class);
                CancellableContinuation<DiscoveryData> cancellableContinuation = cancellableContinuationImpl2;
                Result.Companion companion = Result.INSTANCE;
                cancellableContinuation.resumeWith(Result.m7258constructorimpl(discoveryData));
                return;
            } catch (Exception e) {
                e.printStackTrace();
                CancellableContinuation<DiscoveryData> cancellableContinuation2 = cancellableContinuationImpl2;
                Result.Companion companion2 = Result.INSTANCE;
                cancellableContinuation2.resumeWith(Result.m7258constructorimpl(null));
                return;
            }
        }
        CancellableContinuation<DiscoveryData> cancellableContinuation3 = cancellableContinuationImpl2;
        Result.Companion companion3 = Result.INSTANCE;
        cancellableContinuation3.resumeWith(Result.m7258constructorimpl(null));
    }
}