package pk.gov.nadra.oneapp.auth.main.deep;

import android.view.View;
import com.google.firebase.messaging.RemoteMessage;
import pk.gov.nadra.oneapp.auth.main.databinding.DeepOssConsentFragmnetBinding;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DeepSSOConsentFragment$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public final /* synthetic */ DeepOssConsentFragmnetBinding f$1;
    public final /* synthetic */ RemoteMessage f$2;

    public /* synthetic */ DeepSSOConsentFragment$$ExternalSyntheticLambda1(DeepOssConsentFragmnetBinding deepOssConsentFragmnetBinding, RemoteMessage remoteMessage) {
        binding = deepOssConsentFragmnetBinding;
        remoteMessage = remoteMessage;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        DeepSSOConsentFragment.attachLayoutViews$lambda$10$lambda$8(this.f$0, binding, remoteMessage, view);
    }
}