package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.RadioGroupLayoutBinding;

/* loaded from: classes5.dex */
public final class RegisterVerifyIdentityFragmentBinding implements ViewBinding {
    public final TextView emailVerificationResendDescriptionTextView;
    public final EdittextLayoutBinding issueDobDateLayout;
    public final RadioGroupLayoutBinding issueDobDateRadioGroup;
    public final MaskedEdittextLayoutBinding registerVerifyCnicLayout;
    public final ConfigurableButton registerVerifyNextButtonLayout;
    private final ConstraintLayout rootView;
    public final ImageView verifyIdentityIconImageView;
    public final TextView verifyIdentityLabelTextView;
    public final TextView verifyIdentityTextView;

    private RegisterVerifyIdentityFragmentBinding(ConstraintLayout rootView, TextView emailVerificationResendDescriptionTextView, EdittextLayoutBinding issueDobDateLayout, RadioGroupLayoutBinding issueDobDateRadioGroup, MaskedEdittextLayoutBinding registerVerifyCnicLayout, ConfigurableButton registerVerifyNextButtonLayout, ImageView verifyIdentityIconImageView, TextView verifyIdentityLabelTextView, TextView verifyIdentityTextView) {
        this.rootView = rootView;
        this.emailVerificationResendDescriptionTextView = emailVerificationResendDescriptionTextView;
        this.issueDobDateLayout = issueDobDateLayout;
        this.issueDobDateRadioGroup = issueDobDateRadioGroup;
        this.registerVerifyCnicLayout = registerVerifyCnicLayout;
        this.registerVerifyNextButtonLayout = registerVerifyNextButtonLayout;
        this.verifyIdentityIconImageView = verifyIdentityIconImageView;
        this.verifyIdentityLabelTextView = verifyIdentityLabelTextView;
        this.verifyIdentityTextView = verifyIdentityTextView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static RegisterVerifyIdentityFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static RegisterVerifyIdentityFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.register_verify_identity_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static RegisterVerifyIdentityFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        int i = R.id.email_verification_resend_description_textView;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.issue_dob_date_layout))) != null) {
            EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById);
            i = R.id.issue_dob_date_radio_group;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, i);
            if (viewFindChildViewById2 != null) {
                RadioGroupLayoutBinding radioGroupLayoutBindingBind = RadioGroupLayoutBinding.bind(viewFindChildViewById2);
                i = R.id.register_verify_cnic_layout;
                View viewFindChildViewById3 = ViewBindings.findChildViewById(rootView, i);
                if (viewFindChildViewById3 != null) {
                    MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById3);
                    i = R.id.register_verify_next_button_layout;
                    ConfigurableButton configurableButton = (ConfigurableButton) ViewBindings.findChildViewById(rootView, i);
                    if (configurableButton != null) {
                        i = R.id.verify_identity_icon_imageView;
                        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                        if (imageView != null) {
                            i = R.id.verify_identity_label_textView;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                            if (textView2 != null) {
                                i = R.id.verify_identity_textView;
                                TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                if (textView3 != null) {
                                    return new RegisterVerifyIdentityFragmentBinding((ConstraintLayout) rootView, textView, edittextLayoutBindingBind, radioGroupLayoutBindingBind, maskedEdittextLayoutBindingBind, configurableButton, imageView, textView2, textView3);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}