package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class RvOptionsCardItemBinding implements ViewBinding {
    private final MaterialCardView rootView;
    public final MaterialCardView rvCardLayout;
    public final TextView rvDesc;
    public final ImageView rvImage;
    public final TextView rvTitle;
    public final TextView rvUrduDesc;
    public final TextView rvUrduTitle;

    private RvOptionsCardItemBinding(MaterialCardView rootView, MaterialCardView rvCardLayout, TextView rvDesc, ImageView rvImage, TextView rvTitle, TextView rvUrduDesc, TextView rvUrduTitle) {
        this.rootView = rootView;
        this.rvCardLayout = rvCardLayout;
        this.rvDesc = rvDesc;
        this.rvImage = rvImage;
        this.rvTitle = rvTitle;
        this.rvUrduDesc = rvUrduDesc;
        this.rvUrduTitle = rvUrduTitle;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static RvOptionsCardItemBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static RvOptionsCardItemBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.rv_options_card_item, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static RvOptionsCardItemBinding bind(View rootView) {
        MaterialCardView materialCardView = (MaterialCardView) rootView;
        int i = R.id.rv_desc;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null) {
            i = R.id.rv_image;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
            if (imageView != null) {
                i = R.id.rv_title;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView2 != null) {
                    i = R.id.rv_urdu_desc;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView3 != null) {
                        i = R.id.rv_urdu_title;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                        if (textView4 != null) {
                            return new RvOptionsCardItemBinding(materialCardView, materialCardView, textView, imageView, textView2, textView3, textView4);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}