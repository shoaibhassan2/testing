package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class ForgotPasswordSetNewPasswordFragmentBinding implements ViewBinding {
    public final ButtonLayoutBinding confirmButtonLayout;
    public final TextView criteriaFifthTextView;
    public final TextView criteriaFirstTextView;
    public final TextView criteriaFourthTextView;
    public final TextView criteriaSecondTextView;
    public final TextView criteriaThirdTextView;
    public final TextInputLayout enterOldPasswordLayout;
    public final TextInputLayout enterPasswordLayout;
    public final ScrollView familyDetailsScrollView;
    public final TextView forgotPasswordTextView;
    public final UpdatedHeaderLayoutBackTitleBinding headerLayout;
    public final TextInputEditText oldPasswordTextInputEditText;
    public final ConstraintLayout passwordConstraintLayout;
    public final TextInputEditText passwordTextInputEditText;
    public final TextInputLayout reEnterPasswordLayout;
    public final TextInputEditText rePasswordTextInputEditText;
    private final ConstraintLayout rootView;
    public final TextView setNewPasswordDescriptionTextView;
    public final TextView setNewPasswordLabelTextView;

    private ForgotPasswordSetNewPasswordFragmentBinding(ConstraintLayout rootView, ButtonLayoutBinding confirmButtonLayout, TextView criteriaFifthTextView, TextView criteriaFirstTextView, TextView criteriaFourthTextView, TextView criteriaSecondTextView, TextView criteriaThirdTextView, TextInputLayout enterOldPasswordLayout, TextInputLayout enterPasswordLayout, ScrollView familyDetailsScrollView, TextView forgotPasswordTextView, UpdatedHeaderLayoutBackTitleBinding headerLayout, TextInputEditText oldPasswordTextInputEditText, ConstraintLayout passwordConstraintLayout, TextInputEditText passwordTextInputEditText, TextInputLayout reEnterPasswordLayout, TextInputEditText rePasswordTextInputEditText, TextView setNewPasswordDescriptionTextView, TextView setNewPasswordLabelTextView) {
        this.rootView = rootView;
        this.confirmButtonLayout = confirmButtonLayout;
        this.criteriaFifthTextView = criteriaFifthTextView;
        this.criteriaFirstTextView = criteriaFirstTextView;
        this.criteriaFourthTextView = criteriaFourthTextView;
        this.criteriaSecondTextView = criteriaSecondTextView;
        this.criteriaThirdTextView = criteriaThirdTextView;
        this.enterOldPasswordLayout = enterOldPasswordLayout;
        this.enterPasswordLayout = enterPasswordLayout;
        this.familyDetailsScrollView = familyDetailsScrollView;
        this.forgotPasswordTextView = forgotPasswordTextView;
        this.headerLayout = headerLayout;
        this.oldPasswordTextInputEditText = oldPasswordTextInputEditText;
        this.passwordConstraintLayout = passwordConstraintLayout;
        this.passwordTextInputEditText = passwordTextInputEditText;
        this.reEnterPasswordLayout = reEnterPasswordLayout;
        this.rePasswordTextInputEditText = rePasswordTextInputEditText;
        this.setNewPasswordDescriptionTextView = setNewPasswordDescriptionTextView;
        this.setNewPasswordLabelTextView = setNewPasswordLabelTextView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ForgotPasswordSetNewPasswordFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static ForgotPasswordSetNewPasswordFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.forgot_password_set_new_password_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ForgotPasswordSetNewPasswordFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        int i = R.id.confirm_button_layout;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById2 != null) {
            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById2);
            i = R.id.criteria_fifth_textView;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null) {
                i = R.id.criteria_first_textView;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView2 != null) {
                    i = R.id.criteria_fourth_textView;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView3 != null) {
                        i = R.id.criteria_second_textView;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                        if (textView4 != null) {
                            i = R.id.criteria_third_textView;
                            TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                            if (textView5 != null) {
                                i = R.id.enter_old_password_layout;
                                TextInputLayout textInputLayout = (TextInputLayout) ViewBindings.findChildViewById(rootView, i);
                                if (textInputLayout != null) {
                                    i = R.id.enter_password_layout;
                                    TextInputLayout textInputLayout2 = (TextInputLayout) ViewBindings.findChildViewById(rootView, i);
                                    if (textInputLayout2 != null) {
                                        i = R.id.family_details_scrollView;
                                        ScrollView scrollView = (ScrollView) ViewBindings.findChildViewById(rootView, i);
                                        if (scrollView != null) {
                                            i = R.id.forgot_password_textView;
                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                            if (textView6 != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.headerLayout))) != null) {
                                                UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
                                                i = R.id.old_password_textInputEditText;
                                                TextInputEditText textInputEditText = (TextInputEditText) ViewBindings.findChildViewById(rootView, i);
                                                if (textInputEditText != null) {
                                                    i = R.id.password_constraint_layout;
                                                    ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                                                    if (constraintLayout != null) {
                                                        i = R.id.password_textInputEditText;
                                                        TextInputEditText textInputEditText2 = (TextInputEditText) ViewBindings.findChildViewById(rootView, i);
                                                        if (textInputEditText2 != null) {
                                                            i = R.id.re_enter_password_layout;
                                                            TextInputLayout textInputLayout3 = (TextInputLayout) ViewBindings.findChildViewById(rootView, i);
                                                            if (textInputLayout3 != null) {
                                                                i = R.id.re_password_textInputEditText;
                                                                TextInputEditText textInputEditText3 = (TextInputEditText) ViewBindings.findChildViewById(rootView, i);
                                                                if (textInputEditText3 != null) {
                                                                    i = R.id.set_new_password_description_textView;
                                                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                    if (textView7 != null) {
                                                                        i = R.id.set_new_password_label_textView;
                                                                        TextView textView8 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                        if (textView8 != null) {
                                                                            return new ForgotPasswordSetNewPasswordFragmentBinding((ConstraintLayout) rootView, buttonLayoutBindingBind, textView, textView2, textView3, textView4, textView5, textInputLayout, textInputLayout2, scrollView, textView6, updatedHeaderLayoutBackTitleBindingBind, textInputEditText, constraintLayout, textInputEditText2, textInputLayout3, textInputEditText3, textView7, textView8);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}