package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class DashboardItemDigitalCardLayoutBinding implements ViewBinding {
    public final ConstraintLayout digitalCardCardView;
    public final ImageView generateDigitalCardImageView;
    private final ConstraintLayout rootView;
    public final ImageView viewDigitalCardImageView;

    private DashboardItemDigitalCardLayoutBinding(ConstraintLayout rootView, ConstraintLayout digitalCardCardView, ImageView generateDigitalCardImageView, ImageView viewDigitalCardImageView) {
        this.rootView = rootView;
        this.digitalCardCardView = digitalCardCardView;
        this.generateDigitalCardImageView = generateDigitalCardImageView;
        this.viewDigitalCardImageView = viewDigitalCardImageView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static DashboardItemDigitalCardLayoutBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static DashboardItemDigitalCardLayoutBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.dashboard_item_digital_card_layout, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static DashboardItemDigitalCardLayoutBinding bind(View rootView) {
        ConstraintLayout constraintLayout = (ConstraintLayout) rootView;
        int i = R.id.generate_digital_card_imageView;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
        if (imageView != null) {
            i = R.id.view_digital_card_imageView;
            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(rootView, i);
            if (imageView2 != null) {
                return new DashboardItemDigitalCardLayoutBinding(constraintLayout, constraintLayout, imageView, imageView2);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}