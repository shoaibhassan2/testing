package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class GuidelinesFragmentBinding implements ViewBinding {
    public final UpdatedHeaderLayoutBackTitleBinding guidelineHeaderLayout;
    public final ConstraintLayout main;
    private final ConstraintLayout rootView;
    public final RecyclerView rvGuidelines;

    private GuidelinesFragmentBinding(ConstraintLayout rootView, UpdatedHeaderLayoutBackTitleBinding guidelineHeaderLayout, ConstraintLayout main, RecyclerView rvGuidelines) {
        this.rootView = rootView;
        this.guidelineHeaderLayout = guidelineHeaderLayout;
        this.main = main;
        this.rvGuidelines = rvGuidelines;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static GuidelinesFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static GuidelinesFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.guidelines_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static GuidelinesFragmentBinding bind(View rootView) {
        int i = R.id.guideline_header_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById != null) {
            UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
            ConstraintLayout constraintLayout = (ConstraintLayout) rootView;
            int i2 = R.id.rv_guidelines;
            RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(rootView, i2);
            if (recyclerView != null) {
                return new GuidelinesFragmentBinding(constraintLayout, updatedHeaderLayoutBackTitleBindingBind, constraintLayout, recyclerView);
            }
            i = i2;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}