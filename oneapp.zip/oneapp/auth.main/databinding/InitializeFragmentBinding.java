package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.constraintlayout.helper.widget.Flow;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class InitializeFragmentBinding implements ViewBinding {
    public final StepActionLayoutBinding applicantInfoLayout;
    public final Flow flow;
    public final MaterialCardView myselfLayout;
    public final UpdatedHeaderLayoutBackTitleBinding newAppHeaderLayout;
    public final ButtonLayoutBinding nextButtonLayout;
    public final RadioButton radioRelative;
    public final RadioButton radioSelf;
    public final RadioButton rbIdCard;
    public final RadioButton rbNicop;
    public final RadioButton rbNo;
    public final RadioButton rbPoco;
    public final RadioButton rbSmartId;
    public final RadioButton rbYes;
    public final MaskedEdittextLayoutBinding relativeCnicLayout;
    public final StepActionLayoutBinding relativeHeadingLayout;
    public final MaterialCardView relativeLayout;
    public final RadioGroup rgIdentityType;
    public final RadioGroup rgNicopPoc;
    private final ConstraintLayout rootView;
    public final TextView tvIdentityType;
    public final TextView tvIdentityTypeUrdu;
    public final TextView tvNewIdcardDesc;
    public final TextView tvNewNicopDesc;
    public final TextView tvNewPocDesc;
    public final TextView tvNewSmartIdDesc;
    public final TextView tvNicopPoc;
    public final TextView tvProvideRelativeCnicDescription;
    public final TextView tvRelativeDefinitionDescription;
    public final TextView tvRelativeDesc;
    public final TextView tvRelativeTitle;
    public final TextView tvRelativeUrduDesc;
    public final TextView tvSelfTitle;
    public final TextView tvStartAppTitle;

    private InitializeFragmentBinding(ConstraintLayout rootView, StepActionLayoutBinding applicantInfoLayout, Flow flow, MaterialCardView myselfLayout, UpdatedHeaderLayoutBackTitleBinding newAppHeaderLayout, ButtonLayoutBinding nextButtonLayout, RadioButton radioRelative, RadioButton radioSelf, RadioButton rbIdCard, RadioButton rbNicop, RadioButton rbNo, RadioButton rbPoco, RadioButton rbSmartId, RadioButton rbYes, MaskedEdittextLayoutBinding relativeCnicLayout, StepActionLayoutBinding relativeHeadingLayout, MaterialCardView relativeLayout, RadioGroup rgIdentityType, RadioGroup rgNicopPoc, TextView tvIdentityType, TextView tvIdentityTypeUrdu, TextView tvNewIdcardDesc, TextView tvNewNicopDesc, TextView tvNewPocDesc, TextView tvNewSmartIdDesc, TextView tvNicopPoc, TextView tvProvideRelativeCnicDescription, TextView tvRelativeDefinitionDescription, TextView tvRelativeDesc, TextView tvRelativeTitle, TextView tvRelativeUrduDesc, TextView tvSelfTitle, TextView tvStartAppTitle) {
        this.rootView = rootView;
        this.applicantInfoLayout = applicantInfoLayout;
        this.flow = flow;
        this.myselfLayout = myselfLayout;
        this.newAppHeaderLayout = newAppHeaderLayout;
        this.nextButtonLayout = nextButtonLayout;
        this.radioRelative = radioRelative;
        this.radioSelf = radioSelf;
        this.rbIdCard = rbIdCard;
        this.rbNicop = rbNicop;
        this.rbNo = rbNo;
        this.rbPoco = rbPoco;
        this.rbSmartId = rbSmartId;
        this.rbYes = rbYes;
        this.relativeCnicLayout = relativeCnicLayout;
        this.relativeHeadingLayout = relativeHeadingLayout;
        this.relativeLayout = relativeLayout;
        this.rgIdentityType = rgIdentityType;
        this.rgNicopPoc = rgNicopPoc;
        this.tvIdentityType = tvIdentityType;
        this.tvIdentityTypeUrdu = tvIdentityTypeUrdu;
        this.tvNewIdcardDesc = tvNewIdcardDesc;
        this.tvNewNicopDesc = tvNewNicopDesc;
        this.tvNewPocDesc = tvNewPocDesc;
        this.tvNewSmartIdDesc = tvNewSmartIdDesc;
        this.tvNicopPoc = tvNicopPoc;
        this.tvProvideRelativeCnicDescription = tvProvideRelativeCnicDescription;
        this.tvRelativeDefinitionDescription = tvRelativeDefinitionDescription;
        this.tvRelativeDesc = tvRelativeDesc;
        this.tvRelativeTitle = tvRelativeTitle;
        this.tvRelativeUrduDesc = tvRelativeUrduDesc;
        this.tvSelfTitle = tvSelfTitle;
        this.tvStartAppTitle = tvStartAppTitle;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static InitializeFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static InitializeFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.initialize_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static InitializeFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i = R.id.applicant_info_layout;
        View viewFindChildViewById3 = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById3 != null) {
            StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById3);
            i = R.id.flow;
            Flow flow = (Flow) ViewBindings.findChildViewById(rootView, i);
            if (flow != null) {
                i = R.id.myself_layout;
                MaterialCardView materialCardView = (MaterialCardView) ViewBindings.findChildViewById(rootView, i);
                if (materialCardView != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.new_app_header_layout))) != null) {
                    UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
                    i = R.id.next_button_layout;
                    View viewFindChildViewById4 = ViewBindings.findChildViewById(rootView, i);
                    if (viewFindChildViewById4 != null) {
                        ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById4);
                        i = R.id.radio_relative;
                        RadioButton radioButton = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                        if (radioButton != null) {
                            i = R.id.radio_self;
                            RadioButton radioButton2 = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                            if (radioButton2 != null) {
                                i = R.id.rb_idCard;
                                RadioButton radioButton3 = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                                if (radioButton3 != null) {
                                    i = R.id.rb_nicop;
                                    RadioButton radioButton4 = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                                    if (radioButton4 != null) {
                                        i = R.id.rb_no;
                                        RadioButton radioButton5 = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                                        if (radioButton5 != null) {
                                            i = R.id.rb_poco;
                                            RadioButton radioButton6 = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                                            if (radioButton6 != null) {
                                                i = R.id.rb_smartId;
                                                RadioButton radioButton7 = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                                                if (radioButton7 != null) {
                                                    i = R.id.rb_yes;
                                                    RadioButton radioButton8 = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                                                    if (radioButton8 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, (i = R.id.relative_cnic_layout))) != null) {
                                                        MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById2);
                                                        i = R.id.relative_heading_layout;
                                                        View viewFindChildViewById5 = ViewBindings.findChildViewById(rootView, i);
                                                        if (viewFindChildViewById5 != null) {
                                                            StepActionLayoutBinding stepActionLayoutBindingBind2 = StepActionLayoutBinding.bind(viewFindChildViewById5);
                                                            i = R.id.relative_layout;
                                                            MaterialCardView materialCardView2 = (MaterialCardView) ViewBindings.findChildViewById(rootView, i);
                                                            if (materialCardView2 != null) {
                                                                i = R.id.rg_identity_type;
                                                                RadioGroup radioGroup = (RadioGroup) ViewBindings.findChildViewById(rootView, i);
                                                                if (radioGroup != null) {
                                                                    i = R.id.rg_nicop_poc;
                                                                    RadioGroup radioGroup2 = (RadioGroup) ViewBindings.findChildViewById(rootView, i);
                                                                    if (radioGroup2 != null) {
                                                                        i = R.id.tv_identity_type;
                                                                        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                        if (textView != null) {
                                                                            i = R.id.tv_identity_type_urdu;
                                                                            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                            if (textView2 != null) {
                                                                                i = R.id.tv_new_idcard_desc;
                                                                                TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                if (textView3 != null) {
                                                                                    i = R.id.tv_new_nicop_desc;
                                                                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                    if (textView4 != null) {
                                                                                        i = R.id.tv_new_poc_desc;
                                                                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                        if (textView5 != null) {
                                                                                            i = R.id.tv_new_smartId_desc;
                                                                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                            if (textView6 != null) {
                                                                                                i = R.id.tv_nicop_poc;
                                                                                                TextView textView7 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                if (textView7 != null) {
                                                                                                    i = R.id.tv_provide_relative_cnic_description;
                                                                                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                    if (textView8 != null) {
                                                                                                        i = R.id.tv_relative_definition_description;
                                                                                                        TextView textView9 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                        if (textView9 != null) {
                                                                                                            i = R.id.tv_relative_desc;
                                                                                                            TextView textView10 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                            if (textView10 != null) {
                                                                                                                i = R.id.tv_relative_title;
                                                                                                                TextView textView11 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                if (textView11 != null) {
                                                                                                                    i = R.id.tv_relative_urdu_desc;
                                                                                                                    TextView textView12 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                    if (textView12 != null) {
                                                                                                                        i = R.id.tv_self_title;
                                                                                                                        TextView textView13 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                        if (textView13 != null) {
                                                                                                                            i = R.id.tv_start_app_title;
                                                                                                                            TextView textView14 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                            if (textView14 != null) {
                                                                                                                                return new InitializeFragmentBinding((ConstraintLayout) rootView, stepActionLayoutBindingBind, flow, materialCardView, updatedHeaderLayoutBackTitleBindingBind, buttonLayoutBindingBind, radioButton, radioButton2, radioButton3, radioButton4, radioButton5, radioButton6, radioButton7, radioButton8, maskedEdittextLayoutBindingBind, stepActionLayoutBindingBind2, materialCardView2, radioGroup, radioGroup2, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13, textView14);
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}