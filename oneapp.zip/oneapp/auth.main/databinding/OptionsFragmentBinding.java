package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class OptionsFragmentBinding implements ViewBinding {
    public final ConstraintLayout main;
    public final UpdatedHeaderLayoutBackTitleBinding newAppHeaderLayout;
    public final StepActionLayoutBinding optionsInfoLayout;
    private final ConstraintLayout rootView;
    public final RecyclerView rvCardOptions;
    public final TextView tvTitle;

    private OptionsFragmentBinding(ConstraintLayout rootView, ConstraintLayout main, UpdatedHeaderLayoutBackTitleBinding newAppHeaderLayout, StepActionLayoutBinding optionsInfoLayout, RecyclerView rvCardOptions, TextView tvTitle) {
        this.rootView = rootView;
        this.main = main;
        this.newAppHeaderLayout = newAppHeaderLayout;
        this.optionsInfoLayout = optionsInfoLayout;
        this.rvCardOptions = rvCardOptions;
        this.tvTitle = tvTitle;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static OptionsFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static OptionsFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.options_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static OptionsFragmentBinding bind(View rootView) {
        ConstraintLayout constraintLayout = (ConstraintLayout) rootView;
        int i = R.id.new_app_header_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById != null) {
            UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
            i = R.id.options_info_layout;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, i);
            if (viewFindChildViewById2 != null) {
                StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById2);
                i = R.id.rv_card_options;
                RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(rootView, i);
                if (recyclerView != null) {
                    i = R.id.tv_title;
                    TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView != null) {
                        return new OptionsFragmentBinding(constraintLayout, constraintLayout, updatedHeaderLayoutBackTitleBindingBind, stepActionLayoutBindingBind, recyclerView, textView);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}