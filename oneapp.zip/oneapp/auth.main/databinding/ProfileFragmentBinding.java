package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.divider.MaterialDivider;
import com.google.android.material.switchmaterial.SwitchMaterial;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class ProfileFragmentBinding implements ViewBinding {
    public final MaterialDivider dividerBiometricPermissionAccess;
    public final MaterialDivider dividerCnic;
    public final MaterialDivider dividerEmail;
    public final MaterialDivider dividerFaceId;
    public final MaterialDivider dividerMobileNumber;
    public final MaterialDivider dividerPassword;
    public final MaterialDivider dividerProfile;
    public final UpdatedHeaderLayoutBackTitleBinding newAppHeaderLayout;
    public final MaterialCardView profileItemsCardView;
    private final ConstraintLayout rootView;
    public final SwitchMaterial switchBiometricPermissionAccess;
    public final SwitchMaterial switchSignInOption;
    public final TextView tvBiometricPermissionAccess;
    public final AppCompatImageView tvChangeEmail;
    public final TextView tvChangePassword;
    public final AppCompatImageView tvChangePhoneNumber;
    public final TextView tvCnic;
    public final TextView tvCnicTitle;
    public final TextView tvDeleteAccountTitle;
    public final TextView tvEmail;
    public final TextView tvEmailTitle;
    public final TextView tvPassword;
    public final TextView tvPasswordTitle;
    public final TextView tvPermissionTitle;
    public final TextView tvPhoneNumber;
    public final TextView tvPhoneNumberTitle;
    public final Button tvRequestDeleteAccount;
    public final TextView tvSignInOption;
    public final TextView tvSignInOptionTitle;
    public final TextView tvTitleProfile;

    private ProfileFragmentBinding(ConstraintLayout rootView, MaterialDivider dividerBiometricPermissionAccess, MaterialDivider dividerCnic, MaterialDivider dividerEmail, MaterialDivider dividerFaceId, MaterialDivider dividerMobileNumber, MaterialDivider dividerPassword, MaterialDivider dividerProfile, UpdatedHeaderLayoutBackTitleBinding newAppHeaderLayout, MaterialCardView profileItemsCardView, SwitchMaterial switchBiometricPermissionAccess, SwitchMaterial switchSignInOption, TextView tvBiometricPermissionAccess, AppCompatImageView tvChangeEmail, TextView tvChangePassword, AppCompatImageView tvChangePhoneNumber, TextView tvCnic, TextView tvCnicTitle, TextView tvDeleteAccountTitle, TextView tvEmail, TextView tvEmailTitle, TextView tvPassword, TextView tvPasswordTitle, TextView tvPermissionTitle, TextView tvPhoneNumber, TextView tvPhoneNumberTitle, Button tvRequestDeleteAccount, TextView tvSignInOption, TextView tvSignInOptionTitle, TextView tvTitleProfile) {
        this.rootView = rootView;
        this.dividerBiometricPermissionAccess = dividerBiometricPermissionAccess;
        this.dividerCnic = dividerCnic;
        this.dividerEmail = dividerEmail;
        this.dividerFaceId = dividerFaceId;
        this.dividerMobileNumber = dividerMobileNumber;
        this.dividerPassword = dividerPassword;
        this.dividerProfile = dividerProfile;
        this.newAppHeaderLayout = newAppHeaderLayout;
        this.profileItemsCardView = profileItemsCardView;
        this.switchBiometricPermissionAccess = switchBiometricPermissionAccess;
        this.switchSignInOption = switchSignInOption;
        this.tvBiometricPermissionAccess = tvBiometricPermissionAccess;
        this.tvChangeEmail = tvChangeEmail;
        this.tvChangePassword = tvChangePassword;
        this.tvChangePhoneNumber = tvChangePhoneNumber;
        this.tvCnic = tvCnic;
        this.tvCnicTitle = tvCnicTitle;
        this.tvDeleteAccountTitle = tvDeleteAccountTitle;
        this.tvEmail = tvEmail;
        this.tvEmailTitle = tvEmailTitle;
        this.tvPassword = tvPassword;
        this.tvPasswordTitle = tvPasswordTitle;
        this.tvPermissionTitle = tvPermissionTitle;
        this.tvPhoneNumber = tvPhoneNumber;
        this.tvPhoneNumberTitle = tvPhoneNumberTitle;
        this.tvRequestDeleteAccount = tvRequestDeleteAccount;
        this.tvSignInOption = tvSignInOption;
        this.tvSignInOptionTitle = tvSignInOptionTitle;
        this.tvTitleProfile = tvTitleProfile;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ProfileFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static ProfileFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.profile_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ProfileFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        int i = R.id.divider_biometric_permission_access;
        MaterialDivider materialDivider = (MaterialDivider) ViewBindings.findChildViewById(rootView, i);
        if (materialDivider != null) {
            i = R.id.divider_cnic;
            MaterialDivider materialDivider2 = (MaterialDivider) ViewBindings.findChildViewById(rootView, i);
            if (materialDivider2 != null) {
                i = R.id.divider_email;
                MaterialDivider materialDivider3 = (MaterialDivider) ViewBindings.findChildViewById(rootView, i);
                if (materialDivider3 != null) {
                    i = R.id.divider_face_id;
                    MaterialDivider materialDivider4 = (MaterialDivider) ViewBindings.findChildViewById(rootView, i);
                    if (materialDivider4 != null) {
                        i = R.id.divider_mobile_number;
                        MaterialDivider materialDivider5 = (MaterialDivider) ViewBindings.findChildViewById(rootView, i);
                        if (materialDivider5 != null) {
                            i = R.id.divider_password;
                            MaterialDivider materialDivider6 = (MaterialDivider) ViewBindings.findChildViewById(rootView, i);
                            if (materialDivider6 != null) {
                                i = R.id.divider_profile;
                                MaterialDivider materialDivider7 = (MaterialDivider) ViewBindings.findChildViewById(rootView, i);
                                if (materialDivider7 != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.new_app_header_layout))) != null) {
                                    UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
                                    i = R.id.profile_items_cardView;
                                    MaterialCardView materialCardView = (MaterialCardView) ViewBindings.findChildViewById(rootView, i);
                                    if (materialCardView != null) {
                                        i = R.id.switch_biometric_permission_access;
                                        SwitchMaterial switchMaterial = (SwitchMaterial) ViewBindings.findChildViewById(rootView, i);
                                        if (switchMaterial != null) {
                                            i = R.id.switch_sign_in_option;
                                            SwitchMaterial switchMaterial2 = (SwitchMaterial) ViewBindings.findChildViewById(rootView, i);
                                            if (switchMaterial2 != null) {
                                                i = R.id.tv_biometric_permission_access;
                                                TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                if (textView != null) {
                                                    i = R.id.tv_change_email;
                                                    AppCompatImageView appCompatImageView = (AppCompatImageView) ViewBindings.findChildViewById(rootView, i);
                                                    if (appCompatImageView != null) {
                                                        i = R.id.tv_change_password;
                                                        TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                        if (textView2 != null) {
                                                            i = R.id.tv_change_phone_number;
                                                            AppCompatImageView appCompatImageView2 = (AppCompatImageView) ViewBindings.findChildViewById(rootView, i);
                                                            if (appCompatImageView2 != null) {
                                                                i = R.id.tv_cnic;
                                                                TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                if (textView3 != null) {
                                                                    i = R.id.tv_cnic_title;
                                                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                    if (textView4 != null) {
                                                                        i = R.id.tv_delete_account_title;
                                                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                        if (textView5 != null) {
                                                                            i = R.id.tv_email;
                                                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                            if (textView6 != null) {
                                                                                i = R.id.tv_email_title;
                                                                                TextView textView7 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                if (textView7 != null) {
                                                                                    i = R.id.tv_password;
                                                                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                    if (textView8 != null) {
                                                                                        i = R.id.tv_password_title;
                                                                                        TextView textView9 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                        if (textView9 != null) {
                                                                                            i = R.id.tv_permission_title;
                                                                                            TextView textView10 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                            if (textView10 != null) {
                                                                                                i = R.id.tv_phone_number;
                                                                                                TextView textView11 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                if (textView11 != null) {
                                                                                                    i = R.id.tv_phone_number_title;
                                                                                                    TextView textView12 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                    if (textView12 != null) {
                                                                                                        i = R.id.tv_request_delete_account;
                                                                                                        Button button = (Button) ViewBindings.findChildViewById(rootView, i);
                                                                                                        if (button != null) {
                                                                                                            i = R.id.tv_sign_in_option;
                                                                                                            TextView textView13 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                            if (textView13 != null) {
                                                                                                                i = R.id.tv_sign_in_option_title;
                                                                                                                TextView textView14 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                if (textView14 != null) {
                                                                                                                    i = R.id.tv_title_profile;
                                                                                                                    TextView textView15 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                    if (textView15 != null) {
                                                                                                                        return new ProfileFragmentBinding((ConstraintLayout) rootView, materialDivider, materialDivider2, materialDivider3, materialDivider4, materialDivider5, materialDivider6, materialDivider7, updatedHeaderLayoutBackTitleBindingBind, materialCardView, switchMaterial, switchMaterial2, textView, appCompatImageView, textView2, appCompatImageView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, button, textView13, textView14, textView15);
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}