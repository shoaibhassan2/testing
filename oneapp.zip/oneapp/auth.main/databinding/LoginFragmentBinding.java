package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;

/* loaded from: classes5.dex */
public final class LoginFragmentBinding implements ViewBinding {
    public final TextView appVersionTextView;
    public final TextView copyrightTextView;
    public final TextInputEditText emailAddressTextInputEditText;
    public final ConstraintLayout emailCnicConstraintLayout;
    public final ImageView loginBiometricImageView;
    public final ConfigurableButton loginButtonLayout;
    public final MaskedEdittextLayoutBinding loginCnicLayout;
    public final TextInputLayout loginEmailAddressLayout;
    public final TextView loginForgotPasswordTextView;
    public final TextView loginHeaderTitleTextView;
    public final ConstraintLayout loginLayout;
    public final ImageView loginPakIdLogoImageView;
    public final TextInputLayout loginPasswordLayout;
    public final TabLayout loginTabLayout;
    public final TextView loginTypeHeadingTextView;
    public final TextView loginTypeSubHeadingTextView;
    public final TextView newToPakIdTextView;
    public final TextInputEditText passwordTextInputEditText;
    public final TextView privacyPolicyTextView;
    public final TextView registerButtonLayout;
    public final TextView registerButtonUrdu;
    private final ConstraintLayout rootView;
    public final TextView textView3;
    public final TextView textView5;
    public final View view;

    private LoginFragmentBinding(ConstraintLayout rootView, TextView appVersionTextView, TextView copyrightTextView, TextInputEditText emailAddressTextInputEditText, ConstraintLayout emailCnicConstraintLayout, ImageView loginBiometricImageView, ConfigurableButton loginButtonLayout, MaskedEdittextLayoutBinding loginCnicLayout, TextInputLayout loginEmailAddressLayout, TextView loginForgotPasswordTextView, TextView loginHeaderTitleTextView, ConstraintLayout loginLayout, ImageView loginPakIdLogoImageView, TextInputLayout loginPasswordLayout, TabLayout loginTabLayout, TextView loginTypeHeadingTextView, TextView loginTypeSubHeadingTextView, TextView newToPakIdTextView, TextInputEditText passwordTextInputEditText, TextView privacyPolicyTextView, TextView registerButtonLayout, TextView registerButtonUrdu, TextView textView3, TextView textView5, View view) {
        this.rootView = rootView;
        this.appVersionTextView = appVersionTextView;
        this.copyrightTextView = copyrightTextView;
        this.emailAddressTextInputEditText = emailAddressTextInputEditText;
        this.emailCnicConstraintLayout = emailCnicConstraintLayout;
        this.loginBiometricImageView = loginBiometricImageView;
        this.loginButtonLayout = loginButtonLayout;
        this.loginCnicLayout = loginCnicLayout;
        this.loginEmailAddressLayout = loginEmailAddressLayout;
        this.loginForgotPasswordTextView = loginForgotPasswordTextView;
        this.loginHeaderTitleTextView = loginHeaderTitleTextView;
        this.loginLayout = loginLayout;
        this.loginPakIdLogoImageView = loginPakIdLogoImageView;
        this.loginPasswordLayout = loginPasswordLayout;
        this.loginTabLayout = loginTabLayout;
        this.loginTypeHeadingTextView = loginTypeHeadingTextView;
        this.loginTypeSubHeadingTextView = loginTypeSubHeadingTextView;
        this.newToPakIdTextView = newToPakIdTextView;
        this.passwordTextInputEditText = passwordTextInputEditText;
        this.privacyPolicyTextView = privacyPolicyTextView;
        this.registerButtonLayout = registerButtonLayout;
        this.registerButtonUrdu = registerButtonUrdu;
        this.textView3 = textView3;
        this.textView5 = textView5;
        this.view = view;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static LoginFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static LoginFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.login_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static LoginFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i = R.id.app_version_textView;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null) {
            i = R.id.copyright_textView;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView2 != null) {
                i = R.id.email_address_textInputEditText;
                TextInputEditText textInputEditText = (TextInputEditText) ViewBindings.findChildViewById(rootView, i);
                if (textInputEditText != null) {
                    i = R.id.email_cnic_constraint_layout;
                    ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                    if (constraintLayout != null) {
                        i = R.id.login_biometric_imageView;
                        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                        if (imageView != null) {
                            i = R.id.login_button_layout;
                            ConfigurableButton configurableButton = (ConfigurableButton) ViewBindings.findChildViewById(rootView, i);
                            if (configurableButton != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.login_cnic_layout))) != null) {
                                MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById);
                                i = R.id.login_email_address_layout;
                                TextInputLayout textInputLayout = (TextInputLayout) ViewBindings.findChildViewById(rootView, i);
                                if (textInputLayout != null) {
                                    i = R.id.login_forgot_password_textView;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                    if (textView3 != null) {
                                        i = R.id.login_header_title_textView;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                        if (textView4 != null) {
                                            ConstraintLayout constraintLayout2 = (ConstraintLayout) rootView;
                                            i = R.id.login_pak_id_logo_imageView;
                                            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                            if (imageView2 != null) {
                                                i = R.id.login_password_layout;
                                                TextInputLayout textInputLayout2 = (TextInputLayout) ViewBindings.findChildViewById(rootView, i);
                                                if (textInputLayout2 != null) {
                                                    i = R.id.login_tabLayout;
                                                    TabLayout tabLayout = (TabLayout) ViewBindings.findChildViewById(rootView, i);
                                                    if (tabLayout != null) {
                                                        i = R.id.login_type_heading_textView;
                                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                        if (textView5 != null) {
                                                            i = R.id.login_type_sub_heading_textView;
                                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                            if (textView6 != null) {
                                                                i = R.id.new_to_pak_id_text_view;
                                                                TextView textView7 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                if (textView7 != null) {
                                                                    i = R.id.password_textInputEditText;
                                                                    TextInputEditText textInputEditText2 = (TextInputEditText) ViewBindings.findChildViewById(rootView, i);
                                                                    if (textInputEditText2 != null) {
                                                                        i = R.id.privacy_policy_textView;
                                                                        TextView textView8 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                        if (textView8 != null) {
                                                                            i = R.id.register_button_layout;
                                                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                            if (textView9 != null) {
                                                                                i = R.id.registerButtonUrdu;
                                                                                TextView textView10 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                if (textView10 != null) {
                                                                                    i = R.id.textView3;
                                                                                    TextView textView11 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                    if (textView11 != null) {
                                                                                        i = R.id.textView5;
                                                                                        TextView textView12 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                        if (textView12 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, (i = R.id.view))) != null) {
                                                                                            return new LoginFragmentBinding(constraintLayout2, textView, textView2, textInputEditText, constraintLayout, imageView, configurableButton, maskedEdittextLayoutBindingBind, textInputLayout, textView3, textView4, constraintLayout2, imageView2, textInputLayout2, tabLayout, textView5, textView6, textView7, textInputEditText2, textView8, textView9, textView10, textView11, textView12, viewFindChildViewById2);
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}