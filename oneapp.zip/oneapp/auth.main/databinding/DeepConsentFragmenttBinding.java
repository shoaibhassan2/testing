package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.button.MaterialButton;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class DeepConsentFragmenttBinding implements ViewBinding {
    public final MaterialButton allowButtonLayout;
    public final TextView consentAppNameTitle;
    public final TextView consentDescText;
    public final TextView consentDetailInfo;
    public final TextView consentHeaderTitleTextView;
    public final TextView consentLearnMoreTv;
    public final TextView consentNotYouTv;
    public final ImageView consentTopImageView;
    public final TextView consentUserDataValue1;
    public final TextView consentUserDataValue2;
    public final TextView consentUserDataValue3;
    public final TextView consentUserDataValue4;
    public final TextView consentUserDataValue5;
    public final MaterialButton denyButtonLayout;
    public final ConstraintLayout loginLayout;
    private final ConstraintLayout rootView;

    private DeepConsentFragmenttBinding(ConstraintLayout rootView, MaterialButton allowButtonLayout, TextView consentAppNameTitle, TextView consentDescText, TextView consentDetailInfo, TextView consentHeaderTitleTextView, TextView consentLearnMoreTv, TextView consentNotYouTv, ImageView consentTopImageView, TextView consentUserDataValue1, TextView consentUserDataValue2, TextView consentUserDataValue3, TextView consentUserDataValue4, TextView consentUserDataValue5, MaterialButton denyButtonLayout, ConstraintLayout loginLayout) {
        this.rootView = rootView;
        this.allowButtonLayout = allowButtonLayout;
        this.consentAppNameTitle = consentAppNameTitle;
        this.consentDescText = consentDescText;
        this.consentDetailInfo = consentDetailInfo;
        this.consentHeaderTitleTextView = consentHeaderTitleTextView;
        this.consentLearnMoreTv = consentLearnMoreTv;
        this.consentNotYouTv = consentNotYouTv;
        this.consentTopImageView = consentTopImageView;
        this.consentUserDataValue1 = consentUserDataValue1;
        this.consentUserDataValue2 = consentUserDataValue2;
        this.consentUserDataValue3 = consentUserDataValue3;
        this.consentUserDataValue4 = consentUserDataValue4;
        this.consentUserDataValue5 = consentUserDataValue5;
        this.denyButtonLayout = denyButtonLayout;
        this.loginLayout = loginLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static DeepConsentFragmenttBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static DeepConsentFragmenttBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.deep_consent_fragmentt, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static DeepConsentFragmenttBinding bind(View rootView) {
        int i = R.id.allow_button_layout;
        MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(rootView, i);
        if (materialButton != null) {
            i = R.id.consent_app_name_title;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null) {
                i = R.id.consent_desc_text;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView2 != null) {
                    i = R.id.consent_detail_info;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView3 != null) {
                        i = R.id.consent_header_title_textView;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                        if (textView4 != null) {
                            i = R.id.consent_learn_more_tv;
                            TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                            if (textView5 != null) {
                                i = R.id.consent_not_you_tv;
                                TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                if (textView6 != null) {
                                    i = R.id.consent_top_imageView;
                                    ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                    if (imageView != null) {
                                        i = R.id.consent_user_data_value1;
                                        TextView textView7 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                        if (textView7 != null) {
                                            i = R.id.consent_user_data_value2;
                                            TextView textView8 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                            if (textView8 != null) {
                                                i = R.id.consent_user_data_value3;
                                                TextView textView9 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                if (textView9 != null) {
                                                    i = R.id.consent_user_data_value4;
                                                    TextView textView10 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                    if (textView10 != null) {
                                                        i = R.id.consent_user_data_value5;
                                                        TextView textView11 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                        if (textView11 != null) {
                                                            i = R.id.deny_button_layout;
                                                            MaterialButton materialButton2 = (MaterialButton) ViewBindings.findChildViewById(rootView, i);
                                                            if (materialButton2 != null) {
                                                                ConstraintLayout constraintLayout = (ConstraintLayout) rootView;
                                                                return new DeepConsentFragmenttBinding(constraintLayout, materialButton, textView, textView2, textView3, textView4, textView5, textView6, imageView, textView7, textView8, textView9, textView10, textView11, materialButton2, constraintLayout);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}