package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class NotificationFragmentBinding implements ViewBinding {
    public final LinearLayout noNotificationsYetLayout;
    public final TextView noNotificationsYetUrdu;
    public final UpdatedHeaderLayoutBackTitleBinding notificationHeaderLayout;
    private final ConstraintLayout rootView;
    public final RecyclerView rvNotifications;

    private NotificationFragmentBinding(ConstraintLayout rootView, LinearLayout noNotificationsYetLayout, TextView noNotificationsYetUrdu, UpdatedHeaderLayoutBackTitleBinding notificationHeaderLayout, RecyclerView rvNotifications) {
        this.rootView = rootView;
        this.noNotificationsYetLayout = noNotificationsYetLayout;
        this.noNotificationsYetUrdu = noNotificationsYetUrdu;
        this.notificationHeaderLayout = notificationHeaderLayout;
        this.rvNotifications = rvNotifications;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static NotificationFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static NotificationFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.notification_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static NotificationFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        int i = R.id.no_notifications_yet_layout;
        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(rootView, i);
        if (linearLayout != null) {
            i = R.id.no_notifications_yet_urdu;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.notification_header_layout))) != null) {
                UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
                i = R.id.rv_notifications;
                RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(rootView, i);
                if (recyclerView != null) {
                    return new NotificationFragmentBinding((ConstraintLayout) rootView, linearLayout, textView, updatedHeaderLayoutBackTitleBindingBind, recyclerView);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}