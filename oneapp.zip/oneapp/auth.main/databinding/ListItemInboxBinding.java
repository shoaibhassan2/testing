package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.imageview.ShapeableImageView;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class ListItemInboxBinding implements ViewBinding {
    public final TextView appStatusTextView;
    public final TextView appTypeTextView;
    public final TextView applicationFeeLabelTextView;
    public final TextView applicationFeeTextView;
    public final TextView appliedOnLabelTextView;
    public final TextView appliedOnTextView;
    public final ImageView cancelIconIv;
    public final ShapeableImageView docTypeBackground;
    public final TextView docTypeTextView;
    public final TextView inboxCancelImageButton;
    public final ImageButton inboxDownloadImageButton;
    public final ImageButton inboxInfoImageButton;
    public final MaterialCardView inboxListItemCardView;
    public final ImageButton inboxPaymentImageButton;
    public final TextView pinCodeTextView;
    private final MaterialCardView rootView;
    public final TextView trackTV;
    public final TextView trackingIdTextView;

    private ListItemInboxBinding(MaterialCardView rootView, TextView appStatusTextView, TextView appTypeTextView, TextView applicationFeeLabelTextView, TextView applicationFeeTextView, TextView appliedOnLabelTextView, TextView appliedOnTextView, ImageView cancelIconIv, ShapeableImageView docTypeBackground, TextView docTypeTextView, TextView inboxCancelImageButton, ImageButton inboxDownloadImageButton, ImageButton inboxInfoImageButton, MaterialCardView inboxListItemCardView, ImageButton inboxPaymentImageButton, TextView pinCodeTextView, TextView trackTV, TextView trackingIdTextView) {
        this.rootView = rootView;
        this.appStatusTextView = appStatusTextView;
        this.appTypeTextView = appTypeTextView;
        this.applicationFeeLabelTextView = applicationFeeLabelTextView;
        this.applicationFeeTextView = applicationFeeTextView;
        this.appliedOnLabelTextView = appliedOnLabelTextView;
        this.appliedOnTextView = appliedOnTextView;
        this.cancelIconIv = cancelIconIv;
        this.docTypeBackground = docTypeBackground;
        this.docTypeTextView = docTypeTextView;
        this.inboxCancelImageButton = inboxCancelImageButton;
        this.inboxDownloadImageButton = inboxDownloadImageButton;
        this.inboxInfoImageButton = inboxInfoImageButton;
        this.inboxListItemCardView = inboxListItemCardView;
        this.inboxPaymentImageButton = inboxPaymentImageButton;
        this.pinCodeTextView = pinCodeTextView;
        this.trackTV = trackTV;
        this.trackingIdTextView = trackingIdTextView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static ListItemInboxBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static ListItemInboxBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.list_item_inbox, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ListItemInboxBinding bind(View rootView) {
        int i = R.id.appStatusTextView;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null) {
            i = R.id.appTypeTextView;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView2 != null) {
                i = R.id.applicationFeeLabelTextView;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView3 != null) {
                    i = R.id.applicationFeeTextView;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView4 != null) {
                        i = R.id.appliedOnLabelTextView;
                        TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                        if (textView5 != null) {
                            i = R.id.appliedOnTextView;
                            TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                            if (textView6 != null) {
                                i = R.id.cancelIconIv;
                                ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                if (imageView != null) {
                                    i = R.id.docTypeBackground;
                                    ShapeableImageView shapeableImageView = (ShapeableImageView) ViewBindings.findChildViewById(rootView, i);
                                    if (shapeableImageView != null) {
                                        i = R.id.docTypeTextView;
                                        TextView textView7 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                        if (textView7 != null) {
                                            i = R.id.inboxCancelImageButton;
                                            TextView textView8 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                            if (textView8 != null) {
                                                i = R.id.inboxDownloadImageButton;
                                                ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(rootView, i);
                                                if (imageButton != null) {
                                                    i = R.id.inboxInfoImageButton;
                                                    ImageButton imageButton2 = (ImageButton) ViewBindings.findChildViewById(rootView, i);
                                                    if (imageButton2 != null) {
                                                        MaterialCardView materialCardView = (MaterialCardView) rootView;
                                                        i = R.id.inboxPaymentImageButton;
                                                        ImageButton imageButton3 = (ImageButton) ViewBindings.findChildViewById(rootView, i);
                                                        if (imageButton3 != null) {
                                                            i = R.id.pinCodeTextView;
                                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                            if (textView9 != null) {
                                                                i = R.id.trackTV;
                                                                TextView textView10 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                if (textView10 != null) {
                                                                    i = R.id.trackingIdTextView;
                                                                    TextView textView11 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                    if (textView11 != null) {
                                                                        return new ListItemInboxBinding(materialCardView, textView, textView2, textView3, textView4, textView5, textView6, imageView, shapeableImageView, textView7, textView8, imageButton, imageButton2, materialCardView, imageButton3, textView9, textView10, textView11);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}