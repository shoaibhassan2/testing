package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class RvPhoneNumberItemBinding implements ViewBinding {
    public final ImageView ivPhoneNumberSelector;
    private final MaterialCardView rootView;
    public final MaterialCardView rvCardLayout;
    public final TextView tvPhoneNumber;

    private RvPhoneNumberItemBinding(MaterialCardView rootView, ImageView ivPhoneNumberSelector, MaterialCardView rvCardLayout, TextView tvPhoneNumber) {
        this.rootView = rootView;
        this.ivPhoneNumberSelector = ivPhoneNumberSelector;
        this.rvCardLayout = rvCardLayout;
        this.tvPhoneNumber = tvPhoneNumber;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static RvPhoneNumberItemBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static RvPhoneNumberItemBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.rv_phone_number_item, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static RvPhoneNumberItemBinding bind(View rootView) {
        int i = R.id.iv_phone_number_selector;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
        if (imageView != null) {
            MaterialCardView materialCardView = (MaterialCardView) rootView;
            int i2 = R.id.tv_phone_number;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i2);
            if (textView != null) {
                return new RvPhoneNumberItemBinding(materialCardView, imageView, materialCardView, textView);
            }
            i = i2;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}