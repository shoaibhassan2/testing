package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class ComplaintsFragmentBinding implements ViewBinding {
    public final WebView complaintWebView;
    public final ImageView complaintsHeaderChatImageView;
    public final ImageView complaintsHeaderInboxImageView;
    public final ConstraintLayout complaintsHeaderLayout;
    public final ImageView complaintsHeaderNotificationImageView;
    public final TextView complaintsHeaderTitleTextView;
    private final ConstraintLayout rootView;
    public final View viewAfterChatIcon;
    public final View viewAfterMessageIcon;

    private ComplaintsFragmentBinding(ConstraintLayout rootView, WebView complaintWebView, ImageView complaintsHeaderChatImageView, ImageView complaintsHeaderInboxImageView, ConstraintLayout complaintsHeaderLayout, ImageView complaintsHeaderNotificationImageView, TextView complaintsHeaderTitleTextView, View viewAfterChatIcon, View viewAfterMessageIcon) {
        this.rootView = rootView;
        this.complaintWebView = complaintWebView;
        this.complaintsHeaderChatImageView = complaintsHeaderChatImageView;
        this.complaintsHeaderInboxImageView = complaintsHeaderInboxImageView;
        this.complaintsHeaderLayout = complaintsHeaderLayout;
        this.complaintsHeaderNotificationImageView = complaintsHeaderNotificationImageView;
        this.complaintsHeaderTitleTextView = complaintsHeaderTitleTextView;
        this.viewAfterChatIcon = viewAfterChatIcon;
        this.viewAfterMessageIcon = viewAfterMessageIcon;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ComplaintsFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static ComplaintsFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.complaints_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ComplaintsFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i = R.id.complaint_webView;
        WebView webView = (WebView) ViewBindings.findChildViewById(rootView, i);
        if (webView != null) {
            i = R.id.complaints_header_chat_imageView;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
            if (imageView != null) {
                i = R.id.complaints_header_inbox_imageView;
                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                if (imageView2 != null) {
                    i = R.id.complaintsHeaderLayout;
                    ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                    if (constraintLayout != null) {
                        i = R.id.complaints_header_notification_imageView;
                        ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                        if (imageView3 != null) {
                            i = R.id.complaints_header_title_textView;
                            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                            if (textView != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.view_after_chat_icon))) != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, (i = R.id.view_after_message_icon))) != null) {
                                return new ComplaintsFragmentBinding((ConstraintLayout) rootView, webView, imageView, imageView2, constraintLayout, imageView3, textView, viewFindChildViewById, viewFindChildViewById2);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}