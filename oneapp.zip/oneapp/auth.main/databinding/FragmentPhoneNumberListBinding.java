package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class FragmentPhoneNumberListBinding implements ViewBinding {
    public final LinearLayout llEmailParentLayout;
    public final LinearLayout llPhoneNumberParentLayout;
    public final UpdatedHeaderLayoutBackTitleBinding phoneNumberBackIconImageView;
    public final TextView phoneNumberDescriptionTextView;
    public final TextView phoneNumberDescriptionUrduTextView;
    public final TextView phoneNumberLabelTextView;
    public final TextInputEditText phoneNumberTextInputEditText;
    public final TextInputLayout phoneNumberTextInputLayout;
    public final AutocompletetextviewLayoutBinding registerCountryLayout;
    public final EdittextLayoutBinding registerEmailLayout;
    public final AutocompletetextviewLayoutBinding registerPhoneNumberOperatorLayout;
    private final ConstraintLayout rootView;
    public final ButtonLayoutBinding submitButtonLayout;

    private FragmentPhoneNumberListBinding(ConstraintLayout rootView, LinearLayout llEmailParentLayout, LinearLayout llPhoneNumberParentLayout, UpdatedHeaderLayoutBackTitleBinding phoneNumberBackIconImageView, TextView phoneNumberDescriptionTextView, TextView phoneNumberDescriptionUrduTextView, TextView phoneNumberLabelTextView, TextInputEditText phoneNumberTextInputEditText, TextInputLayout phoneNumberTextInputLayout, AutocompletetextviewLayoutBinding registerCountryLayout, EdittextLayoutBinding registerEmailLayout, AutocompletetextviewLayoutBinding registerPhoneNumberOperatorLayout, ButtonLayoutBinding submitButtonLayout) {
        this.rootView = rootView;
        this.llEmailParentLayout = llEmailParentLayout;
        this.llPhoneNumberParentLayout = llPhoneNumberParentLayout;
        this.phoneNumberBackIconImageView = phoneNumberBackIconImageView;
        this.phoneNumberDescriptionTextView = phoneNumberDescriptionTextView;
        this.phoneNumberDescriptionUrduTextView = phoneNumberDescriptionUrduTextView;
        this.phoneNumberLabelTextView = phoneNumberLabelTextView;
        this.phoneNumberTextInputEditText = phoneNumberTextInputEditText;
        this.phoneNumberTextInputLayout = phoneNumberTextInputLayout;
        this.registerCountryLayout = registerCountryLayout;
        this.registerEmailLayout = registerEmailLayout;
        this.registerPhoneNumberOperatorLayout = registerPhoneNumberOperatorLayout;
        this.submitButtonLayout = submitButtonLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentPhoneNumberListBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static FragmentPhoneNumberListBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.fragment_phone_number_list, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentPhoneNumberListBinding bind(View rootView) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i = R.id.ll_email_parent_layout;
        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(rootView, i);
        if (linearLayout != null) {
            i = R.id.ll_phone_number_parent_layout;
            LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(rootView, i);
            if (linearLayout2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.phone_number_back_icon_imageView))) != null) {
                UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
                i = R.id.phone_number_description_textView;
                TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView != null) {
                    i = R.id.phone_number_description_urdu_textView;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView2 != null) {
                        i = R.id.phone_number_label_textView;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                        if (textView3 != null) {
                            i = R.id.phone_number_textInputEditText;
                            TextInputEditText textInputEditText = (TextInputEditText) ViewBindings.findChildViewById(rootView, i);
                            if (textInputEditText != null) {
                                i = R.id.phone_number_textInputLayout;
                                TextInputLayout textInputLayout = (TextInputLayout) ViewBindings.findChildViewById(rootView, i);
                                if (textInputLayout != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, (i = R.id.register_country_layout))) != null) {
                                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById2);
                                    i = R.id.register_email_layout;
                                    View viewFindChildViewById3 = ViewBindings.findChildViewById(rootView, i);
                                    if (viewFindChildViewById3 != null) {
                                        EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById3);
                                        i = R.id.register_phone_number_operator_layout;
                                        View viewFindChildViewById4 = ViewBindings.findChildViewById(rootView, i);
                                        if (viewFindChildViewById4 != null) {
                                            AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind2 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById4);
                                            i = R.id.submit_button_layout;
                                            View viewFindChildViewById5 = ViewBindings.findChildViewById(rootView, i);
                                            if (viewFindChildViewById5 != null) {
                                                return new FragmentPhoneNumberListBinding((ConstraintLayout) rootView, linearLayout, linearLayout2, updatedHeaderLayoutBackTitleBindingBind, textView, textView2, textView3, textInputEditText, textInputLayout, autocompletetextviewLayoutBindingBind, edittextLayoutBindingBind, autocompletetextviewLayoutBindingBind2, ButtonLayoutBinding.bind(viewFindChildViewById5));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}