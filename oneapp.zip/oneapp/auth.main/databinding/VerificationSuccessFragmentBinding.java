package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;

/* loaded from: classes5.dex */
public final class VerificationSuccessFragmentBinding implements ViewBinding {
    private final ConstraintLayout rootView;
    public final ImageView successIconImageView;
    public final TextView verificationSuccessfullyDetailTextView;
    public final ButtonLayoutBinding verifySuccessButtonLayout;
    public final TextView verifySuccessfullyTextView;

    private VerificationSuccessFragmentBinding(ConstraintLayout rootView, ImageView successIconImageView, TextView verificationSuccessfullyDetailTextView, ButtonLayoutBinding verifySuccessButtonLayout, TextView verifySuccessfullyTextView) {
        this.rootView = rootView;
        this.successIconImageView = successIconImageView;
        this.verificationSuccessfullyDetailTextView = verificationSuccessfullyDetailTextView;
        this.verifySuccessButtonLayout = verifySuccessButtonLayout;
        this.verifySuccessfullyTextView = verifySuccessfullyTextView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static VerificationSuccessFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static VerificationSuccessFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.verification_success_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static VerificationSuccessFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        int i = R.id.success_icon_imageView;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
        if (imageView != null) {
            i = R.id.verification_successfully_detail_textView;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.verify_success_button_layout))) != null) {
                ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById);
                i = R.id.verify_successfully_textView;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView2 != null) {
                    return new VerificationSuccessFragmentBinding((ConstraintLayout) rootView, imageView, textView, buttonLayoutBindingBind, textView2);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}