package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.tabs.TabLayout;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonutils.utils.SwitchCompatOneApp;

/* loaded from: classes5.dex */
public final class HomeFragmentBinding implements ViewBinding {
    public final TextView dashboardAppVersionTextView;
    public final TextView dashboardGeoAddressTextView;
    public final FrameLayout fragmentContainer;
    public final ConstraintLayout headerLayout;
    public final ImageView homeHeaderChatImageView;
    public final ImageView homeHeaderInboxImageView;
    public final ConstraintLayout homeHeaderLayout;
    public final ImageView homeHeaderMenuImageView;
    public final ImageView homeHeaderNotificationImageView;
    public final ImageView homeHeaderPakIdLogoImageView;
    public final TextView homeHeaderTitleTextView;
    public final TextView homeHeaderUserTitleTextView;
    public final TextView homeHeaderWelcomeTextView;
    public final EditText homeItemSearchBoxEditText;
    public final ImageView homeLanguageSwitch;
    public final SwitchCompatOneApp homeLanguageSwitchh;
    public final ConstraintLayout rootLayout;
    private final ConstraintLayout rootView;
    public final TabLayout tabLayout;
    public final TextView verifyAccountNowTextView;
    public final View viewAfterChatIcon;
    public final View viewAfterMessageIcon;

    private HomeFragmentBinding(ConstraintLayout rootView, TextView dashboardAppVersionTextView, TextView dashboardGeoAddressTextView, FrameLayout fragmentContainer, ConstraintLayout headerLayout, ImageView homeHeaderChatImageView, ImageView homeHeaderInboxImageView, ConstraintLayout homeHeaderLayout, ImageView homeHeaderMenuImageView, ImageView homeHeaderNotificationImageView, ImageView homeHeaderPakIdLogoImageView, TextView homeHeaderTitleTextView, TextView homeHeaderUserTitleTextView, TextView homeHeaderWelcomeTextView, EditText homeItemSearchBoxEditText, ImageView homeLanguageSwitch, SwitchCompatOneApp homeLanguageSwitchh, ConstraintLayout rootLayout, TabLayout tabLayout, TextView verifyAccountNowTextView, View viewAfterChatIcon, View viewAfterMessageIcon) {
        this.rootView = rootView;
        this.dashboardAppVersionTextView = dashboardAppVersionTextView;
        this.dashboardGeoAddressTextView = dashboardGeoAddressTextView;
        this.fragmentContainer = fragmentContainer;
        this.headerLayout = headerLayout;
        this.homeHeaderChatImageView = homeHeaderChatImageView;
        this.homeHeaderInboxImageView = homeHeaderInboxImageView;
        this.homeHeaderLayout = homeHeaderLayout;
        this.homeHeaderMenuImageView = homeHeaderMenuImageView;
        this.homeHeaderNotificationImageView = homeHeaderNotificationImageView;
        this.homeHeaderPakIdLogoImageView = homeHeaderPakIdLogoImageView;
        this.homeHeaderTitleTextView = homeHeaderTitleTextView;
        this.homeHeaderUserTitleTextView = homeHeaderUserTitleTextView;
        this.homeHeaderWelcomeTextView = homeHeaderWelcomeTextView;
        this.homeItemSearchBoxEditText = homeItemSearchBoxEditText;
        this.homeLanguageSwitch = homeLanguageSwitch;
        this.homeLanguageSwitchh = homeLanguageSwitchh;
        this.rootLayout = rootLayout;
        this.tabLayout = tabLayout;
        this.verifyAccountNowTextView = verifyAccountNowTextView;
        this.viewAfterChatIcon = viewAfterChatIcon;
        this.viewAfterMessageIcon = viewAfterMessageIcon;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static HomeFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static HomeFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.home_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static HomeFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i = R.id.dashboard_app_version_textView;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null) {
            i = R.id.dashboard_geo_address_textView;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView2 != null) {
                i = R.id.fragmentContainer;
                FrameLayout frameLayout = (FrameLayout) ViewBindings.findChildViewById(rootView, i);
                if (frameLayout != null) {
                    i = R.id.headerLayout;
                    ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                    if (constraintLayout != null) {
                        i = R.id.home_header_chat_imageView;
                        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                        if (imageView != null) {
                            i = R.id.home_header_inbox_imageView;
                            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                            if (imageView2 != null) {
                                i = R.id.home_header_layout;
                                ConstraintLayout constraintLayout2 = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                                if (constraintLayout2 != null) {
                                    i = R.id.home_header_menu_imageView;
                                    ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                    if (imageView3 != null) {
                                        i = R.id.home_header_notification_imageView;
                                        ImageView imageView4 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                        if (imageView4 != null) {
                                            i = R.id.home_header_pak_id_logo_imageView;
                                            ImageView imageView5 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                            if (imageView5 != null) {
                                                i = R.id.home_header_title_textView;
                                                TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                if (textView3 != null) {
                                                    i = R.id.home_header_user_title_textView;
                                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                    if (textView4 != null) {
                                                        i = R.id.home_header_welcome_textView;
                                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                        if (textView5 != null) {
                                                            i = R.id.home_item_searchBox_editText;
                                                            EditText editText = (EditText) ViewBindings.findChildViewById(rootView, i);
                                                            if (editText != null) {
                                                                i = R.id.home_language_switch;
                                                                ImageView imageView6 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                                                if (imageView6 != null) {
                                                                    i = R.id.home_language_switchh;
                                                                    SwitchCompatOneApp switchCompatOneApp = (SwitchCompatOneApp) ViewBindings.findChildViewById(rootView, i);
                                                                    if (switchCompatOneApp != null) {
                                                                        ConstraintLayout constraintLayout3 = (ConstraintLayout) rootView;
                                                                        i = R.id.tabLayout;
                                                                        TabLayout tabLayout = (TabLayout) ViewBindings.findChildViewById(rootView, i);
                                                                        if (tabLayout != null) {
                                                                            i = R.id.verify_account_now_textView;
                                                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                            if (textView6 != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.view_after_chat_icon))) != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, (i = R.id.view_after_message_icon))) != null) {
                                                                                return new HomeFragmentBinding(constraintLayout3, textView, textView2, frameLayout, constraintLayout, imageView, imageView2, constraintLayout2, imageView3, imageView4, imageView5, textView3, textView4, textView5, editText, imageView6, switchCompatOneApp, constraintLayout3, tabLayout, textView6, viewFindChildViewById, viewFindChildViewById2);
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}