package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class DeepOtherDocsListItemLayoutBinding implements ViewBinding {
    public final TextView deepRvDocDateTime;
    public final TextView deepRvDocDesc;
    public final ImageView deepRvDocImg;
    public final TextView deepRvDocTitle;
    private final MaterialCardView rootView;
    public final MaterialCardView rvCardLayout;

    private DeepOtherDocsListItemLayoutBinding(MaterialCardView rootView, TextView deepRvDocDateTime, TextView deepRvDocDesc, ImageView deepRvDocImg, TextView deepRvDocTitle, MaterialCardView rvCardLayout) {
        this.rootView = rootView;
        this.deepRvDocDateTime = deepRvDocDateTime;
        this.deepRvDocDesc = deepRvDocDesc;
        this.deepRvDocImg = deepRvDocImg;
        this.deepRvDocTitle = deepRvDocTitle;
        this.rvCardLayout = rvCardLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static DeepOtherDocsListItemLayoutBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static DeepOtherDocsListItemLayoutBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.deep_other_docs_list_item_layout, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static DeepOtherDocsListItemLayoutBinding bind(View rootView) {
        int i = R.id.deep_rv_doc_date_time;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null) {
            i = R.id.deep_rv_doc_desc;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView2 != null) {
                i = R.id.deep_rv_doc_img;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                if (imageView != null) {
                    i = R.id.deep_rv_doc_title;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView3 != null) {
                        MaterialCardView materialCardView = (MaterialCardView) rootView;
                        return new DeepOtherDocsListItemLayoutBinding(materialCardView, textView, textView2, imageView, textView3, materialCardView);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}