package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ImageUploadLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class VerifyRegistrationPhotographFragmentBinding implements ViewBinding {
    public final UpdatedHeaderLayoutBackTitleBinding headerLayout;
    public final ImageView homeHeaderPakIdLogoImageView;
    public final TextView homeHeaderUserTitleTextView;
    public final TextView homeHeaderWelcomeTextView;
    private final ConstraintLayout rootView;
    public final ConstraintLayout verifyPhotoHeaderLayout;
    public final ButtonLayoutBinding verifyRegisterPhotoCaptureButtonLayout;
    public final StepActionLayoutBinding verifyRegisterPhotoStepAction;
    public final ButtonLayoutBinding verifyRegisterPhotoSubmitButtonLayout;
    public final ImageUploadLayoutBinding verifyRegisterTakePhoto;

    private VerifyRegistrationPhotographFragmentBinding(ConstraintLayout rootView, UpdatedHeaderLayoutBackTitleBinding headerLayout, ImageView homeHeaderPakIdLogoImageView, TextView homeHeaderUserTitleTextView, TextView homeHeaderWelcomeTextView, ConstraintLayout verifyPhotoHeaderLayout, ButtonLayoutBinding verifyRegisterPhotoCaptureButtonLayout, StepActionLayoutBinding verifyRegisterPhotoStepAction, ButtonLayoutBinding verifyRegisterPhotoSubmitButtonLayout, ImageUploadLayoutBinding verifyRegisterTakePhoto) {
        this.rootView = rootView;
        this.headerLayout = headerLayout;
        this.homeHeaderPakIdLogoImageView = homeHeaderPakIdLogoImageView;
        this.homeHeaderUserTitleTextView = homeHeaderUserTitleTextView;
        this.homeHeaderWelcomeTextView = homeHeaderWelcomeTextView;
        this.verifyPhotoHeaderLayout = verifyPhotoHeaderLayout;
        this.verifyRegisterPhotoCaptureButtonLayout = verifyRegisterPhotoCaptureButtonLayout;
        this.verifyRegisterPhotoStepAction = verifyRegisterPhotoStepAction;
        this.verifyRegisterPhotoSubmitButtonLayout = verifyRegisterPhotoSubmitButtonLayout;
        this.verifyRegisterTakePhoto = verifyRegisterTakePhoto;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static VerifyRegistrationPhotographFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static VerifyRegistrationPhotographFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.verify_registration_photograph_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static VerifyRegistrationPhotographFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        int i = R.id.header_layout;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById2 != null) {
            UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById2);
            i = R.id.home_header_pak_id_logo_imageView;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
            if (imageView != null) {
                i = R.id.home_header_user_title_textView;
                TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView != null) {
                    i = R.id.home_header_welcome_textView;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView2 != null) {
                        i = R.id.verify_photo_header_layout;
                        ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                        if (constraintLayout != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.verify_register_photo_capture_button_layout))) != null) {
                            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById);
                            i = R.id.verify_register_photo_step_action;
                            View viewFindChildViewById3 = ViewBindings.findChildViewById(rootView, i);
                            if (viewFindChildViewById3 != null) {
                                StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById3);
                                i = R.id.verify_register_photo_submit_button_layout;
                                View viewFindChildViewById4 = ViewBindings.findChildViewById(rootView, i);
                                if (viewFindChildViewById4 != null) {
                                    ButtonLayoutBinding buttonLayoutBindingBind2 = ButtonLayoutBinding.bind(viewFindChildViewById4);
                                    i = R.id.verify_register_take_photo;
                                    View viewFindChildViewById5 = ViewBindings.findChildViewById(rootView, i);
                                    if (viewFindChildViewById5 != null) {
                                        return new VerifyRegistrationPhotographFragmentBinding((ConstraintLayout) rootView, updatedHeaderLayoutBackTitleBindingBind, imageView, textView, textView2, constraintLayout, buttonLayoutBindingBind, stepActionLayoutBindingBind, buttonLayoutBindingBind2, ImageUploadLayoutBinding.bind(viewFindChildViewById5));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}