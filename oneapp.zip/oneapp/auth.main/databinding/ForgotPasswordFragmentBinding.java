package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class ForgotPasswordFragmentBinding implements ViewBinding {
    public final TextView forgotPasswordDescriptionTextView;
    public final EdittextLayoutBinding forgotPasswordEmailLayout;
    public final ImageView forgotPasswordLockImageView;
    public final UpdatedHeaderLayoutBackTitleBinding headerLayout;
    public final ButtonLayoutBinding loginButtonLayout;
    public final MaskedEdittextLayoutBinding passwordResetCnicLayout;
    private final ConstraintLayout rootView;
    public final ButtonLayoutBinding submitButtonLayout;

    private ForgotPasswordFragmentBinding(ConstraintLayout rootView, TextView forgotPasswordDescriptionTextView, EdittextLayoutBinding forgotPasswordEmailLayout, ImageView forgotPasswordLockImageView, UpdatedHeaderLayoutBackTitleBinding headerLayout, ButtonLayoutBinding loginButtonLayout, MaskedEdittextLayoutBinding passwordResetCnicLayout, ButtonLayoutBinding submitButtonLayout) {
        this.rootView = rootView;
        this.forgotPasswordDescriptionTextView = forgotPasswordDescriptionTextView;
        this.forgotPasswordEmailLayout = forgotPasswordEmailLayout;
        this.forgotPasswordLockImageView = forgotPasswordLockImageView;
        this.headerLayout = headerLayout;
        this.loginButtonLayout = loginButtonLayout;
        this.passwordResetCnicLayout = passwordResetCnicLayout;
        this.submitButtonLayout = submitButtonLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ForgotPasswordFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static ForgotPasswordFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.forgot_password_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ForgotPasswordFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i = R.id.forgot_password_description_textView;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.forgot_password_email_layout))) != null) {
            EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById);
            i = R.id.forgot_password_lock_imageView;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
            if (imageView != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, (i = R.id.headerLayout))) != null) {
                UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById2);
                i = R.id.login_button_layout;
                View viewFindChildViewById3 = ViewBindings.findChildViewById(rootView, i);
                if (viewFindChildViewById3 != null) {
                    ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById3);
                    i = R.id.password_reset_cnic_layout;
                    View viewFindChildViewById4 = ViewBindings.findChildViewById(rootView, i);
                    if (viewFindChildViewById4 != null) {
                        MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById4);
                        i = R.id.submit_button_layout;
                        View viewFindChildViewById5 = ViewBindings.findChildViewById(rootView, i);
                        if (viewFindChildViewById5 != null) {
                            return new ForgotPasswordFragmentBinding((ConstraintLayout) rootView, textView, edittextLayoutBindingBind, imageView, updatedHeaderLayoutBackTitleBindingBind, buttonLayoutBindingBind, maskedEdittextLayoutBindingBind, ButtonLayoutBinding.bind(viewFindChildViewById5));
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}