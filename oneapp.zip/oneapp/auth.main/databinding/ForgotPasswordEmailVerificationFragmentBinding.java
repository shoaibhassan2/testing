package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.otpview.OTPTextView;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class ForgotPasswordEmailVerificationFragmentBinding implements ViewBinding {
    public final TextView emailVerificationCodeTextView;
    public final TextView emailVerificationDescriptionTextView;
    public final TextView emailVerificationLabelTextView;
    public final TextView emailVerificationResendDescriptionTextView;
    public final TextView emailVerificationResendTextView;
    public final UpdatedHeaderLayoutBackTitleBinding headerLayout;
    public final OTPTextView otpView;
    public final ConstraintLayout otpViewLayout;
    private final ConstraintLayout rootView;

    private ForgotPasswordEmailVerificationFragmentBinding(ConstraintLayout rootView, TextView emailVerificationCodeTextView, TextView emailVerificationDescriptionTextView, TextView emailVerificationLabelTextView, TextView emailVerificationResendDescriptionTextView, TextView emailVerificationResendTextView, UpdatedHeaderLayoutBackTitleBinding headerLayout, OTPTextView otpView, ConstraintLayout otpViewLayout) {
        this.rootView = rootView;
        this.emailVerificationCodeTextView = emailVerificationCodeTextView;
        this.emailVerificationDescriptionTextView = emailVerificationDescriptionTextView;
        this.emailVerificationLabelTextView = emailVerificationLabelTextView;
        this.emailVerificationResendDescriptionTextView = emailVerificationResendDescriptionTextView;
        this.emailVerificationResendTextView = emailVerificationResendTextView;
        this.headerLayout = headerLayout;
        this.otpView = otpView;
        this.otpViewLayout = otpViewLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ForgotPasswordEmailVerificationFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static ForgotPasswordEmailVerificationFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.forgot_password_email_verification_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ForgotPasswordEmailVerificationFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        int i = R.id.email_verification_code_textView;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null) {
            i = R.id.email_verification_description_textView;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView2 != null) {
                i = R.id.email_verification_label_textView;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView3 != null) {
                    i = R.id.email_verification_resend_description_textView;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView4 != null) {
                        i = R.id.email_verification_resend_textView;
                        TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                        if (textView5 != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.headerLayout))) != null) {
                            UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
                            i = R.id.otp_view;
                            OTPTextView oTPTextView = (OTPTextView) ViewBindings.findChildViewById(rootView, i);
                            if (oTPTextView != null) {
                                i = R.id.otp_view_layout;
                                ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                                if (constraintLayout != null) {
                                    return new ForgotPasswordEmailVerificationFragmentBinding((ConstraintLayout) rootView, textView, textView2, textView3, textView4, textView5, updatedHeaderLayoutBackTitleBindingBind, oTPTextView, constraintLayout);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}