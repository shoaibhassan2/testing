package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.otpview.OTPTextView;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class FragmentPhoneNumberOTPVerificationBinding implements ViewBinding {
    public final OTPTextView otpView;
    public final ConstraintLayout otpViewLayout;
    private final ConstraintLayout rootView;
    public final UpdatedHeaderLayoutBackTitleBinding verificationBackIconImageView;
    public final TextView verificationCodeTextView;
    public final TextView verificationCodeUrduTextView;
    public final TextView verificationDescriptionTextView;
    public final TextView verificationDescriptionUrduTextView;
    public final TextView verificationLabelTextView;
    public final TextView verificationLabelUrduTextView;
    public final TextView verificationResendDescriptionTextView;
    public final TextView verificationResendDescriptionUrduTextView;
    public final TextView verificationResendTextView;

    private FragmentPhoneNumberOTPVerificationBinding(ConstraintLayout rootView, OTPTextView otpView, ConstraintLayout otpViewLayout, UpdatedHeaderLayoutBackTitleBinding verificationBackIconImageView, TextView verificationCodeTextView, TextView verificationCodeUrduTextView, TextView verificationDescriptionTextView, TextView verificationDescriptionUrduTextView, TextView verificationLabelTextView, TextView verificationLabelUrduTextView, TextView verificationResendDescriptionTextView, TextView verificationResendDescriptionUrduTextView, TextView verificationResendTextView) {
        this.rootView = rootView;
        this.otpView = otpView;
        this.otpViewLayout = otpViewLayout;
        this.verificationBackIconImageView = verificationBackIconImageView;
        this.verificationCodeTextView = verificationCodeTextView;
        this.verificationCodeUrduTextView = verificationCodeUrduTextView;
        this.verificationDescriptionTextView = verificationDescriptionTextView;
        this.verificationDescriptionUrduTextView = verificationDescriptionUrduTextView;
        this.verificationLabelTextView = verificationLabelTextView;
        this.verificationLabelUrduTextView = verificationLabelUrduTextView;
        this.verificationResendDescriptionTextView = verificationResendDescriptionTextView;
        this.verificationResendDescriptionUrduTextView = verificationResendDescriptionUrduTextView;
        this.verificationResendTextView = verificationResendTextView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentPhoneNumberOTPVerificationBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static FragmentPhoneNumberOTPVerificationBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.fragment_phone_number_o_t_p_verification, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentPhoneNumberOTPVerificationBinding bind(View rootView) {
        View viewFindChildViewById;
        int i = R.id.otp_view;
        OTPTextView oTPTextView = (OTPTextView) ViewBindings.findChildViewById(rootView, i);
        if (oTPTextView != null) {
            i = R.id.otp_view_layout;
            ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
            if (constraintLayout != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.verification_back_icon_imageView))) != null) {
                UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
                i = R.id.verification_code_textView;
                TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView != null) {
                    i = R.id.verification_code_urdu_textView;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView2 != null) {
                        i = R.id.verification_description_textView;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                        if (textView3 != null) {
                            i = R.id.verification_description_urdu_textView;
                            TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                            if (textView4 != null) {
                                i = R.id.verification_label_textView;
                                TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                if (textView5 != null) {
                                    i = R.id.verification_label_urdu_textView;
                                    TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                    if (textView6 != null) {
                                        i = R.id.verification_resend_description_textView;
                                        TextView textView7 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                        if (textView7 != null) {
                                            i = R.id.verification_resend_description_urdu_textView;
                                            TextView textView8 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                            if (textView8 != null) {
                                                i = R.id.verification_resend_textView;
                                                TextView textView9 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                if (textView9 != null) {
                                                    return new FragmentPhoneNumberOTPVerificationBinding((ConstraintLayout) rootView, oTPTextView, constraintLayout, updatedHeaderLayoutBackTitleBindingBind, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}