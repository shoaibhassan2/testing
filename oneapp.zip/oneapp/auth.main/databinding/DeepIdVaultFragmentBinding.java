package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.tabs.TabLayout;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class DeepIdVaultFragmentBinding implements ViewBinding {
    public final ImageView addDocsBtn;
    public final ConstraintLayout cardLayout;
    public final TextView cnicLabel;
    public final TextView cnicValue;
    public final ConstraintLayout deepVaultFirstRow;
    public final LinearLayout deepVaultHeaderLayout;
    public final MaterialCardView deepVaultMain;
    public final ConstraintLayout deepVaultMainBlur;
    public final ConstraintLayout deepVaultSecondRow;
    public final TabLayout deepVaultTabLayout;
    public final TextView getDigID;
    public final ImageView idToprow;
    public final ConstraintLayout loginLayout;
    public final TextView nameLabel;
    public final TextView nameValue;
    public final TextView otherDocTv;
    private final ConstraintLayout rootView;
    public final RecyclerView rvDeepOtherDocs;
    public final TextView tvTitleNadraServices;

    private DeepIdVaultFragmentBinding(ConstraintLayout rootView, ImageView addDocsBtn, ConstraintLayout cardLayout, TextView cnicLabel, TextView cnicValue, ConstraintLayout deepVaultFirstRow, LinearLayout deepVaultHeaderLayout, MaterialCardView deepVaultMain, ConstraintLayout deepVaultMainBlur, ConstraintLayout deepVaultSecondRow, TabLayout deepVaultTabLayout, TextView getDigID, ImageView idToprow, ConstraintLayout loginLayout, TextView nameLabel, TextView nameValue, TextView otherDocTv, RecyclerView rvDeepOtherDocs, TextView tvTitleNadraServices) {
        this.rootView = rootView;
        this.addDocsBtn = addDocsBtn;
        this.cardLayout = cardLayout;
        this.cnicLabel = cnicLabel;
        this.cnicValue = cnicValue;
        this.deepVaultFirstRow = deepVaultFirstRow;
        this.deepVaultHeaderLayout = deepVaultHeaderLayout;
        this.deepVaultMain = deepVaultMain;
        this.deepVaultMainBlur = deepVaultMainBlur;
        this.deepVaultSecondRow = deepVaultSecondRow;
        this.deepVaultTabLayout = deepVaultTabLayout;
        this.getDigID = getDigID;
        this.idToprow = idToprow;
        this.loginLayout = loginLayout;
        this.nameLabel = nameLabel;
        this.nameValue = nameValue;
        this.otherDocTv = otherDocTv;
        this.rvDeepOtherDocs = rvDeepOtherDocs;
        this.tvTitleNadraServices = tvTitleNadraServices;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static DeepIdVaultFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static DeepIdVaultFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.deep_id_vault_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static DeepIdVaultFragmentBinding bind(View rootView) {
        int i = R.id.add_docs_btn;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
        if (imageView != null) {
            i = R.id.card_layout;
            ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
            if (constraintLayout != null) {
                i = R.id.cnic_label;
                TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView != null) {
                    i = R.id.cnic_value;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView2 != null) {
                        i = R.id.deep_vault_first_row;
                        ConstraintLayout constraintLayout2 = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                        if (constraintLayout2 != null) {
                            i = R.id.deep_vault_header_layout;
                            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(rootView, i);
                            if (linearLayout != null) {
                                i = R.id.deep_vault_main;
                                MaterialCardView materialCardView = (MaterialCardView) ViewBindings.findChildViewById(rootView, i);
                                if (materialCardView != null) {
                                    i = R.id.deep_vault_main_blur;
                                    ConstraintLayout constraintLayout3 = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                                    if (constraintLayout3 != null) {
                                        i = R.id.deep_vault_second_row;
                                        ConstraintLayout constraintLayout4 = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                                        if (constraintLayout4 != null) {
                                            i = R.id.deep_vault_tabLayout;
                                            TabLayout tabLayout = (TabLayout) ViewBindings.findChildViewById(rootView, i);
                                            if (tabLayout != null) {
                                                i = R.id.getDigID;
                                                TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                if (textView3 != null) {
                                                    i = R.id.id_toprow;
                                                    ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                                    if (imageView2 != null) {
                                                        ConstraintLayout constraintLayout5 = (ConstraintLayout) rootView;
                                                        i = R.id.name_label;
                                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                        if (textView4 != null) {
                                                            i = R.id.name_value;
                                                            TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                            if (textView5 != null) {
                                                                i = R.id.otherDocTv;
                                                                TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                if (textView6 != null) {
                                                                    i = R.id.rv_deep_other_docs;
                                                                    RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(rootView, i);
                                                                    if (recyclerView != null) {
                                                                        i = R.id.tv_title_nadra_services;
                                                                        TextView textView7 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                        if (textView7 != null) {
                                                                            return new DeepIdVaultFragmentBinding(constraintLayout5, imageView, constraintLayout, textView, textView2, constraintLayout2, linearLayout, materialCardView, constraintLayout3, constraintLayout4, tabLayout, textView3, imageView2, constraintLayout5, textView4, textView5, textView6, recyclerView, textView7);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}