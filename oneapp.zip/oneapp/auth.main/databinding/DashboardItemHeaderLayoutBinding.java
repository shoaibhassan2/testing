package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.divider.MaterialDivider;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class DashboardItemHeaderLayoutBinding implements ViewBinding {
    public final TextView dashboardItemServicesHeaderTextView;
    public final TextView dashboardItemServicesUrduHeaderTextView;
    public final MaterialDivider groupDivider;
    private final ConstraintLayout rootView;

    private DashboardItemHeaderLayoutBinding(ConstraintLayout rootView, TextView dashboardItemServicesHeaderTextView, TextView dashboardItemServicesUrduHeaderTextView, MaterialDivider groupDivider) {
        this.rootView = rootView;
        this.dashboardItemServicesHeaderTextView = dashboardItemServicesHeaderTextView;
        this.dashboardItemServicesUrduHeaderTextView = dashboardItemServicesUrduHeaderTextView;
        this.groupDivider = groupDivider;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static DashboardItemHeaderLayoutBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static DashboardItemHeaderLayoutBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.dashboard_item_header_layout, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static DashboardItemHeaderLayoutBinding bind(View rootView) {
        int i = R.id.dashboard_item_services_header_textView;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null) {
            i = R.id.dashboard_item_services_urdu_header_textView;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView2 != null) {
                i = R.id.group_divider;
                MaterialDivider materialDivider = (MaterialDivider) ViewBindings.findChildViewById(rootView, i);
                if (materialDivider != null) {
                    return new DashboardItemHeaderLayoutBinding((ConstraintLayout) rootView, textView, textView2, materialDivider);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}