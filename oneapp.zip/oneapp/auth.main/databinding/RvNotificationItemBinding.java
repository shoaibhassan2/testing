package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class RvNotificationItemBinding implements ViewBinding {
    public final ImageView ivNotification;
    private final MaterialCardView rootView;
    public final MaterialCardView rvCardLayout;
    public final TextView tvNotificationDate;
    public final TextView tvNotificationTitle;

    private RvNotificationItemBinding(MaterialCardView rootView, ImageView ivNotification, MaterialCardView rvCardLayout, TextView tvNotificationDate, TextView tvNotificationTitle) {
        this.rootView = rootView;
        this.ivNotification = ivNotification;
        this.rvCardLayout = rvCardLayout;
        this.tvNotificationDate = tvNotificationDate;
        this.tvNotificationTitle = tvNotificationTitle;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static RvNotificationItemBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static RvNotificationItemBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.rv_notification_item, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static RvNotificationItemBinding bind(View rootView) {
        int i = R.id.iv_notification;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
        if (imageView != null) {
            MaterialCardView materialCardView = (MaterialCardView) rootView;
            i = R.id.tv_notification_date;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null) {
                i = R.id.tv_notification_title;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView2 != null) {
                    return new RvNotificationItemBinding(materialCardView, imageView, materialCardView, textView, textView2);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}