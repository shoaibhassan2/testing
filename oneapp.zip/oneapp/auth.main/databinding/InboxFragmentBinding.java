package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class InboxFragmentBinding implements ViewBinding {
    public final ImageView filterButton;
    public final TextView inboxBackEnglishTitleTextView;
    public final ImageView inboxBackIconImageView;
    public final LinearLayout inboxBackLinearLayout;
    public final TextView inboxBackUrduTitleTextView;
    public final TextView inboxEnglishTitleTextView;
    public final ConstraintLayout inboxHeaderLayout;
    public final TextView inboxNoApplicationDescTextView;
    public final RecyclerView inboxRecyclerView;
    public final SwipeRefreshLayout inboxSwipeRefresh;
    public final ImageView inboxTryAgainImageView;
    public final LinearLayout inboxTryAgainLayout;
    public final TextView inboxTryAgainTextView;
    public final TextView inboxUrduTitleTextView;
    private final SwipeRefreshLayout rootView;
    public final TextView totalApplicationsTitleTextView;
    public final TextView urduInboxNoApplicationDescTextView;
    public final TextView urduInboxTryAgainTextView;
    public final TextView urduTotalApplicationsTitleTextView;

    private InboxFragmentBinding(SwipeRefreshLayout rootView, ImageView filterButton, TextView inboxBackEnglishTitleTextView, ImageView inboxBackIconImageView, LinearLayout inboxBackLinearLayout, TextView inboxBackUrduTitleTextView, TextView inboxEnglishTitleTextView, ConstraintLayout inboxHeaderLayout, TextView inboxNoApplicationDescTextView, RecyclerView inboxRecyclerView, SwipeRefreshLayout inboxSwipeRefresh, ImageView inboxTryAgainImageView, LinearLayout inboxTryAgainLayout, TextView inboxTryAgainTextView, TextView inboxUrduTitleTextView, TextView totalApplicationsTitleTextView, TextView urduInboxNoApplicationDescTextView, TextView urduInboxTryAgainTextView, TextView urduTotalApplicationsTitleTextView) {
        this.rootView = rootView;
        this.filterButton = filterButton;
        this.inboxBackEnglishTitleTextView = inboxBackEnglishTitleTextView;
        this.inboxBackIconImageView = inboxBackIconImageView;
        this.inboxBackLinearLayout = inboxBackLinearLayout;
        this.inboxBackUrduTitleTextView = inboxBackUrduTitleTextView;
        this.inboxEnglishTitleTextView = inboxEnglishTitleTextView;
        this.inboxHeaderLayout = inboxHeaderLayout;
        this.inboxNoApplicationDescTextView = inboxNoApplicationDescTextView;
        this.inboxRecyclerView = inboxRecyclerView;
        this.inboxSwipeRefresh = inboxSwipeRefresh;
        this.inboxTryAgainImageView = inboxTryAgainImageView;
        this.inboxTryAgainLayout = inboxTryAgainLayout;
        this.inboxTryAgainTextView = inboxTryAgainTextView;
        this.inboxUrduTitleTextView = inboxUrduTitleTextView;
        this.totalApplicationsTitleTextView = totalApplicationsTitleTextView;
        this.urduInboxNoApplicationDescTextView = urduInboxNoApplicationDescTextView;
        this.urduInboxTryAgainTextView = urduInboxTryAgainTextView;
        this.urduTotalApplicationsTitleTextView = urduTotalApplicationsTitleTextView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public SwipeRefreshLayout getRoot() {
        return this.rootView;
    }

    public static InboxFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static InboxFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.inbox_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static InboxFragmentBinding bind(View rootView) {
        int i = R.id.filter_button;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
        if (imageView != null) {
            i = R.id.inbox_back_english_title_textView;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null) {
                i = R.id.inbox_back_icon_imageView;
                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                if (imageView2 != null) {
                    i = R.id.inbox_back_linearLayout;
                    LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(rootView, i);
                    if (linearLayout != null) {
                        i = R.id.inbox_back_urdu_title_textView;
                        TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                        if (textView2 != null) {
                            i = R.id.inbox_english_title_textView;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                            if (textView3 != null) {
                                i = R.id.inbox_header_layout;
                                ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                                if (constraintLayout != null) {
                                    i = R.id.inbox_no_application_desc_textView;
                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                    if (textView4 != null) {
                                        i = R.id.inbox_recyclerView;
                                        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(rootView, i);
                                        if (recyclerView != null) {
                                            SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) rootView;
                                            i = R.id.inbox_try_again_imageView;
                                            ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                            if (imageView3 != null) {
                                                i = R.id.inbox_try_again_layout;
                                                LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(rootView, i);
                                                if (linearLayout2 != null) {
                                                    i = R.id.inbox_try_again_textView;
                                                    TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                    if (textView5 != null) {
                                                        i = R.id.inbox_urdu_title_textView;
                                                        TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                        if (textView6 != null) {
                                                            i = R.id.total_applications_title_textView;
                                                            TextView textView7 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                            if (textView7 != null) {
                                                                i = R.id.urdu_inbox_no_application_desc_textView;
                                                                TextView textView8 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                if (textView8 != null) {
                                                                    i = R.id.urdu_inbox_try_again_textView;
                                                                    TextView textView9 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                    if (textView9 != null) {
                                                                        i = R.id.urdu_total_applications_title_textView;
                                                                        TextView textView10 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                        if (textView10 != null) {
                                                                            return new InboxFragmentBinding(swipeRefreshLayout, imageView, textView, imageView2, linearLayout, textView2, textView3, constraintLayout, textView4, recyclerView, swipeRefreshLayout, imageView3, linearLayout2, textView5, textView6, textView7, textView8, textView9, textView10);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}