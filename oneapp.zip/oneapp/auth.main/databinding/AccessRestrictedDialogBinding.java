package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;

/* loaded from: classes5.dex */
public final class AccessRestrictedDialogBinding implements ViewBinding {
    public final TextView accessRestrictedDetailTextView;
    public final TextView accessRestrictedDetailTextViewUrdu;
    public final ImageView accessRestrictedIconImageView;
    public final ConfigurableButton accessRestrictedSkipButtonLayout;
    public final TextView accessRestrictedTitleTextView;
    public final ConfigurableButton accessRestrictedVerifyNowButtonLayout;
    private final MaterialCardView rootView;
    public final MaterialCardView rvCardLayout;

    private AccessRestrictedDialogBinding(MaterialCardView rootView, TextView accessRestrictedDetailTextView, TextView accessRestrictedDetailTextViewUrdu, ImageView accessRestrictedIconImageView, ConfigurableButton accessRestrictedSkipButtonLayout, TextView accessRestrictedTitleTextView, ConfigurableButton accessRestrictedVerifyNowButtonLayout, MaterialCardView rvCardLayout) {
        this.rootView = rootView;
        this.accessRestrictedDetailTextView = accessRestrictedDetailTextView;
        this.accessRestrictedDetailTextViewUrdu = accessRestrictedDetailTextViewUrdu;
        this.accessRestrictedIconImageView = accessRestrictedIconImageView;
        this.accessRestrictedSkipButtonLayout = accessRestrictedSkipButtonLayout;
        this.accessRestrictedTitleTextView = accessRestrictedTitleTextView;
        this.accessRestrictedVerifyNowButtonLayout = accessRestrictedVerifyNowButtonLayout;
        this.rvCardLayout = rvCardLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static AccessRestrictedDialogBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static AccessRestrictedDialogBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.access_restricted_dialog, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static AccessRestrictedDialogBinding bind(View rootView) {
        int i = R.id.access_restricted_detail_textView;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null) {
            i = R.id.access_restricted_detail_textView_urdu;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView2 != null) {
                i = R.id.access_restricted_icon_imageView;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                if (imageView != null) {
                    i = R.id.access_restricted_skip_button_layout;
                    ConfigurableButton configurableButton = (ConfigurableButton) ViewBindings.findChildViewById(rootView, i);
                    if (configurableButton != null) {
                        i = R.id.access_restricted_title_textView;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                        if (textView3 != null) {
                            i = R.id.access_restricted_verify_now_button_layout;
                            ConfigurableButton configurableButton2 = (ConfigurableButton) ViewBindings.findChildViewById(rootView, i);
                            if (configurableButton2 != null) {
                                MaterialCardView materialCardView = (MaterialCardView) rootView;
                                return new AccessRestrictedDialogBinding(materialCardView, textView, textView2, imageView, configurableButton, textView3, configurableButton2, materialCardView);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}