package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.tabs.TabLayout;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.NewHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class DeepRequestDocFragmentBinding implements ViewBinding {
    public final NewHeaderLayoutBackTitleBinding deepRequestDocHeaderLayout;
    public final TabLayout deepTabLayout;
    public final TextView docsText;
    public final ConstraintLayout loginLayout;
    public final TextView reqDocsTitle;
    private final ConstraintLayout rootView;
    public final RecyclerView rvDeepRequestDocs;
    public final CardView searchBar;
    public final ImageButton searchButton;
    public final EditText searchEditText;

    private DeepRequestDocFragmentBinding(ConstraintLayout rootView, NewHeaderLayoutBackTitleBinding deepRequestDocHeaderLayout, TabLayout deepTabLayout, TextView docsText, ConstraintLayout loginLayout, TextView reqDocsTitle, RecyclerView rvDeepRequestDocs, CardView searchBar, ImageButton searchButton, EditText searchEditText) {
        this.rootView = rootView;
        this.deepRequestDocHeaderLayout = deepRequestDocHeaderLayout;
        this.deepTabLayout = deepTabLayout;
        this.docsText = docsText;
        this.loginLayout = loginLayout;
        this.reqDocsTitle = reqDocsTitle;
        this.rvDeepRequestDocs = rvDeepRequestDocs;
        this.searchBar = searchBar;
        this.searchButton = searchButton;
        this.searchEditText = searchEditText;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static DeepRequestDocFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static DeepRequestDocFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.deep_request_doc_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static DeepRequestDocFragmentBinding bind(View rootView) {
        int i = R.id.deep_request_doc_header_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById != null) {
            NewHeaderLayoutBackTitleBinding newHeaderLayoutBackTitleBindingBind = NewHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
            i = R.id.deep_tabLayout;
            TabLayout tabLayout = (TabLayout) ViewBindings.findChildViewById(rootView, i);
            if (tabLayout != null) {
                i = R.id.docs_text;
                TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView != null) {
                    ConstraintLayout constraintLayout = (ConstraintLayout) rootView;
                    i = R.id.req_docs_title;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView2 != null) {
                        i = R.id.rv_deep_request_docs;
                        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(rootView, i);
                        if (recyclerView != null) {
                            i = R.id.search_bar;
                            CardView cardView = (CardView) ViewBindings.findChildViewById(rootView, i);
                            if (cardView != null) {
                                i = R.id.searchButton;
                                ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(rootView, i);
                                if (imageButton != null) {
                                    i = R.id.searchEditText;
                                    EditText editText = (EditText) ViewBindings.findChildViewById(rootView, i);
                                    if (editText != null) {
                                        return new DeepRequestDocFragmentBinding(constraintLayout, newHeaderLayoutBackTitleBindingBind, tabLayout, textView, constraintLayout, textView2, recyclerView, cardView, imageButton, editText);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}