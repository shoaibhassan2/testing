package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class DeepRequestDocsListItemLayoutBinding implements ViewBinding {
    public final TextView deepRvDocDesc;
    public final TextView deepRvDocTitle;
    public final MaterialButton docGetBtn;
    private final MaterialCardView rootView;
    public final MaterialCardView rvCardLayout;

    private DeepRequestDocsListItemLayoutBinding(MaterialCardView rootView, TextView deepRvDocDesc, TextView deepRvDocTitle, MaterialButton docGetBtn, MaterialCardView rvCardLayout) {
        this.rootView = rootView;
        this.deepRvDocDesc = deepRvDocDesc;
        this.deepRvDocTitle = deepRvDocTitle;
        this.docGetBtn = docGetBtn;
        this.rvCardLayout = rvCardLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static DeepRequestDocsListItemLayoutBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static DeepRequestDocsListItemLayoutBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.deep_request_docs_list_item_layout, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static DeepRequestDocsListItemLayoutBinding bind(View rootView) {
        int i = R.id.deep_rv_doc_desc;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null) {
            i = R.id.deep_rv_doc_title;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView2 != null) {
                i = R.id.doc_get_btn;
                MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(rootView, i);
                if (materialButton != null) {
                    MaterialCardView materialCardView = (MaterialCardView) rootView;
                    return new DeepRequestDocsListItemLayoutBinding(materialCardView, textView, textView2, materialButton, materialCardView);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}