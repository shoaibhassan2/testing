package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ImageUploadLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class VerifyRegistrationBiometricFragmentBinding implements ViewBinding {
    public final UpdatedHeaderLayoutBackTitleBinding headerLayout;
    public final TextView headingTextView;
    public final ImageView homeHeaderPakIdLogoImageView;
    public final TextView homeHeaderUserTitleTextView;
    public final TextView homeHeaderWelcomeTextView;
    private final ConstraintLayout rootView;
    public final ConstraintLayout verifyBiometricHeaderLayout;
    public final ButtonLayoutBinding verifyRegisterBiometricCaptureButtonLayout;
    public final TextView verifyRegisterBiometricCountTextView;
    public final ImageUploadLayoutBinding verifyRegisterTakeBiometric;

    private VerifyRegistrationBiometricFragmentBinding(ConstraintLayout rootView, UpdatedHeaderLayoutBackTitleBinding headerLayout, TextView headingTextView, ImageView homeHeaderPakIdLogoImageView, TextView homeHeaderUserTitleTextView, TextView homeHeaderWelcomeTextView, ConstraintLayout verifyBiometricHeaderLayout, ButtonLayoutBinding verifyRegisterBiometricCaptureButtonLayout, TextView verifyRegisterBiometricCountTextView, ImageUploadLayoutBinding verifyRegisterTakeBiometric) {
        this.rootView = rootView;
        this.headerLayout = headerLayout;
        this.headingTextView = headingTextView;
        this.homeHeaderPakIdLogoImageView = homeHeaderPakIdLogoImageView;
        this.homeHeaderUserTitleTextView = homeHeaderUserTitleTextView;
        this.homeHeaderWelcomeTextView = homeHeaderWelcomeTextView;
        this.verifyBiometricHeaderLayout = verifyBiometricHeaderLayout;
        this.verifyRegisterBiometricCaptureButtonLayout = verifyRegisterBiometricCaptureButtonLayout;
        this.verifyRegisterBiometricCountTextView = verifyRegisterBiometricCountTextView;
        this.verifyRegisterTakeBiometric = verifyRegisterTakeBiometric;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static VerifyRegistrationBiometricFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static VerifyRegistrationBiometricFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.verify_registration_biometric_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static VerifyRegistrationBiometricFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i = R.id.header_layout;
        View viewFindChildViewById3 = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById3 != null) {
            UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById3);
            i = R.id.heading_text_view;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null) {
                i = R.id.home_header_pak_id_logo_imageView;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                if (imageView != null) {
                    i = R.id.home_header_user_title_textView;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView2 != null) {
                        i = R.id.home_header_welcome_textView;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                        if (textView3 != null) {
                            i = R.id.verify_biometric_header_layout;
                            ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                            if (constraintLayout != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.verify_register_biometric_capture_button_layout))) != null) {
                                ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById);
                                i = R.id.verify_register_biometric_count_textView;
                                TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                if (textView4 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, (i = R.id.verify_register_take_biometric))) != null) {
                                    return new VerifyRegistrationBiometricFragmentBinding((ConstraintLayout) rootView, updatedHeaderLayoutBackTitleBindingBind, textView, imageView, textView2, textView3, constraintLayout, buttonLayoutBindingBind, textView4, ImageUploadLayoutBinding.bind(viewFindChildViewById2));
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}