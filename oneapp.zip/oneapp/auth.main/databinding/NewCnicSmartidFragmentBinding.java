package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedStepTitleLayoutBinding;

/* loaded from: classes5.dex */
public final class NewCnicSmartidFragmentBinding implements ViewBinding {
    public final MaskedEdittextLayoutBinding attestorCnicNumberLayout;
    public final ButtonLayoutBinding birthCertificateButtonLayout;
    public final AutocompletetextviewLayoutBinding crmsNumberLayout;
    public final ConstraintLayout deceasedMainLayout;
    public final ConstraintLayout main;
    public final UpdatedHeaderLayoutBackTitleBinding newAppHeaderLayout;
    public final TextView newCnicUcMessageTextView;
    public final TextView newCnicUcMessageTextViewUrdu;
    public final ButtonLayoutBinding nextButtonLayout;
    public final RadioButton noRegisteredInUcRadioButton;
    public final TextView registerBirthCivilTextView;
    public final TextView registerBirthCivilTextViewUrdu;
    public final RadioGroup registeredInUcRadioGroup;
    public final AutocompletetextviewLayoutBinding relationLayout;
    private final ConstraintLayout rootView;
    public final UpdatedStepTitleLayoutBinding stepTitleHeadingLayout;
    public final TextView tvIdentityNoRecord;
    public final TextView tvIdentityNoRecordUrdu;
    public final ButtonLayoutBinding verifyAttestorButtonLayout;
    public final RadioButton yesRegisteredInUcRadioButton;

    private NewCnicSmartidFragmentBinding(ConstraintLayout rootView, MaskedEdittextLayoutBinding attestorCnicNumberLayout, ButtonLayoutBinding birthCertificateButtonLayout, AutocompletetextviewLayoutBinding crmsNumberLayout, ConstraintLayout deceasedMainLayout, ConstraintLayout main, UpdatedHeaderLayoutBackTitleBinding newAppHeaderLayout, TextView newCnicUcMessageTextView, TextView newCnicUcMessageTextViewUrdu, ButtonLayoutBinding nextButtonLayout, RadioButton noRegisteredInUcRadioButton, TextView registerBirthCivilTextView, TextView registerBirthCivilTextViewUrdu, RadioGroup registeredInUcRadioGroup, AutocompletetextviewLayoutBinding relationLayout, UpdatedStepTitleLayoutBinding stepTitleHeadingLayout, TextView tvIdentityNoRecord, TextView tvIdentityNoRecordUrdu, ButtonLayoutBinding verifyAttestorButtonLayout, RadioButton yesRegisteredInUcRadioButton) {
        this.rootView = rootView;
        this.attestorCnicNumberLayout = attestorCnicNumberLayout;
        this.birthCertificateButtonLayout = birthCertificateButtonLayout;
        this.crmsNumberLayout = crmsNumberLayout;
        this.deceasedMainLayout = deceasedMainLayout;
        this.main = main;
        this.newAppHeaderLayout = newAppHeaderLayout;
        this.newCnicUcMessageTextView = newCnicUcMessageTextView;
        this.newCnicUcMessageTextViewUrdu = newCnicUcMessageTextViewUrdu;
        this.nextButtonLayout = nextButtonLayout;
        this.noRegisteredInUcRadioButton = noRegisteredInUcRadioButton;
        this.registerBirthCivilTextView = registerBirthCivilTextView;
        this.registerBirthCivilTextViewUrdu = registerBirthCivilTextViewUrdu;
        this.registeredInUcRadioGroup = registeredInUcRadioGroup;
        this.relationLayout = relationLayout;
        this.stepTitleHeadingLayout = stepTitleHeadingLayout;
        this.tvIdentityNoRecord = tvIdentityNoRecord;
        this.tvIdentityNoRecordUrdu = tvIdentityNoRecordUrdu;
        this.verifyAttestorButtonLayout = verifyAttestorButtonLayout;
        this.yesRegisteredInUcRadioButton = yesRegisteredInUcRadioButton;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static NewCnicSmartidFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static NewCnicSmartidFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.new_cnic_smartid_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static NewCnicSmartidFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        int i = R.id.attestor_cnic_number_layout;
        View viewFindChildViewById4 = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById4 != null) {
            MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById4);
            i = R.id.birth_certificate_button_layout;
            View viewFindChildViewById5 = ViewBindings.findChildViewById(rootView, i);
            if (viewFindChildViewById5 != null) {
                ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById5);
                i = R.id.crms_number_layout;
                View viewFindChildViewById6 = ViewBindings.findChildViewById(rootView, i);
                if (viewFindChildViewById6 != null) {
                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById6);
                    i = R.id.deceased_main_layout;
                    ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                    if (constraintLayout != null) {
                        ConstraintLayout constraintLayout2 = (ConstraintLayout) rootView;
                        i = R.id.new_app_header_layout;
                        View viewFindChildViewById7 = ViewBindings.findChildViewById(rootView, i);
                        if (viewFindChildViewById7 != null) {
                            UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById7);
                            i = R.id.new_cnic_uc_message_textView;
                            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                            if (textView != null) {
                                i = R.id.new_cnic_uc_message_textView_urdu;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                if (textView2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.next_button_layout))) != null) {
                                    ButtonLayoutBinding buttonLayoutBindingBind2 = ButtonLayoutBinding.bind(viewFindChildViewById);
                                    i = R.id.no_registered_in_uc_radioButton;
                                    RadioButton radioButton = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                                    if (radioButton != null) {
                                        i = R.id.register_birth_civil_textView;
                                        TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                        if (textView3 != null) {
                                            i = R.id.register_birth_civil_textView_urdu;
                                            TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                            if (textView4 != null) {
                                                i = R.id.registered_in_uc_radioGroup;
                                                RadioGroup radioGroup = (RadioGroup) ViewBindings.findChildViewById(rootView, i);
                                                if (radioGroup != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, (i = R.id.relation_layout))) != null) {
                                                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind2 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById2);
                                                    i = R.id.step_title_heading_layout;
                                                    View viewFindChildViewById8 = ViewBindings.findChildViewById(rootView, i);
                                                    if (viewFindChildViewById8 != null) {
                                                        UpdatedStepTitleLayoutBinding updatedStepTitleLayoutBindingBind = UpdatedStepTitleLayoutBinding.bind(viewFindChildViewById8);
                                                        i = R.id.tv_identity_no_record;
                                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                        if (textView5 != null) {
                                                            i = R.id.tv_identity_no_record_urdu;
                                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                            if (textView6 != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(rootView, (i = R.id.verify_attestor_button_layout))) != null) {
                                                                ButtonLayoutBinding buttonLayoutBindingBind3 = ButtonLayoutBinding.bind(viewFindChildViewById3);
                                                                i = R.id.yes_registered_in_uc_radioButton;
                                                                RadioButton radioButton2 = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                                                                if (radioButton2 != null) {
                                                                    return new NewCnicSmartidFragmentBinding(constraintLayout2, maskedEdittextLayoutBindingBind, buttonLayoutBindingBind, autocompletetextviewLayoutBindingBind, constraintLayout, constraintLayout2, updatedHeaderLayoutBackTitleBindingBind, textView, textView2, buttonLayoutBindingBind2, radioButton, textView3, textView4, radioGroup, autocompletetextviewLayoutBindingBind2, updatedStepTitleLayoutBindingBind, textView5, textView6, buttonLayoutBindingBind3, radioButton2);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}