package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class RvCardItemBinding implements ViewBinding {
    private final MaterialCardView rootView;
    public final MaterialCardView rvCardLayout;
    public final TextView rvDesc;
    public final ImageView rvImage;
    public final TextView rvTitle;

    private RvCardItemBinding(MaterialCardView rootView, MaterialCardView rvCardLayout, TextView rvDesc, ImageView rvImage, TextView rvTitle) {
        this.rootView = rootView;
        this.rvCardLayout = rvCardLayout;
        this.rvDesc = rvDesc;
        this.rvImage = rvImage;
        this.rvTitle = rvTitle;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static RvCardItemBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static RvCardItemBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.rv_card_item, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static RvCardItemBinding bind(View rootView) {
        MaterialCardView materialCardView = (MaterialCardView) rootView;
        int i = R.id.rv_desc;
        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
        if (textView != null) {
            i = R.id.rv_image;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
            if (imageView != null) {
                i = R.id.rv_title;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView2 != null) {
                    return new RvCardItemBinding(materialCardView, materialCardView, textView, imageView, textView2);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}