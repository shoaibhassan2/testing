package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.radiobutton.MaterialRadioButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.CheckboxLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.RadioGroupLayoutBinding;

/* loaded from: classes5.dex */
public final class RegisterFragmentBinding implements ViewBinding {
    public final CheckboxLayoutBinding acceptTermsCheckbox;
    public final TextView createAccountTitleTextView;
    public final RadioGroupLayoutBinding haveCnicRadioGroup;
    public final EdittextLayoutBinding issueDobDateLayout;
    public final RadioGroupLayoutBinding issueDobDateRadioGroup;
    public final ConstraintLayout loginLayout;
    public final ImageView loginPakIdLogoImageView;
    public final MaterialRadioButton nonPakistaniRadioButton;
    public final RadioGroup pakistaniOrNonRadioGroup;
    public final MaterialRadioButton pakistaniRadioButton;
    public final TextInputEditText phoneNumberTextInputEditText;
    public final TextView registerCnicHeadingTextView;
    public final MaskedEdittextLayoutBinding registerCnicLayout;
    public final EdittextLayoutBinding registerConfirmPasswordLayout;
    public final TextInputLayout registerContactNumberLayout;
    public final AutocompletetextviewLayoutBinding registerCountryLayout;
    public final EdittextLayoutBinding registerEmailLayout;
    public final EdittextLayoutBinding registerFirstNameLayout;
    public final EdittextLayoutBinding registerLastNameLayout;
    public final ConfigurableButton registerLoginButtonLayout;
    public final TextView registerMobileNumberGuideTextView;
    public final TextView registerNationalityHeadingTextView;
    public final ConfigurableButton registerNextButtonLayout;
    public final TextView registerNoCnicTextView;
    public final EdittextLayoutBinding registerPasswordLayout;
    public final AutocompletetextviewLayoutBinding registerPhoneNumberOperatorLayout;
    private final ConstraintLayout rootView;

    private RegisterFragmentBinding(ConstraintLayout rootView, CheckboxLayoutBinding acceptTermsCheckbox, TextView createAccountTitleTextView, RadioGroupLayoutBinding haveCnicRadioGroup, EdittextLayoutBinding issueDobDateLayout, RadioGroupLayoutBinding issueDobDateRadioGroup, ConstraintLayout loginLayout, ImageView loginPakIdLogoImageView, MaterialRadioButton nonPakistaniRadioButton, RadioGroup pakistaniOrNonRadioGroup, MaterialRadioButton pakistaniRadioButton, TextInputEditText phoneNumberTextInputEditText, TextView registerCnicHeadingTextView, MaskedEdittextLayoutBinding registerCnicLayout, EdittextLayoutBinding registerConfirmPasswordLayout, TextInputLayout registerContactNumberLayout, AutocompletetextviewLayoutBinding registerCountryLayout, EdittextLayoutBinding registerEmailLayout, EdittextLayoutBinding registerFirstNameLayout, EdittextLayoutBinding registerLastNameLayout, ConfigurableButton registerLoginButtonLayout, TextView registerMobileNumberGuideTextView, TextView registerNationalityHeadingTextView, ConfigurableButton registerNextButtonLayout, TextView registerNoCnicTextView, EdittextLayoutBinding registerPasswordLayout, AutocompletetextviewLayoutBinding registerPhoneNumberOperatorLayout) {
        this.rootView = rootView;
        this.acceptTermsCheckbox = acceptTermsCheckbox;
        this.createAccountTitleTextView = createAccountTitleTextView;
        this.haveCnicRadioGroup = haveCnicRadioGroup;
        this.issueDobDateLayout = issueDobDateLayout;
        this.issueDobDateRadioGroup = issueDobDateRadioGroup;
        this.loginLayout = loginLayout;
        this.loginPakIdLogoImageView = loginPakIdLogoImageView;
        this.nonPakistaniRadioButton = nonPakistaniRadioButton;
        this.pakistaniOrNonRadioGroup = pakistaniOrNonRadioGroup;
        this.pakistaniRadioButton = pakistaniRadioButton;
        this.phoneNumberTextInputEditText = phoneNumberTextInputEditText;
        this.registerCnicHeadingTextView = registerCnicHeadingTextView;
        this.registerCnicLayout = registerCnicLayout;
        this.registerConfirmPasswordLayout = registerConfirmPasswordLayout;
        this.registerContactNumberLayout = registerContactNumberLayout;
        this.registerCountryLayout = registerCountryLayout;
        this.registerEmailLayout = registerEmailLayout;
        this.registerFirstNameLayout = registerFirstNameLayout;
        this.registerLastNameLayout = registerLastNameLayout;
        this.registerLoginButtonLayout = registerLoginButtonLayout;
        this.registerMobileNumberGuideTextView = registerMobileNumberGuideTextView;
        this.registerNationalityHeadingTextView = registerNationalityHeadingTextView;
        this.registerNextButtonLayout = registerNextButtonLayout;
        this.registerNoCnicTextView = registerNoCnicTextView;
        this.registerPasswordLayout = registerPasswordLayout;
        this.registerPhoneNumberOperatorLayout = registerPhoneNumberOperatorLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static RegisterFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static RegisterFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.register_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static RegisterFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        View viewFindChildViewById4;
        int i = R.id.accept_terms_checkbox;
        View viewFindChildViewById5 = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById5 != null) {
            CheckboxLayoutBinding checkboxLayoutBindingBind = CheckboxLayoutBinding.bind(viewFindChildViewById5);
            i = R.id.create_account_title_textView;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.have_cnic_radio_group))) != null) {
                RadioGroupLayoutBinding radioGroupLayoutBindingBind = RadioGroupLayoutBinding.bind(viewFindChildViewById);
                i = R.id.issue_dob_date_layout;
                View viewFindChildViewById6 = ViewBindings.findChildViewById(rootView, i);
                if (viewFindChildViewById6 != null) {
                    EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById6);
                    i = R.id.issue_dob_date_radio_group;
                    View viewFindChildViewById7 = ViewBindings.findChildViewById(rootView, i);
                    if (viewFindChildViewById7 != null) {
                        RadioGroupLayoutBinding radioGroupLayoutBindingBind2 = RadioGroupLayoutBinding.bind(viewFindChildViewById7);
                        ConstraintLayout constraintLayout = (ConstraintLayout) rootView;
                        i = R.id.login_pak_id_logo_imageView;
                        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                        if (imageView != null) {
                            i = R.id.non_pakistani_radio_button;
                            MaterialRadioButton materialRadioButton = (MaterialRadioButton) ViewBindings.findChildViewById(rootView, i);
                            if (materialRadioButton != null) {
                                i = R.id.pakistani_or_non_radio_group;
                                RadioGroup radioGroup = (RadioGroup) ViewBindings.findChildViewById(rootView, i);
                                if (radioGroup != null) {
                                    i = R.id.pakistani_radio_button;
                                    MaterialRadioButton materialRadioButton2 = (MaterialRadioButton) ViewBindings.findChildViewById(rootView, i);
                                    if (materialRadioButton2 != null) {
                                        i = R.id.phone_number_textInputEditText;
                                        TextInputEditText textInputEditText = (TextInputEditText) ViewBindings.findChildViewById(rootView, i);
                                        if (textInputEditText != null) {
                                            i = R.id.register_cnic_heading_textView;
                                            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                            if (textView2 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, (i = R.id.register_cnic_layout))) != null) {
                                                MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById2);
                                                i = R.id.register_confirm_password_layout;
                                                View viewFindChildViewById8 = ViewBindings.findChildViewById(rootView, i);
                                                if (viewFindChildViewById8 != null) {
                                                    EdittextLayoutBinding edittextLayoutBindingBind2 = EdittextLayoutBinding.bind(viewFindChildViewById8);
                                                    i = R.id.register_contact_number_layout;
                                                    TextInputLayout textInputLayout = (TextInputLayout) ViewBindings.findChildViewById(rootView, i);
                                                    if (textInputLayout != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(rootView, (i = R.id.register_country_layout))) != null) {
                                                        AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById3);
                                                        i = R.id.register_email_layout;
                                                        View viewFindChildViewById9 = ViewBindings.findChildViewById(rootView, i);
                                                        if (viewFindChildViewById9 != null) {
                                                            EdittextLayoutBinding edittextLayoutBindingBind3 = EdittextLayoutBinding.bind(viewFindChildViewById9);
                                                            i = R.id.register_first_name_layout;
                                                            View viewFindChildViewById10 = ViewBindings.findChildViewById(rootView, i);
                                                            if (viewFindChildViewById10 != null) {
                                                                EdittextLayoutBinding edittextLayoutBindingBind4 = EdittextLayoutBinding.bind(viewFindChildViewById10);
                                                                i = R.id.register_last_name_layout;
                                                                View viewFindChildViewById11 = ViewBindings.findChildViewById(rootView, i);
                                                                if (viewFindChildViewById11 != null) {
                                                                    EdittextLayoutBinding edittextLayoutBindingBind5 = EdittextLayoutBinding.bind(viewFindChildViewById11);
                                                                    i = R.id.register_login_button_layout;
                                                                    ConfigurableButton configurableButton = (ConfigurableButton) ViewBindings.findChildViewById(rootView, i);
                                                                    if (configurableButton != null) {
                                                                        i = R.id.register_mobile_number_guide_textView;
                                                                        TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                        if (textView3 != null) {
                                                                            i = R.id.register_nationality_heading_textView;
                                                                            TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                            if (textView4 != null) {
                                                                                i = R.id.register_next_button_layout;
                                                                                ConfigurableButton configurableButton2 = (ConfigurableButton) ViewBindings.findChildViewById(rootView, i);
                                                                                if (configurableButton2 != null) {
                                                                                    i = R.id.register_no_cnic_textView;
                                                                                    TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                    if (textView5 != null && (viewFindChildViewById4 = ViewBindings.findChildViewById(rootView, (i = R.id.register_password_layout))) != null) {
                                                                                        EdittextLayoutBinding edittextLayoutBindingBind6 = EdittextLayoutBinding.bind(viewFindChildViewById4);
                                                                                        i = R.id.register_phone_number_operator_layout;
                                                                                        View viewFindChildViewById12 = ViewBindings.findChildViewById(rootView, i);
                                                                                        if (viewFindChildViewById12 != null) {
                                                                                            return new RegisterFragmentBinding(constraintLayout, checkboxLayoutBindingBind, textView, radioGroupLayoutBindingBind, edittextLayoutBindingBind, radioGroupLayoutBindingBind2, constraintLayout, imageView, materialRadioButton, radioGroup, materialRadioButton2, textInputEditText, textView2, maskedEdittextLayoutBindingBind, edittextLayoutBindingBind2, textInputLayout, autocompletetextviewLayoutBindingBind, edittextLayoutBindingBind3, edittextLayoutBindingBind4, edittextLayoutBindingBind5, configurableButton, textView3, textView4, configurableButton2, textView5, edittextLayoutBindingBind6, AutocompletetextviewLayoutBinding.bind(viewFindChildViewById12));
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}