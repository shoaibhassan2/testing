package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;

/* loaded from: classes5.dex */
public final class OneappPaymentFragmentBinding implements ViewBinding {
    public final CardView creditCardView;
    public final TextView creditDebitCardText;
    public final View dividerView;
    public final TextView downloadReceiptHeading;
    public final TextView downloadReceiptText;
    public final CardView downloadReceiptView;
    public final ImageView eShaulatIcon;
    public final ImageView easyPaisaIcon;
    public final ImageView forwardIcon;
    public final TextView homeHeaderWelcomeTextView;
    public final ImageView jazzCashIcon;
    public final ImageView masterCardIcon;
    public final WebView oneapPaymentWebview;
    public final ConstraintLayout oneappPaymentWebviewLayout;
    public final CardView otherPaymentOptionCardView;
    public final ConfigurableButton paymentButtonLayout;
    public final TextView paymentDetailText;
    public final ImageView paymentHeaderBackIconImageView;
    public final ConstraintLayout paymentHeaderLayout;
    public final ImageView paymentHeaderPakIdLogoImageView;
    public final TextView paymentHeaderUserTitleTextView;
    public final ImageView paymentNotReceived;
    public final ConstraintLayout paymentOptionsLayout;
    public final ImageView paymentReceived;
    public final TextView paymentSuccessHeading;
    public final ImageView paymentSuccessImage;
    public final ConstraintLayout paymentSuccessLayout;
    public final TextView paymentSuccessMsg;
    public final ImageView pdfIcon;
    public final ImageView proceedIcon;
    public final ConstraintLayout rootLayout;
    private final ConstraintLayout rootView;
    public final TextView text1;
    public final TextView text2;
    public final TextView tvPaymentOption;
    public final ImageView visaIcon;

    private OneappPaymentFragmentBinding(ConstraintLayout rootView, CardView creditCardView, TextView creditDebitCardText, View dividerView, TextView downloadReceiptHeading, TextView downloadReceiptText, CardView downloadReceiptView, ImageView eShaulatIcon, ImageView easyPaisaIcon, ImageView forwardIcon, TextView homeHeaderWelcomeTextView, ImageView jazzCashIcon, ImageView masterCardIcon, WebView oneapPaymentWebview, ConstraintLayout oneappPaymentWebviewLayout, CardView otherPaymentOptionCardView, ConfigurableButton paymentButtonLayout, TextView paymentDetailText, ImageView paymentHeaderBackIconImageView, ConstraintLayout paymentHeaderLayout, ImageView paymentHeaderPakIdLogoImageView, TextView paymentHeaderUserTitleTextView, ImageView paymentNotReceived, ConstraintLayout paymentOptionsLayout, ImageView paymentReceived, TextView paymentSuccessHeading, ImageView paymentSuccessImage, ConstraintLayout paymentSuccessLayout, TextView paymentSuccessMsg, ImageView pdfIcon, ImageView proceedIcon, ConstraintLayout rootLayout, TextView text1, TextView text2, TextView tvPaymentOption, ImageView visaIcon) {
        this.rootView = rootView;
        this.creditCardView = creditCardView;
        this.creditDebitCardText = creditDebitCardText;
        this.dividerView = dividerView;
        this.downloadReceiptHeading = downloadReceiptHeading;
        this.downloadReceiptText = downloadReceiptText;
        this.downloadReceiptView = downloadReceiptView;
        this.eShaulatIcon = eShaulatIcon;
        this.easyPaisaIcon = easyPaisaIcon;
        this.forwardIcon = forwardIcon;
        this.homeHeaderWelcomeTextView = homeHeaderWelcomeTextView;
        this.jazzCashIcon = jazzCashIcon;
        this.masterCardIcon = masterCardIcon;
        this.oneapPaymentWebview = oneapPaymentWebview;
        this.oneappPaymentWebviewLayout = oneappPaymentWebviewLayout;
        this.otherPaymentOptionCardView = otherPaymentOptionCardView;
        this.paymentButtonLayout = paymentButtonLayout;
        this.paymentDetailText = paymentDetailText;
        this.paymentHeaderBackIconImageView = paymentHeaderBackIconImageView;
        this.paymentHeaderLayout = paymentHeaderLayout;
        this.paymentHeaderPakIdLogoImageView = paymentHeaderPakIdLogoImageView;
        this.paymentHeaderUserTitleTextView = paymentHeaderUserTitleTextView;
        this.paymentNotReceived = paymentNotReceived;
        this.paymentOptionsLayout = paymentOptionsLayout;
        this.paymentReceived = paymentReceived;
        this.paymentSuccessHeading = paymentSuccessHeading;
        this.paymentSuccessImage = paymentSuccessImage;
        this.paymentSuccessLayout = paymentSuccessLayout;
        this.paymentSuccessMsg = paymentSuccessMsg;
        this.pdfIcon = pdfIcon;
        this.proceedIcon = proceedIcon;
        this.rootLayout = rootLayout;
        this.text1 = text1;
        this.text2 = text2;
        this.tvPaymentOption = tvPaymentOption;
        this.visaIcon = visaIcon;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static OneappPaymentFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static OneappPaymentFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.oneapp_payment_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static OneappPaymentFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        int i = R.id.credit_card_view;
        CardView cardView = (CardView) ViewBindings.findChildViewById(rootView, i);
        if (cardView != null) {
            i = R.id.credit_debit_card_text;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.divider_view))) != null) {
                i = R.id.download_receipt_heading;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView2 != null) {
                    i = R.id.download_receipt_text;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                    if (textView3 != null) {
                        i = R.id.download_receipt_view;
                        CardView cardView2 = (CardView) ViewBindings.findChildViewById(rootView, i);
                        if (cardView2 != null) {
                            i = R.id.e_shaulat_icon;
                            ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                            if (imageView != null) {
                                i = R.id.easy_paisa_icon;
                                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                if (imageView2 != null) {
                                    i = R.id.forward_icon;
                                    ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                    if (imageView3 != null) {
                                        i = R.id.home_header_welcome_textView;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                        if (textView4 != null) {
                                            i = R.id.jazz_cash_icon;
                                            ImageView imageView4 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                            if (imageView4 != null) {
                                                i = R.id.master_card_icon;
                                                ImageView imageView5 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                                if (imageView5 != null) {
                                                    i = R.id.oneap_payment_webview;
                                                    WebView webView = (WebView) ViewBindings.findChildViewById(rootView, i);
                                                    if (webView != null) {
                                                        i = R.id.oneapp_payment_webview_layout;
                                                        ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                                                        if (constraintLayout != null) {
                                                            i = R.id.other_payment_option_card_view;
                                                            CardView cardView3 = (CardView) ViewBindings.findChildViewById(rootView, i);
                                                            if (cardView3 != null) {
                                                                i = R.id.payment_button_layout;
                                                                ConfigurableButton configurableButton = (ConfigurableButton) ViewBindings.findChildViewById(rootView, i);
                                                                if (configurableButton != null) {
                                                                    i = R.id.payment_detail_text;
                                                                    TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                    if (textView5 != null) {
                                                                        i = R.id.payment_header_back_icon_imageView;
                                                                        ImageView imageView6 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                                                        if (imageView6 != null) {
                                                                            i = R.id.payment_header_layout;
                                                                            ConstraintLayout constraintLayout2 = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                                                                            if (constraintLayout2 != null) {
                                                                                i = R.id.payment_header_pak_id_logo_imageView;
                                                                                ImageView imageView7 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                                                                if (imageView7 != null) {
                                                                                    i = R.id.payment_header_user_title_textView;
                                                                                    TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                    if (textView6 != null) {
                                                                                        i = R.id.payment_not_received;
                                                                                        ImageView imageView8 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                                                                        if (imageView8 != null) {
                                                                                            i = R.id.payment_options_layout;
                                                                                            ConstraintLayout constraintLayout3 = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                                                                                            if (constraintLayout3 != null) {
                                                                                                i = R.id.payment_received;
                                                                                                ImageView imageView9 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                                                                                if (imageView9 != null) {
                                                                                                    i = R.id.payment_success_heading;
                                                                                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                    if (textView7 != null) {
                                                                                                        i = R.id.payment_success_image;
                                                                                                        ImageView imageView10 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                                                                                        if (imageView10 != null) {
                                                                                                            i = R.id.payment_success_layout;
                                                                                                            ConstraintLayout constraintLayout4 = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                                                                                                            if (constraintLayout4 != null) {
                                                                                                                i = R.id.payment_success_msg;
                                                                                                                TextView textView8 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                if (textView8 != null) {
                                                                                                                    i = R.id.pdf_icon;
                                                                                                                    ImageView imageView11 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                    if (imageView11 != null) {
                                                                                                                        i = R.id.proceed_icon;
                                                                                                                        ImageView imageView12 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                        if (imageView12 != null) {
                                                                                                                            ConstraintLayout constraintLayout5 = (ConstraintLayout) rootView;
                                                                                                                            i = R.id.text1;
                                                                                                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                            if (textView9 != null) {
                                                                                                                                i = R.id.text2;
                                                                                                                                TextView textView10 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                                if (textView10 != null) {
                                                                                                                                    i = R.id.tv_payment_option;
                                                                                                                                    TextView textView11 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                                    if (textView11 != null) {
                                                                                                                                        i = R.id.visa_icon;
                                                                                                                                        ImageView imageView13 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                                                                                                                                        if (imageView13 != null) {
                                                                                                                                            return new OneappPaymentFragmentBinding(constraintLayout5, cardView, textView, viewFindChildViewById, textView2, textView3, cardView2, imageView, imageView2, imageView3, textView4, imageView4, imageView5, webView, constraintLayout, cardView3, configurableButton, textView5, imageView6, constraintLayout2, imageView7, textView6, imageView8, constraintLayout3, imageView9, textView7, imageView10, constraintLayout4, textView8, imageView11, imageView12, constraintLayout5, textView9, textView10, textView11, imageView13);
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}