package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;

/* loaded from: classes5.dex */
public final class CustomConfirmationDialogBinding implements ViewBinding {
    public final ConfigurableButton customConfirmationCancelButtonLayout;
    public final ConfigurableButton customConfirmationConfirmButtonLayout;
    public final TextView customConfirmationDetailTextView;
    public final ImageView customConfirmationIconImageView;
    public final TextView customConfirmationTitleTextView;
    private final MaterialCardView rootView;
    public final MaterialCardView rvCardLayout;

    private CustomConfirmationDialogBinding(MaterialCardView rootView, ConfigurableButton customConfirmationCancelButtonLayout, ConfigurableButton customConfirmationConfirmButtonLayout, TextView customConfirmationDetailTextView, ImageView customConfirmationIconImageView, TextView customConfirmationTitleTextView, MaterialCardView rvCardLayout) {
        this.rootView = rootView;
        this.customConfirmationCancelButtonLayout = customConfirmationCancelButtonLayout;
        this.customConfirmationConfirmButtonLayout = customConfirmationConfirmButtonLayout;
        this.customConfirmationDetailTextView = customConfirmationDetailTextView;
        this.customConfirmationIconImageView = customConfirmationIconImageView;
        this.customConfirmationTitleTextView = customConfirmationTitleTextView;
        this.rvCardLayout = rvCardLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static CustomConfirmationDialogBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static CustomConfirmationDialogBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.custom_confirmation_dialog, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static CustomConfirmationDialogBinding bind(View rootView) {
        int i = R.id.custom_confirmation_cancel_button_layout;
        ConfigurableButton configurableButton = (ConfigurableButton) ViewBindings.findChildViewById(rootView, i);
        if (configurableButton != null) {
            i = R.id.custom_confirmation_confirm_button_layout;
            ConfigurableButton configurableButton2 = (ConfigurableButton) ViewBindings.findChildViewById(rootView, i);
            if (configurableButton2 != null) {
                i = R.id.custom_confirmation_detail_textView;
                TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView != null) {
                    i = R.id.custom_confirmation_icon_imageView;
                    ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                    if (imageView != null) {
                        i = R.id.custom_confirmation_title_textView;
                        TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                        if (textView2 != null) {
                            MaterialCardView materialCardView = (MaterialCardView) rootView;
                            return new CustomConfirmationDialogBinding(materialCardView, configurableButton, configurableButton2, textView, imageView, textView2, materialCardView);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}