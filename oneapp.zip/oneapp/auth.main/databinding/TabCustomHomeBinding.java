package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class TabCustomHomeBinding implements ViewBinding {
    public final LinearLayout customTabLayoutRoot;
    private final LinearLayout rootView;
    public final ImageView tabIcon;
    public final TextView tabTitle;
    public final TextView tabUrduTitle;

    private TabCustomHomeBinding(LinearLayout rootView, LinearLayout customTabLayoutRoot, ImageView tabIcon, TextView tabTitle, TextView tabUrduTitle) {
        this.rootView = rootView;
        this.customTabLayoutRoot = customTabLayoutRoot;
        this.tabIcon = tabIcon;
        this.tabTitle = tabTitle;
        this.tabUrduTitle = tabUrduTitle;
    }

    @Override // androidx.viewbinding.ViewBinding
    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static TabCustomHomeBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static TabCustomHomeBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.tab_custom_home, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static TabCustomHomeBinding bind(View rootView) {
        LinearLayout linearLayout = (LinearLayout) rootView;
        int i = R.id.tabIcon;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
        if (imageView != null) {
            i = R.id.tabTitle;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null) {
                i = R.id.tabUrduTitle;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView2 != null) {
                    return new TabCustomHomeBinding(linearLayout, linearLayout, imageView, textView, textView2);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}