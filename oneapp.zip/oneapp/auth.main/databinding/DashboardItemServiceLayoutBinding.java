package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class DashboardItemServiceLayoutBinding implements ViewBinding {
    public final ImageView dashboardItemServiceIconImageView;
    public final TextView dashboardItemServiceTitleTextView;
    public final TextView dashboardItemServiceUrduTitleTextView;
    private final ConstraintLayout rootView;

    private DashboardItemServiceLayoutBinding(ConstraintLayout rootView, ImageView dashboardItemServiceIconImageView, TextView dashboardItemServiceTitleTextView, TextView dashboardItemServiceUrduTitleTextView) {
        this.rootView = rootView;
        this.dashboardItemServiceIconImageView = dashboardItemServiceIconImageView;
        this.dashboardItemServiceTitleTextView = dashboardItemServiceTitleTextView;
        this.dashboardItemServiceUrduTitleTextView = dashboardItemServiceUrduTitleTextView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static DashboardItemServiceLayoutBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static DashboardItemServiceLayoutBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.dashboard_item_service_layout, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static DashboardItemServiceLayoutBinding bind(View rootView) {
        int i = R.id.dashboard_item_service_icon_imageView;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
        if (imageView != null) {
            i = R.id.dashboard_item_service_title_textView;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null) {
                i = R.id.dashboard_item_service_urdu_title_textView;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView2 != null) {
                    return new DashboardItemServiceLayoutBinding((ConstraintLayout) rootView, imageView, textView, textView2);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}