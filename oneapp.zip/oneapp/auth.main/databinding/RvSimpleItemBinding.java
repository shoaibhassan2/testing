package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class RvSimpleItemBinding implements ViewBinding {
    private final MaterialCardView rootView;
    public final MaterialCardView rvCardLayout;
    public final ImageView rvImage;
    public final TextView rvTitle;
    public final ConstraintLayout showMoreLayout;

    private RvSimpleItemBinding(MaterialCardView rootView, MaterialCardView rvCardLayout, ImageView rvImage, TextView rvTitle, ConstraintLayout showMoreLayout) {
        this.rootView = rootView;
        this.rvCardLayout = rvCardLayout;
        this.rvImage = rvImage;
        this.rvTitle = rvTitle;
        this.showMoreLayout = showMoreLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static RvSimpleItemBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static RvSimpleItemBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.rv_simple_item, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static RvSimpleItemBinding bind(View rootView) {
        MaterialCardView materialCardView = (MaterialCardView) rootView;
        int i = R.id.rv_image;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
        if (imageView != null) {
            i = R.id.rv_title;
            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
            if (textView != null) {
                i = R.id.show_more_layout;
                ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                if (constraintLayout != null) {
                    return new RvSimpleItemBinding(materialCardView, materialCardView, imageView, textView, constraintLayout);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}