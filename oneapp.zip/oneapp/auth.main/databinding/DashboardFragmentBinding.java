package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class DashboardFragmentBinding implements ViewBinding {
    public final RecyclerView dashboardRecyclerView;
    private final ConstraintLayout rootView;
    public final LinearLayout setPrimaryPhoneNumberLayout;
    public final TextView urduSetPrimaryNumberTextView;

    private DashboardFragmentBinding(ConstraintLayout rootView, RecyclerView dashboardRecyclerView, LinearLayout setPrimaryPhoneNumberLayout, TextView urduSetPrimaryNumberTextView) {
        this.rootView = rootView;
        this.dashboardRecyclerView = dashboardRecyclerView;
        this.setPrimaryPhoneNumberLayout = setPrimaryPhoneNumberLayout;
        this.urduSetPrimaryNumberTextView = urduSetPrimaryNumberTextView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static DashboardFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static DashboardFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.dashboard_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static DashboardFragmentBinding bind(View rootView) {
        int i = R.id.dashboard_recyclerView;
        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(rootView, i);
        if (recyclerView != null) {
            i = R.id.set_primary_phone_number_layout;
            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(rootView, i);
            if (linearLayout != null) {
                i = R.id.urdu_set_primary_number_textView;
                TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                if (textView != null) {
                    return new DashboardFragmentBinding((ConstraintLayout) rootView, recyclerView, linearLayout, textView);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}