package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.radiobutton.MaterialRadioButton;
import com.google.android.material.tabs.TabLayout;
import pk.gov.nadra.oneapp.auth.main.R;

/* loaded from: classes5.dex */
public final class FragmentIntroBinding implements ViewBinding {
    public final View border;
    public final ConstraintLayout contentContainerConstraintLayout;
    public final ScrollView contentContainerScrollView;
    public final ImageView idCardIntoImageView;
    public final ImageView imageView3;
    public final MaterialRadioButton introNonPakistaniRadioButton;
    public final RadioGroup introPakistaniOrNonRadioGroup;
    public final MaterialRadioButton introPakistaniRadioButton;
    public final TabLayout introTabLayout;
    public final TextView loginButton;
    public final ConstraintLayout main;
    public final TextView registerButton;
    private final ConstraintLayout rootView;
    public final TextView selectionLoginOptionTextView;
    public final TextView welcomePakidTextView;
    public final TextView welcomePakidUrduTextView;

    private FragmentIntroBinding(ConstraintLayout rootView, View border, ConstraintLayout contentContainerConstraintLayout, ScrollView contentContainerScrollView, ImageView idCardIntoImageView, ImageView imageView3, MaterialRadioButton introNonPakistaniRadioButton, RadioGroup introPakistaniOrNonRadioGroup, MaterialRadioButton introPakistaniRadioButton, TabLayout introTabLayout, TextView loginButton, ConstraintLayout main, TextView registerButton, TextView selectionLoginOptionTextView, TextView welcomePakidTextView, TextView welcomePakidUrduTextView) {
        this.rootView = rootView;
        this.border = border;
        this.contentContainerConstraintLayout = contentContainerConstraintLayout;
        this.contentContainerScrollView = contentContainerScrollView;
        this.idCardIntoImageView = idCardIntoImageView;
        this.imageView3 = imageView3;
        this.introNonPakistaniRadioButton = introNonPakistaniRadioButton;
        this.introPakistaniOrNonRadioGroup = introPakistaniOrNonRadioGroup;
        this.introPakistaniRadioButton = introPakistaniRadioButton;
        this.introTabLayout = introTabLayout;
        this.loginButton = loginButton;
        this.main = main;
        this.registerButton = registerButton;
        this.selectionLoginOptionTextView = selectionLoginOptionTextView;
        this.welcomePakidTextView = welcomePakidTextView;
        this.welcomePakidUrduTextView = welcomePakidUrduTextView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentIntroBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static FragmentIntroBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.fragment_intro, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentIntroBinding bind(View rootView) {
        int i = R.id.border;
        View viewFindChildViewById = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById != null) {
            i = R.id.content_container_constraintLayout;
            ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
            if (constraintLayout != null) {
                i = R.id.content_container_scrollView;
                ScrollView scrollView = (ScrollView) ViewBindings.findChildViewById(rootView, i);
                if (scrollView != null) {
                    i = R.id.id_card_into_imageView;
                    ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                    if (imageView != null) {
                        i = R.id.imageView3;
                        ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(rootView, i);
                        if (imageView2 != null) {
                            i = R.id.intro_non_pakistani_radio_button;
                            MaterialRadioButton materialRadioButton = (MaterialRadioButton) ViewBindings.findChildViewById(rootView, i);
                            if (materialRadioButton != null) {
                                i = R.id.intro_pakistani_or_non_radioGroup;
                                RadioGroup radioGroup = (RadioGroup) ViewBindings.findChildViewById(rootView, i);
                                if (radioGroup != null) {
                                    i = R.id.intro_pakistani_radio_button;
                                    MaterialRadioButton materialRadioButton2 = (MaterialRadioButton) ViewBindings.findChildViewById(rootView, i);
                                    if (materialRadioButton2 != null) {
                                        i = R.id.intro_tabLayout;
                                        TabLayout tabLayout = (TabLayout) ViewBindings.findChildViewById(rootView, i);
                                        if (tabLayout != null) {
                                            i = R.id.loginButton;
                                            TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                                            if (textView != null) {
                                                ConstraintLayout constraintLayout2 = (ConstraintLayout) rootView;
                                                i = R.id.registerButton;
                                                TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                if (textView2 != null) {
                                                    i = R.id.selection_login_option_textView;
                                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                    if (textView3 != null) {
                                                        i = R.id.welcome_pakid_textView;
                                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                        if (textView4 != null) {
                                                            i = R.id.welcome_pakid_urdu_textView;
                                                            TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                            if (textView5 != null) {
                                                                return new FragmentIntroBinding(constraintLayout2, viewFindChildViewById, constraintLayout, scrollView, imageView, imageView2, materialRadioButton, radioGroup, materialRadioButton2, tabLayout, textView, constraintLayout2, textView2, textView3, textView4, textView5);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}