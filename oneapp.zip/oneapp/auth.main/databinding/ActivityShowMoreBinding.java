package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.NewHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class ActivityShowMoreBinding implements ViewBinding {
    public final ConstraintLayout main;
    public final NewHeaderLayoutBackTitleBinding newAppHeaderLayout;
    private final ConstraintLayout rootView;
    public final RecyclerView rvShowMore;

    private ActivityShowMoreBinding(ConstraintLayout rootView, ConstraintLayout main, NewHeaderLayoutBackTitleBinding newAppHeaderLayout, RecyclerView rvShowMore) {
        this.rootView = rootView;
        this.main = main;
        this.newAppHeaderLayout = newAppHeaderLayout;
        this.rvShowMore = rvShowMore;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivityShowMoreBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static ActivityShowMoreBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.activity_show_more, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivityShowMoreBinding bind(View rootView) {
        ConstraintLayout constraintLayout = (ConstraintLayout) rootView;
        int i = R.id.new_app_header_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById != null) {
            NewHeaderLayoutBackTitleBinding newHeaderLayoutBackTitleBindingBind = NewHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
            int i2 = R.id.rv_show_more;
            RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(rootView, i2);
            if (recyclerView != null) {
                return new ActivityShowMoreBinding(constraintLayout, constraintLayout, newHeaderLayoutBackTitleBindingBind, recyclerView);
            }
            i = i2;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}