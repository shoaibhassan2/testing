package pk.gov.nadra.oneapp.auth.main.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class CancellationDeathFragmentBinding implements ViewBinding {
    public final ButtonLayoutBinding buttonLayout;
    public final ButtonLayoutBinding deathCertificateButtonLayout;
    public final ImageView deathCertificateSample;
    public final MaskedEdittextLayoutBinding deceasedCnicLayout;
    public final ConstraintLayout deceasedMainLayout;
    public final ConstraintLayout main;
    public final UpdatedHeaderLayoutBackTitleBinding newAppHeaderLayout;
    public final RadioButton rbNo;
    public final RadioButton rbYes;
    public final RadioGroup rgIdentity;
    private final ConstraintLayout rootView;
    public final TextView tvIdentityNoRecord;
    public final TextView tvIdentityNoRecordUrdu;
    public final TextView tvIdentityType;
    public final TextView tvIdentityTypeUrdu;
    public final TextView tvRegisterDeathCivil;
    public final TextView tvRegisterDeathCivilUrdu;

    private CancellationDeathFragmentBinding(ConstraintLayout rootView, ButtonLayoutBinding buttonLayout, ButtonLayoutBinding deathCertificateButtonLayout, ImageView deathCertificateSample, MaskedEdittextLayoutBinding deceasedCnicLayout, ConstraintLayout deceasedMainLayout, ConstraintLayout main, UpdatedHeaderLayoutBackTitleBinding newAppHeaderLayout, RadioButton rbNo, RadioButton rbYes, RadioGroup rgIdentity, TextView tvIdentityNoRecord, TextView tvIdentityNoRecordUrdu, TextView tvIdentityType, TextView tvIdentityTypeUrdu, TextView tvRegisterDeathCivil, TextView tvRegisterDeathCivilUrdu) {
        this.rootView = rootView;
        this.buttonLayout = buttonLayout;
        this.deathCertificateButtonLayout = deathCertificateButtonLayout;
        this.deathCertificateSample = deathCertificateSample;
        this.deceasedCnicLayout = deceasedCnicLayout;
        this.deceasedMainLayout = deceasedMainLayout;
        this.main = main;
        this.newAppHeaderLayout = newAppHeaderLayout;
        this.rbNo = rbNo;
        this.rbYes = rbYes;
        this.rgIdentity = rgIdentity;
        this.tvIdentityNoRecord = tvIdentityNoRecord;
        this.tvIdentityNoRecordUrdu = tvIdentityNoRecordUrdu;
        this.tvIdentityType = tvIdentityType;
        this.tvIdentityTypeUrdu = tvIdentityTypeUrdu;
        this.tvRegisterDeathCivil = tvRegisterDeathCivil;
        this.tvRegisterDeathCivilUrdu = tvRegisterDeathCivilUrdu;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static CancellationDeathFragmentBinding inflate(LayoutInflater inflater) {
        return inflate(inflater, null, false);
    }

    public static CancellationDeathFragmentBinding inflate(LayoutInflater inflater, ViewGroup parent, boolean attachToParent) {
        View viewInflate = inflater.inflate(R.layout.cancellation_death_fragment, parent, false);
        if (attachToParent) {
            parent.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static CancellationDeathFragmentBinding bind(View rootView) {
        View viewFindChildViewById;
        int i = R.id.button_layout;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(rootView, i);
        if (viewFindChildViewById2 != null) {
            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById2);
            i = R.id.death_certificate_button_layout;
            View viewFindChildViewById3 = ViewBindings.findChildViewById(rootView, i);
            if (viewFindChildViewById3 != null) {
                ButtonLayoutBinding buttonLayoutBindingBind2 = ButtonLayoutBinding.bind(viewFindChildViewById3);
                i = R.id.death_certificate_sample;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(rootView, i);
                if (imageView != null && (viewFindChildViewById = ViewBindings.findChildViewById(rootView, (i = R.id.deceased_cnic_layout))) != null) {
                    MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById);
                    i = R.id.deceased_main_layout;
                    ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(rootView, i);
                    if (constraintLayout != null) {
                        ConstraintLayout constraintLayout2 = (ConstraintLayout) rootView;
                        i = R.id.new_app_header_layout;
                        View viewFindChildViewById4 = ViewBindings.findChildViewById(rootView, i);
                        if (viewFindChildViewById4 != null) {
                            UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById4);
                            i = R.id.rb_no;
                            RadioButton radioButton = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                            if (radioButton != null) {
                                i = R.id.rb_yes;
                                RadioButton radioButton2 = (RadioButton) ViewBindings.findChildViewById(rootView, i);
                                if (radioButton2 != null) {
                                    i = R.id.rg_identity;
                                    RadioGroup radioGroup = (RadioGroup) ViewBindings.findChildViewById(rootView, i);
                                    if (radioGroup != null) {
                                        i = R.id.tv_identity_no_record;
                                        TextView textView = (TextView) ViewBindings.findChildViewById(rootView, i);
                                        if (textView != null) {
                                            i = R.id.tv_identity_no_record_urdu;
                                            TextView textView2 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                            if (textView2 != null) {
                                                i = R.id.tv_identity_type;
                                                TextView textView3 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                if (textView3 != null) {
                                                    i = R.id.tv_identity_type_urdu;
                                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                    if (textView4 != null) {
                                                        i = R.id.tv_register_death_civil;
                                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                        if (textView5 != null) {
                                                            i = R.id.tv_register_death_civil_urdu;
                                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(rootView, i);
                                                            if (textView6 != null) {
                                                                return new CancellationDeathFragmentBinding(constraintLayout2, buttonLayoutBindingBind, buttonLayoutBindingBind2, imageView, maskedEdittextLayoutBindingBind, constraintLayout, constraintLayout2, updatedHeaderLayoutBackTitleBindingBind, radioButton, radioButton2, radioGroup, textView, textView2, textView3, textView4, textView5, textView6);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(rootView.getResources().getResourceName(i)));
    }
}