package pk.gov.nadra.oneapp.auth.main;

import android.app.Application;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ApplicationContextHelper.kt */
@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0005J\u0006\u0010\t\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/ApplicationContextHelper;", "", "<init>", "()V", "application", "Landroid/app/Application;", "init", "", "context", "getApplicationContext", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ApplicationContextHelper {
    public static final ApplicationContextHelper INSTANCE = new ApplicationContextHelper();
    private static Application application;

    private ApplicationContextHelper() {
    }

    public final void init(Application context) {
        Intrinsics.checkNotNullParameter(context, "context");
        application = context;
    }

    public final Application getApplicationContext() {
        Application application2 = application;
        if (application2 != null) {
            return application2;
        }
        Intrinsics.throwUninitializedPropertyAccessException("application");
        return null;
    }
}