package pk.gov.nadra.oneapp.auth.main.adapters;

import androidx.recyclerview.widget.GridLayoutManager;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import pk.gov.nadra.oneapp.models.dashboard.DashboardItem;

/* compiled from: DashboardItemsAdapter.kt */
@Metadata(d1 = {"\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003H\u0016¨\u0006\u0005"}, d2 = {"pk/gov/nadra/oneapp/auth/main/adapters/DashboardItemsAdapter$filter$1$1", "Landroidx/recyclerview/widget/GridLayoutManager$SpanSizeLookup;", "getSpanSize", "", "position", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DashboardItemsAdapter$filter$1$1 extends GridLayoutManager.SpanSizeLookup {
    DashboardItemsAdapter$filter$1$1() {
    }

    @Override // androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup
    public int getSpanSize(int position) {
        DashboardItem dashboardItem = (DashboardItem) this.this$0.originalItems.get(position);
        if ((dashboardItem instanceof DashboardItem.DigitalCard) || (dashboardItem instanceof DashboardItem.SectionHeader)) {
            return 4;
        }
        if (dashboardItem instanceof DashboardItem.ServiceItem) {
            return 1;
        }
        throw new NoWhenBranchMatchedException();
    }
}