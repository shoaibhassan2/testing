package pk.gov.nadra.oneapp.auth.main.adapters;

import android.view.View;
import pk.gov.nadra.oneapp.auth.main.adapters.OptionsCardAdapter;
import pk.gov.nadra.oneapp.models.dashboard.AppOptionsTokenResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class OptionsCardAdapter$DetailedViewHolder$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ AppOptionsTokenResponse.AllowedOption f$1;

    public /* synthetic */ OptionsCardAdapter$DetailedViewHolder$$ExternalSyntheticLambda0(AppOptionsTokenResponse.AllowedOption allowedOption) {
        item = allowedOption;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        OptionsCardAdapter.DetailedViewHolder.bind$lambda$1$lambda$0(onActionSelected, item, view);
    }
}