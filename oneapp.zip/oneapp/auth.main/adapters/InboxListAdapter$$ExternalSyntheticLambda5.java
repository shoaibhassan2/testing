package pk.gov.nadra.oneapp.auth.main.adapters;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class InboxListAdapter$$ExternalSyntheticLambda5 implements View.OnClickListener {
    public final /* synthetic */ int f$1;

    public /* synthetic */ InboxListAdapter$$ExternalSyntheticLambda5(int i) {
        i = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        InboxListAdapter.onBindViewHolder$lambda$8$lambda$7$lambda$6$lambda$5(this.f$0, i, view);
    }
}