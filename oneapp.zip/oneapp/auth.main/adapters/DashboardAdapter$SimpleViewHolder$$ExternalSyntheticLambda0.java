package pk.gov.nadra.oneapp.auth.main.adapters;

import android.view.View;
import pk.gov.nadra.oneapp.auth.main.adapters.DashboardAdapter;
import pk.gov.nadra.oneapp.models.dashboard.DashboardModel;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardAdapter$SimpleViewHolder$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ DashboardModel f$1;

    public /* synthetic */ DashboardAdapter$SimpleViewHolder$$ExternalSyntheticLambda0(DashboardModel dashboardModel) {
        item = dashboardModel;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        DashboardAdapter.SimpleViewHolder.bind$lambda$1$lambda$0(onActionSelected, item, view);
    }
}