package pk.gov.nadra.oneapp.auth.main.adapters;

import android.view.View;
import pk.gov.nadra.oneapp.auth.main.adapters.DashboardItemsAdapter;
import pk.gov.nadra.oneapp.models.dashboard.DashboardItem;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardItemsAdapter$ServiceViewHolder$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ DashboardItem.ServiceItem f$1;

    public /* synthetic */ DashboardItemsAdapter$ServiceViewHolder$$ExternalSyntheticLambda0(DashboardItem.ServiceItem serviceItem) {
        item = serviceItem;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        DashboardItemsAdapter.ServiceViewHolder.bind$lambda$0(onClick, item, view);
    }
}