package pk.gov.nadra.oneapp.auth.main.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.actions.SearchIntents;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import pk.gov.nadra.oneapp.auth.main.adapters.DashboardItemsAdapter;
import pk.gov.nadra.oneapp.auth.main.databinding.DashboardItemDigitalCardLayoutBinding;
import pk.gov.nadra.oneapp.auth.main.databinding.DashboardItemHeaderLayoutBinding;
import pk.gov.nadra.oneapp.auth.main.databinding.DashboardItemServiceLayoutBinding;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.models.dashboard.DashboardItem;

/* compiled from: DashboardItemsAdapter.kt */
@Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 \"2\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0004\"#$%B=\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007\u0012\u0012\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\t0\u0007¢\u0006\u0004\b\f\u0010\rJ\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0013H\u0016J\u0018\u0010\u0015\u001a\u00020\u00022\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0013H\u0016J\u0018\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u00022\u0006\u0010\u0014\u001a\u00020\u0013H\u0016J\b\u0010\u001b\u001a\u00020\u0013H\u0016J\u0014\u0010\u001c\u001a\u00020\t2\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004J\u0016\u0010\u001d\u001a\u00020\t2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\t0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00050\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u000b0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00050\u000fX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006&"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardItemsAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", FirebaseAnalytics.Param.ITEMS, "", "Lpk/gov/nadra/oneapp/models/dashboard/DashboardItem;", "onDigitalCardClick", "Lkotlin/Function1;", "Lpk/gov/nadra/oneapp/models/dashboard/DashboardItem$DigitalCard;", "", "onClick", "Lpk/gov/nadra/oneapp/models/dashboard/DashboardItem$ServiceItem;", "<init>", "(Ljava/util/List;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V", "originalItems", "", "allServices", "filteredItems", "getItemViewType", "", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onBindViewHolder", "holder", "getItemCount", "setData", "filter", SearchIntents.EXTRA_QUERY, "", "recyclerView", "Landroidx/recyclerview/widget/RecyclerView;", "Companion", "DigitalCardViewHolder", "SectionHeaderViewHolder", "ServiceViewHolder", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DashboardItemsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_DIGITAL_CARD = 0;
    private static final int TYPE_HEADER = 1;
    private static final int TYPE_SERVICE = 2;
    private final List<DashboardItem.ServiceItem> allServices;
    private final List<DashboardItem> filteredItems;
    private final List<DashboardItem> items;
    private final Function1<DashboardItem.ServiceItem, Unit> onClick;
    private final Function1<DashboardItem.DigitalCard, Unit> onDigitalCardClick;
    private final List<DashboardItem> originalItems;

    /* JADX WARN: Multi-variable type inference failed */
    public DashboardItemsAdapter(List<? extends DashboardItem> items, Function1<? super DashboardItem.DigitalCard, Unit> onDigitalCardClick, Function1<? super DashboardItem.ServiceItem, Unit> onClick) {
        Intrinsics.checkNotNullParameter(items, "items");
        Intrinsics.checkNotNullParameter(onDigitalCardClick, "onDigitalCardClick");
        Intrinsics.checkNotNullParameter(onClick, "onClick");
        this.items = items;
        this.onDigitalCardClick = onDigitalCardClick;
        this.onClick = onClick;
        this.originalItems = new ArrayList();
        this.allServices = new ArrayList();
        this.filteredItems = new ArrayList();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int position) {
        DashboardItem dashboardItem = this.filteredItems.get(position);
        if (dashboardItem instanceof DashboardItem.DigitalCard) {
            return 0;
        }
        if (dashboardItem instanceof DashboardItem.SectionHeader) {
            return 1;
        }
        if (dashboardItem instanceof DashboardItem.ServiceItem) {
            return 2;
        }
        throw new NoWhenBranchMatchedException();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        if (viewType == 0) {
            DashboardItemDigitalCardLayoutBinding dashboardItemDigitalCardLayoutBindingInflate = DashboardItemDigitalCardLayoutBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            Intrinsics.checkNotNullExpressionValue(dashboardItemDigitalCardLayoutBindingInflate, "inflate(...)");
            return new DigitalCardViewHolder(dashboardItemDigitalCardLayoutBindingInflate);
        }
        if (viewType == 1) {
            DashboardItemHeaderLayoutBinding dashboardItemHeaderLayoutBindingInflate = DashboardItemHeaderLayoutBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            Intrinsics.checkNotNullExpressionValue(dashboardItemHeaderLayoutBindingInflate, "inflate(...)");
            return new SectionHeaderViewHolder(dashboardItemHeaderLayoutBindingInflate);
        }
        DashboardItemServiceLayoutBinding dashboardItemServiceLayoutBindingInflate = DashboardItemServiceLayoutBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(dashboardItemServiceLayoutBindingInflate, "inflate(...)");
        return new ServiceViewHolder(dashboardItemServiceLayoutBindingInflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        DashboardItem dashboardItem = this.filteredItems.get(position);
        if (dashboardItem instanceof DashboardItem.DigitalCard) {
            ((DigitalCardViewHolder) holder).bind((DashboardItem.DigitalCard) dashboardItem, this.onDigitalCardClick);
        } else if (dashboardItem instanceof DashboardItem.SectionHeader) {
            ((SectionHeaderViewHolder) holder).bind((DashboardItem.SectionHeader) dashboardItem);
        } else {
            if (!(dashboardItem instanceof DashboardItem.ServiceItem)) {
                throw new NoWhenBranchMatchedException();
            }
            ((ServiceViewHolder) holder).bind((DashboardItem.ServiceItem) dashboardItem, this.onClick);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.filteredItems.size();
    }

    /* compiled from: DashboardItemsAdapter.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\"\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0012\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00070\u000bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardItemsAdapter$DigitalCardViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/DashboardItemDigitalCardLayoutBinding;", "<init>", "(Lpk/gov/nadra/oneapp/auth/main/databinding/DashboardItemDigitalCardLayoutBinding;)V", "bind", "", "item", "Lpk/gov/nadra/oneapp/models/dashboard/DashboardItem$DigitalCard;", "onDigitalCardClick", "Lkotlin/Function1;", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class DigitalCardViewHolder extends RecyclerView.ViewHolder {
        private final DashboardItemDigitalCardLayoutBinding binding;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public DigitalCardViewHolder(DashboardItemDigitalCardLayoutBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.binding = binding;
        }

        public final void bind(final DashboardItem.DigitalCard item, final Function1<? super DashboardItem.DigitalCard, Unit> onDigitalCardClick) {
            Intrinsics.checkNotNullParameter(item, "item");
            Intrinsics.checkNotNullParameter(onDigitalCardClick, "onDigitalCardClick");
            if (item.getGenerateOrViewDigitalCard()) {
                this.binding.viewDigitalCardImageView.setVisibility(0);
            } else {
                this.binding.generateDigitalCardImageView.setVisibility(0);
            }
            this.binding.getRoot().setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.adapters.DashboardItemsAdapter$DigitalCardViewHolder$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    DashboardItemsAdapter.DigitalCardViewHolder.bind$lambda$0(onDigitalCardClick, item, view);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void bind$lambda$0(Function1 onDigitalCardClick, DashboardItem.DigitalCard item, View view) {
            Intrinsics.checkNotNullParameter(onDigitalCardClick, "$onDigitalCardClick");
            Intrinsics.checkNotNullParameter(item, "$item");
            onDigitalCardClick.invoke(item);
        }
    }

    public final void setData(List<? extends DashboardItem> items) {
        Intrinsics.checkNotNullParameter(items, "items");
        this.originalItems.clear();
        this.originalItems.addAll(items);
        this.allServices.clear();
        List listListOf = CollectionsKt.listOf("");
        ArrayList arrayList = new ArrayList();
        for (Object obj : items) {
            if (obj instanceof DashboardItem.ServiceItem) {
                arrayList.add(obj);
            }
        }
        ArrayList arrayList2 = new ArrayList();
        for (Object obj2 : arrayList) {
            if (!listListOf.contains(((DashboardItem.ServiceItem) obj2).getTitle())) {
                arrayList2.add(obj2);
            }
        }
        this.allServices.addAll(arrayList2);
        this.filteredItems.clear();
        this.filteredItems.addAll(this.originalItems);
        notifyDataSetChanged();
    }

    public final void filter(String query, RecyclerView recyclerView) {
        Intrinsics.checkNotNullParameter(query, "query");
        Intrinsics.checkNotNullParameter(recyclerView, "recyclerView");
        String lowerCase = StringsKt.trim((CharSequence) query).toString().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        this.filteredItems.clear();
        String str = lowerCase;
        if (str.length() == 0) {
            this.filteredItems.addAll(this.originalItems);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(recyclerView.getContext(), 4);
            gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() { // from class: pk.gov.nadra.oneapp.auth.main.adapters.DashboardItemsAdapter$filter$1$1
                @Override // androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup
                public int getSpanSize(int position) {
                    DashboardItem dashboardItem = (DashboardItem) this.this$0.originalItems.get(position);
                    if ((dashboardItem instanceof DashboardItem.DigitalCard) || (dashboardItem instanceof DashboardItem.SectionHeader)) {
                        return 4;
                    }
                    if (dashboardItem instanceof DashboardItem.ServiceItem) {
                        return 1;
                    }
                    throw new NoWhenBranchMatchedException();
                }
            });
            recyclerView.setLayoutManager(gridLayoutManager);
        } else {
            List<DashboardItem.ServiceItem> list = this.allServices;
            ArrayList arrayList = new ArrayList();
            for (Object obj : list) {
                DashboardItem.ServiceItem serviceItem = (DashboardItem.ServiceItem) obj;
                String lowerCase2 = serviceItem.getTitle().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                if (!StringsKt.contains$default((CharSequence) lowerCase2, (CharSequence) str, false, 2, (Object) null)) {
                    String urduTitle = serviceItem.getUrduTitle();
                    if (urduTitle != null) {
                        String lowerCase3 = urduTitle.toLowerCase(Locale.ROOT);
                        Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
                        if (lowerCase3 == null || !StringsKt.contains$default((CharSequence) lowerCase3, (CharSequence) str, false, 2, (Object) null)) {
                        }
                    }
                }
                arrayList.add(obj);
            }
            this.filteredItems.addAll(arrayList);
            recyclerView.setLayoutManager(new GridLayoutManager(recyclerView.getContext(), 4));
        }
        notifyDataSetChanged();
    }

    /* compiled from: DashboardItemsAdapter.kt */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardItemsAdapter$SectionHeaderViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/DashboardItemHeaderLayoutBinding;", "<init>", "(Lpk/gov/nadra/oneapp/auth/main/databinding/DashboardItemHeaderLayoutBinding;)V", "bind", "", "item", "Lpk/gov/nadra/oneapp/models/dashboard/DashboardItem$SectionHeader;", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class SectionHeaderViewHolder extends RecyclerView.ViewHolder {
        private final DashboardItemHeaderLayoutBinding binding;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public SectionHeaderViewHolder(DashboardItemHeaderLayoutBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.binding = binding;
        }

        public final void bind(DashboardItem.SectionHeader item) {
            Intrinsics.checkNotNullParameter(item, "item");
            this.binding.dashboardItemServicesHeaderTextView.setText(item.getTitle());
            String urduTitle = item.getUrduTitle();
            if (item.getTitle().length() > 21) {
                urduTitle = "\n\n\n" + item.getUrduTitle();
            }
            this.binding.dashboardItemServicesUrduHeaderTextView.setText(urduTitle);
            this.binding.dashboardItemServicesUrduHeaderTextView.setTypeface(ResourcesCompat.getFont(this.itemView.getContext(), R.font.nadra_nastaleeq));
        }
    }

    /* compiled from: DashboardItemsAdapter.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\"\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0012\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00070\u000bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardItemsAdapter$ServiceViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/DashboardItemServiceLayoutBinding;", "<init>", "(Lpk/gov/nadra/oneapp/auth/main/databinding/DashboardItemServiceLayoutBinding;)V", "bind", "", "item", "Lpk/gov/nadra/oneapp/models/dashboard/DashboardItem$ServiceItem;", "onClick", "Lkotlin/Function1;", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class ServiceViewHolder extends RecyclerView.ViewHolder {
        private final DashboardItemServiceLayoutBinding binding;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ServiceViewHolder(DashboardItemServiceLayoutBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.binding = binding;
        }

        public final void bind(final DashboardItem.ServiceItem item, final Function1<? super DashboardItem.ServiceItem, Unit> onClick) {
            Intrinsics.checkNotNullParameter(item, "item");
            Intrinsics.checkNotNullParameter(onClick, "onClick");
            this.binding.dashboardItemServiceTitleTextView.setText(item.getTitle());
            this.binding.dashboardItemServiceUrduTitleTextView.setText(item.getUrduTitle());
            this.binding.dashboardItemServiceIconImageView.setImageResource(item.getIconRes());
            this.binding.dashboardItemServiceUrduTitleTextView.setTypeface(ResourcesCompat.getFont(this.itemView.getContext(), R.font.nadra_nastaleeq));
            this.binding.getRoot().setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.adapters.DashboardItemsAdapter$ServiceViewHolder$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    DashboardItemsAdapter.ServiceViewHolder.bind$lambda$0(onClick, item, view);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void bind$lambda$0(Function1 onClick, DashboardItem.ServiceItem item, View view) {
            Intrinsics.checkNotNullParameter(onClick, "$onClick");
            Intrinsics.checkNotNullParameter(item, "$item");
            onClick.invoke(item);
        }
    }
}