package pk.gov.nadra.oneapp.auth.main.adapters;

import android.view.View;
import pk.gov.nadra.oneapp.models.primaryNumber.MobileData;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class PhoneNumberListAdapter$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ int f$1;
    public final /* synthetic */ MobileData f$2;

    public /* synthetic */ PhoneNumberListAdapter$$ExternalSyntheticLambda0(int i, MobileData mobileData) {
        position = i;
        mobileData = mobileData;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        PhoneNumberListAdapter.onBindViewHolder$lambda$1(this.f$0, position, mobileData, view);
    }
}