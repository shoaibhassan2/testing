package pk.gov.nadra.oneapp.auth.main.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.auth.main.R;
import pk.gov.nadra.oneapp.auth.main.databinding.RvPhoneNumberItemBinding;
import pk.gov.nadra.oneapp.models.primaryNumber.MobileData;

/* compiled from: PhoneNumberListAdapter.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0019B)\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\u0004\b\t\u0010\nJ\u0018\u0010\u0011\u001a\u00020\u00022\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\fH\u0016J\u0018\u0010\u0015\u001a\u00020\b2\u0006\u0010\u0016\u001a\u00020\u00022\u0006\u0010\u0017\u001a\u00020\fH\u0016J\b\u0010\u0018\u001a\u00020\fH\u0016R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000b\u001a\u00020\fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010¨\u0006\u001a"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/PhoneNumberListAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lpk/gov/nadra/oneapp/auth/main/adapters/PhoneNumberListAdapter$DetailedViewHolder;", "mList", "", "Lpk/gov/nadra/oneapp/models/primaryNumber/MobileData;", "onActionSelected", "Lkotlin/Function1;", "", "<init>", "(Ljava/util/List;Lkotlin/jvm/functions/Function1;)V", "selectedPosition", "", "getSelectedPosition", "()I", "setSelectedPosition", "(I)V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onBindViewHolder", "holder", "position", "getItemCount", "DetailedViewHolder", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class PhoneNumberListAdapter extends RecyclerView.Adapter<DetailedViewHolder> {
    private List<MobileData> mList;
    private final Function1<MobileData, Unit> onActionSelected;
    private int selectedPosition;

    /* JADX WARN: Multi-variable type inference failed */
    public PhoneNumberListAdapter(List<MobileData> mList, Function1<? super MobileData, Unit> onActionSelected) {
        Intrinsics.checkNotNullParameter(mList, "mList");
        Intrinsics.checkNotNullParameter(onActionSelected, "onActionSelected");
        this.mList = mList;
        this.onActionSelected = onActionSelected;
        this.selectedPosition = -1;
    }

    public final int getSelectedPosition() {
        return this.selectedPosition;
    }

    public final void setSelectedPosition(int i) {
        this.selectedPosition = i;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public DetailedViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        RvPhoneNumberItemBinding rvPhoneNumberItemBindingInflate = RvPhoneNumberItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(rvPhoneNumberItemBindingInflate, "inflate(...)");
        return new DetailedViewHolder(rvPhoneNumberItemBindingInflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(DetailedViewHolder holder, final int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        final MobileData mobileData = this.mList.get(position);
        RvPhoneNumberItemBinding binding = holder.getBinding();
        binding.tvPhoneNumber.setText(mobileData.getMobileNumber());
        if (this.selectedPosition == position) {
            binding.ivPhoneNumberSelector.setImageResource(R.drawable.ic_selected_primary_number);
        } else {
            binding.ivPhoneNumberSelector.setImageResource(R.drawable.ic_unselect_primary_number);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.adapters.PhoneNumberListAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                PhoneNumberListAdapter.onBindViewHolder$lambda$1(this.f$0, position, mobileData, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$1(PhoneNumberListAdapter this$0, int i, MobileData item, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(item, "$item");
        this$0.selectedPosition = i;
        this$0.notifyDataSetChanged();
        this$0.onActionSelected.invoke(item);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.mList.size();
    }

    /* compiled from: PhoneNumberListAdapter.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/PhoneNumberListAdapter$DetailedViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/RvPhoneNumberItemBinding;", "<init>", "(Lpk/gov/nadra/oneapp/auth/main/databinding/RvPhoneNumberItemBinding;)V", "getBinding", "()Lpk/gov/nadra/oneapp/auth/main/databinding/RvPhoneNumberItemBinding;", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class DetailedViewHolder extends RecyclerView.ViewHolder {
        private final RvPhoneNumberItemBinding binding;

        public final RvPhoneNumberItemBinding getBinding() {
            return this.binding;
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public DetailedViewHolder(RvPhoneNumberItemBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.binding = binding;
        }
    }
}