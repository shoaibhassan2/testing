package pk.gov.nadra.oneapp.auth.main.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.auth.main.adapters.OptionsCardAdapter;
import pk.gov.nadra.oneapp.auth.main.databinding.RvOptionsCardItemBinding;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.models.dashboard.AppOptionsTokenResponse;

/* compiled from: OptionsCardAdapter.kt */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u001a\u001bB1\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u0012\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0004\b\u000b\u0010\fJ\u0018\u0010\u0011\u001a\u00020\u00022\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0016J\u0018\u0010\u0016\u001a\u00020\n2\u0006\u0010\u0017\u001a\u00020\u00022\u0006\u0010\u0018\u001a\u00020\u0015H\u0016J\b\u0010\u0019\u001a\u00020\u0015H\u0016R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001c"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/OptionsCardAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lpk/gov/nadra/oneapp/auth/main/adapters/OptionsCardAdapter$BaseViewHolder;", "context", "Landroid/content/Context;", "showMoreList", "", "Lpk/gov/nadra/oneapp/models/dashboard/AppOptionsTokenResponse$AllowedOption;", "onActionSelected", "Lkotlin/Function1;", "", "<init>", "(Landroid/content/Context;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V", "getContext", "()Landroid/content/Context;", "setContext", "(Landroid/content/Context;)V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "onBindViewHolder", "holder", "position", "getItemCount", "BaseViewHolder", "DetailedViewHolder", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class OptionsCardAdapter extends RecyclerView.Adapter<BaseViewHolder> {
    private Context context;
    private final Function1<AppOptionsTokenResponse.AllowedOption, Unit> onActionSelected;
    private List<AppOptionsTokenResponse.AllowedOption> showMoreList;

    public final Context getContext() {
        return this.context;
    }

    public final void setContext(Context context) {
        Intrinsics.checkNotNullParameter(context, "<set-?>");
        this.context = context;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public OptionsCardAdapter(Context context, List<AppOptionsTokenResponse.AllowedOption> showMoreList, Function1<? super AppOptionsTokenResponse.AllowedOption, Unit> onActionSelected) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(showMoreList, "showMoreList");
        Intrinsics.checkNotNullParameter(onActionSelected, "onActionSelected");
        this.context = context;
        this.showMoreList = showMoreList;
        this.onActionSelected = onActionSelected;
    }

    /* compiled from: OptionsCardAdapter.kt */
    @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b&\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J,\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0012\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00070\rH&¨\u0006\u000e"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/OptionsCardAdapter$BaseViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "bindingRoot", "Landroid/view/View;", "<init>", "(Landroid/view/View;)V", "bind", "", "item", "Lpk/gov/nadra/oneapp/models/dashboard/AppOptionsTokenResponse$AllowedOption;", "context", "Landroid/content/Context;", "onActionSelected", "Lkotlin/Function1;", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static abstract class BaseViewHolder extends RecyclerView.ViewHolder {
        public abstract void bind(AppOptionsTokenResponse.AllowedOption item, Context context, Function1<? super AppOptionsTokenResponse.AllowedOption, Unit> onActionSelected);

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public BaseViewHolder(View bindingRoot) {
            super(bindingRoot);
            Intrinsics.checkNotNullParameter(bindingRoot, "bindingRoot");
        }
    }

    /* compiled from: OptionsCardAdapter.kt */
    @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J,\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0012\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00070\rH\u0016J\u000e\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\b\u001a\u00020\tR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/OptionsCardAdapter$DetailedViewHolder;", "Lpk/gov/nadra/oneapp/auth/main/adapters/OptionsCardAdapter$BaseViewHolder;", "binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/RvOptionsCardItemBinding;", "<init>", "(Lpk/gov/nadra/oneapp/auth/main/databinding/RvOptionsCardItemBinding;)V", "bind", "", "item", "Lpk/gov/nadra/oneapp/models/dashboard/AppOptionsTokenResponse$AllowedOption;", "context", "Landroid/content/Context;", "onActionSelected", "Lkotlin/Function1;", "getImageByKey", "", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class DetailedViewHolder extends BaseViewHolder {
        private final RvOptionsCardItemBinding binding;

        /* JADX WARN: Illegal instructions before constructor call */
        public DetailedViewHolder(RvOptionsCardItemBinding binding) {
            Intrinsics.checkNotNullParameter(binding, "binding");
            MaterialCardView root = binding.getRoot();
            Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
            super(root);
            this.binding = binding;
        }

        @Override // pk.gov.nadra.oneapp.auth.main.adapters.OptionsCardAdapter.BaseViewHolder
        public void bind(final AppOptionsTokenResponse.AllowedOption item, Context context, final Function1<? super AppOptionsTokenResponse.AllowedOption, Unit> onActionSelected) {
            Intrinsics.checkNotNullParameter(item, "item");
            Intrinsics.checkNotNullParameter(context, "context");
            Intrinsics.checkNotNullParameter(onActionSelected, "onActionSelected");
            RvOptionsCardItemBinding rvOptionsCardItemBinding = this.binding;
            rvOptionsCardItemBinding.rvTitle.setText(item.getTitle());
            rvOptionsCardItemBinding.rvUrduTitle.setText(item.getTitleUrdu());
            rvOptionsCardItemBinding.rvUrduTitle.setTypeface(ResourcesCompat.getFont(context, R.font.nadra_nastaleeq));
            String subTitle = item.getSubTitle();
            if (subTitle == null || subTitle.length() == 0) {
                rvOptionsCardItemBinding.rvDesc.setVisibility(8);
            } else {
                rvOptionsCardItemBinding.rvDesc.setVisibility(0);
                rvOptionsCardItemBinding.rvDesc.setText(item.getSubTitle());
            }
            String subTitleUrdu = item.getSubTitleUrdu();
            if (subTitleUrdu == null || subTitleUrdu.length() == 0) {
                rvOptionsCardItemBinding.rvUrduDesc.setVisibility(8);
            } else {
                rvOptionsCardItemBinding.rvUrduDesc.setVisibility(0);
                rvOptionsCardItemBinding.rvUrduDesc.setText(item.getSubTitleUrdu());
                rvOptionsCardItemBinding.rvUrduDesc.setTypeface(ResourcesCompat.getFont(context, R.font.nadra_nastaleeq));
            }
            rvOptionsCardItemBinding.rvImage.setImageResource(getImageByKey(item));
            rvOptionsCardItemBinding.getRoot().setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.adapters.OptionsCardAdapter$DetailedViewHolder$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    OptionsCardAdapter.DetailedViewHolder.bind$lambda$1$lambda$0(onActionSelected, item, view);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void bind$lambda$1$lambda$0(Function1 onActionSelected, AppOptionsTokenResponse.AllowedOption item, View view) {
            Intrinsics.checkNotNullParameter(onActionSelected, "$onActionSelected");
            Intrinsics.checkNotNullParameter(item, "$item");
            onActionSelected.invoke(item);
        }

        public final int getImageByKey(AppOptionsTokenResponse.AllowedOption item) {
            Intrinsics.checkNotNullParameter(item, "item");
            AppOptionsTokenResponse.AllowedOption.RequiredDocument requiredDocument = item.getRequiredDocument();
            String key = requiredDocument != null ? requiredDocument.getKey() : null;
            AppOptionsTokenResponse.AllowedOption.RequiredAppType requiredAppType = item.getRequiredAppType();
            String key2 = requiredAppType != null ? requiredAppType.getKey() : null;
            if (Intrinsics.areEqual(key, "CRC")) {
                return R.drawable.crc_icon;
            }
            if (Intrinsics.areEqual(key, "FRC")) {
                return R.drawable.frc_icon;
            }
            if (Intrinsics.areEqual(key, "POLC")) {
                return R.drawable.biometric_cards;
            }
            if (Intrinsics.areEqual(key2, "REPRINT_LOST")) {
                return R.drawable.reprint_icon;
            }
            if (Intrinsics.areEqual(key2, "RENEWAL")) {
                return R.drawable.renewal_icon;
            }
            if (Intrinsics.areEqual(key2, "CONVERSION")) {
                return R.drawable.conversion_icon;
            }
            if (Intrinsics.areEqual(key2, "BIOMETRIC_UPDATE")) {
                return R.drawable.biometric_update_card;
            }
            if (CollectionsKt.contains(CollectionsKt.listOf((Object[]) new String[]{"CANCEL_DIVORCED", "CANCEL_DEATH"}), key2)) {
                return R.drawable.cancellation_cards;
            }
            if (Intrinsics.areEqual(key2, "CANCEL")) {
                return R.drawable.surrender_card;
            }
            if (Intrinsics.areEqual(key2, "MODIFY") || Intrinsics.areEqual(key2, "MODIFY_NP")) {
                return R.drawable.modification_card_icon;
            }
            if (Intrinsics.areEqual(key2, "BIOMETRIC_VERIFY") || Intrinsics.areEqual(key2, "RELATIVE_ATTESTATION")) {
                return R.drawable.ic_biometric_verification;
            }
            return R.drawable.nic_cards;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public BaseViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        RvOptionsCardItemBinding rvOptionsCardItemBindingInflate = RvOptionsCardItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(rvOptionsCardItemBindingInflate, "inflate(...)");
        return new DetailedViewHolder(rvOptionsCardItemBindingInflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(BaseViewHolder holder, int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        holder.bind(this.showMoreList.get(position), this.context, this.onActionSelected);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.showMoreList.size();
    }
}