package pk.gov.nadra.oneapp.auth.main.adapters;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.core.graphics.ColorUtils;
import androidx.recyclerview.widget.RecyclerView;
import com.idemia.biometricsdkuiextensions.model.common.Colors;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.apache.commons.lang3.StringUtils;
import pk.gov.nadra.oneapp.auth.main.databinding.ListItemInboxBinding;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.models.inbox.ExistingApplicationResponse;

/* compiled from: InboxListAdapter.kt */
@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010$\n\u0002\b\u0005\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0002#$BD\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012-\u0010\u0006\u001a)\u0012\u0004\u0012\u00020\b\u0012\u0013\u0012\u00110\t¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\r0\u0007¢\u0006\u0004\b\u000e\u0010\u000fJ\u0014\u0010\u0010\u001a\u00020\r2\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004J\u001c\u0010\u0012\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\tH\u0016J\u001c\u0010\u0016\u001a\u00020\r2\n\u0010\u0017\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\f\u001a\u00020\tH\u0016J\b\u0010\u0018\u001a\u00020\tH\u0016J\u001c\u0010\u0019\u001a\u00020\r*\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001eH\u0002J\u000e\u0010\"\u001a\u00020\u001c2\u0006\u0010\u001b\u001a\u00020\u001cR\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R5\u0010\u0006\u001a)\u0012\u0004\u0012\u00020\b\u0012\u0013\u0012\u00110\t¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\r0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u001f\u001a\u000e\u0012\u0004\u0012\u00020\u001c\u0012\u0004\u0012\u00020\u001c0 X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010!\u001a\u000e\u0012\u0004\u0012\u00020\u001c\u0012\u0004\u0012\u00020\u001c0 X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006%"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/InboxListAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lpk/gov/nadra/oneapp/auth/main/adapters/InboxListAdapter$ViewHolder;", "applicationList", "", "Lpk/gov/nadra/oneapp/models/inbox/ExistingApplicationResponse$Inbox;", "onActionSelected", "Lkotlin/Function3;", "Lpk/gov/nadra/oneapp/auth/main/adapters/InboxListAdapter$ActionType;", "", "Lkotlin/ParameterName;", "name", "position", "", "<init>", "(Ljava/util/List;Lkotlin/jvm/functions/Function3;)V", "updateInboxList", "listItems", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onBindViewHolder", "holder", "getItemCount", "setRoundedBackground", "Landroid/widget/TextView;", "appTypeCode", "", "radiusDp", "", "appTypeColorMapping", "", "docTypeColorMapping", "getAppTypeLabel", "ViewHolder", "ActionType", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class InboxListAdapter extends RecyclerView.Adapter<ViewHolder> {
    private final Map<String, String> appTypeColorMapping;
    private List<ExistingApplicationResponse.Inbox> applicationList;
    private final Map<String, String> docTypeColorMapping;
    private final Function3<ActionType, Integer, ExistingApplicationResponse.Inbox, Unit> onActionSelected;

    /* compiled from: InboxListAdapter.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/InboxListAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/ListItemInboxBinding;", "<init>", "(Lpk/gov/nadra/oneapp/auth/main/adapters/InboxListAdapter;Lpk/gov/nadra/oneapp/auth/main/databinding/ListItemInboxBinding;)V", "getBinding", "()Lpk/gov/nadra/oneapp/auth/main/databinding/ListItemInboxBinding;", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public final class ViewHolder extends RecyclerView.ViewHolder {
        private final ListItemInboxBinding binding;
        final /* synthetic */ InboxListAdapter this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ViewHolder(InboxListAdapter inboxListAdapter, ListItemInboxBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.this$0 = inboxListAdapter;
            this.binding = binding;
        }

        public final ListItemInboxBinding getBinding() {
            return this.binding;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public InboxListAdapter(List<ExistingApplicationResponse.Inbox> applicationList, Function3<? super ActionType, ? super Integer, ? super ExistingApplicationResponse.Inbox, Unit> onActionSelected) {
        Intrinsics.checkNotNullParameter(applicationList, "applicationList");
        Intrinsics.checkNotNullParameter(onActionSelected, "onActionSelected");
        this.applicationList = applicationList;
        this.onActionSelected = onActionSelected;
        this.appTypeColorMapping = MapsKt.mapOf(TuplesKt.to("new", "#00A14B"), TuplesKt.to("reprint lost", "#8274DF"), TuplesKt.to("modify", "#F0AA57"), TuplesKt.to("cancel", "#B3261E"), TuplesKt.to("renewal", "#6C6C6C"), TuplesKt.to("bank", "#5F5DC2"), TuplesKt.to("punjabvehicle", "#5F5DC2"), TuplesKt.to("ictvehicle", "#5F5DC2"), TuplesKt.to("succession-bio", "#5F5DC2"), TuplesKt.to("poa", "#5F5DC2"), TuplesKt.to("cancel_death", "#B3261E"), TuplesKt.to("cancel_divorced", "#B3261E"), TuplesKt.to("refund", "#ADD8E6"), TuplesKt.to("priority", "#6C6C6C"), TuplesKt.to("modify np", "#F0AA57"), TuplesKt.to("biometric verify", "#00A14B"), TuplesKt.to("biometric update", "#00A14B"), TuplesKt.to("modification", "#F0AA57"), TuplesKt.to("reprint", "#8274DF"), TuplesKt.to("conversion", "#F0AA57"), TuplesKt.to(Constant.KEY_DIGITAL_CARD, "#00A14B"), TuplesKt.to("dup clearance", "#B3261E"));
        this.docTypeColorMapping = MapsKt.mapOf(TuplesKt.to("smpoc", "#065F46"), TuplesKt.to(Constant.KEY_FRC, "#059669"), TuplesKt.to("smnicop", "#1D4ED8"), TuplesKt.to("nicop", "#1E40AF"), TuplesKt.to("smartid", "#0284C7"), TuplesKt.to("idcard", "#1E3A8A"), TuplesKt.to("bioverif", "#2563EB"), TuplesKt.to(Constant.KEY_CRC, "#064E3B"), TuplesKt.to(Constant.KEY_POLC, "#4338CA"), TuplesKt.to("succcert", "#6D28D9"), TuplesKt.to("pals", "#5B21B6"), TuplesKt.to(CrmsConstants.S1_FORM_EVENT, "#009688"), TuplesKt.to("birth", "#CA8A04"), TuplesKt.to("marriage", "#BE185D"), TuplesKt.to("death", "#4B5563"), TuplesKt.to("divorce", "#B91C1C"), TuplesKt.to("poc", "#047857"), TuplesKt.to("simissue", "#0C4A6E"));
    }

    public final void updateInboxList(List<ExistingApplicationResponse.Inbox> listItems) {
        Intrinsics.checkNotNullParameter(listItems, "listItems");
        this.applicationList = listItems;
        notifyDataSetChanged();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        ListItemInboxBinding listItemInboxBindingInflate = ListItemInboxBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(listItemInboxBindingInflate, "inflate(...)");
        return new ViewHolder(this, listItemInboxBindingInflate);
    }

    /* JADX WARN: Removed duplicated region for block: B:38:0x02ce  */
    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onBindViewHolder(pk.gov.nadra.oneapp.auth.main.adapters.InboxListAdapter.ViewHolder r23, final int r24) {
        /*
            Method dump skipped, instructions count: 1022
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: pk.gov.nadra.oneapp.auth.main.adapters.InboxListAdapter.onBindViewHolder(pk.gov.nadra.oneapp.auth.main.adapters.InboxListAdapter$ViewHolder, int):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$8$lambda$7$lambda$6$lambda$0(ExistingApplicationResponse.Inbox this_with, InboxListAdapter this$0, int i, View view) {
        Intrinsics.checkNotNullParameter(this_with, "$this_with");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (Intrinsics.areEqual(this_with.getProcessingStatus(), "cancelled")) {
            return;
        }
        this$0.onActionSelected.invoke(ActionType.EDIT, Integer.valueOf(i), this$0.applicationList.get(i));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$8$lambda$7$lambda$6$lambda$1(ExistingApplicationResponse.Inbox this_with, InboxListAdapter this$0, int i, View view) {
        Intrinsics.checkNotNullParameter(this_with, "$this_with");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this_with.getPaymentP()) {
            this$0.onActionSelected.invoke(ActionType.PAYMENT, Integer.valueOf(i), this$0.applicationList.get(i));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$8$lambda$7$lambda$6$lambda$2(ExistingApplicationResponse.Inbox this_with, InboxListAdapter this$0, int i, View view) {
        Intrinsics.checkNotNullParameter(this_with, "$this_with");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this_with.getDownloadPdf()) {
            this$0.onActionSelected.invoke(ActionType.DOWNLOAD, Integer.valueOf(i), this$0.applicationList.get(i));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$8$lambda$7$lambda$6$lambda$3(ExistingApplicationResponse.Inbox this_with, InboxListAdapter this$0, int i, View view) {
        Intrinsics.checkNotNullParameter(this_with, "$this_with");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        String lowerCase = this_with.getProcessingStatus().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        if (!Intrinsics.areEqual(lowerCase, "empty")) {
            String lowerCase2 = this_with.getProcessingStatus().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
            if (!Intrinsics.areEqual(lowerCase2, "ready for payment")) {
                String lowerCase3 = this_with.getProcessingStatus().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
                if (!Intrinsics.areEqual(lowerCase3, "inprocess") && !this_with.getPaymentP()) {
                    return;
                }
            }
        }
        this$0.onActionSelected.invoke(ActionType.CANCEL, Integer.valueOf(i), this$0.applicationList.get(i));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$8$lambda$7$lambda$6$lambda$4(ExistingApplicationResponse.Inbox this_with, InboxListAdapter this$0, int i, View view) {
        Intrinsics.checkNotNullParameter(this_with, "$this_with");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this_with.getRejectedCancelledP()) {
            this$0.onActionSelected.invoke(ActionType.INFO, Integer.valueOf(i), this$0.applicationList.get(i));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$8$lambda$7$lambda$6$lambda$5(InboxListAdapter this$0, int i, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.onActionSelected.invoke(ActionType.TRACK, Integer.valueOf(i), this$0.applicationList.get(i));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.applicationList.size();
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: InboxListAdapter.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\t\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\t¨\u0006\n"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/InboxListAdapter$ActionType;", "", "<init>", "(Ljava/lang/String;I)V", "DOWNLOAD", "PAYMENT", "CANCEL", "INFO", "EDIT", "TRACK", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class ActionType {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ ActionType[] $VALUES;
        public static final ActionType DOWNLOAD = new ActionType("DOWNLOAD", 0);
        public static final ActionType PAYMENT = new ActionType("PAYMENT", 1);
        public static final ActionType CANCEL = new ActionType("CANCEL", 2);
        public static final ActionType INFO = new ActionType("INFO", 3);
        public static final ActionType EDIT = new ActionType("EDIT", 4);
        public static final ActionType TRACK = new ActionType("TRACK", 5);

        private static final /* synthetic */ ActionType[] $values() {
            return new ActionType[]{DOWNLOAD, PAYMENT, CANCEL, INFO, EDIT, TRACK};
        }

        public static EnumEntries<ActionType> getEntries() {
            return $ENTRIES;
        }

        private ActionType(String str, int i) {
        }

        static {
            ActionType[] actionTypeArr$values = $values();
            $VALUES = actionTypeArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(actionTypeArr$values);
        }

        public static ActionType valueOf(String str) {
            return (ActionType) Enum.valueOf(ActionType.class, str);
        }

        public static ActionType[] values() {
            return (ActionType[]) $VALUES.clone();
        }
    }

    private final void setRoundedBackground(TextView textView, String str, float f) {
        float fApplyDimension = TypedValue.applyDimension(1, f, textView.getResources().getDisplayMetrics());
        String str2 = this.appTypeColorMapping.get(str);
        if (str2 == null) {
            str2 = Colors.black;
        }
        int color = Color.parseColor(str2);
        textView.setTextColor(color);
        int alphaComponent = ColorUtils.setAlphaComponent(color, 25);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setCornerRadius(fApplyDimension);
        gradientDrawable.setColor(alphaComponent);
        textView.setBackground(gradientDrawable);
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue
    java.lang.NullPointerException: Cannot invoke "java.util.List.iterator()" because the return value of "jadx.core.dex.visitors.regions.SwitchOverStringVisitor$SwitchData.getNewCases()" is null
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.restoreSwitchOverString(SwitchOverStringVisitor.java:109)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.visitRegion(SwitchOverStringVisitor.java:66)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterativeStepInternal(DepthRegionTraversal.java:77)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterativeStepInternal(DepthRegionTraversal.java:82)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterative(DepthRegionTraversal.java:31)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.visit(SwitchOverStringVisitor.java:60)
     */
    public final String getAppTypeLabel(String appTypeCode) {
        Intrinsics.checkNotNullParameter(appTypeCode, "appTypeCode");
        String string = StringsKt.trim((CharSequence) appTypeCode).toString();
        switch (string.hashCode()) {
            case -1490755473:
                if (string.equals("cancel_death")) {
                    return "Cancellation - Death";
                }
                break;
            case -1367724422:
                if (string.equals("cancel")) {
                    return "Cancellation - Surrender";
                }
                break;
            case -1282417229:
                if (string.equals("cancel_divorced")) {
                    return "Cancellation - Divorced";
                }
                break;
            case 45308511:
                if (string.equals("vehicle transfer")) {
                    return "Vehicle Transfer";
                }
                break;
            case 130634967:
                if (string.equals(Constant.KEY_DIGITAL_CARD)) {
                    return "Digital Card";
                }
                break;
            case 283181115:
                if (string.equals("dup clearance")) {
                    return "Dup Clearance";
                }
                break;
            case 1295988218:
                if (string.equals("office mistake")) {
                    return "Office Mistake";
                }
                break;
        }
        return (String) CollectionsKt.first(StringsKt.split$default((CharSequence) string, new String[]{StringUtils.SPACE}, false, 0, 6, (Object) null));
    }
}