package pk.gov.nadra.oneapp.auth.main.adapters;

import android.view.View;
import pk.gov.nadra.oneapp.auth.main.adapters.NotificationAdapter;
import pk.gov.nadra.oneapp.models.dashboard.NotificationsResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class NotificationAdapter$DetailedViewHolder$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ NotificationsResponse f$1;

    public /* synthetic */ NotificationAdapter$DetailedViewHolder$$ExternalSyntheticLambda0(NotificationsResponse notificationsResponse) {
        item = notificationsResponse;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        NotificationAdapter.DetailedViewHolder.bind$lambda$1$lambda$0(onActionSelected, item, view);
    }
}