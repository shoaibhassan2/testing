package pk.gov.nadra.oneapp.auth.main.adapters;

import android.view.View;
import pk.gov.nadra.oneapp.auth.main.adapters.ProvincialOptionsCardAdapter;
import pk.gov.nadra.oneapp.models.dashboard.DashboardItem;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ProvincialOptionsCardAdapter$DetailedViewHolder$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ DashboardItem.ServiceItem f$1;

    public /* synthetic */ ProvincialOptionsCardAdapter$DetailedViewHolder$$ExternalSyntheticLambda0(DashboardItem.ServiceItem serviceItem) {
        item = serviceItem;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ProvincialOptionsCardAdapter.DetailedViewHolder.bind$lambda$1$lambda$0(onActionSelected, item, view);
    }
}