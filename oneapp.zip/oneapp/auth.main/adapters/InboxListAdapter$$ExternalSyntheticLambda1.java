package pk.gov.nadra.oneapp.auth.main.adapters;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class InboxListAdapter$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public final /* synthetic */ InboxListAdapter f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ InboxListAdapter$$ExternalSyntheticLambda1(InboxListAdapter inboxListAdapter, int i) {
        inboxListAdapter = inboxListAdapter;
        i = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        InboxListAdapter.onBindViewHolder$lambda$8$lambda$7$lambda$6$lambda$1(inbox, inboxListAdapter, i, view);
    }
}