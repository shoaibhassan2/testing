package pk.gov.nadra.oneapp.auth.main.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.auth.main.adapters.DashboardAdapter;
import pk.gov.nadra.oneapp.auth.main.databinding.RvCardItemBinding;
import pk.gov.nadra.oneapp.auth.main.databinding.RvSimpleItemBinding;
import pk.gov.nadra.oneapp.commonutils.preferences.AppPreferences;
import pk.gov.nadra.oneapp.commonutils.utils.LocaleHelper;
import pk.gov.nadra.oneapp.commonutils.utils.MethodName;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.dashboard.DashboardModel;

/* compiled from: DashboardAdapter.kt */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0003\u0016\u0017\u0018B7\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0018\u0010\b\u001a\u0014\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0004\b\u000b\u0010\fJ\u0018\u0010\r\u001a\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0016J\u0018\u0010\u0012\u001a\u00020\n2\u0006\u0010\u0013\u001a\u00020\u00022\u0006\u0010\u0014\u001a\u00020\u0011H\u0016J\b\u0010\u0015\u001a\u00020\u0011H\u0016R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\b\u001a\u0014\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0019"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardAdapter$BaseViewHolder;", "showMoreList", "", "Lpk/gov/nadra/oneapp/models/dashboard/DashboardModel;", "layoutType", "Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;", "onActionSelected", "Lkotlin/Function2;", "", "<init>", "(Ljava/util/List;Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;Lkotlin/jvm/functions/Function2;)V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "onBindViewHolder", "holder", "position", "getItemCount", "BaseViewHolder", "SimpleViewHolder", "DetailedViewHolder", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DashboardAdapter extends RecyclerView.Adapter<BaseViewHolder> {
    private final MethodName layoutType;
    private final Function2<DashboardModel, MethodName, Unit> onActionSelected;
    private List<DashboardModel> showMoreList;

    /* compiled from: DashboardAdapter.kt */
    @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[MethodName.values().length];
            try {
                iArr[MethodName.SIMPLE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[MethodName.CARD.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public DashboardAdapter(List<DashboardModel> showMoreList, MethodName layoutType, Function2<? super DashboardModel, ? super MethodName, Unit> onActionSelected) {
        Intrinsics.checkNotNullParameter(showMoreList, "showMoreList");
        Intrinsics.checkNotNullParameter(layoutType, "layoutType");
        Intrinsics.checkNotNullParameter(onActionSelected, "onActionSelected");
        this.showMoreList = showMoreList;
        this.layoutType = layoutType;
        this.onActionSelected = onActionSelected;
    }

    /* compiled from: DashboardAdapter.kt */
    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b&\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J*\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0018\u0010\n\u001a\u0014\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u00070\u000bH&¨\u0006\r"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardAdapter$BaseViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "bindingRoot", "Landroid/view/View;", "<init>", "(Landroid/view/View;)V", "bind", "", "item", "Lpk/gov/nadra/oneapp/models/dashboard/DashboardModel;", "onActionSelected", "Lkotlin/Function2;", "Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static abstract class BaseViewHolder extends RecyclerView.ViewHolder {
        public abstract void bind(DashboardModel item, Function2<? super DashboardModel, ? super MethodName, Unit> onActionSelected);

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public BaseViewHolder(View bindingRoot) {
            super(bindingRoot);
            Intrinsics.checkNotNullParameter(bindingRoot, "bindingRoot");
        }
    }

    /* compiled from: DashboardAdapter.kt */
    @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J*\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0018\u0010\f\u001a\u0014\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\t0\rH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardAdapter$SimpleViewHolder;", "Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardAdapter$BaseViewHolder;", "context", "Landroid/content/Context;", "binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/RvSimpleItemBinding;", "<init>", "(Landroid/content/Context;Lpk/gov/nadra/oneapp/auth/main/databinding/RvSimpleItemBinding;)V", "bind", "", "item", "Lpk/gov/nadra/oneapp/models/dashboard/DashboardModel;", "onActionSelected", "Lkotlin/Function2;", "Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class SimpleViewHolder extends BaseViewHolder {
        private final RvSimpleItemBinding binding;
        private final Context context;

        /* JADX WARN: Illegal instructions before constructor call */
        public SimpleViewHolder(Context context, RvSimpleItemBinding binding) {
            Intrinsics.checkNotNullParameter(context, "context");
            Intrinsics.checkNotNullParameter(binding, "binding");
            MaterialCardView root = binding.getRoot();
            Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
            super(root);
            this.context = context;
            this.binding = binding;
        }

        @Override // pk.gov.nadra.oneapp.auth.main.adapters.DashboardAdapter.BaseViewHolder
        public void bind(final DashboardModel item, final Function2<? super DashboardModel, ? super MethodName, Unit> onActionSelected) {
            Intrinsics.checkNotNullParameter(item, "item");
            Intrinsics.checkNotNullParameter(onActionSelected, "onActionSelected");
            RvSimpleItemBinding rvSimpleItemBinding = this.binding;
            AppPreferences appPreferences = AppPreferences.getInstance(this.context);
            LocaleHelper localeHelper = LocaleHelper.INSTANCE;
            Context context = this.context;
            String appLanguage = appPreferences.getAppLanguage();
            Intrinsics.checkNotNullExpressionValue(appLanguage, "getAppLanguage(...)");
            Context locale = localeHelper.setLocale(context, appLanguage);
            try {
                TextView textView = this.binding.rvTitle;
                Util util = Util.INSTANCE;
                String appLanguage2 = appPreferences.getAppLanguage();
                Intrinsics.checkNotNullExpressionValue(appLanguage2, "getAppLanguage(...)");
                textView.setTypeface(util.getLocaleFont(locale, appLanguage2));
            } catch (Exception unused) {
            }
            rvSimpleItemBinding.rvTitle.setText(item.getTitle());
            rvSimpleItemBinding.rvImage.setImageResource(item.getImage());
            rvSimpleItemBinding.getRoot().setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.adapters.DashboardAdapter$SimpleViewHolder$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    DashboardAdapter.SimpleViewHolder.bind$lambda$1$lambda$0(onActionSelected, item, view);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void bind$lambda$1$lambda$0(Function2 onActionSelected, DashboardModel item, View view) {
            Intrinsics.checkNotNullParameter(onActionSelected, "$onActionSelected");
            Intrinsics.checkNotNullParameter(item, "$item");
            onActionSelected.invoke(item, MethodName.SIMPLE);
        }
    }

    /* compiled from: DashboardAdapter.kt */
    @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J*\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0018\u0010\f\u001a\u0014\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\t0\rH\u0016J\u0018\u0010\u000f\u001a\u00020\t2\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardAdapter$DetailedViewHolder;", "Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardAdapter$BaseViewHolder;", "context", "Landroid/content/Context;", "binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/RvCardItemBinding;", "<init>", "(Landroid/content/Context;Lpk/gov/nadra/oneapp/auth/main/databinding/RvCardItemBinding;)V", "bind", "", "item", "Lpk/gov/nadra/oneapp/models/dashboard/DashboardModel;", "onActionSelected", "Lkotlin/Function2;", "Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;", "getLocaleFont", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class DetailedViewHolder extends BaseViewHolder {
        private final RvCardItemBinding binding;
        private final Context context;

        /* JADX WARN: Illegal instructions before constructor call */
        public DetailedViewHolder(Context context, RvCardItemBinding binding) {
            Intrinsics.checkNotNullParameter(context, "context");
            Intrinsics.checkNotNullParameter(binding, "binding");
            MaterialCardView root = binding.getRoot();
            Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
            super(root);
            this.context = context;
            this.binding = binding;
        }

        @Override // pk.gov.nadra.oneapp.auth.main.adapters.DashboardAdapter.BaseViewHolder
        public void bind(final DashboardModel item, final Function2<? super DashboardModel, ? super MethodName, Unit> onActionSelected) {
            Intrinsics.checkNotNullParameter(item, "item");
            Intrinsics.checkNotNullParameter(onActionSelected, "onActionSelected");
            RvCardItemBinding rvCardItemBinding = this.binding;
            getLocaleFont(this.context, rvCardItemBinding);
            rvCardItemBinding.rvTitle.setText(item.getTitle());
            String descp = item.getDescp();
            if (descp == null || descp.length() == 0) {
                rvCardItemBinding.rvDesc.setVisibility(8);
            } else {
                rvCardItemBinding.rvDesc.setVisibility(0);
                rvCardItemBinding.rvDesc.setText(item.getDescp());
            }
            rvCardItemBinding.rvImage.setImageResource(item.getImage());
            rvCardItemBinding.getRoot().setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.adapters.DashboardAdapter$DetailedViewHolder$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    DashboardAdapter.DetailedViewHolder.bind$lambda$1$lambda$0(onActionSelected, item, view);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void bind$lambda$1$lambda$0(Function2 onActionSelected, DashboardModel item, View view) {
            Intrinsics.checkNotNullParameter(onActionSelected, "$onActionSelected");
            Intrinsics.checkNotNullParameter(item, "$item");
            onActionSelected.invoke(item, MethodName.CARD);
        }

        private final void getLocaleFont(Context context, RvCardItemBinding binding) {
            AppPreferences appPreferences = AppPreferences.getInstance(context);
            LocaleHelper localeHelper = LocaleHelper.INSTANCE;
            String appLanguage = appPreferences.getAppLanguage();
            Intrinsics.checkNotNullExpressionValue(appLanguage, "getAppLanguage(...)");
            Context locale = localeHelper.setLocale(context, appLanguage);
            try {
                TextView textView = binding.rvTitle;
                Util util = Util.INSTANCE;
                String appLanguage2 = appPreferences.getAppLanguage();
                Intrinsics.checkNotNullExpressionValue(appLanguage2, "getAppLanguage(...)");
                textView.setTypeface(util.getLocaleFont(locale, appLanguage2));
                TextView textView2 = binding.rvDesc;
                Util util2 = Util.INSTANCE;
                String appLanguage3 = appPreferences.getAppLanguage();
                Intrinsics.checkNotNullExpressionValue(appLanguage3, "getAppLanguage(...)");
                textView2.setTypeface(util2.getLocaleFont(locale, appLanguage3));
            } catch (Exception unused) {
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public BaseViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        int i = WhenMappings.$EnumSwitchMapping$0[this.layoutType.ordinal()];
        if (i == 1) {
            RvSimpleItemBinding rvSimpleItemBindingInflate = RvSimpleItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            Intrinsics.checkNotNullExpressionValue(rvSimpleItemBindingInflate, "inflate(...)");
            Context context = parent.getContext();
            Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
            return new SimpleViewHolder(context, rvSimpleItemBindingInflate);
        }
        if (i == 2) {
            RvCardItemBinding rvCardItemBindingInflate = RvCardItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            Intrinsics.checkNotNullExpressionValue(rvCardItemBindingInflate, "inflate(...)");
            Context context2 = parent.getContext();
            Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
            return new DetailedViewHolder(context2, rvCardItemBindingInflate);
        }
        RvSimpleItemBinding rvSimpleItemBindingInflate2 = RvSimpleItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(rvSimpleItemBindingInflate2, "inflate(...)");
        Context context3 = parent.getContext();
        Intrinsics.checkNotNullExpressionValue(context3, "getContext(...)");
        return new SimpleViewHolder(context3, rvSimpleItemBindingInflate2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(BaseViewHolder holder, int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        holder.bind(this.showMoreList.get(position), this.onActionSelected);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.showMoreList.size();
    }
}