package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda1 implements Function0 {
    public /* synthetic */ DashboardFragment$$ExternalSyntheticLambda1() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return DashboardFragment.handleFailureCase$lambda$23(this.f$0);
    }
}