package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CancellationDeathFragment$$ExternalSyntheticLambda12 implements Function0 {
    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return Unit.INSTANCE;
    }
}