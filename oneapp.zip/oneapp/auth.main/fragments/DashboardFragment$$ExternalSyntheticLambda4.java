package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function0;
import pk.gov.nadra.oneapp.digitalvault.data.local.model.DigitalDocumentEntity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda4 implements Function0 {
    public final /* synthetic */ DigitalDocumentEntity f$1;
    public final /* synthetic */ long f$2;

    public /* synthetic */ DashboardFragment$$ExternalSyntheticLambda4(DigitalDocumentEntity digitalDocumentEntity, long j) {
        digitalDocumentEntity = digitalDocumentEntity;
        j = j;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return DashboardFragment.checkVaccineCertificate$lambda$13$lambda$12$lambda$11(this.f$0, digitalDocumentEntity, j);
    }
}