package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda9 implements Function1 {
    public /* synthetic */ DashboardFragment$$ExternalSyntheticLambda9() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return DashboardFragment.attachDashboardViews$lambda$6$lambda$5(this.f$0, (String) obj);
    }
}