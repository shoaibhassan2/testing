package pk.gov.nadra.oneapp.auth.main.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.auth.main.adapters.OptionsCardAdapter;
import pk.gov.nadra.oneapp.auth.main.databinding.BioVerifyOptionsFragmentBinding;
import pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment;
import pk.gov.nadra.oneapp.auth.main.viewModel.AuthMainSharedViewModel;
import pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity;
import pk.gov.nadra.oneapp.biometricverif.views.BiometricVerifActivity;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.preferences.AppPreferences;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.DataProvider;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.models.dashboard.AppOptionsTokenResponse;
import pk.gov.nadra.oneapp.models.dashboard.CheckApplicationStatusRequest;
import pk.gov.nadra.oneapp.models.login.LoginResponse;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;
import pk.gov.nadra.oneapp.polc.views.PolcActivity;
import pk.gov.nadra.oneapp.relativeattestation.views.RelativeAttestationActivity;

/* compiled from: BioVerifyOptionsFragment.kt */
@Metadata(d1 = {"\u0000\u009e\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001dH\u0016J$\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!2\b\u0010\"\u001a\u0004\u0018\u00010#2\b\u0010$\u001a\u0004\u0018\u00010%H\u0016J\u001a\u0010&\u001a\u00020\u001b2\u0006\u0010'\u001a\u00020\u001f2\b\u0010$\u001a\u0004\u0018\u00010%H\u0016J\b\u0010(\u001a\u00020\u001bH\u0002J\u0010\u0010)\u001a\u00020\u001b2\u0006\u0010*\u001a\u00020\u0013H\u0002J\b\u0010+\u001a\u00020,H\u0002J(\u0010-\u001a\u00020\u001b2\u0006\u0010.\u001a\u00020/2\u0006\u00100\u001a\u00020/2\u0006\u00101\u001a\u0002022\u0006\u00103\u001a\u00020/H\u0002J\u0010\u00104\u001a\u00020\u001b2\u0006\u00103\u001a\u00020/H\u0002J(\u00105\u001a\u00020\u001b2\u0006\u0010.\u001a\u00020/2\u0006\u00100\u001a\u00020/2\u0006\u00101\u001a\u0002022\u0006\u00106\u001a\u00020/H\u0002J \u0010;\u001a\u00020\u001b2\u0006\u00106\u001a\u00020/2\u0006\u00103\u001a\u00020/2\u0006\u0010<\u001a\u00020/H\u0002J \u0010=\u001a\u00020>2\u0006\u0010?\u001a\u00020/2\u0006\u00103\u001a\u00020/2\u0006\u00106\u001a\u00020/H\u0002J \u0010@\u001a\u00020\u001b2\u0006\u0010A\u001a\u00020B2\u0006\u0010C\u001a\u00020/2\u0006\u0010?\u001a\u00020/H\u0002J\u0018\u0010D\u001a\u00020\u001b2\u0006\u0010E\u001a\u00020B2\u0006\u0010F\u001a\u00020GH\u0002R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u001b\u0010\u000b\u001a\u00020\f8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000f\u0010\u0010\u001a\u0004\b\r\u0010\u000eR \u0010\u0011\u001a\u0012\u0012\u0004\u0012\u00020\u00130\u0014j\b\u0012\u0004\u0012\u00020\u0013`\u0012X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u0015R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082.¢\u0006\u0002\n\u0000R\u001c\u00107\u001a\u0010\u0012\f\u0012\n :*\u0004\u0018\u0001090908X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006H"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/fragments/BioVerifyOptionsFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/BioVerifyOptionsFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/auth/main/databinding/BioVerifyOptionsFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/auth/main/views/AuthMainActivity;", "authMainSharedViewModel", "Lpk/gov/nadra/oneapp/auth/main/viewModel/AuthMainSharedViewModel;", "getAuthMainSharedViewModel", "()Lpk/gov/nadra/oneapp/auth/main/viewModel/AuthMainSharedViewModel;", "authMainSharedViewModel$delegate", "Lkotlin/Lazy;", "optionsList", "Lkotlin/collections/ArrayList;", "Lpk/gov/nadra/oneapp/models/dashboard/AppOptionsTokenResponse$AllowedOption;", "Ljava/util/ArrayList;", "Ljava/util/ArrayList;", "optionsAdapter", "Lpk/gov/nadra/oneapp/auth/main/adapters/OptionsCardAdapter;", "userCredentials", "Lpk/gov/nadra/oneapp/models/login/LoginResponse;", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "initViews", "handleItemClick", "selectedOption", "getReactNativeData", "Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "startBiometricVerifiation", "citizenNumber", "", "accountHolderCnicNo", "facialVerifP", "", "appType", "startRelativeVerifiation", "startPolc", "docType", "intentLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "checkApplicationStatus", "cnicNumber", "getCheckApplicationStatusRequest", "Lpk/gov/nadra/oneapp/models/dashboard/CheckApplicationStatusRequest;", "cnic", "processCheckApplicationStatusSuccessResponseResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "documentType", "handleFailureCase", "jsonResponse", "responseCode", "", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class BioVerifyOptionsFragment extends Fragment {
    private BioVerifyOptionsFragmentBinding _binding;
    private AuthMainActivity activity;

    /* renamed from: authMainSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy authMainSharedViewModel;
    private final ActivityResultLauncher<Intent> intentLauncher;
    private OptionsCardAdapter optionsAdapter;
    private ArrayList<AppOptionsTokenResponse.AllowedOption> optionsList = new ArrayList<>();
    private LoginResponse userCredentials;

    public BioVerifyOptionsFragment() {
        final BioVerifyOptionsFragment bioVerifyOptionsFragment = this;
        final Function0 function0 = null;
        this.authMainSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(bioVerifyOptionsFragment, Reflection.getOrCreateKotlinClass(AuthMainSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = bioVerifyOptionsFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = bioVerifyOptionsFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = bioVerifyOptionsFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$$ExternalSyntheticLambda0
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                BioVerifyOptionsFragment.intentLauncher$lambda$4(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.intentLauncher = activityResultLauncherRegisterForActivityResult;
    }

    private final BioVerifyOptionsFragmentBinding getBinding() {
        BioVerifyOptionsFragmentBinding bioVerifyOptionsFragmentBinding = this._binding;
        Intrinsics.checkNotNull(bioVerifyOptionsFragmentBinding);
        return bioVerifyOptionsFragmentBinding;
    }

    private final AuthMainSharedViewModel getAuthMainSharedViewModel() {
        return (AuthMainSharedViewModel) this.authMainSharedViewModel.getValue();
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity");
        this.activity = (AuthMainActivity) fragmentActivityRequireActivity;
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        this.userCredentials = new SharedPreferencesTokenProvider(authMainActivity).getUserCredentials();
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = BioVerifyOptionsFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        DataProvider dataProvider = DataProvider.INSTANCE;
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        this.optionsList = new ArrayList<>(dataProvider.getBioVerifyOptionsDataList(authMainActivity));
        if (!getAuthMainSharedViewModel().getFacialVerificationConfigResponse().getFacialVerificationEnabled()) {
            CollectionsKt.removeAll((List) this.optionsList, new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return Boolean.valueOf(BioVerifyOptionsFragment.onViewCreated$lambda$0((AppOptionsTokenResponse.AllowedOption) obj));
                }
            });
        }
        initViews();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean onViewCreated$lambda$0(AppOptionsTokenResponse.AllowedOption it) {
        Intrinsics.checkNotNullParameter(it, "it");
        AppOptionsTokenResponse.AllowedOption.RequiredDocument requiredDocument = it.getRequiredDocument();
        return Intrinsics.areEqual(requiredDocument != null ? requiredDocument.getKey() : null, "POLC");
    }

    private final void initViews() {
        BioVerifyOptionsFragmentBinding binding = getBinding();
        binding.newAppHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                BioVerifyOptionsFragment.initViews$lambda$3$lambda$1(this.f$0, view);
            }
        });
        TextView textView = binding.newAppHeaderLayout.textTitle;
        Util util = Util.INSTANCE;
        AuthMainActivity authMainActivity = this.activity;
        OptionsCardAdapter optionsCardAdapter = null;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        String string = getString(R.string.new_application);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = getString(R.string.new_application_ur);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util, authMainActivity, string, string2, 0, false, 12, null));
        TextView textView2 = binding.tvTitle;
        Util util2 = Util.INSTANCE;
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity2 = null;
        }
        String string3 = getString(R.string.choose_biometric_verification_option);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        String string4 = getString(R.string.choose_biometric_verification_option_ur);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        textView2.setText(Util.setEnglishTextSpan$default(util2, authMainActivity2, string3, string4, 0, false, 12, null));
        AuthMainActivity authMainActivity3 = this.activity;
        if (authMainActivity3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity3 = null;
        }
        binding.rvOptions.setLayoutManager(new GridLayoutManager(authMainActivity3, 2));
        Context contextRequireContext = requireContext();
        Intrinsics.checkNotNullExpressionValue(contextRequireContext, "requireContext(...)");
        this.optionsAdapter = new OptionsCardAdapter(contextRequireContext, this.optionsList, new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return BioVerifyOptionsFragment.initViews$lambda$3$lambda$2(this.f$0, (AppOptionsTokenResponse.AllowedOption) obj);
            }
        });
        RecyclerView recyclerView = binding.rvOptions;
        OptionsCardAdapter optionsCardAdapter2 = this.optionsAdapter;
        if (optionsCardAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("optionsAdapter");
        } else {
            optionsCardAdapter = optionsCardAdapter2;
        }
        recyclerView.setAdapter(optionsCardAdapter);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initViews$lambda$3$lambda$1(BioVerifyOptionsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initViews$lambda$3$lambda$2(BioVerifyOptionsFragment this$0, AppOptionsTokenResponse.AllowedOption item) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(item, "item");
        this$0.handleItemClick(item);
        return Unit.INSTANCE;
    }

    private final void handleItemClick(AppOptionsTokenResponse.AllowedOption selectedOption) {
        String string = StringsKt.trim((CharSequence) StringsKt.replace$default(getAuthMainSharedViewModel().getProcessingType().getCitizenNumber(), "-", "", false, 4, (Object) null)).toString();
        String string2 = StringsKt.trim((CharSequence) StringsKt.replace$default(getAuthMainSharedViewModel().getAccountHolderCnic(), "-", "", false, 4, (Object) null)).toString();
        if (Intrinsics.areEqual(selectedOption.getRequiredAppType().getKey(), "BIOMETRIC_VERIFY")) {
            startBiometricVerifiation(string, string2, false, selectedOption.getRequiredAppType().getKey());
        } else if (Intrinsics.areEqual(selectedOption.getRequiredAppType().getKey(), "RELATIVE_ATTESTATION")) {
            startRelativeVerifiation(selectedOption.getRequiredAppType().getKey());
        } else if (Intrinsics.areEqual(selectedOption.getRequiredDocument().getKey(), "POLC")) {
            checkApplicationStatus(selectedOption.getRequiredDocument().getKey(), "BIOMETRIC_VERIFY", string);
        }
    }

    private final ReactNativeData getReactNativeData() {
        AuthMainActivity authMainActivity = null;
        ReactNativeData.MobileOperator mobileOperator = new ReactNativeData.MobileOperator(0, null, 3, null);
        LoginResponse loginResponse = this.userCredentials;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        mobileOperator.setKey(loginResponse.getMobileOperator().getKey());
        LoginResponse loginResponse2 = this.userCredentials;
        if (loginResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse2 = null;
        }
        mobileOperator.setValue(loginResponse2.getMobileOperator().getValue());
        LoginResponse loginResponse3 = this.userCredentials;
        if (loginResponse3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse3 = null;
        }
        String email = loginResponse3.getEmail();
        LoginResponse loginResponse4 = this.userCredentials;
        if (loginResponse4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse4 = null;
        }
        String fullName = loginResponse4.getFullName();
        LoginResponse loginResponse5 = this.userCredentials;
        if (loginResponse5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse5 = null;
        }
        String mobileNumber = loginResponse5.getMobileNumber();
        LoginResponse loginResponse6 = this.userCredentials;
        if (loginResponse6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse6 = null;
        }
        String refreshToken = loginResponse6.getRefreshToken();
        LoginResponse loginResponse7 = this.userCredentials;
        if (loginResponse7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse7 = null;
        }
        String token = loginResponse7.getToken();
        LoginResponse loginResponse8 = this.userCredentials;
        if (loginResponse8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse8 = null;
        }
        String sessionKey = loginResponse8.getSessionKey();
        LoginResponse loginResponse9 = this.userCredentials;
        if (loginResponse9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse9 = null;
        }
        boolean encryptionDecryptionEnabled = loginResponse9.getEncryptionDecryptionEnabled();
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        String fcmToken = AppPreferences.getInstance(authMainActivity).getFcmToken();
        Intrinsics.checkNotNullExpressionValue(fcmToken, "getFcmToken(...)");
        return new ReactNativeData(null, email, fullName, mobileNumber, refreshToken, token, "", true, true, true, null, null, false, null, mobileOperator, sessionKey, encryptionDecryptionEnabled, fcmToken, false, false, false, false, null, null, false, false, false, null, false, false, null, null, null, false, null, null, null, false, false, null, null, null, null, false, null, null, null, null, null, null, -246783, 262143, null);
    }

    private final void startBiometricVerifiation(String citizenNumber, String accountHolderCnicNo, boolean facialVerifP, String appType) {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setCitizenNumber(citizenNumber);
        reactNativeData.setAppType(appType);
        reactNativeData.setFacialVerificationP(facialVerifP);
        reactNativeData.setAccountHolderCnic(accountHolderCnicNo);
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) BiometricVerifActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startRelativeVerifiation(String appType) {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType(appType);
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) RelativeAttestationActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startPolc(String citizenNumber, String accountHolderCnicNo, boolean facialVerifP, String docType) {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setCitizenNumber(citizenNumber);
        reactNativeData.setAppType("BIOMETRIC_VERIFY");
        reactNativeData.setDocType(docType);
        reactNativeData.setFacialVerificationP(facialVerifP);
        reactNativeData.setAccountHolderCnic(accountHolderCnicNo);
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) PolcActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void intentLauncher$lambda$4(BioVerifyOptionsFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        Intent data = result.getData();
        AuthMainActivity authMainActivity = null;
        String stringExtra = data != null ? data.getStringExtra("RESPONSE_TO_REACT_NATIVE") : null;
        if (result.getResultCode() == -1 && Intrinsics.areEqual(stringExtra, Constant.GO_TO_LOGIN)) {
            AuthMainActivity authMainActivity2 = this$0.activity;
            if (authMainActivity2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity = authMainActivity2;
            }
            authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.loginFragment);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r13v2, types: [T, java.lang.Object, java.lang.String] */
    private final void checkApplicationStatus(String docType, String appType, String cnicNumber) {
        Ref.ObjectRef objectRef = new Ref.ObjectRef();
        objectRef.element = cnicNumber;
        Ref.ObjectRef objectRef2 = new Ref.ObjectRef();
        objectRef2.element = appType;
        Ref.ObjectRef objectRef3 = new Ref.ObjectRef();
        ?? upperCase = docType.toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        objectRef3.element = upperCase;
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(objectRef, objectRef2, objectRef3, docType, cnicNumber, null), 3, null);
    }

    /* compiled from: BioVerifyOptionsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$checkApplicationStatus$1", f = "BioVerifyOptionsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$checkApplicationStatus$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Ref.ObjectRef<String> $appTypeCode;
        final /* synthetic */ Ref.ObjectRef<String> $citizenNumber;
        final /* synthetic */ String $cnicNumber;
        final /* synthetic */ String $docType;
        final /* synthetic */ Ref.ObjectRef<String> $docTypeCode;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(Ref.ObjectRef<String> objectRef, Ref.ObjectRef<String> objectRef2, Ref.ObjectRef<String> objectRef3, String str, String str2, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$citizenNumber = objectRef;
            this.$appTypeCode = objectRef2;
            this.$docTypeCode = objectRef3;
            this.$docType = str;
            this.$cnicNumber = str2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return BioVerifyOptionsFragment.this.new AnonymousClass1(this.$citizenNumber, this.$appTypeCode, this.$docTypeCode, this.$docType, this.$cnicNumber, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = BioVerifyOptionsFragment.this.activity;
            AuthMainActivity authMainActivity2 = null;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.showLoader(authMainActivity);
            AuthMainActivity authMainActivity3 = BioVerifyOptionsFragment.this.activity;
            if (authMainActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity2 = authMainActivity3;
            }
            APIRequests aPIRequests = new APIRequests(authMainActivity2);
            CheckApplicationStatusRequest checkApplicationStatusRequest = BioVerifyOptionsFragment.this.getCheckApplicationStatusRequest(this.$citizenNumber.element, this.$appTypeCode.element, this.$docTypeCode.element);
            final BioVerifyOptionsFragment bioVerifyOptionsFragment = BioVerifyOptionsFragment.this;
            final String str = this.$docType;
            final String str2 = this.$cnicNumber;
            aPIRequests.checkApplicationStatus(checkApplicationStatusRequest, new Function3() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$checkApplicationStatus$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return BioVerifyOptionsFragment.AnonymousClass1.invokeSuspend$lambda$0(bioVerifyOptionsFragment, str, str2, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(BioVerifyOptionsFragment bioVerifyOptionsFragment, String str, String str2, JsonObject jsonObject, String str3, int i) {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = bioVerifyOptionsFragment.activity;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.hideLoader(authMainActivity);
            if (Intrinsics.areEqual(str3, "SUCCESS")) {
                bioVerifyOptionsFragment.processCheckApplicationStatusSuccessResponseResponse(jsonObject, str, str2);
            } else {
                bioVerifyOptionsFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final CheckApplicationStatusRequest getCheckApplicationStatusRequest(String cnic, String appType, String docType) {
        CheckApplicationStatusRequest checkApplicationStatusRequest = new CheckApplicationStatusRequest(null, null, null, 7, null);
        checkApplicationStatusRequest.setCitizenNumber(cnic);
        checkApplicationStatusRequest.setAppTypeCode(appType);
        checkApplicationStatusRequest.setDocumentCode(docType);
        return checkApplicationStatusRequest;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processCheckApplicationStatusSuccessResponseResponse(JsonObject jSonObject, String documentType, String cnic) {
        startPolc(cnic, StringsKt.trim((CharSequence) StringsKt.replace$default(getAuthMainSharedViewModel().getAccountHolderCnic(), "-", "", false, 4, (Object) null)).toString(), true, documentType);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            AuthMainActivity authMainActivity = null;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    for (ErrorResponse.Error error : errors) {
                    }
                    return;
                }
                return;
            }
            if (Intrinsics.areEqual(errorResponse.getStatus(), "BUSINESS_RULE_FAILED")) {
                NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                AuthMainActivity authMainActivity2 = this.activity;
                if (authMainActivity2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                } else {
                    authMainActivity = authMainActivity2;
                }
                Intrinsics.checkNotNull(errorResponse);
                NetworkErrorHandler.handleError$default(networkErrorHandler, authMainActivity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BioVerifyOptionsFragment.handleFailureCase$lambda$9(this.f$0);
                    }
                }, 8, null);
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            AuthMainActivity authMainActivity3 = this.activity;
            if (authMainActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity = authMainActivity3;
            }
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler2, authMainActivity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return BioVerifyOptionsFragment.handleFailureCase$lambda$10(this.f$0);
                }
            }, 8, null);
            return;
        }
        AuthMainActivity authMainActivity4 = null;
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        AuthMainActivity authMainActivity5 = this.activity;
        if (authMainActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity4 = authMainActivity5;
        }
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler3, authMainActivity4, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.BioVerifyOptionsFragment$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return BioVerifyOptionsFragment.handleFailureCase$lambda$11(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$9(BioVerifyOptionsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$10(BioVerifyOptionsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$11(BioVerifyOptionsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }
}