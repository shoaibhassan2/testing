package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda20 implements Function1 {
    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return DashboardFragment.handleResponse$lambda$33$lambda$32(((Integer) obj).intValue());
    }
}