package pk.gov.nadra.oneapp.auth.main.fragments;

import com.google.gson.JsonObject;
import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CancellationDeathFragment$checkCnicCrmsDeathService$1$$ExternalSyntheticLambda0 implements Function3 {
    public /* synthetic */ CancellationDeathFragment$checkCnicCrmsDeathService$1$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return CancellationDeathFragment.AnonymousClass1.invokeSuspend$lambda$0(cancellationDeathFragment, (JsonObject) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}