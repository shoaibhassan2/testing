package pk.gov.nadra.oneapp.auth.main.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AccessRestrictedDialogFragment$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public /* synthetic */ AccessRestrictedDialogFragment$$ExternalSyntheticLambda1() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AccessRestrictedDialogFragment.onCreateDialog$lambda$1(this.f$0, view);
    }
}