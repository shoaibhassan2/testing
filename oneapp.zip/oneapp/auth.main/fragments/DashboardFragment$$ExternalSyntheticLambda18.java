package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function1;
import pk.gov.nadra.oneapp.digitalvault.data.local.model.DigitalDocumentEntity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda18 implements Function1 {
    public final /* synthetic */ long f$1;

    public /* synthetic */ DashboardFragment$$ExternalSyntheticLambda18(long j) {
        docId = j;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return DashboardFragment.checkVaccineCertificate$lambda$13(this.f$0, docId, (DigitalDocumentEntity) obj);
    }
}