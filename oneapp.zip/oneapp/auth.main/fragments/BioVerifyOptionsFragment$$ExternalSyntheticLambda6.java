package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class BioVerifyOptionsFragment$$ExternalSyntheticLambda6 implements Function0 {
    public /* synthetic */ BioVerifyOptionsFragment$$ExternalSyntheticLambda6() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return BioVerifyOptionsFragment.handleFailureCase$lambda$11(this.f$0);
    }
}