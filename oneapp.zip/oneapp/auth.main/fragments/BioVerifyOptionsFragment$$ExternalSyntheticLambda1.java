package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function1;
import pk.gov.nadra.oneapp.models.dashboard.AppOptionsTokenResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class BioVerifyOptionsFragment$$ExternalSyntheticLambda1 implements Function1 {
    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return Boolean.valueOf(BioVerifyOptionsFragment.onViewCreated$lambda$0((AppOptionsTokenResponse.AllowedOption) obj));
    }
}