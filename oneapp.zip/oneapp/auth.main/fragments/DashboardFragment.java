package pk.gov.nadra.oneapp.auth.main.fragments;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Spannable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import net.sqlcipher.database.SQLiteDatabase;
import org.apache.commons.lang3.StringUtils;
import pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity;
import pk.gov.nadra.oneapp.auth.main.ApplicationContextHelper;
import pk.gov.nadra.oneapp.auth.main.adapters.DashboardItemsAdapter;
import pk.gov.nadra.oneapp.auth.main.databinding.DashboardFragmentBinding;
import pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment;
import pk.gov.nadra.oneapp.auth.main.viewModel.AppViewModelProvider;
import pk.gov.nadra.oneapp.auth.main.viewModel.AuthMainSharedViewModel;
import pk.gov.nadra.oneapp.auth.main.viewModel.SSOActionViewModel;
import pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.preferences.AppPreferences;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.DataProvider;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.LocaleHelper;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.RSAKeyPair;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.digitalid.views.DigitalIdActivity;
import pk.gov.nadra.oneapp.digitalvault.core.DeepUtils;
import pk.gov.nadra.oneapp.digitalvault.core.utils.ApiCallHelper;
import pk.gov.nadra.oneapp.digitalvault.core.utils.DVBottomSheetUtils;
import pk.gov.nadra.oneapp.digitalvault.core.utils.ExtentionsKt;
import pk.gov.nadra.oneapp.digitalvault.data.dto.DigitalQRLogsRequest;
import pk.gov.nadra.oneapp.digitalvault.data.local.db.DigitalIdDatabase;
import pk.gov.nadra.oneapp.digitalvault.data.local.model.DigitalDocumentEntity;
import pk.gov.nadra.oneapp.digitalvault.data.local.model.DigitalQRLogsEntity;
import pk.gov.nadra.oneapp.digitalvault.data.local.repository.DQRLocalRepositoryImpl;
import pk.gov.nadra.oneapp.digitalvault.data.local.repository.DVLocalRepositoryImpl;
import pk.gov.nadra.oneapp.digitalvault.data.mapper.DigitalQrLogsMapperKt;
import pk.gov.nadra.oneapp.digitalvault.data.remote.DigitalApiRequest;
import pk.gov.nadra.oneapp.digitalvault.data.repository.DigitalIdRepositoryImpl;
import pk.gov.nadra.oneapp.digitalvault.domain.enums.DigitalIdDocumentStatus;
import pk.gov.nadra.oneapp.digitalvault.domain.enums.DigitalIdDocumentTypes;
import pk.gov.nadra.oneapp.digitalvault.domain.model.DigitalIdDocumentItem;
import pk.gov.nadra.oneapp.digitalvault.domain.model.DigitalIdRequest;
import pk.gov.nadra.oneapp.digitalvault.domain.model.DigitalIdTransactionIdResponse;
import pk.gov.nadra.oneapp.digitalvault.domain.usecase.RequestDigitalIdUseCase;
import pk.gov.nadra.oneapp.digitalvault.presentation.activity.DVQRScannerActivity;
import pk.gov.nadra.oneapp.digitalvault.presentation.activity.DigitalIdHomeActivity;
import pk.gov.nadra.oneapp.digitalvault.presentation.base.UiUtils;
import pk.gov.nadra.oneapp.digitalvault.presentation.state.UiState;
import pk.gov.nadra.oneapp.digitalvault.presentation.viewmodel.DigitalIdViewModel;
import pk.gov.nadra.oneapp.digitalvault.presentation.viewmodel.QRScanLogsViewModel;
import pk.gov.nadra.oneapp.digitalvault.presentation.viewmodel.factory.DigitalIdViewModelFactory;
import pk.gov.nadra.oneapp.digitalvault.presentation.viewmodel.factory.QRScanLogsViewModelFactory;
import pk.gov.nadra.oneapp.etdTransfer.views.EtdVerificationActivity;
import pk.gov.nadra.oneapp.expedite.views.ExpediteActivity;
import pk.gov.nadra.oneapp.facialverif.views.FacialVerifyActivity;
import pk.gov.nadra.oneapp.familytree.views.FamilyTreeActivity;
import pk.gov.nadra.oneapp.mbvs.views.MBVSActivity;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintRequest;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintResponse;
import pk.gov.nadra.oneapp.models.dashboard.DashboardItem;
import pk.gov.nadra.oneapp.models.dashboard.InitAppSelection;
import pk.gov.nadra.oneapp.models.dashboard.ProcessingType;
import pk.gov.nadra.oneapp.models.login.LoginResponse;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;
import pk.gov.nadra.oneapp.relativeattestation.views.RelativeAttestationActivity;
import pk.gov.nadra.rahbar.android.activity.SplashActivity;

/* compiled from: DashboardFragment.kt */
@Metadata(d1 = {"\u0000Ò\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010.\u001a\u00020/2\b\u00100\u001a\u0004\u0018\u000101H\u0016J\u0010\u00102\u001a\u00020/2\u0006\u00103\u001a\u00020\u001aH\u0016J$\u00104\u001a\u0002052\u0006\u00106\u001a\u0002072\b\u00108\u001a\u0004\u0018\u0001092\b\u00100\u001a\u0004\u0018\u000101H\u0016J\u001a\u0010:\u001a\u00020/2\u0006\u0010;\u001a\u0002052\b\u00100\u001a\u0004\u0018\u000101H\u0016J\b\u0010<\u001a\u00020/H\u0002J\b\u0010=\u001a\u00020/H\u0002J\u0010\u0010>\u001a\u00020/2\u0006\u0010?\u001a\u00020@H\u0002J\b\u0010A\u001a\u00020/H\u0002J \u0010B\u001a\u00020/2\u0006\u0010C\u001a\u00020D2\u0006\u0010E\u001a\u00020F2\u0006\u0010G\u001a\u00020FH\u0002J\u0010\u0010H\u001a\u00020/2\u0006\u0010?\u001a\u00020@H\u0002J\u0010\u0010I\u001a\u00020/2\u0006\u0010J\u001a\u00020@H\u0002J\u0018\u0010N\u001a\u00020/2\u0006\u0010O\u001a\u00020@2\u0006\u0010P\u001a\u00020@H\u0002J\b\u0010Q\u001a\u00020/H\u0002J\b\u0010R\u001a\u00020/H\u0002J\b\u0010S\u001a\u00020/H\u0016J\u0010\u0010X\u001a\u00020/2\u0006\u0010Y\u001a\u00020FH\u0002J\b\u0010Z\u001a\u00020[H\u0002J\b\u0010\\\u001a\u00020/H\u0002J\b\u0010]\u001a\u00020/H\u0002J\b\u0010^\u001a\u00020/H\u0002J\b\u0010_\u001a\u00020/H\u0002J\b\u0010`\u001a\u00020/H\u0002J\b\u0010a\u001a\u00020/H\u0002J\b\u0010b\u001a\u00020/H\u0002J\b\u0010c\u001a\u00020/H\u0002J\b\u0010d\u001a\u00020/H\u0002J\u0018\u0010e\u001a\u00020/2\u0006\u0010f\u001a\u00020g2\u0006\u0010h\u001a\u00020*H\u0002J\b\u0010i\u001a\u00020jH\u0002J\b\u0010k\u001a\u00020/H\u0002J\b\u0010l\u001a\u00020/H\u0002J\b\u0010m\u001a\u00020/H\u0002J\b\u0010n\u001a\u00020/H\u0002J\b\u0010o\u001a\u00020/H\u0002J\b\u0010p\u001a\u00020/H\u0002J\b\u0010q\u001a\u00020/H\u0002J\b\u0010r\u001a\u00020/H\u0002J\b\u0010s\u001a\u00020/H\u0002J\b\u0010t\u001a\u00020/H\u0002J\b\u0010u\u001a\u00020/H\u0002J\b\u0010v\u001a\u00020[H\u0002J0\u0010w\u001a\u00020/2\u0006\u0010x\u001a\u00020F2\u0006\u0010y\u001a\u00020j2\u0006\u0010z\u001a\u00020j2\u0006\u0010{\u001a\u00020F2\u0006\u0010|\u001a\u00020}H\u0002J \u0010~\u001a\u00020/2\u0006\u0010\u007f\u001a\u00020F2\u0006\u0010y\u001a\u00020j2\u0006\u0010z\u001a\u00020jH\u0002J*\u0010\u0080\u0001\u001a\u00020/2\u0007\u0010\u0081\u0001\u001a\u00020g2\u0006\u0010\u007f\u001a\u00020F2\u0006\u0010y\u001a\u00020j2\u0006\u0010z\u001a\u00020jH\u0002J\t\u0010\u0082\u0001\u001a\u00020/H\u0002J\t\u0010\u0083\u0001\u001a\u00020/H\u0002J\t\u0010\u0084\u0001\u001a\u00020/H\u0002J\u001c\u0010\u0085\u0001\u001a\u00020/2\b\u0010\u0086\u0001\u001a\u00030\u0087\u00012\u0007\u0010\u0088\u0001\u001a\u00020(H\u0002J\t\u0010\u0089\u0001\u001a\u00020/H\u0002J\t\u0010\u008a\u0001\u001a\u00020/H\u0002J\u0012\u0010\u008b\u0001\u001a\u00020/2\u0007\u0010\u008c\u0001\u001a\u00020FH\u0002R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u001b\u0010\u000b\u001a\u00020\f8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000f\u0010\u0010\u001a\u0004\b\r\u0010\u000eR\u000e\u0010\u0011\u001a\u00020\u0012X\u0082.¢\u0006\u0002\n\u0000R\u001a\u0010\u0013\u001a\u00020\u0014X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R\u001a\u0010\u0019\u001a\u00020\u001aX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR\u000e\u0010\u001f\u001a\u00020 X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020&X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010'\u001a\u0004\u0018\u00010(X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020*X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010+\u001a\b\u0012\u0004\u0012\u00020-0,X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010K\u001a\u00020FX\u0086D¢\u0006\b\n\u0000\u001a\u0004\bL\u0010MR\u001c\u0010T\u001a\u0010\u0012\f\u0012\n W*\u0004\u0018\u00010V0V0UX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u008d\u0001"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/fragments/DashboardFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/DashboardFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/auth/main/databinding/DashboardFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/auth/main/views/AuthMainActivity;", "authMainSharedViewModel", "Lpk/gov/nadra/oneapp/auth/main/viewModel/AuthMainSharedViewModel;", "getAuthMainSharedViewModel", "()Lpk/gov/nadra/oneapp/auth/main/viewModel/AuthMainSharedViewModel;", "authMainSharedViewModel$delegate", "Lkotlin/Lazy;", "userCredentials", "Lpk/gov/nadra/oneapp/models/login/LoginResponse;", "preferences", "Lpk/gov/nadra/oneapp/commonutils/preferences/AppPreferences;", "getPreferences", "()Lpk/gov/nadra/oneapp/commonutils/preferences/AppPreferences;", "setPreferences", "(Lpk/gov/nadra/oneapp/commonutils/preferences/AppPreferences;)V", "contextWithLocale", "Landroid/content/Context;", "getContextWithLocale", "()Landroid/content/Context;", "setContextWithLocale", "(Landroid/content/Context;)V", "ssoActionViewModel", "Lpk/gov/nadra/oneapp/auth/main/viewModel/SSOActionViewModel;", "adapter", "Lpk/gov/nadra/oneapp/auth/main/adapters/DashboardItemsAdapter;", "digitalIdViewModel", "Lpk/gov/nadra/oneapp/digitalvault/presentation/viewmodel/DigitalIdViewModel;", "qrScanLogsViewModel", "Lpk/gov/nadra/oneapp/digitalvault/presentation/viewmodel/QRScanLogsViewModel;", "activeDocumentItem", "Lpk/gov/nadra/oneapp/digitalvault/domain/model/DigitalIdDocumentItem;", "uploadIndex", "", "uploadList", "", "Lpk/gov/nadra/oneapp/digitalvault/data/local/model/DigitalQRLogsEntity;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onAttach", "context", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "onViewCreated", Promotion.ACTION_VIEW, "attachDashboardViews", "initViewModel", "validateVaccineProcess", "docId", "", "dismissDialog", "showVaccineMessageBottomSheet", "entity", "Lpk/gov/nadra/oneapp/digitalvault/data/local/model/DigitalDocumentEntity;", "english", "", "urdu", "checkVaccineCertificate", "openVaccinationCertificates", "docTypeId", "TAG", "getTAG", "()Ljava/lang/String;", "applyForVaccineCertificate", "docType", "transactionId", "observeDocumentRequestState", "checkAndStartDigitalId", "onDestroyView", "intentLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "applyForServices", "productType", "getReactNativeData", "Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "startDigitalCard", "startExpedite", "startRelativeAttestationDocuments", "startRelativeAttestation", "startYoutube", "startVerifyDigitalCard", "startSimIssuance", "startVerifyPalsCard", "startRahbar", "handleFailureCase", "jsonResponse", "Lcom/google/gson/JsonObject;", "responseCode", "isAccountVerified", "", "showAccessRestrictedDialog", "startPALSDigitalCard", "startAppointmentSystem", "startFacialVerif", "startPayment", "startVehicleDigitalCard", "startPECDigitalCard", "startMBVS", "startTIDTracking", "startQrCodeVerification", "showUnderDevelopmentBottomSheet", "getReactNativeDataForFamilyTree", "launchFamilyTree", "citizenNumber", "applicantFingerprintsExist", "livelinessControl", "documentType", "verifyFingerprintResponse", "Lpk/gov/nadra/oneapp/models/crc/fingerprint/VerifyFingerprintResponse;", "getFamilyCompositionDocTypeService", "cnic", "processGetFamilyCompositionDocTypeSuccessResponse", "jSonObject", "startEtdVerification", "verifyNumberView", "showPrimaryNumberBottomSheet", "handleResponse", "response", "Lpk/gov/nadra/oneapp/digitalvault/domain/model/DigitalIdTransactionIdResponse;", "activeDocument", "getAllQrScanLogsFromLocal", "digitalQrScanLogObserver", "applyForProvincialCRMS", "province", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DashboardFragment extends Fragment {
    private DashboardFragmentBinding _binding;
    private DigitalIdDocumentItem activeDocumentItem;
    private AuthMainActivity activity;
    private DashboardItemsAdapter adapter;

    /* renamed from: authMainSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy authMainSharedViewModel;
    public Context contextWithLocale;
    private DigitalIdViewModel digitalIdViewModel;
    private final ActivityResultLauncher<Intent> intentLauncher;
    public AppPreferences preferences;
    private QRScanLogsViewModel qrScanLogsViewModel;
    private SSOActionViewModel ssoActionViewModel;
    private int uploadIndex;
    private LoginResponse userCredentials;
    private List<DigitalQRLogsEntity> uploadList = CollectionsKt.emptyList();
    private final String TAG = "de_digi";

    /* compiled from: DashboardFragment.kt */
    @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[DigitalIdDocumentStatus.values().length];
            try {
                iArr[DigitalIdDocumentStatus.INITIALIZED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[DigitalIdDocumentStatus.SUCCESS.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[DigitalIdDocumentStatus.ACTIVE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[DigitalIdDocumentStatus.EXPIRED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[DigitalIdDocumentStatus.PENDING_DOWNLOAD.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[DigitalIdDocumentStatus.FAILURE.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[DigitalIdDocumentStatus.ERROR.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr[DigitalIdDocumentStatus.BLOCKED.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr[DigitalIdDocumentStatus.CANCELLED.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                iArr[DigitalIdDocumentStatus.RENEWED.ordinal()] = 10;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                iArr[DigitalIdDocumentStatus.REPRINT.ordinal()] = 11;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                iArr[DigitalIdDocumentStatus.MODIFIED.ordinal()] = 12;
            } catch (NoSuchFieldError unused12) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public DashboardFragment() {
        final DashboardFragment dashboardFragment = this;
        final Function0 function0 = null;
        this.authMainSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(dashboardFragment, Reflection.getOrCreateKotlinClass(AuthMainSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = dashboardFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = dashboardFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = dashboardFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda22
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                DashboardFragment.intentLauncher$lambda$18(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.intentLauncher = activityResultLauncherRegisterForActivityResult;
    }

    private final DashboardFragmentBinding getBinding() {
        DashboardFragmentBinding dashboardFragmentBinding = this._binding;
        Intrinsics.checkNotNull(dashboardFragmentBinding);
        return dashboardFragmentBinding;
    }

    private final AuthMainSharedViewModel getAuthMainSharedViewModel() {
        return (AuthMainSharedViewModel) this.authMainSharedViewModel.getValue();
    }

    public final AppPreferences getPreferences() {
        AppPreferences appPreferences = this.preferences;
        if (appPreferences != null) {
            return appPreferences;
        }
        Intrinsics.throwUninitializedPropertyAccessException("preferences");
        return null;
    }

    public final void setPreferences(AppPreferences appPreferences) {
        Intrinsics.checkNotNullParameter(appPreferences, "<set-?>");
        this.preferences = appPreferences;
    }

    public final Context getContextWithLocale() {
        Context context = this.contextWithLocale;
        if (context != null) {
            return context;
        }
        Intrinsics.throwUninitializedPropertyAccessException("contextWithLocale");
        return null;
    }

    public final void setContextWithLocale(Context context) {
        Intrinsics.checkNotNullParameter(context, "<set-?>");
        this.contextWithLocale = context;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initViewModel();
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity");
        AuthMainActivity authMainActivity = (AuthMainActivity) fragmentActivityRequireActivity;
        this.activity = authMainActivity;
        AuthMainActivity authMainActivity2 = null;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        setPreferences(AppPreferences.getInstance(authMainActivity));
        AuthMainActivity authMainActivity3 = this.activity;
        if (authMainActivity3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity2 = authMainActivity3;
        }
        this.userCredentials = new SharedPreferencesTokenProvider(authMainActivity2).getUserCredentials();
        LocaleHelper localeHelper = LocaleHelper.INSTANCE;
        String appLanguage = getPreferences().getAppLanguage();
        Intrinsics.checkNotNullExpressionValue(appLanguage, "getAppLanguage(...)");
        super.onAttach(localeHelper.wrapContext(context, appLanguage));
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        LocaleHelper localeHelper = LocaleHelper.INSTANCE;
        Context contextRequireContext = requireContext();
        Intrinsics.checkNotNullExpressionValue(contextRequireContext, "requireContext(...)");
        String appLanguage = getPreferences().getAppLanguage();
        Intrinsics.checkNotNullExpressionValue(appLanguage, "getAppLanguage(...)");
        setContextWithLocale(localeHelper.wrapContext(contextRequireContext, appLanguage));
        this._binding = DashboardFragmentBinding.inflate(inflater.cloneInContext(new ContextThemeWrapper(getContextWithLocale(), R.style.Theme_CommonUI)), container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        verifyNumberView();
        getBinding();
        attachDashboardViews();
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        if (AppPreferences.getInstance(authMainActivity).isVerifiableVaultEnable().booleanValue()) {
            observeDocumentRequestState();
        }
        digitalQrScanLogObserver();
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                DashboardFragment.onViewCreated$lambda$1(this.f$0);
            }
        }, 2000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$1(DashboardFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getAllQrScanLogsFromLocal();
    }

    private final void attachDashboardViews() {
        DashboardFragmentBinding binding = getBinding();
        boolean z = AppPreferences.getInstance(getContext()).isVerifiableVaultEnable().booleanValue() && AppPreferences.getInstance(getContext()).isDigitalCardEnable().booleanValue();
        DataProvider dataProvider = DataProvider.INSTANCE;
        Context contextWithLocale = getContextWithLocale();
        LoginResponse loginResponse = this.userCredentials;
        DashboardItemsAdapter dashboardItemsAdapter = null;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Boolean boolIsNimsCertificateEnable = AppPreferences.getInstance(authMainActivity).isNimsCertificateEnable();
        Intrinsics.checkNotNullExpressionValue(boolIsNimsCertificateEnable, "isNimsCertificateEnable(...)");
        final List<DashboardItem> dashboardItems = dataProvider.getDashboardItems(contextWithLocale, loginResponse, z, boolIsNimsCertificateEnable.booleanValue());
        RecyclerView recyclerView = binding.dashboardRecyclerView;
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity2 = null;
        }
        GridLayoutManager gridLayoutManager = new GridLayoutManager(authMainActivity2, 4);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$attachDashboardViews$1$1$1
            @Override // androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup
            public int getSpanSize(int position) {
                DashboardItem dashboardItem = dashboardItems.get(position);
                if ((dashboardItem instanceof DashboardItem.DigitalCard) || (dashboardItem instanceof DashboardItem.SectionHeader)) {
                    return 4;
                }
                return dashboardItem instanceof DashboardItem.ServiceItem ? 1 : 0;
            }
        });
        recyclerView.setLayoutManager(gridLayoutManager);
        this.adapter = new DashboardItemsAdapter(dashboardItems, new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return DashboardFragment.attachDashboardViews$lambda$6$lambda$3(this.f$0, (DashboardItem.DigitalCard) obj);
            }
        }, new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return DashboardFragment.attachDashboardViews$lambda$6$lambda$4(this.f$0, (DashboardItem.ServiceItem) obj);
            }
        });
        RecyclerView recyclerView2 = getBinding().dashboardRecyclerView;
        DashboardItemsAdapter dashboardItemsAdapter2 = this.adapter;
        if (dashboardItemsAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
            dashboardItemsAdapter2 = null;
        }
        recyclerView2.setAdapter(dashboardItemsAdapter2);
        DashboardItemsAdapter dashboardItemsAdapter3 = this.adapter;
        if (dashboardItemsAdapter3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
        } else {
            dashboardItemsAdapter = dashboardItemsAdapter3;
        }
        dashboardItemsAdapter.setData(dashboardItems);
        getAuthMainSharedViewModel().getSearchQuery().observe(getViewLifecycleOwner(), new DashboardFragment$sam$androidx_lifecycle_Observer$0(new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda9
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return DashboardFragment.attachDashboardViews$lambda$6$lambda$5(this.f$0, (String) obj);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit attachDashboardViews$lambda$6$lambda$3(DashboardFragment this$0, DashboardItem.DigitalCard item) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(item, "item");
        if (!this$0.isAccountVerified()) {
            return Unit.INSTANCE;
        }
        if (Intrinsics.areEqual(item.getKey(), Constant.KEY_DIGITAL_ID)) {
            this$0.checkAndStartDigitalId();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public static final Unit attachDashboardViews$lambda$6$lambda$4(DashboardFragment this$0, DashboardItem.ServiceItem item) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(item, "item");
        if (!this$0.isAccountVerified()) {
            return Unit.INSTANCE;
        }
        this$0.getAuthMainSharedViewModel().setDashboardOptionSelectionType("");
        this$0.getAuthMainSharedViewModel().setDashboardInboxFilterType("");
        String key = item.getKey();
        SSOActionViewModel sSOActionViewModel = null;
        LoginResponse loginResponse = null;
        AuthMainActivity authMainActivity = null;
        LoginResponse loginResponse2 = null;
        AuthMainActivity authMainActivity2 = null;
        AuthMainActivity authMainActivity3 = null;
        switch (key.hashCode()) {
            case -2021888165:
                if (key.equals(Constant.KEY_ICT)) {
                    this$0.applyForProvincialCRMS(Constant.KEY_ICT);
                    break;
                }
                break;
            case -1935699042:
                if (key.equals("expedite")) {
                    this$0.startExpedite();
                    break;
                }
                break;
            case -1804791407:
                if (key.equals(Constant.KEY_DIGITAL_ID_APPLY)) {
                    AuthMainActivity authMainActivity4 = this$0.activity;
                    if (authMainActivity4 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("activity");
                        authMainActivity4 = null;
                    }
                    if (!AppPreferences.getInstance(authMainActivity4).isVerifiableVaultEnable().booleanValue()) {
                        this$0.startDigitalCard();
                        break;
                    } else {
                        SSOActionViewModel sSOActionViewModel2 = this$0.ssoActionViewModel;
                        if (sSOActionViewModel2 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("ssoActionViewModel");
                        } else {
                            sSOActionViewModel = sSOActionViewModel2;
                        }
                        sSOActionViewModel.setNavigateDigitalId(true);
                        break;
                    }
                }
                break;
            case -1695880543:
                if (key.equals(Constant.KEY_QR_SCAN)) {
                    this$0.startQrCodeVerification();
                    break;
                }
                break;
            case -1474995297:
                if (key.equals(Constant.KEY_APPOINTMENT)) {
                    this$0.startAppointmentSystem();
                    break;
                }
                break;
            case -1259263365:
                if (key.equals(Constant.KEY_VERIFY_LICENSE)) {
                    this$0.startVerifyDigitalCard();
                    break;
                }
                break;
            case -1192703293:
                if (key.equals("sim_issuance")) {
                    this$0.startSimIssuance();
                    break;
                }
                break;
            case -1120892669:
                if (key.equals(Constant.KEY_CANCELLATION)) {
                    AuthMainActivity authMainActivity5 = this$0.activity;
                    if (authMainActivity5 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("activity");
                    } else {
                        authMainActivity3 = authMainActivity5;
                    }
                    authMainActivity3.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.cancellationDeathFragment);
                    break;
                }
                break;
            case -983998444:
                if (key.equals(Constant.KEY_KPK)) {
                    this$0.applyForProvincialCRMS(Constant.KEY_KPK);
                    break;
                }
                break;
            case -977068446:
                if (key.equals(Constant.KEY_PUNJAB)) {
                    this$0.applyForProvincialCRMS(Constant.KEY_PUNJAB);
                    break;
                }
                break;
            case -733629147:
                if (key.equals(Constant.KEY_SUCCESSION)) {
                    this$0.getAuthMainSharedViewModel().setDashboardOptionSelectionType("BIOMETRIC_VERIFY");
                    this$0.applyForServices("BIOMETRIC_VERIFY");
                    break;
                }
                break;
            case -709624112:
                if (key.equals(Constant.KEY_ATTESTATION)) {
                    this$0.startRelativeAttestation();
                    break;
                }
                break;
            case -697586694:
                if (key.equals(Constant.KEY_UNDER_PROCESS_APPLICATIONS)) {
                    this$0.getAuthMainSharedViewModel().setDashboardInboxFilterType("inprocess");
                    AuthMainActivity authMainActivity6 = this$0.activity;
                    if (authMainActivity6 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("activity");
                    } else {
                        authMainActivity2 = authMainActivity6;
                    }
                    authMainActivity2.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.inboxFragment);
                    break;
                }
                break;
            case -660917644:
                if (key.equals(Constant.KEY_NADRA_CENTER)) {
                    this$0.startRahbar();
                    break;
                }
                break;
            case -359119563:
                if (key.equals(Constant.KEY_IDENTIFY_CITIZEN)) {
                    this$0.startFacialVerif();
                    break;
                }
                break;
            case -242755078:
                if (key.equals(Constant.KEY_UPLOAD_DOC)) {
                    this$0.startRelativeAttestationDocuments();
                    break;
                }
                break;
            case 98772:
                if (key.equals(Constant.KEY_CRC)) {
                    this$0.getAuthMainSharedViewModel().setDashboardOptionSelectionType("CRC");
                    this$0.applyForServices("CERTIFICATE");
                    break;
                }
                break;
            case 101655:
                if (key.equals(Constant.KEY_FRC)) {
                    this$0.getAuthMainSharedViewModel().setDashboardOptionSelectionType("FRC");
                    LoginResponse loginResponse3 = this$0.userCredentials;
                    if (loginResponse3 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
                    } else {
                        loginResponse2 = loginResponse3;
                    }
                    this$0.getFamilyCompositionDocTypeService(loginResponse2.getCitizenNumber(), true, true);
                    break;
                }
                break;
            case 110747:
                if (key.equals(Constant.KEY_PAL)) {
                    this$0.startVerifyPalsCard();
                    break;
                }
                break;
            case 110862:
                if (key.equals(Constant.KEY_PEC)) {
                    this$0.startPECDigitalCard();
                    break;
                }
                break;
            case 3446710:
                if (key.equals(Constant.KEY_POLC)) {
                    this$0.getAuthMainSharedViewModel().setDashboardOptionSelectionType("POLC");
                    this$0.applyForServices("BIOMETRIC_VERIFY");
                    break;
                }
                break;
            case 3450336:
                if (key.equals(Constant.KEY_PSEB)) {
                    this$0.getAuthMainSharedViewModel().setDashboardOptionSelectionType("PSEB");
                    this$0.applyForServices("BIOMETRIC_VERIFY");
                    break;
                }
                break;
            case 109441884:
                if (key.equals(Constant.KEY_SINDH)) {
                    this$0.applyForProvincialCRMS(Constant.KEY_SINDH);
                    break;
                }
                break;
            case 118849818:
                if (key.equals(Constant.KEY_DIGITAL_LICENSE)) {
                    this$0.startPALSDigitalCard();
                    break;
                }
                break;
            case 130634967:
                if (key.equals(Constant.KEY_DIGITAL_CARD)) {
                    this$0.startMBVS();
                    break;
                }
                break;
            case 370225550:
                if (key.equals(Constant.KEY_DIVORCED)) {
                    this$0.getAuthMainSharedViewModel().setDashboardOptionSelectionType("CANCEL_DIVORCED");
                    this$0.applyForServices("CANCELLATION");
                    break;
                }
                break;
            case 1216777234:
                if (key.equals(Constant.KEY_PASSPORT)) {
                    this$0.getAuthMainSharedViewModel().setDashboardOptionSelectionType("PASSPORT");
                    this$0.applyForServices("BIOMETRIC_VERIFY");
                    break;
                }
                break;
            case 1270488759:
                if (key.equals("tracking")) {
                    this$0.startTIDTracking();
                    break;
                }
                break;
            case 1306833226:
                if (key.equals(Constant.KEY_VACCINE_CERT_YELLOW_FEVER)) {
                    this$0.validateVaccineProcess(DigitalIdDocumentTypes.YELLOW_FEVER_VACCINE_CERT.getId());
                    break;
                }
                break;
            case 1382682413:
                if (key.equals(Constant.KEY_PAYMENTS)) {
                    this$0.startPayment();
                    break;
                }
                break;
            case 1398810800:
                if (key.equals(Constant.KEY_BALOCHISTAN)) {
                    this$0.applyForProvincialCRMS(Constant.KEY_BALOCHISTAN);
                    break;
                }
                break;
            case 1512673927:
                if (key.equals(Constant.KEY_ICT_VEHICLE)) {
                    this$0.startVehicleDigitalCard();
                    break;
                }
                break;
            case 1598792921:
                if (key.equals(Constant.KEY_GB)) {
                    this$0.applyForProvincialCRMS(Constant.KEY_GB);
                    break;
                }
                break;
            case 1652301748:
                if (key.equals("id_card")) {
                    this$0.applyForServices("CARD");
                    break;
                }
                break;
            case 1792072436:
                if (key.equals(Constant.KEY_VACCINE_CERT_COVID_19)) {
                    this$0.validateVaccineProcess(DigitalIdDocumentTypes.COVID_VACCINE_CERT.getId());
                    break;
                }
                break;
            case 1803092966:
                if (key.equals(Constant.KEY_SURRENDER)) {
                    this$0.getAuthMainSharedViewModel().setDashboardOptionSelectionType("CANCEL");
                    this$0.applyForServices("CANCELLATION");
                    break;
                }
                break;
            case 1804068610:
                if (key.equals(Constant.KEY_VACCINE_CERT_POLIO)) {
                    this$0.validateVaccineProcess(DigitalIdDocumentTypes.POLIO_VACCINE_CERT.getId());
                    break;
                }
                break;
            case 1823110553:
                if (key.equals("arms_license")) {
                    this$0.applyForServices("ARMS_LICENSE");
                    break;
                }
                break;
            case 1976887959:
                if (key.equals(Constant.KEY_COMPLETED_APPLICATIONS)) {
                    this$0.getAuthMainSharedViewModel().setDashboardInboxFilterType("completed");
                    AuthMainActivity authMainActivity7 = this$0.activity;
                    if (authMainActivity7 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("activity");
                    } else {
                        authMainActivity = authMainActivity7;
                    }
                    authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.inboxFragment);
                    break;
                }
                break;
            case 1996606799:
                if (key.equals(Constant.KEY_FAMILY_COMPOSITION)) {
                    LoginResponse loginResponse4 = this$0.userCredentials;
                    if (loginResponse4 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
                    } else {
                        loginResponse = loginResponse4;
                    }
                    this$0.getFamilyCompositionDocTypeService(loginResponse.getCitizenNumber(), true, true);
                    break;
                }
                break;
            case 2094347879:
                if (key.equals(Constant.KEY_AJK)) {
                    this$0.applyForProvincialCRMS(Constant.KEY_AJK);
                    break;
                }
                break;
            case 2139794334:
                if (key.equals(Constant.KEY_VEHICLE_TRANSFER)) {
                    this$0.startEtdVerification();
                    break;
                }
                break;
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit attachDashboardViews$lambda$6$lambda$5(DashboardFragment this$0, String str) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        DashboardItemsAdapter dashboardItemsAdapter = this$0.adapter;
        if (dashboardItemsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
            dashboardItemsAdapter = null;
        }
        Intrinsics.checkNotNull(str);
        RecyclerView dashboardRecyclerView = this$0.getBinding().dashboardRecyclerView;
        Intrinsics.checkNotNullExpressionValue(dashboardRecyclerView, "dashboardRecyclerView");
        dashboardItemsAdapter.filter(str, dashboardRecyclerView);
        return Unit.INSTANCE;
    }

    private final void initViewModel() {
        AuthMainActivity authMainActivity = this.activity;
        AuthMainActivity authMainActivity2 = null;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        DigitalApiRequest digitalApiRequest = new DigitalApiRequest(authMainActivity);
        DigitalIdDatabase.Companion companion = DigitalIdDatabase.INSTANCE;
        AuthMainActivity authMainActivity3 = this.activity;
        if (authMainActivity3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity3 = null;
        }
        DigitalIdDatabase companion2 = companion.getInstance(authMainActivity3);
        Intrinsics.checkNotNull(companion2);
        DigitalIdViewModelFactory digitalIdViewModelFactory = new DigitalIdViewModelFactory(new RequestDigitalIdUseCase(new DigitalIdRepositoryImpl(digitalApiRequest)), new DVLocalRepositoryImpl(companion2.digitalDao()));
        AuthMainActivity authMainActivity4 = this.activity;
        if (authMainActivity4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity4 = null;
        }
        this.digitalIdViewModel = (DigitalIdViewModel) new ViewModelProvider(authMainActivity4, digitalIdViewModelFactory).get(DigitalIdViewModel.class);
        this.ssoActionViewModel = (SSOActionViewModel) new ViewModelProvider(AppViewModelProvider.INSTANCE, ViewModelProvider.AndroidViewModelFactory.INSTANCE.getInstance(ApplicationContextHelper.INSTANCE.getApplicationContext())).get(SSOActionViewModel.class);
        QRScanLogsViewModelFactory qRScanLogsViewModelFactory = new QRScanLogsViewModelFactory(new DQRLocalRepositoryImpl(companion2.digitalQrDao()));
        AuthMainActivity authMainActivity5 = this.activity;
        if (authMainActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity2 = authMainActivity5;
        }
        this.qrScanLogsViewModel = (QRScanLogsViewModel) new ViewModelProvider(authMainActivity2, qRScanLogsViewModelFactory).get(QRScanLogsViewModel.class);
    }

    private final void validateVaccineProcess(long docId) {
        AuthMainActivity authMainActivity = this.activity;
        LoginResponse loginResponse = null;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        if (AppPreferences.getInstance(authMainActivity).isVerifiableVaultEnable().booleanValue()) {
            LoginResponse loginResponse2 = this.userCredentials;
            if (loginResponse2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
                loginResponse2 = null;
            }
            if (loginResponse2.getPrimaryNumberFeatureEnabled()) {
                LoginResponse loginResponse3 = this.userCredentials;
                if (loginResponse3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
                } else {
                    loginResponse = loginResponse3;
                }
                if (!loginResponse.getPrimaryContactConfigured()) {
                    showPrimaryNumberBottomSheet();
                    return;
                } else {
                    checkVaccineCertificate(docId);
                    return;
                }
            }
            checkVaccineCertificate(docId);
        }
    }

    private final void dismissDialog() {
        try {
            BottomSheetUtils.INSTANCE.getDialog().dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private final void showVaccineMessageBottomSheet(DigitalDocumentEntity entity, String english, String urdu) {
        dismissDialog();
        DeepUtils deepUtils = DeepUtils.INSTANCE;
        AuthMainActivity authMainActivity = this.activity;
        AuthMainActivity authMainActivity2 = null;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Bitmap bitmapDrawableToBitmap = deepUtils.drawableToBitmap(authMainActivity, UiUtils.INSTANCE.drawableOnStatus(entity.getStatus()));
        AuthMainActivity authMainActivity3 = this.activity;
        if (authMainActivity3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity3 = null;
        }
        Spannable combineString = ExtentionsKt.getCombineString(authMainActivity3, pk.gov.nadra.oneapp.digitalvault.R.string.close, StringUtils.SPACE, true);
        UiUtils uiUtils = UiUtils.INSTANCE;
        AuthMainActivity authMainActivity4 = this.activity;
        if (authMainActivity4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity4 = null;
        }
        Spannable spannableBottomSheetsVaccineDescriptionOnStatus$default = UiUtils.bottomSheetsVaccineDescriptionOnStatus$default(uiUtils, authMainActivity4, entity.getStatus(), english, urdu, false, 16, null);
        DVBottomSheetUtils dVBottomSheetUtils = DVBottomSheetUtils.INSTANCE;
        AuthMainActivity authMainActivity5 = this.activity;
        if (authMainActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity5 = null;
        }
        AuthMainActivity authMainActivity6 = authMainActivity5;
        UiUtils uiUtils2 = UiUtils.INSTANCE;
        AuthMainActivity authMainActivity7 = this.activity;
        if (authMainActivity7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity2 = authMainActivity7;
        }
        dVBottomSheetUtils.showMessageBottomSheet(authMainActivity6, bitmapDrawableToBitmap, uiUtils2.bottomSheetsLableOnStatus(authMainActivity2, entity.getStatus()), spannableBottomSheetsVaccineDescriptionOnStatus$default, combineString, (96 & 32) != 0 ? false : false, (96 & 64) != 0 ? "" : null, (Function0<Unit>) new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda16
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        }, (Function0<Unit>) new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda17
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        });
    }

    private final void checkVaccineCertificate(final long docId) {
        DigitalIdViewModel digitalIdViewModel = this.digitalIdViewModel;
        if (digitalIdViewModel == null) {
            Intrinsics.throwUninitializedPropertyAccessException("digitalIdViewModel");
            digitalIdViewModel = null;
        }
        digitalIdViewModel.getDocumentById(docId, new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda18
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return DashboardFragment.checkVaccineCertificate$lambda$13(this.f$0, docId, (DigitalDocumentEntity) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit checkVaccineCertificate$lambda$13(final DashboardFragment this$0, final long j, final DigitalDocumentEntity digitalDocumentEntity) {
        String englishPlace;
        String urduPlace;
        String englishPlace2;
        String urduPlace2;
        String englishPlace3;
        String urduPlace3;
        String englishPlace4;
        String urduPlace4;
        String englishPlace5;
        String urduPlace5;
        String englishPlace6;
        String urduPlace6;
        String englishPlace7;
        String urduPlace7;
        String englishPlace8;
        String urduPlace8;
        String englishPlace9;
        String urduPlace9;
        String englishPlace10;
        String urduPlace10;
        String strName;
        String strName2;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        String str = "";
        if (digitalDocumentEntity == null) {
            int i = (int) j;
            DigitalIdDocumentTypes digitalIdDocumentTypesFromId = DigitalIdDocumentTypes.INSTANCE.fromId(j);
            this$0.activeDocumentItem = new DigitalIdDocumentItem("", "", 0, i, (digitalIdDocumentTypesFromId == null || (strName2 = digitalIdDocumentTypesFromId.name()) == null) ? "" : strName2, "", null);
            this$0.applyForVaccineCertificate(j, -1L);
            return Unit.INSTANCE;
        }
        int documentId = (int) digitalDocumentEntity.getDocumentId();
        DigitalIdDocumentTypes digitalIdDocumentTypesFromId2 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
        this$0.activeDocumentItem = new DigitalIdDocumentItem("", "", 0, documentId, (digitalIdDocumentTypesFromId2 == null || (strName = digitalIdDocumentTypesFromId2.name()) == null) ? "" : strName, "", null);
        AuthMainActivity authMainActivity = null;
        switch (WhenMappings.$EnumSwitchMapping$0[DigitalIdDocumentStatus.valueOf(digitalDocumentEntity.getStatus()).ordinal()]) {
            case 1:
                this$0.applyForVaccineCertificate(j, digitalDocumentEntity.getTransactionId());
                break;
            case 2:
                Log.d("tag_response", digitalDocumentEntity.getVerifiableCredential());
                if (DeepUtils.INSTANCE.isVCExpired(digitalDocumentEntity.getVerifiableCredential())) {
                    DigitalDocumentEntity digitalDocumentEntityCopy$default = DigitalDocumentEntity.copy$default(digitalDocumentEntity, 0, 0L, null, 0L, null, null, false, null, "EXPIRED", 0L, 0L, null, null, false, false, 32511, null);
                    DigitalIdDocumentTypes digitalIdDocumentTypesFromId3 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                    if (digitalIdDocumentTypesFromId3 == null || (englishPlace = digitalIdDocumentTypesFromId3.getEnglishPlace()) == null) {
                        englishPlace = "";
                    }
                    DigitalIdDocumentTypes digitalIdDocumentTypesFromId4 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                    if (digitalIdDocumentTypesFromId4 == null || (urduPlace = digitalIdDocumentTypesFromId4.getUrduPlace()) == null) {
                        urduPlace = "";
                    }
                    this$0.showVaccineMessageBottomSheet(digitalDocumentEntityCopy$default, englishPlace, urduPlace);
                    break;
                } else {
                    this$0.openVaccinationCertificates(digitalDocumentEntity.getDocumentId());
                    break;
                }
                break;
            case 3:
                if (DeepUtils.INSTANCE.isVCExpired(digitalDocumentEntity.getVerifiableCredential())) {
                    DigitalDocumentEntity digitalDocumentEntityCopy$default2 = DigitalDocumentEntity.copy$default(digitalDocumentEntity, 0, 0L, null, 0L, null, null, false, null, "EXPIRED", 0L, 0L, null, null, false, false, 32511, null);
                    DigitalIdDocumentTypes digitalIdDocumentTypesFromId5 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                    if (digitalIdDocumentTypesFromId5 == null || (englishPlace2 = digitalIdDocumentTypesFromId5.getEnglishPlace()) == null) {
                        englishPlace2 = "";
                    }
                    DigitalIdDocumentTypes digitalIdDocumentTypesFromId6 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                    if (digitalIdDocumentTypesFromId6 == null || (urduPlace2 = digitalIdDocumentTypesFromId6.getUrduPlace()) == null) {
                        urduPlace2 = "";
                    }
                    this$0.showVaccineMessageBottomSheet(digitalDocumentEntityCopy$default2, englishPlace2, urduPlace2);
                    break;
                } else {
                    this$0.openVaccinationCertificates(digitalDocumentEntity.getDocumentId());
                    break;
                }
                break;
            case 4:
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId7 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId7 == null || (englishPlace3 = digitalIdDocumentTypesFromId7.getEnglishPlace()) == null) {
                    englishPlace3 = "";
                }
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId8 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId8 == null || (urduPlace3 = digitalIdDocumentTypesFromId8.getUrduPlace()) == null) {
                    urduPlace3 = "";
                }
                this$0.showVaccineMessageBottomSheet(digitalDocumentEntity, englishPlace3, urduPlace3);
                break;
            case 5:
                this$0.applyForVaccineCertificate(j, digitalDocumentEntity.getTransactionId());
                break;
            case 6:
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId9 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId9 == null || (englishPlace4 = digitalIdDocumentTypesFromId9.getEnglishPlace()) == null) {
                    englishPlace4 = "";
                }
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId10 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId10 == null || (urduPlace4 = digitalIdDocumentTypesFromId10.getUrduPlace()) == null) {
                    urduPlace4 = "";
                }
                this$0.showVaccineMessageBottomSheet(digitalDocumentEntity, englishPlace4, urduPlace4);
                break;
            case 7:
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId11 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId11 == null || (englishPlace5 = digitalIdDocumentTypesFromId11.getEnglishPlace()) == null) {
                    englishPlace5 = "";
                }
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId12 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId12 == null || (urduPlace5 = digitalIdDocumentTypesFromId12.getUrduPlace()) == null) {
                    urduPlace5 = "";
                }
                this$0.showVaccineMessageBottomSheet(digitalDocumentEntity, englishPlace5, urduPlace5);
                break;
            case 8:
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId13 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId13 == null || (englishPlace6 = digitalIdDocumentTypesFromId13.getEnglishPlace()) == null) {
                    englishPlace6 = "";
                }
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId14 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId14 == null || (urduPlace6 = digitalIdDocumentTypesFromId14.getUrduPlace()) == null) {
                    urduPlace6 = "";
                }
                this$0.showVaccineMessageBottomSheet(digitalDocumentEntity, englishPlace6, urduPlace6);
                break;
            case 9:
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId15 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId15 == null || (englishPlace7 = digitalIdDocumentTypesFromId15.getEnglishPlace()) == null) {
                    englishPlace7 = "";
                }
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId16 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId16 == null || (urduPlace7 = digitalIdDocumentTypesFromId16.getUrduPlace()) == null) {
                    urduPlace7 = "";
                }
                this$0.showVaccineMessageBottomSheet(digitalDocumentEntity, englishPlace7, urduPlace7);
                break;
            case 10:
                UiUtils uiUtils = UiUtils.INSTANCE;
                AuthMainActivity authMainActivity2 = this$0.activity;
                if (authMainActivity2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                } else {
                    authMainActivity = authMainActivity2;
                }
                AuthMainActivity authMainActivity3 = authMainActivity;
                String status = digitalDocumentEntity.getStatus();
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId17 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId17 == null || (englishPlace8 = digitalIdDocumentTypesFromId17.getEnglishPlace()) == null) {
                    englishPlace8 = "";
                }
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId18 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId18 != null && (urduPlace8 = digitalIdDocumentTypesFromId18.getUrduPlace()) != null) {
                    str = urduPlace8;
                }
                uiUtils.showVaccineCertificateUpdateBottomSheet(authMainActivity3, digitalDocumentEntity, status, englishPlace8, str, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return DashboardFragment.checkVaccineCertificate$lambda$13$lambda$12$lambda$9(this.f$0, digitalDocumentEntity, j);
                    }
                });
                break;
            case 11:
                UiUtils uiUtils2 = UiUtils.INSTANCE;
                AuthMainActivity authMainActivity4 = this$0.activity;
                if (authMainActivity4 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                } else {
                    authMainActivity = authMainActivity4;
                }
                AuthMainActivity authMainActivity5 = authMainActivity;
                String status2 = digitalDocumentEntity.getStatus();
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId19 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId19 == null || (englishPlace9 = digitalIdDocumentTypesFromId19.getEnglishPlace()) == null) {
                    englishPlace9 = "";
                }
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId20 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId20 != null && (urduPlace9 = digitalIdDocumentTypesFromId20.getUrduPlace()) != null) {
                    str = urduPlace9;
                }
                uiUtils2.showVaccineCertificateUpdateBottomSheet(authMainActivity5, digitalDocumentEntity, status2, englishPlace9, str, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return DashboardFragment.checkVaccineCertificate$lambda$13$lambda$12$lambda$10(this.f$0, digitalDocumentEntity, j);
                    }
                });
                break;
            case 12:
                UiUtils uiUtils3 = UiUtils.INSTANCE;
                AuthMainActivity authMainActivity6 = this$0.activity;
                if (authMainActivity6 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                } else {
                    authMainActivity = authMainActivity6;
                }
                AuthMainActivity authMainActivity7 = authMainActivity;
                String status3 = digitalDocumentEntity.getStatus();
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId21 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId21 == null || (englishPlace10 = digitalIdDocumentTypesFromId21.getEnglishPlace()) == null) {
                    englishPlace10 = "";
                }
                DigitalIdDocumentTypes digitalIdDocumentTypesFromId22 = DigitalIdDocumentTypes.INSTANCE.fromId(j);
                if (digitalIdDocumentTypesFromId22 != null && (urduPlace10 = digitalIdDocumentTypesFromId22.getUrduPlace()) != null) {
                    str = urduPlace10;
                }
                uiUtils3.showVaccineCertificateUpdateBottomSheet(authMainActivity7, digitalDocumentEntity, status3, englishPlace10, str, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return DashboardFragment.checkVaccineCertificate$lambda$13$lambda$12$lambda$11(this.f$0, digitalDocumentEntity, j);
                    }
                });
                break;
            default:
                throw new NoWhenBranchMatchedException();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit checkVaccineCertificate$lambda$13$lambda$12$lambda$9(DashboardFragment this$0, DigitalDocumentEntity digitalDocumentEntity, long j) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        DigitalIdViewModel digitalIdViewModel = this$0.digitalIdViewModel;
        if (digitalIdViewModel == null) {
            Intrinsics.throwUninitializedPropertyAccessException("digitalIdViewModel");
            digitalIdViewModel = null;
        }
        digitalIdViewModel.deleteRecord(digitalDocumentEntity.getTransactionId());
        this$0.applyForVaccineCertificate(j, digitalDocumentEntity.getTransactionId());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit checkVaccineCertificate$lambda$13$lambda$12$lambda$10(DashboardFragment this$0, DigitalDocumentEntity digitalDocumentEntity, long j) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        DigitalIdViewModel digitalIdViewModel = this$0.digitalIdViewModel;
        if (digitalIdViewModel == null) {
            Intrinsics.throwUninitializedPropertyAccessException("digitalIdViewModel");
            digitalIdViewModel = null;
        }
        digitalIdViewModel.deleteRecord(digitalDocumentEntity.getTransactionId());
        this$0.applyForVaccineCertificate(j, digitalDocumentEntity.getTransactionId());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit checkVaccineCertificate$lambda$13$lambda$12$lambda$11(DashboardFragment this$0, DigitalDocumentEntity digitalDocumentEntity, long j) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        DigitalIdViewModel digitalIdViewModel = this$0.digitalIdViewModel;
        if (digitalIdViewModel == null) {
            Intrinsics.throwUninitializedPropertyAccessException("digitalIdViewModel");
            digitalIdViewModel = null;
        }
        digitalIdViewModel.deleteRecord(digitalDocumentEntity.getTransactionId());
        this$0.applyForVaccineCertificate(j, digitalDocumentEntity.getTransactionId());
        return Unit.INSTANCE;
    }

    private final void openVaccinationCertificates(long docTypeId) {
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) DigitalIdHomeActivity.class);
        int i = (int) docTypeId;
        intent.putExtra("doc_type_redirect", i);
        intent.putExtra("doc_name", i);
        startActivity(intent);
    }

    public final String getTAG() {
        return this.TAG;
    }

    private final void applyForVaccineCertificate(long docType, long transactionId) {
        LoginResponse loginResponse = this.userCredentials;
        DigitalIdViewModel digitalIdViewModel = null;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        String citizenNumber = loginResponse.getCitizenNumber();
        if (citizenNumber.length() <= 0) {
            citizenNumber = null;
        }
        DigitalIdRequest digitalIdRequest = new DigitalIdRequest(citizenNumber != null ? Long.parseLong(citizenNumber) : -1L, String.valueOf(docType), RSAKeyPair.INSTANCE.getPublicKeyString(), transactionId, null, 16, null);
        Log.d(this.TAG, "applyForVaccineCertificate: ");
        DigitalIdViewModel digitalIdViewModel2 = this.digitalIdViewModel;
        if (digitalIdViewModel2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("digitalIdViewModel");
        } else {
            digitalIdViewModel = digitalIdViewModel2;
        }
        digitalIdViewModel.requestDigitalId(digitalIdRequest);
    }

    private final void observeDocumentRequestState() {
        DigitalIdViewModel digitalIdViewModel = this.digitalIdViewModel;
        if (digitalIdViewModel == null) {
            Intrinsics.throwUninitializedPropertyAccessException("digitalIdViewModel");
            digitalIdViewModel = null;
        }
        digitalIdViewModel.getDigitalIdState().observe(getViewLifecycleOwner(), new DashboardFragment$sam$androidx_lifecycle_Observer$0(new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda12
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return DashboardFragment.observeDocumentRequestState$lambda$17(this.f$0, (UiState) obj);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit observeDocumentRequestState$lambda$17(DashboardFragment this$0, UiState uiState) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Log.d(this$0.TAG, "observeDocumentRequestState: status of observe: " + uiState);
        AuthMainActivity authMainActivity = null;
        if (uiState instanceof UiState.Error) {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity2 = this$0.activity;
            if (authMainActivity2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity2 = null;
            }
            loaderManager.hideLoader(authMainActivity2);
            ApiCallHelper apiCallHelper = ApiCallHelper.INSTANCE;
            AuthMainActivity authMainActivity3 = this$0.activity;
            if (authMainActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity3 = null;
            }
            AuthMainActivity authMainActivity4 = authMainActivity3;
            UiState.Error error = (UiState.Error) uiState;
            ErrorResponse errorResponse = error.getErrorResponse();
            int code = error.getCode();
            String message = error.getMessage();
            if (message == null) {
                AuthMainActivity authMainActivity5 = this$0.activity;
                if (authMainActivity5 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    authMainActivity5 = null;
                }
                message = ExtentionsKt.getCombineString$default(authMainActivity5, pk.gov.nadra.oneapp.digitalvault.R.string.an_error_occurred_while_processing_your_request_please_try_again_later, null, 2, null).toString();
            }
            apiCallHelper.handleFailureCase(authMainActivity4, errorResponse, code, message, new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return DashboardFragment.observeDocumentRequestState$lambda$17$lambda$16((String) obj);
                }
            });
        } else if (Intrinsics.areEqual(uiState, UiState.Loading.INSTANCE)) {
            LoaderManager loaderManager2 = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity6 = this$0.activity;
            if (authMainActivity6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity = authMainActivity6;
            }
            loaderManager2.showLoader(authMainActivity);
        } else if (uiState instanceof UiState.Success) {
            Log.d(this$0.TAG, "observeDocumentRequestState: ");
            LoaderManager loaderManager3 = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity7 = this$0.activity;
            if (authMainActivity7 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity = authMainActivity7;
            }
            loaderManager3.hideLoader(authMainActivity);
            Object data = ((UiState.Success) uiState).getData();
            Intrinsics.checkNotNull(data, "null cannot be cast to non-null type pk.gov.nadra.oneapp.digitalvault.domain.model.DigitalIdTransactionIdResponse");
            DigitalIdDocumentItem digitalIdDocumentItem = this$0.activeDocumentItem;
            Intrinsics.checkNotNull(digitalIdDocumentItem);
            this$0.handleResponse((DigitalIdTransactionIdResponse) data, digitalIdDocumentItem);
        } else {
            if (!Intrinsics.areEqual(uiState, UiState.Idle.INSTANCE)) {
                throw new NoWhenBranchMatchedException();
            }
            Log.d("TAG_", "observeDocumentRequestState: idle");
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit observeDocumentRequestState$lambda$17$lambda$16(String action) {
        Intrinsics.checkNotNullParameter(action, "action");
        return Unit.INSTANCE;
    }

    private final void checkAndStartDigitalId() {
        AuthMainActivity authMainActivity = this.activity;
        SSOActionViewModel sSOActionViewModel = null;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        if (AppPreferences.getInstance(authMainActivity).isVerifiableVaultEnable().booleanValue()) {
            LoginResponse loginResponse = this.userCredentials;
            if (loginResponse == null) {
                Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
                loginResponse = null;
            }
            if (loginResponse.getPrimaryNumberFeatureEnabled()) {
                LoginResponse loginResponse2 = this.userCredentials;
                if (loginResponse2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
                    loginResponse2 = null;
                }
                if (!loginResponse2.getPrimaryContactConfigured()) {
                    showPrimaryNumberBottomSheet();
                    return;
                }
                SSOActionViewModel sSOActionViewModel2 = this.ssoActionViewModel;
                if (sSOActionViewModel2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("ssoActionViewModel");
                } else {
                    sSOActionViewModel = sSOActionViewModel2;
                }
                sSOActionViewModel.setNavigateDigitalId(true);
                return;
            }
            SSOActionViewModel sSOActionViewModel3 = this.ssoActionViewModel;
            if (sSOActionViewModel3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("ssoActionViewModel");
            } else {
                sSOActionViewModel = sSOActionViewModel3;
            }
            sSOActionViewModel.setNavigateDigitalId(true);
            return;
        }
        startDigitalCard();
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0056, code lost:
    
        if (r0.equals(pk.gov.nadra.oneapp.commonutils.utils.Constant.GO_TO_INBOX) != false) goto L39;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void intentLauncher$lambda$18(pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment r4, androidx.activity.result.ActivityResult r5) {
        /*
            java.lang.String r0 = "this$0"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "result"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            android.content.Intent r0 = r5.getData()
            r1 = 0
            if (r0 == 0) goto L18
            java.lang.String r2 = "RESPONSE_TO_REACT_NATIVE"
            java.lang.String r0 = r0.getStringExtra(r2)
            goto L19
        L18:
            r0 = r1
        L19:
            int r5 = r5.getResultCode()
            r2 = -1
            if (r5 != r2) goto L84
            java.lang.String r5 = "activity"
            if (r0 == 0) goto L76
            int r2 = r0.hashCode()
            r3 = -1192833034(0xffffffffb8e6cff6, float:-1.10059904E-4)
            if (r2 == r3) goto L59
            r3 = -1028571879(0xffffffffc2b13d19, float:-88.61933)
            if (r2 == r3) goto L50
            r3 = -1025766916(0xffffffffc2dc09fc, float:-110.0195)
            if (r2 == r3) goto L38
            goto L61
        L38:
            java.lang.String r2 = "GO_TO_LOGIN"
            boolean r0 = r0.equals(r2)
            if (r0 != 0) goto L41
            goto L61
        L41:
            pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity r4 = r4.activity
            if (r4 != 0) goto L49
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r5)
            goto L4a
        L49:
            r1 = r4
        L4a:
            int r4 = pk.gov.nadra.oneapp.auth.main.R.id.loginFragment
            r1.navigateToFragment(r4)
            return
        L50:
            java.lang.String r2 = "GO_TO_INBOX"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L61
            goto L76
        L59:
            java.lang.String r2 = "GO_TO_ID_CARD_SERVICES"
            boolean r0 = r0.equals(r2)
            if (r0 != 0) goto L70
        L61:
            pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity r4 = r4.activity
            if (r4 != 0) goto L69
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r5)
            goto L6a
        L69:
            r1 = r4
        L6a:
            int r4 = pk.gov.nadra.oneapp.auth.main.R.id.homeFragment
            r1.navigateToFragment(r4)
            return
        L70:
            java.lang.String r5 = "CARD"
            r4.applyForServices(r5)
            return
        L76:
            pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity r4 = r4.activity
            if (r4 != 0) goto L7e
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r5)
            goto L7f
        L7e:
            r1 = r4
        L7f:
            int r4 = pk.gov.nadra.oneapp.auth.main.R.id.homeFragment
            r1.navigateToFragment(r4)
        L84:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment.intentLauncher$lambda$18(pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment, androidx.activity.result.ActivityResult):void");
    }

    private final void applyForServices(String productType) {
        AuthMainActivity authMainActivity = null;
        getAuthMainSharedViewModel().setInitAppSelection(new InitAppSelection(null, null, null, null, 15, null));
        AuthMainSharedViewModel authMainSharedViewModel = getAuthMainSharedViewModel();
        LoginResponse loginResponse = this.userCredentials;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        authMainSharedViewModel.setProcessingType(new ProcessingType(productType, loginResponse.getCitizenNumber()));
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.initializeFragment);
    }

    private final ReactNativeData getReactNativeData() {
        LoginResponse loginResponse = null;
        ReactNativeData.MobileOperator mobileOperator = new ReactNativeData.MobileOperator(0, null, 3, null);
        LoginResponse loginResponse2 = this.userCredentials;
        if (loginResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse2 = null;
        }
        mobileOperator.setKey(loginResponse2.getMobileOperator().getKey());
        LoginResponse loginResponse3 = this.userCredentials;
        if (loginResponse3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse3 = null;
        }
        mobileOperator.setValue(loginResponse3.getMobileOperator().getValue());
        LoginResponse loginResponse4 = this.userCredentials;
        if (loginResponse4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse4 = null;
        }
        String email = loginResponse4.getEmail();
        LoginResponse loginResponse5 = this.userCredentials;
        if (loginResponse5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse5 = null;
        }
        String fullName = loginResponse5.getFullName();
        LoginResponse loginResponse6 = this.userCredentials;
        if (loginResponse6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse6 = null;
        }
        String mobileNumber = loginResponse6.getMobileNumber();
        LoginResponse loginResponse7 = this.userCredentials;
        if (loginResponse7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse7 = null;
        }
        String refreshToken = loginResponse7.getRefreshToken();
        LoginResponse loginResponse8 = this.userCredentials;
        if (loginResponse8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse8 = null;
        }
        String token = loginResponse8.getToken();
        LoginResponse loginResponse9 = this.userCredentials;
        if (loginResponse9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse9 = null;
        }
        String sessionKey = loginResponse9.getSessionKey();
        LoginResponse loginResponse10 = this.userCredentials;
        if (loginResponse10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse10 = null;
        }
        boolean encryptionDecryptionEnabled = loginResponse10.getEncryptionDecryptionEnabled();
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        String fcmToken = AppPreferences.getInstance(authMainActivity).getFcmToken();
        Intrinsics.checkNotNullExpressionValue(fcmToken, "getFcmToken(...)");
        LoginResponse loginResponse11 = this.userCredentials;
        if (loginResponse11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
        } else {
            loginResponse = loginResponse11;
        }
        return new ReactNativeData(null, email, fullName, mobileNumber, refreshToken, token, "", true, true, true, null, null, false, loginResponse.getCitizenNumber(), mobileOperator, sessionKey, encryptionDecryptionEnabled, fcmToken, false, false, false, false, null, null, false, false, false, null, false, false, null, null, null, false, null, null, null, false, false, null, null, null, null, false, null, null, null, null, null, null, -254975, 262143, null);
    }

    private final void startDigitalCard() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("DIGITAL_CARD");
        reactNativeData.setVerifyDigitalCard(false);
        reactNativeData.setVerifyPalsCard(false);
        reactNativeData.setDematerialisePals(false);
        reactNativeData.setDematerialiseVehicleCard(false);
        reactNativeData.setDematerialisePECCard(false);
        LoginResponse loginResponse = this.userCredentials;
        AuthMainActivity authMainActivity = null;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        reactNativeData.setCitizenNumber(loginResponse.getCitizenNumber());
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) DigitalIdActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startExpedite() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("EXPEDITE");
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) ExpediteActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startRelativeAttestationDocuments() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("RELATIVE_ATTESTATION");
        reactNativeData.setRelativeDocumentUpload(true);
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) RelativeAttestationActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startRelativeAttestation() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("RELATIVE_ATTESTATION");
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) RelativeAttestationActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startYoutube() {
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(Constant.YOUTUBE_OFFICIAL_URL));
        intent.addFlags(SQLiteDatabase.CREATE_IF_NECESSARY);
        startActivity(intent);
    }

    private final void startVerifyDigitalCard() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("DIGITAL_CARD");
        reactNativeData.setVerifyDigitalCard(true);
        reactNativeData.setVerifyPalsCard(false);
        reactNativeData.setDematerialisePals(false);
        reactNativeData.setDematerialiseVehicleCard(false);
        reactNativeData.setDematerialisePECCard(false);
        Location location = getAuthMainSharedViewModel().getLocation();
        AuthMainActivity authMainActivity = null;
        String strValueOf = String.valueOf(location != null ? Double.valueOf(location.getLatitude()) : null);
        if (strValueOf == null) {
            strValueOf = "";
        }
        reactNativeData.setLatitude(strValueOf);
        Location location2 = getAuthMainSharedViewModel().getLocation();
        String strValueOf2 = String.valueOf(location2 != null ? Double.valueOf(location2.getLongitude()) : null);
        reactNativeData.setLongitude(strValueOf2 != null ? strValueOf2 : "");
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) DigitalIdActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startSimIssuance() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("BIOMETRIC_VERIFY");
        reactNativeData.setDocType("SIMISSUE");
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) MBVSActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startVerifyPalsCard() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("DIGITAL_CARD");
        reactNativeData.setVerifyDigitalCard(false);
        reactNativeData.setVerifyPalsCard(true);
        reactNativeData.setDematerialisePals(false);
        reactNativeData.setDematerialiseVehicleCard(false);
        reactNativeData.setDematerialisePECCard(false);
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) DigitalIdActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startRahbar() {
        ActivityResultLauncher<Intent> activityResultLauncher = this.intentLauncher;
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        activityResultLauncher.launch(new Intent(authMainActivity, (Class<?>) SplashActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            AuthMainActivity authMainActivity = null;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    for (ErrorResponse.Error error : errors) {
                    }
                    return;
                }
                return;
            }
            if (Intrinsics.areEqual(errorResponse.getStatus(), "BUSINESS_RULE_FAILED")) {
                NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                AuthMainActivity authMainActivity2 = this.activity;
                if (authMainActivity2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                } else {
                    authMainActivity = authMainActivity2;
                }
                Intrinsics.checkNotNull(errorResponse);
                NetworkErrorHandler.handleError$default(networkErrorHandler, authMainActivity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda25
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return DashboardFragment.handleFailureCase$lambda$21(this.f$0);
                    }
                }, 8, null);
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            AuthMainActivity authMainActivity3 = this.activity;
            if (authMainActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity = authMainActivity3;
            }
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler2, authMainActivity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda26
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return DashboardFragment.handleFailureCase$lambda$22(this.f$0);
                }
            }, 8, null);
            return;
        }
        AuthMainActivity authMainActivity4 = null;
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        AuthMainActivity authMainActivity5 = this.activity;
        if (authMainActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity4 = authMainActivity5;
        }
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler3, authMainActivity4, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return DashboardFragment.handleFailureCase$lambda$23(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$21(DashboardFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$22(DashboardFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$23(DashboardFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final boolean isAccountVerified() {
        LoginResponse loginResponse = this.userCredentials;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        String lowerCase = loginResponse.getVerificationStatus().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        if (Intrinsics.areEqual(lowerCase, "verified")) {
            return true;
        }
        showAccessRestrictedDialog();
        return false;
    }

    private final void showAccessRestrictedDialog() {
        AccessRestrictedDialogFragment.INSTANCE.newInstance(new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda21
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return DashboardFragment.showAccessRestrictedDialog$lambda$24(this.f$0);
            }
        }).show(getParentFragmentManager(), "AccessRestrictedDialog");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit showAccessRestrictedDialog$lambda$24(DashboardFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getAuthMainSharedViewModel().setVerificationLoadFrom("Dashboard");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.registerVerifyIdentityFragment);
        return Unit.INSTANCE;
    }

    private final void startPALSDigitalCard() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("PALS_DIGITAL_CARD");
        reactNativeData.setVerifyDigitalCard(false);
        reactNativeData.setVerifyPalsCard(false);
        reactNativeData.setDematerialisePals(true);
        reactNativeData.setDematerialiseVehicleCard(false);
        reactNativeData.setDematerialisePECCard(false);
        LoginResponse loginResponse = this.userCredentials;
        AuthMainActivity authMainActivity = null;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        reactNativeData.setCitizenNumber(loginResponse.getCitizenNumber());
        LoginResponse loginResponse2 = this.userCredentials;
        if (loginResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse2 = null;
        }
        reactNativeData.setAccountHolderCnic(loginResponse2.getCitizenNumber());
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) DigitalIdActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startAppointmentSystem() {
        ReactNativeData reactNativeData = getReactNativeData();
        LoginResponse loginResponse = this.userCredentials;
        AuthMainActivity authMainActivity = null;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        reactNativeData.setCitizenNumber(loginResponse.getCitizenNumber());
        LoginResponse loginResponse2 = this.userCredentials;
        if (loginResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse2 = null;
        }
        reactNativeData.setAccountHolderCnic(loginResponse2.getCitizenNumber());
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) AppointmentSystemActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startFacialVerif() {
        String json = new Gson().toJson(getReactNativeData(), ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) FacialVerifyActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startPayment() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("PAYMENT");
        reactNativeData.setPayment(true);
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) RelativeAttestationActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startVehicleDigitalCard() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("VEHICLE_DIGITAL_CARD");
        reactNativeData.setVerifyDigitalCard(false);
        reactNativeData.setVerifyPalsCard(false);
        reactNativeData.setDematerialisePals(false);
        reactNativeData.setDematerialiseVehicleCard(true);
        reactNativeData.setDematerialisePECCard(false);
        LoginResponse loginResponse = this.userCredentials;
        AuthMainActivity authMainActivity = null;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        reactNativeData.setCitizenNumber(loginResponse.getCitizenNumber());
        LoginResponse loginResponse2 = this.userCredentials;
        if (loginResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse2 = null;
        }
        reactNativeData.setAccountHolderCnic(loginResponse2.getCitizenNumber());
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) DigitalIdActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startPECDigitalCard() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("PEC_DIGITAL_CARD");
        reactNativeData.setVerifyDigitalCard(false);
        reactNativeData.setVerifyPalsCard(false);
        reactNativeData.setDematerialisePals(false);
        reactNativeData.setDematerialiseVehicleCard(false);
        reactNativeData.setDematerialisePECCard(true);
        LoginResponse loginResponse = this.userCredentials;
        AuthMainActivity authMainActivity = null;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        reactNativeData.setCitizenNumber(loginResponse.getCitizenNumber());
        LoginResponse loginResponse2 = this.userCredentials;
        if (loginResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse2 = null;
        }
        reactNativeData.setAccountHolderCnic(loginResponse2.getCitizenNumber());
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) DigitalIdActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startMBVS() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("BIOMETRIC_VERIFY");
        reactNativeData.setDocType("MBVS");
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) MBVSActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startTIDTracking() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("TID_TRACKING");
        reactNativeData.setTidTracking(true);
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) RelativeAttestationActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void startQrCodeVerification() {
        ReactNativeData reactNativeData = getReactNativeData();
        Location location = getAuthMainSharedViewModel().getLocation();
        AuthMainActivity authMainActivity = null;
        reactNativeData.setLatitude(String.valueOf(location != null ? Double.valueOf(location.getLatitude()) : null));
        Location location2 = getAuthMainSharedViewModel().getLocation();
        reactNativeData.setLongitude(String.valueOf(location2 != null ? Double.valueOf(location2.getLongitude()) : null));
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) DVQRScannerActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void showUnderDevelopmentBottomSheet() {
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        int i = pk.gov.nadra.oneapp.commonutils.R.drawable.ic_info;
        String string = getString(R.string.feature_soon);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = getString(R.string.feature_soon_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        bottomSheetUtils.showMessageBottomSheet(authMainActivity, i, false, "Info", string, false, true, true, string2, "", new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda15
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        });
    }

    private final ReactNativeData getReactNativeDataForFamilyTree() {
        LoginResponse loginResponse = null;
        ReactNativeData.MobileOperator mobileOperator = new ReactNativeData.MobileOperator(0, null, 3, null);
        LoginResponse loginResponse2 = this.userCredentials;
        if (loginResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse2 = null;
        }
        mobileOperator.setKey(loginResponse2.getMobileOperator().getKey());
        LoginResponse loginResponse3 = this.userCredentials;
        if (loginResponse3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse3 = null;
        }
        mobileOperator.setValue(loginResponse3.getMobileOperator().getValue());
        LoginResponse loginResponse4 = this.userCredentials;
        if (loginResponse4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse4 = null;
        }
        String email = loginResponse4.getEmail();
        LoginResponse loginResponse5 = this.userCredentials;
        if (loginResponse5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse5 = null;
        }
        String fullName = loginResponse5.getFullName();
        LoginResponse loginResponse6 = this.userCredentials;
        if (loginResponse6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse6 = null;
        }
        String mobileNumber = loginResponse6.getMobileNumber();
        LoginResponse loginResponse7 = this.userCredentials;
        if (loginResponse7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse7 = null;
        }
        String refreshToken = loginResponse7.getRefreshToken();
        LoginResponse loginResponse8 = this.userCredentials;
        if (loginResponse8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse8 = null;
        }
        String token = loginResponse8.getToken();
        LoginResponse loginResponse9 = this.userCredentials;
        if (loginResponse9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse9 = null;
        }
        String sessionKey = loginResponse9.getSessionKey();
        LoginResponse loginResponse10 = this.userCredentials;
        if (loginResponse10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse10 = null;
        }
        boolean encryptionDecryptionEnabled = loginResponse10.getEncryptionDecryptionEnabled();
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        String fcmToken = AppPreferences.getInstance(authMainActivity).getFcmToken();
        Intrinsics.checkNotNullExpressionValue(fcmToken, "getFcmToken(...)");
        LoginResponse loginResponse11 = this.userCredentials;
        if (loginResponse11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
        } else {
            loginResponse = loginResponse11;
        }
        return new ReactNativeData(null, email, fullName, mobileNumber, refreshToken, token, "", true, true, true, null, null, false, loginResponse.getCitizenNumber(), mobileOperator, sessionKey, encryptionDecryptionEnabled, fcmToken, false, false, false, false, null, null, false, false, false, null, false, false, null, null, null, false, null, null, null, false, false, null, null, null, null, false, null, null, null, null, null, null, -254975, 262143, null);
    }

    private final void launchFamilyTree(String citizenNumber, boolean applicantFingerprintsExist, boolean livelinessControl, String documentType, VerifyFingerprintResponse verifyFingerprintResponse) {
        ReactNativeData reactNativeDataForFamilyTree = getReactNativeDataForFamilyTree();
        reactNativeDataForFamilyTree.setCitizenNumber(citizenNumber);
        reactNativeDataForFamilyTree.setAppType("FAMILY");
        reactNativeDataForFamilyTree.setApplicantFingerprintsExist(applicantFingerprintsExist);
        reactNativeDataForFamilyTree.setLivelinessControl(livelinessControl);
        reactNativeDataForFamilyTree.setDocType(documentType);
        reactNativeDataForFamilyTree.setVerifyFingerprintResponse(verifyFingerprintResponse);
        String json = new Gson().toJson(reactNativeDataForFamilyTree, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) FamilyTreeActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    /* compiled from: DashboardFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$getFamilyCompositionDocTypeService$1", f = "DashboardFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$getFamilyCompositionDocTypeService$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ boolean $applicantFingerprintsExist;
        final /* synthetic */ String $cnic;
        final /* synthetic */ boolean $livelinessControl;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, boolean z, boolean z2, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$cnic = str;
            this.$applicantFingerprintsExist = z;
            this.$livelinessControl = z2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return DashboardFragment.this.new AnonymousClass1(this.$cnic, this.$applicantFingerprintsExist, this.$livelinessControl, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = DashboardFragment.this.activity;
            AuthMainActivity authMainActivity2 = null;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.showLoader(authMainActivity);
            AuthMainActivity authMainActivity3 = DashboardFragment.this.activity;
            if (authMainActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity2 = authMainActivity3;
            }
            APIRequests aPIRequests = new APIRequests(authMainActivity2);
            VerifyFingerprintRequest verifyFingerprintRequest = new VerifyFingerprintRequest(null, this.$cnic, 0, null, null, false, null, false, false, false, false, false, false, null, false, false, false, null, 262141, null);
            final DashboardFragment dashboardFragment = DashboardFragment.this;
            final String str = this.$cnic;
            final boolean z = this.$applicantFingerprintsExist;
            final boolean z2 = this.$livelinessControl;
            aPIRequests.getFamilyCompositionDocType(verifyFingerprintRequest, new Function3() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$getFamilyCompositionDocTypeService$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return DashboardFragment.AnonymousClass1.invokeSuspend$lambda$0(dashboardFragment, str, z, z2, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(DashboardFragment dashboardFragment, String str, boolean z, boolean z2, JsonObject jsonObject, String str2, int i) throws JsonSyntaxException {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = dashboardFragment.activity;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.hideLoader(authMainActivity);
            if (Intrinsics.areEqual(str2, "SUCCESS")) {
                dashboardFragment.processGetFamilyCompositionDocTypeSuccessResponse(jsonObject, str, z, z2);
            } else {
                dashboardFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getFamilyCompositionDocTypeService(String cnic, boolean applicantFingerprintsExist, boolean livelinessControl) {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(cnic, applicantFingerprintsExist, livelinessControl, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processGetFamilyCompositionDocTypeSuccessResponse(JsonObject jSonObject, String cnic, boolean applicantFingerprintsExist, boolean livelinessControl) throws JsonSyntaxException {
        Object element = new Gson().fromJson(jSonObject.toString(), (Class<Object>) VerifyFingerprintResponse.class);
        VerifyFingerprintResponse verifyFingerprintResponse = (VerifyFingerprintResponse) element;
        String documentCodeNis = verifyFingerprintResponse.getDocumentCodeNis();
        Intrinsics.checkNotNull(documentCodeNis);
        Intrinsics.checkNotNullExpressionValue(element, "element");
        launchFamilyTree(cnic, applicantFingerprintsExist, livelinessControl, documentCodeNis, verifyFingerprintResponse);
    }

    private final void startEtdVerification() {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType("VEHICLE_TRANSFER");
        reactNativeData.setDocType("ETD");
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        Intent intent = new Intent(authMainActivity, (Class<?>) EtdVerificationActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    private final void verifyNumberView() {
        LoginResponse loginResponse = this.userCredentials;
        LoginResponse loginResponse2 = null;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        if (loginResponse.getPrimaryNumberFeatureEnabled()) {
            LoginResponse loginResponse3 = this.userCredentials;
            if (loginResponse3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            } else {
                loginResponse2 = loginResponse3;
            }
            if (loginResponse2.getPrimaryContactConfigured()) {
                getBinding().setPrimaryPhoneNumberLayout.setVisibility(8);
                return;
            }
            getBinding().setPrimaryPhoneNumberLayout.setVisibility(0);
            TextView urduSetPrimaryNumberTextView = getBinding().urduSetPrimaryNumberTextView;
            Intrinsics.checkNotNullExpressionValue(urduSetPrimaryNumberTextView, "urduSetPrimaryNumberTextView");
            ExtentionsKt.applyFont(urduSetPrimaryNumberTextView, R.font.nadra_nastaleeq);
            getBinding().setPrimaryPhoneNumberLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda6
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    DashboardFragment.verifyNumberView$lambda$28(this.f$0, view);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void verifyNumberView$lambda$28(DashboardFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        LinearLayout setPrimaryPhoneNumberLayout = this$0.getBinding().setPrimaryPhoneNumberLayout;
        Intrinsics.checkNotNullExpressionValue(setPrimaryPhoneNumberLayout, "setPrimaryPhoneNumberLayout");
        ExtentionsKt.disableTemporary$default((ViewGroup) setPrimaryPhoneNumberLayout, 0L, 1, (Object) null);
        this$0.showPrimaryNumberBottomSheet();
    }

    private final void showPrimaryNumberBottomSheet() {
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        int i = pk.gov.nadra.oneapp.auth.main.R.drawable.ic_verify_phone_number;
        String string = getString(R.string.set_primary_mobile_number);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = getString(R.string.setting_your_primary_number);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        String string3 = getString(R.string.urdu_set_primary_mobile_number);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        String string4 = getString(R.string.urdu_setting_your_primary_number);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        String string5 = getString(R.string.set_now);
        Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
        String string6 = getString(R.string.urdu_set_now);
        Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
        BottomSheetUtils.deepShowMessageBottomSheet$default(bottomSheetUtils, authMainActivity, i, false, string, string2, string3, true, true, true, true, string4, string5, string6, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda13
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return DashboardFragment.showPrimaryNumberBottomSheet$lambda$30(this.f$0);
            }
        }, null, 16384, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit showPrimaryNumberBottomSheet$lambda$30(DashboardFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getAuthMainSharedViewModel().setPrimaryNumberLoadFrom("Home");
        Bundle bundle = new Bundle();
        bundle.putString(Constant.KEY_CONTACT_UPDATE_ACTIONS, "SET_PRIMARY_MOBILE_NUMBER");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.action_homeFragment_to_phoneNumber_list_fragment, bundle);
        return Unit.INSTANCE;
    }

    private final void handleResponse(final DigitalIdTransactionIdResponse response, final DigitalIdDocumentItem activeDocument) {
        DigitalIdViewModel digitalIdViewModel;
        DigitalIdViewModel digitalIdViewModel2 = this.digitalIdViewModel;
        AuthMainActivity authMainActivity = null;
        if (digitalIdViewModel2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("digitalIdViewModel");
            digitalIdViewModel = null;
        } else {
            digitalIdViewModel = digitalIdViewModel2;
        }
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        DigitalIdViewModel.handleSuccessResponse$default(digitalIdViewModel, authMainActivity, response, activeDocument, null, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda24
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return DashboardFragment.handleResponse$lambda$33(response, this, activeDocument);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleResponse$lambda$33(DigitalIdTransactionIdResponse response, final DashboardFragment this$0, final DigitalIdDocumentItem activeDocument) {
        Intrinsics.checkNotNullParameter(response, "$response");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(activeDocument, "$activeDocument");
        DigitalIdViewModel digitalIdViewModel = null;
        if (Intrinsics.areEqual(response.getStatus(), "SUCCESS")) {
            DigitalIdViewModel digitalIdViewModel2 = this$0.digitalIdViewModel;
            if (digitalIdViewModel2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("digitalIdViewModel");
            } else {
                digitalIdViewModel = digitalIdViewModel2;
            }
            digitalIdViewModel.getDocumentById(activeDocument.getDocumentId(), new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda19
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return DashboardFragment.handleResponse$lambda$33$lambda$31(this.f$0, activeDocument, (DigitalDocumentEntity) obj);
                }
            });
            return Unit.INSTANCE;
        }
        if (Intrinsics.areEqual(response.getStatus(), "FAILURE")) {
            DigitalIdViewModel digitalIdViewModel3 = this$0.digitalIdViewModel;
            if (digitalIdViewModel3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("digitalIdViewModel");
            } else {
                digitalIdViewModel = digitalIdViewModel3;
            }
            Long transactionId = response.getTransactionId();
            digitalIdViewModel.deleteDocumentByTransactionId(transactionId != null ? transactionId.longValue() : 1L, new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda20
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return DashboardFragment.handleResponse$lambda$33$lambda$32(((Integer) obj).intValue());
                }
            });
            return Unit.INSTANCE;
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleResponse$lambda$33$lambda$31(DashboardFragment this$0, DigitalIdDocumentItem activeDocument, DigitalDocumentEntity digitalDocumentEntity) {
        String englishPlace;
        String urduPlace;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(activeDocument, "$activeDocument");
        if (digitalDocumentEntity == null) {
            return Unit.INSTANCE;
        }
        if (DeepUtils.INSTANCE.isVCExpired(digitalDocumentEntity.getVerifiableCredential())) {
            DigitalDocumentEntity digitalDocumentEntityCopy$default = DigitalDocumentEntity.copy$default(digitalDocumentEntity, 0, 0L, null, 0L, null, null, false, null, "EXPIRED", 0L, 0L, null, null, false, false, 32511, null);
            DigitalIdDocumentTypes digitalIdDocumentTypesFromId = DigitalIdDocumentTypes.INSTANCE.fromId(activeDocument.getDocumentId());
            String str = "";
            if (digitalIdDocumentTypesFromId == null || (englishPlace = digitalIdDocumentTypesFromId.getEnglishPlace()) == null) {
                englishPlace = "";
            }
            DigitalIdDocumentTypes digitalIdDocumentTypesFromId2 = DigitalIdDocumentTypes.INSTANCE.fromId(activeDocument.getDocumentId());
            if (digitalIdDocumentTypesFromId2 != null && (urduPlace = digitalIdDocumentTypesFromId2.getUrduPlace()) != null) {
                str = urduPlace;
            }
            this$0.showVaccineMessageBottomSheet(digitalDocumentEntityCopy$default, englishPlace, str);
        } else {
            this$0.openVaccinationCertificates(activeDocument.getDocumentId());
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleResponse$lambda$33$lambda$32(int i) {
        return Unit.INSTANCE;
    }

    private final void getAllQrScanLogsFromLocal() {
        QRScanLogsViewModel qRScanLogsViewModel = this.qrScanLogsViewModel;
        if (qRScanLogsViewModel == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrScanLogsViewModel");
            qRScanLogsViewModel = null;
        }
        qRScanLogsViewModel.getAllQRLogs(new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda11
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return DashboardFragment.getAllQrScanLogsFromLocal$lambda$35(this.f$0, (List) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit getAllQrScanLogsFromLocal$lambda$35(DashboardFragment this$0, List list) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        List list2 = list;
        if (list2 == null || list2.isEmpty()) {
            return Unit.INSTANCE;
        }
        List list3 = list;
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list3, 10));
        Iterator it = list3.iterator();
        while (it.hasNext()) {
            arrayList.add(DigitalQrLogsMapperKt.toDto((DigitalQRLogsEntity) it.next()));
        }
        DigitalQRLogsRequest digitalQRLogsRequest = new DigitalQRLogsRequest(arrayList);
        DigitalIdViewModel digitalIdViewModel = this$0.digitalIdViewModel;
        if (digitalIdViewModel == null) {
            Intrinsics.throwUninitializedPropertyAccessException("digitalIdViewModel");
            digitalIdViewModel = null;
        }
        digitalIdViewModel.uploadQrScanLogs(digitalQRLogsRequest);
        return Unit.INSTANCE;
    }

    private final void digitalQrScanLogObserver() {
        DigitalIdViewModel digitalIdViewModel = this.digitalIdViewModel;
        if (digitalIdViewModel == null) {
            Intrinsics.throwUninitializedPropertyAccessException("digitalIdViewModel");
            digitalIdViewModel = null;
        }
        digitalIdViewModel.getUploadQrLogs().observe(getViewLifecycleOwner(), new DashboardFragment$sam$androidx_lifecycle_Observer$0(new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return DashboardFragment.digitalQrScanLogObserver$lambda$37(this.f$0, (UiState) obj);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit digitalQrScanLogObserver$lambda$37(DashboardFragment this$0, UiState uiState) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Log.d(this$0.TAG, "observeDocumentRequestState: status of observe: " + uiState);
        QRScanLogsViewModel qRScanLogsViewModel = null;
        if (uiState instanceof UiState.Success) {
            Log.d(this$0.TAG, "observeDocumentRequestState: ");
            QRScanLogsViewModel qRScanLogsViewModel2 = this$0.qrScanLogsViewModel;
            if (qRScanLogsViewModel2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrScanLogsViewModel");
            } else {
                qRScanLogsViewModel = qRScanLogsViewModel2;
            }
            qRScanLogsViewModel.deleteAllQRLogs(new Function1() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment$$ExternalSyntheticLambda23
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return DashboardFragment.digitalQrScanLogObserver$lambda$37$lambda$36(((Integer) obj).intValue());
                }
            });
        } else if (uiState instanceof UiState.Error) {
            AuthMainActivity authMainActivity = this$0.activity;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            ExtentionsKt.log$default(authMainActivity, "QRLogs error : " + ((UiState.Error) uiState).getMessage(), null, 2, null);
        } else if (!Intrinsics.areEqual(uiState, UiState.Loading.INSTANCE)) {
            if (!Intrinsics.areEqual(uiState, UiState.Idle.INSTANCE)) {
                throw new NoWhenBranchMatchedException();
            }
            Log.d("TAG_", "observeDocumentRequestState: idle");
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit digitalQrScanLogObserver$lambda$37$lambda$36(int i) {
        return Unit.INSTANCE;
    }

    private final void applyForProvincialCRMS(String province) {
        getAuthMainSharedViewModel().setSelectedCRMSProvince(province);
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.provincialOptionsFragment);
    }
}