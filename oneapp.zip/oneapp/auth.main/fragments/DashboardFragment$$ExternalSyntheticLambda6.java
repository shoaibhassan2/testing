package pk.gov.nadra.oneapp.auth.main.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda6 implements View.OnClickListener {
    public /* synthetic */ DashboardFragment$$ExternalSyntheticLambda6() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        DashboardFragment.verifyNumberView$lambda$28(this.f$0, view);
    }
}