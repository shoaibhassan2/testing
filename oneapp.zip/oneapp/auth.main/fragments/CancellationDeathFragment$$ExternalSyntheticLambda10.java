package pk.gov.nadra.oneapp.auth.main.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CancellationDeathFragment$$ExternalSyntheticLambda10 implements ActivityResultCallback {
    public /* synthetic */ CancellationDeathFragment$$ExternalSyntheticLambda10() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        CancellationDeathFragment.intentLauncher$lambda$21(this.f$0, (ActivityResult) obj);
    }
}