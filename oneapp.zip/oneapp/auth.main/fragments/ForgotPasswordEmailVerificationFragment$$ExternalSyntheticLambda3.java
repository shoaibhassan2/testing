package pk.gov.nadra.oneapp.auth.main.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda3 implements View.OnClickListener {
    public /* synthetic */ ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda3() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ForgotPasswordEmailVerificationFragment.onViewCreated$lambda$2$lambda$0(this.f$0, view);
    }
}