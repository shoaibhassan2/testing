package pk.gov.nadra.oneapp.auth.main.fragments;

import androidx.recyclerview.widget.GridLayoutManager;
import java.util.List;
import kotlin.Metadata;
import pk.gov.nadra.oneapp.models.dashboard.DashboardItem;

/* compiled from: DashboardFragment.kt */
@Metadata(d1 = {"\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003H\u0016¨\u0006\u0005"}, d2 = {"pk/gov/nadra/oneapp/auth/main/fragments/DashboardFragment$attachDashboardViews$1$1$1", "Landroidx/recyclerview/widget/GridLayoutManager$SpanSizeLookup;", "getSpanSize", "", "position", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DashboardFragment$attachDashboardViews$1$1$1 extends GridLayoutManager.SpanSizeLookup {
    final /* synthetic */ List<DashboardItem> $dashboardList;

    /* JADX WARN: Multi-variable type inference failed */
    DashboardFragment$attachDashboardViews$1$1$1(List<? extends DashboardItem> list) {
        dashboardItems = list;
    }

    @Override // androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup
    public int getSpanSize(int position) {
        DashboardItem dashboardItem = dashboardItems.get(position);
        if ((dashboardItem instanceof DashboardItem.DigitalCard) || (dashboardItem instanceof DashboardItem.SectionHeader)) {
            return 4;
        }
        return dashboardItem instanceof DashboardItem.ServiceItem ? 1 : 0;
    }
}