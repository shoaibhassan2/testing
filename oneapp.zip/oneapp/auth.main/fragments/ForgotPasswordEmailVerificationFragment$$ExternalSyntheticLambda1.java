package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda1 implements Function0 {
    public /* synthetic */ ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda1() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return ForgotPasswordEmailVerificationFragment.handleFailureCase$lambda$12(this.f$0);
    }
}