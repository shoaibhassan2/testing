package pk.gov.nadra.oneapp.auth.main.fragments;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import androidx.fragment.app.DialogFragment;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.auth.main.databinding.CustomConfirmationDialogBinding;

/* compiled from: CustomConfirmationDialogFragment.kt */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \u001d2\u00020\u0001:\u0001\u001dB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0016J\b\u0010\u001c\u001a\u00020\u0017H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R+\u0010\u0013\u001a\u001f\u0012\u0013\u0012\u00110\n¢\u0006\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\t\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001e"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/fragments/CustomConfirmationDialogFragment;", "Landroidx/fragment/app/DialogFragment;", "<init>", "()V", "_binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/CustomConfirmationDialogBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/auth/main/databinding/CustomConfirmationDialogBinding;", "data", "", "icon", "", "title", "message", "confirmButtonTitle", "cancelButtonTitle", "isCancelVisible", "", "onConfirm", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "", "onCreateDialog", "Landroid/app/Dialog;", "savedInstanceState", "Landroid/os/Bundle;", "onDestroyView", "Companion", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class CustomConfirmationDialogFragment extends DialogFragment {

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private CustomConfirmationDialogBinding _binding;
    private int icon;
    private boolean isCancelVisible;
    private Function1<? super String, Unit> onConfirm;
    private String data = "";
    private String title = "";
    private String message = "";
    private String confirmButtonTitle = "";
    private String cancelButtonTitle = "";

    private final CustomConfirmationDialogBinding getBinding() {
        CustomConfirmationDialogBinding customConfirmationDialogBinding = this._binding;
        Intrinsics.checkNotNull(customConfirmationDialogBinding);
        return customConfirmationDialogBinding;
    }

    /* compiled from: CustomConfirmationDialogFragment.kt */
    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003Ja\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u00072\u0006\u0010\u000e\u001a\u00020\u000f2!\u0010\u0010\u001a\u001d\u0012\u0013\u0012\u00110\u0007¢\u0006\f\b\u0012\u0012\b\b\u0013\u0012\u0004\b\b(\u0006\u0012\u0004\u0012\u00020\u00140\u0011¨\u0006\u0015"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/fragments/CustomConfirmationDialogFragment$Companion;", "", "<init>", "()V", "newInstance", "Lpk/gov/nadra/oneapp/auth/main/fragments/CustomConfirmationDialogFragment;", "data", "", "icon", "", "title", "message", "confirmButtonTitle", "cancelButtonTitle", "isCancelVisible", "", "onConfirm", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final CustomConfirmationDialogFragment newInstance(String data, int icon, String title, String message, String confirmButtonTitle, String cancelButtonTitle, boolean isCancelVisible, Function1<? super String, Unit> onConfirm) {
            Intrinsics.checkNotNullParameter(data, "data");
            Intrinsics.checkNotNullParameter(title, "title");
            Intrinsics.checkNotNullParameter(message, "message");
            Intrinsics.checkNotNullParameter(confirmButtonTitle, "confirmButtonTitle");
            Intrinsics.checkNotNullParameter(cancelButtonTitle, "cancelButtonTitle");
            Intrinsics.checkNotNullParameter(onConfirm, "onConfirm");
            CustomConfirmationDialogFragment customConfirmationDialogFragment = new CustomConfirmationDialogFragment();
            customConfirmationDialogFragment.data = data;
            customConfirmationDialogFragment.icon = icon;
            customConfirmationDialogFragment.title = title;
            customConfirmationDialogFragment.message = message;
            customConfirmationDialogFragment.confirmButtonTitle = confirmButtonTitle;
            customConfirmationDialogFragment.cancelButtonTitle = cancelButtonTitle;
            customConfirmationDialogFragment.isCancelVisible = isCancelVisible;
            customConfirmationDialogFragment.onConfirm = onConfirm;
            return customConfirmationDialogFragment;
        }
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Window window;
        setCancelable(false);
        this._binding = CustomConfirmationDialogBinding.inflate(LayoutInflater.from(requireContext()));
        AlertDialog alertDialogCreate = new AlertDialog.Builder(requireContext()).setView(getBinding().getRoot()).create();
        if (alertDialogCreate != null && (window = alertDialogCreate.getWindow()) != null) {
            window.setBackgroundDrawable(new ColorDrawable(0));
        }
        CustomConfirmationDialogBinding binding = getBinding();
        binding.customConfirmationIconImageView.setImageResource(this.icon);
        binding.customConfirmationTitleTextView.setText(this.title);
        binding.customConfirmationDetailTextView.setText(this.message);
        binding.customConfirmationConfirmButtonLayout.setText(this.confirmButtonTitle);
        binding.customConfirmationCancelButtonLayout.setText(this.cancelButtonTitle);
        if (this.isCancelVisible) {
            binding.customConfirmationCancelButtonLayout.setVisibility(0);
        } else {
            binding.customConfirmationCancelButtonLayout.setVisibility(8);
        }
        binding.customConfirmationConfirmButtonLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CustomConfirmationDialogFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                CustomConfirmationDialogFragment.onCreateDialog$lambda$2$lambda$0(this.f$0, view);
            }
        });
        binding.customConfirmationCancelButtonLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CustomConfirmationDialogFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                CustomConfirmationDialogFragment.onCreateDialog$lambda$2$lambda$1(this.f$0, view);
            }
        });
        Intrinsics.checkNotNull(alertDialogCreate);
        return alertDialogCreate;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreateDialog$lambda$2$lambda$0(CustomConfirmationDialogFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Function1<? super String, Unit> function1 = this$0.onConfirm;
        if (function1 != null) {
            function1.invoke(this$0.data);
        }
        this$0.dismiss();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreateDialog$lambda$2$lambda$1(CustomConfirmationDialogFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dismiss();
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}