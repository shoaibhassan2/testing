package pk.gov.nadra.oneapp.auth.main.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CustomConfirmationDialogFragment$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public /* synthetic */ CustomConfirmationDialogFragment$$ExternalSyntheticLambda0() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        CustomConfirmationDialogFragment.onCreateDialog$lambda$2$lambda$0(this.f$0, view);
    }
}