package pk.gov.nadra.oneapp.auth.main.fragments;

import android.os.CountDownTimer;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.commonui.R;

/* compiled from: ForgotPasswordEmailVerificationFragment.kt */
@Metadata(d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\b\u0010\u0006\u001a\u00020\u0003H\u0016¨\u0006\u0007"}, d2 = {"pk/gov/nadra/oneapp/auth/main/fragments/ForgotPasswordEmailVerificationFragment$setupCountdownTimer$1$1", "Landroid/os/CountDownTimer;", "onTick", "", "millisUntilFinished", "", "onFinish", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ForgotPasswordEmailVerificationFragment$setupCountdownTimer$1$1 extends CountDownTimer {
    final /* synthetic */ ForgotPasswordEmailVerificationFragment this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    ForgotPasswordEmailVerificationFragment$setupCountdownTimer$1$1(ForgotPasswordEmailVerificationFragment forgotPasswordEmailVerificationFragment) {
        super(30000L, 1000L);
        this = forgotPasswordEmailVerificationFragment;
    }

    @Override // android.os.CountDownTimer
    public void onTick(long millisUntilFinished) {
        try {
            binding.emailVerificationResendDescriptionTextView.setText(this.getString(R.string.email_verification_resend_code_description, String.valueOf((int) (millisUntilFinished / 1000))));
        } catch (Exception unused) {
            CountDownTimer countDownTimer = this.countdownTimer;
            if (countDownTimer == null) {
                Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
                countDownTimer = null;
            }
            countDownTimer.cancel();
        }
    }

    @Override // android.os.CountDownTimer
    public void onFinish() {
        binding.emailVerificationResendTextView.setVisibility(0);
        binding.emailVerificationResendDescriptionTextView.setVisibility(8);
    }
}