package pk.gov.nadra.oneapp.auth.main.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CancellationDeathFragment$$ExternalSyntheticLambda4 implements View.OnClickListener {
    public /* synthetic */ CancellationDeathFragment$$ExternalSyntheticLambda4() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        CancellationDeathFragment.initViews$lambda$10$lambda$9(this.f$0, view);
    }
}