package pk.gov.nadra.oneapp.auth.main.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda22 implements ActivityResultCallback {
    public /* synthetic */ DashboardFragment$$ExternalSyntheticLambda22() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        DashboardFragment.intentLauncher$lambda$18(this.f$0, (ActivityResult) obj);
    }
}