package pk.gov.nadra.oneapp.auth.main.fragments;

import android.content.Context;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.SpannableString;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.otpview.OTPListener;
import java.util.ArrayList;
import java.util.List;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.auth.main.databinding.ForgotPasswordEmailVerificationFragmentBinding;
import pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment;
import pk.gov.nadra.oneapp.auth.main.viewModel.AuthMainSharedViewModel;
import pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.preferences.AppPreferences;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.RSAKeyPair;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.register.CnicForgotPasswordRequest;
import pk.gov.nadra.oneapp.models.register.ForgotPasswordOtpRequest;
import pk.gov.nadra.oneapp.models.register.ForgotPasswordOtpResponse;
import pk.gov.nadra.oneapp.models.register.VerifyOtpPasswordRecoveryRequest;
import pk.gov.nadra.oneapp.models.register.VerifyOtpPasswordRecoveryResponse;
import pk.gov.nadra.oneapp.models.register.VerifyOtpRequest;
import pk.gov.nadra.oneapp.models.register.VerifyOtpResponse;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: ForgotPasswordEmailVerificationFragment.kt */
@Metadata(d1 = {"\u0000\u008a\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001cH\u0016J$\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 2\b\u0010!\u001a\u0004\u0018\u00010\"2\b\u0010#\u001a\u0004\u0018\u00010$H\u0016J\u001a\u0010%\u001a\u00020\u001a2\u0006\u0010&\u001a\u00020\u001e2\b\u0010#\u001a\u0004\u0018\u00010$H\u0016J\b\u0010'\u001a\u00020\u001aH\u0002J\b\u0010(\u001a\u00020\u001aH\u0002J\b\u0010)\u001a\u00020\u001aH\u0002J\u0010\u0010*\u001a\u00020+2\u0006\u0010,\u001a\u00020-H\u0002J\u0010\u0010.\u001a\u00020\u001a2\u0006\u0010,\u001a\u00020-H\u0002J\u0010\u0010/\u001a\u00020\u001a2\u0006\u00100\u001a\u000201H\u0002J\u0018\u00102\u001a\u00020\u001a2\u0006\u00103\u001a\u0002012\u0006\u00104\u001a\u000205H\u0002J\b\u00106\u001a\u00020\u001aH\u0002J\b\u00107\u001a\u000208H\u0002J\u0010\u00109\u001a\u00020\u001a2\u0006\u00100\u001a\u000201H\u0002J\u0010\u0010:\u001a\u00020;2\u0006\u0010,\u001a\u00020-H\u0002J\u0010\u0010<\u001a\u00020\u001a2\u0006\u0010,\u001a\u00020-H\u0002J\u0010\u0010=\u001a\u00020\u001a2\u0006\u00100\u001a\u000201H\u0002J\b\u0010>\u001a\u00020\u001aH\u0002J\b\u0010?\u001a\u00020@H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u000e\u0010\u000f\u001a\u00020\u0010X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082.¢\u0006\u0002\n\u0000R\u001a\u0010\u0013\u001a\u00020\u0014X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018¨\u0006A"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/fragments/ForgotPasswordEmailVerificationFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "authMainSharedViewModel", "Lpk/gov/nadra/oneapp/auth/main/viewModel/AuthMainSharedViewModel;", "getAuthMainSharedViewModel", "()Lpk/gov/nadra/oneapp/auth/main/viewModel/AuthMainSharedViewModel;", "authMainSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/ForgotPasswordEmailVerificationFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/auth/main/databinding/ForgotPasswordEmailVerificationFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/auth/main/views/AuthMainActivity;", "countdownTimer", "Landroid/os/CountDownTimer;", "sharedPreferencesTokenProvider", "Lpk/gov/nadra/oneapp/network/common/SharedPreferencesTokenProvider;", "getSharedPreferencesTokenProvider", "()Lpk/gov/nadra/oneapp/network/common/SharedPreferencesTokenProvider;", "setSharedPreferencesTokenProvider", "(Lpk/gov/nadra/oneapp/network/common/SharedPreferencesTokenProvider;)V", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "setUpUrduUi", "setupCountdownTimer", "setUpOtpListener", "getVerifyOtpRequest", "Lpk/gov/nadra/oneapp/models/register/VerifyOtpRequest;", "otp", "", "callVerifyOtp", "processVerifyOtpSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "handleFailureCase", "jsonResponse", "responseCode", "", "callForgotPasswordOtp", "getForgotPasswordOtpRequest", "Lpk/gov/nadra/oneapp/models/register/ForgotPasswordOtpRequest;", "processForgotPasswordOtpSuccessResponse", "getVerifyOtpPasswordRecoveryRequest", "Lpk/gov/nadra/oneapp/models/register/VerifyOtpPasswordRecoveryRequest;", "callVerifyOtpByCNIC", "processVerifyOtpPasswordRecoverySuccessResponse", "callResendForgotPasswordOtpByCNIC", "getCnicForgotPasswordOtpRequest", "Lpk/gov/nadra/oneapp/models/register/CnicForgotPasswordRequest;", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ForgotPasswordEmailVerificationFragment extends Fragment {
    private ForgotPasswordEmailVerificationFragmentBinding _binding;
    private AuthMainActivity activity;

    /* renamed from: authMainSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy authMainSharedViewModel;
    private CountDownTimer countdownTimer;
    public SharedPreferencesTokenProvider sharedPreferencesTokenProvider;

    public ForgotPasswordEmailVerificationFragment() {
        final ForgotPasswordEmailVerificationFragment forgotPasswordEmailVerificationFragment = this;
        final Function0 function0 = null;
        this.authMainSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(forgotPasswordEmailVerificationFragment, Reflection.getOrCreateKotlinClass(AuthMainSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = forgotPasswordEmailVerificationFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = forgotPasswordEmailVerificationFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = forgotPasswordEmailVerificationFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final AuthMainSharedViewModel getAuthMainSharedViewModel() {
        return (AuthMainSharedViewModel) this.authMainSharedViewModel.getValue();
    }

    private final ForgotPasswordEmailVerificationFragmentBinding getBinding() {
        ForgotPasswordEmailVerificationFragmentBinding forgotPasswordEmailVerificationFragmentBinding = this._binding;
        Intrinsics.checkNotNull(forgotPasswordEmailVerificationFragmentBinding);
        return forgotPasswordEmailVerificationFragmentBinding;
    }

    public final SharedPreferencesTokenProvider getSharedPreferencesTokenProvider() {
        SharedPreferencesTokenProvider sharedPreferencesTokenProvider = this.sharedPreferencesTokenProvider;
        if (sharedPreferencesTokenProvider != null) {
            return sharedPreferencesTokenProvider;
        }
        Intrinsics.throwUninitializedPropertyAccessException("sharedPreferencesTokenProvider");
        return null;
    }

    public final void setSharedPreferencesTokenProvider(SharedPreferencesTokenProvider sharedPreferencesTokenProvider) {
        Intrinsics.checkNotNullParameter(sharedPreferencesTokenProvider, "<set-?>");
        this.sharedPreferencesTokenProvider = sharedPreferencesTokenProvider;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity");
        this.activity = (AuthMainActivity) fragmentActivityRequireActivity;
        setSharedPreferencesTokenProvider(new SharedPreferencesTokenProvider(context));
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = ForgotPasswordEmailVerificationFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        setUpUrduUi();
        ForgotPasswordEmailVerificationFragmentBinding binding = getBinding();
        binding.headerLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ForgotPasswordEmailVerificationFragment.onViewCreated$lambda$2$lambda$0(this.f$0, view2);
            }
        });
        setupCountdownTimer();
        setUpOtpListener();
        CountDownTimer countDownTimer = this.countdownTimer;
        if (countDownTimer == null) {
            Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
            countDownTimer = null;
        }
        countDownTimer.start();
        binding.emailVerificationResendTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ForgotPasswordEmailVerificationFragment.onViewCreated$lambda$2$lambda$1(this.f$0, view2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$2$lambda$0(ForgotPasswordEmailVerificationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        CountDownTimer countDownTimer = this$0.countdownTimer;
        AuthMainActivity authMainActivity = null;
        if (countDownTimer == null) {
            Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
            countDownTimer = null;
        }
        countDownTimer.cancel();
        AuthMainActivity authMainActivity2 = this$0.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        authMainActivity.popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$2$lambda$1(ForgotPasswordEmailVerificationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (Intrinsics.areEqual(this$0.getAuthMainSharedViewModel().getOtpVerificationLoadFrom(), "AccountRecovery")) {
            this$0.callResendForgotPasswordOtpByCNIC();
        } else {
            this$0.callForgotPasswordOtp();
        }
    }

    private final void setUpUrduUi() {
        ForgotPasswordEmailVerificationFragmentBinding binding = getBinding();
        binding.headerLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ForgotPasswordEmailVerificationFragment.setUpUrduUi$lambda$4$lambda$3(this.f$0, view);
            }
        });
        TextView textView = binding.headerLayout.textBackUr;
        AuthMainActivity authMainActivity = this.activity;
        AuthMainActivity authMainActivity2 = null;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        textView.setTypeface(ResourcesCompat.getFont(authMainActivity, R.font.nadra_nastaleeq));
        TextView textView2 = binding.headerLayout.textSubtitle;
        AuthMainActivity authMainActivity3 = this.activity;
        if (authMainActivity3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity3 = null;
        }
        textView2.setTypeface(ResourcesCompat.getFont(authMainActivity3, R.font.nadra_nastaleeq));
        binding.headerLayout.iconInfo.setVisibility(8);
        TextView textView3 = binding.emailVerificationLabelTextView;
        Util util = Util.INSTANCE;
        AuthMainActivity authMainActivity4 = this.activity;
        if (authMainActivity4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity4 = null;
        }
        String string = getString(R.string.email_verification_label);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView3.setText(Util.setEnglishTextSpan$default(util, authMainActivity4, string, "\n ای میل پتہ / موبائل نمبر کی تصدیق\n ", com.intuit.sdp.R.dimen._14sdp, false, 8, null));
        TextView textView4 = binding.emailVerificationDescriptionTextView;
        Util util2 = Util.INSTANCE;
        AuthMainActivity authMainActivity5 = this.activity;
        if (authMainActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity5 = null;
        }
        String string2 = getString(R.string.email_verification_description);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textView4.setText(Util.setEnglishTextSpan$default(util2, authMainActivity5, string2, "\n\n آپ اپنے ای میل پتہ یا موبائل نمبر پر بھیجے گئے کوڈ کو درج کریں۔\n ", com.intuit.sdp.R.dimen._12sdp, false, 8, null));
        TextView textView5 = binding.emailVerificationCodeTextView;
        Util util3 = Util.INSTANCE;
        AuthMainActivity authMainActivity6 = this.activity;
        if (authMainActivity6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity6 = null;
        }
        String string3 = getString(R.string.email_verification_code);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        textView5.setText(Util.setEnglishTextSpan$default(util3, authMainActivity6, string3, " تصدیقی کوڈ ", com.intuit.sdp.R.dimen._12sdp, false, 8, null));
        TextView textView6 = binding.emailVerificationResendTextView;
        Util util4 = Util.INSTANCE;
        AuthMainActivity authMainActivity7 = this.activity;
        if (authMainActivity7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity2 = authMainActivity7;
        }
        String string4 = getString(R.string.resend_code);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        textView6.setText(Util.setEnglishTextSpan$default(util4, authMainActivity2, string4, " کوڈ دوبارہ بھیجیں ", com.intuit.sdp.R.dimen._14sdp, false, 8, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setUpUrduUi$lambda$4$lambda$3(ForgotPasswordEmailVerificationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        CountDownTimer countDownTimer = this$0.countdownTimer;
        AuthMainActivity authMainActivity = null;
        if (countDownTimer == null) {
            Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
            countDownTimer = null;
        }
        countDownTimer.cancel();
        AuthMainActivity authMainActivity2 = this$0.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        authMainActivity.popupFromNavHost();
    }

    private final void setupCountdownTimer() {
        final ForgotPasswordEmailVerificationFragmentBinding binding = getBinding();
        this.countdownTimer = new CountDownTimer() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$setupCountdownTimer$1$1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(30000L, 1000L);
            }

            @Override // android.os.CountDownTimer
            public void onTick(long millisUntilFinished) {
                try {
                    binding.emailVerificationResendDescriptionTextView.setText(this.getString(R.string.email_verification_resend_code_description, String.valueOf((int) (millisUntilFinished / 1000))));
                } catch (Exception unused) {
                    CountDownTimer countDownTimer = this.countdownTimer;
                    if (countDownTimer == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
                        countDownTimer = null;
                    }
                    countDownTimer.cancel();
                }
            }

            @Override // android.os.CountDownTimer
            public void onFinish() {
                binding.emailVerificationResendTextView.setVisibility(0);
                binding.emailVerificationResendDescriptionTextView.setVisibility(8);
            }
        };
    }

    private final void setUpOtpListener() {
        getBinding().otpView.setOtpListener(new OTPListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$setUpOtpListener$1$1
            @Override // com.otpview.OTPListener
            public void onInteractionListener() {
            }

            @Override // com.otpview.OTPListener
            public void onOTPComplete(String otp) {
                Intrinsics.checkNotNullParameter(otp, "otp");
                Util util = Util.INSTANCE;
                AuthMainActivity authMainActivity = this.this$0.activity;
                if (authMainActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    authMainActivity = null;
                }
                util.hideKeyboard(authMainActivity);
                if (Intrinsics.areEqual(this.this$0.getAuthMainSharedViewModel().getOtpVerificationLoadFrom(), "AccountRecovery")) {
                    this.this$0.getAuthMainSharedViewModel().setForgotPasswordOTP(otp);
                    this.this$0.callVerifyOtpByCNIC(otp);
                } else {
                    this.this$0.callVerifyOtp(otp);
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final VerifyOtpRequest getVerifyOtpRequest(String otp) {
        return new VerifyOtpRequest(getAuthMainSharedViewModel().getEmail(), otp);
    }

    /* compiled from: ForgotPasswordEmailVerificationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callVerifyOtp$1", f = "ForgotPasswordEmailVerificationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callVerifyOtp$1, reason: invalid class name and case insensitive filesystem */
    static final class C11201 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $otp;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C11201(String str, Continuation<? super C11201> continuation) {
            super(2, continuation);
            this.$otp = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ForgotPasswordEmailVerificationFragment.this.new C11201(this.$otp, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11201) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                AuthMainActivity authMainActivity = ForgotPasswordEmailVerificationFragment.this.activity;
                if (authMainActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    authMainActivity = null;
                }
                APIRequests aPIRequests = new APIRequests(authMainActivity);
                VerifyOtpRequest verifyOtpRequest = ForgotPasswordEmailVerificationFragment.this.getVerifyOtpRequest(this.$otp);
                final ForgotPasswordEmailVerificationFragment forgotPasswordEmailVerificationFragment = ForgotPasswordEmailVerificationFragment.this;
                aPIRequests.verifyOtp(verifyOtpRequest, new Function3() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callVerifyOtp$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        return ForgotPasswordEmailVerificationFragment.C11201.invokeSuspend$lambda$0(forgotPasswordEmailVerificationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                    }
                });
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ForgotPasswordEmailVerificationFragment forgotPasswordEmailVerificationFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = forgotPasswordEmailVerificationFragment.activity;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.hideLoader(authMainActivity);
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("callLoginApi() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                forgotPasswordEmailVerificationFragment.processVerifyOtpSuccessResponse(jsonObject);
            } else {
                forgotPasswordEmailVerificationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void callVerifyOtp(String otp) {
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        loaderManager.showLoader(authMainActivity);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11201(otp, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processVerifyOtpSuccessResponse(JsonObject jSonObject) {
        VerifyOtpResponse verifyOtpResponse = (VerifyOtpResponse) new Gson().fromJson(jSonObject.toString(), VerifyOtpResponse.class);
        if (verifyOtpResponse.getMessage().length() > 0) {
            BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
            AuthMainActivity authMainActivity = this.activity;
            AuthMainActivity authMainActivity2 = null;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            AuthMainActivity authMainActivity3 = authMainActivity;
            String string = getString(R.string.info_label);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            String message = verifyOtpResponse.getMessage();
            Util util = Util.INSTANCE;
            AuthMainActivity authMainActivity4 = this.activity;
            if (authMainActivity4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity2 = authMainActivity4;
            }
            SpannableString englishTextSpan$default = Util.setEnglishTextSpan$default(util, authMainActivity2, "Proceed", " (آگے بڑھیں)", 0, false, 12, null);
            String message_local = verifyOtpResponse.getMessage_local();
            bottomSheetUtils.showMessageBottomSheet((FragmentActivity) authMainActivity3, string, message, true, (CharSequence) englishTextSpan$default, !(message_local == null || message_local.length() == 0), verifyOtpResponse.getMessage_local(), new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return ForgotPasswordEmailVerificationFragment.processVerifyOtpSuccessResponse$lambda$9$lambda$7(this.f$0);
                }
            }, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda8
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return Unit.INSTANCE;
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processVerifyOtpSuccessResponse$lambda$9$lambda$7(ForgotPasswordEmailVerificationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.forgotPasswordSetNewPasswordFragment);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        AuthMainActivity authMainActivity = null;
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    for (ErrorResponse.Error error : errors) {
                        arrayList.add(String.valueOf(error.getMessage()));
                        String message_local = error.getMessage_local();
                        if (message_local == null) {
                            message_local = "";
                        }
                        arrayList2.add(message_local);
                    }
                }
                if (arrayList.isEmpty()) {
                    return;
                }
                BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
                AuthMainActivity authMainActivity2 = this.activity;
                if (authMainActivity2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                } else {
                    authMainActivity = authMainActivity2;
                }
                BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) authMainActivity, "Alert", CollectionsKt.joinToString$default(arrayList, "\n", null, null, 0, null, null, 62, null), false, true, CollectionsKt.joinToString$default(arrayList2, "\n", null, null, 0, null, null, 62, null), (Function1) null, 72, (Object) null);
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            AuthMainActivity authMainActivity3 = this.activity;
            if (authMainActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity = authMainActivity3;
            }
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, authMainActivity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return ForgotPasswordEmailVerificationFragment.handleFailureCase$lambda$12(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        AuthMainActivity authMainActivity4 = this.activity;
        if (authMainActivity4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity4;
        }
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, authMainActivity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ForgotPasswordEmailVerificationFragment.handleFailureCase$lambda$13(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$12(ForgotPasswordEmailVerificationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$13(ForgotPasswordEmailVerificationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* compiled from: ForgotPasswordEmailVerificationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callForgotPasswordOtp$1", f = "ForgotPasswordEmailVerificationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callForgotPasswordOtp$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ForgotPasswordEmailVerificationFragment.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                AuthMainActivity authMainActivity = ForgotPasswordEmailVerificationFragment.this.activity;
                if (authMainActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    authMainActivity = null;
                }
                APIRequests aPIRequests = new APIRequests(authMainActivity);
                ForgotPasswordOtpRequest forgotPasswordOtpRequest = ForgotPasswordEmailVerificationFragment.this.getForgotPasswordOtpRequest();
                final ForgotPasswordEmailVerificationFragment forgotPasswordEmailVerificationFragment = ForgotPasswordEmailVerificationFragment.this;
                aPIRequests.forgotPasswordOtp(forgotPasswordOtpRequest, new Function3() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callForgotPasswordOtp$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        return ForgotPasswordEmailVerificationFragment.AnonymousClass1.invokeSuspend$lambda$0(forgotPasswordEmailVerificationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                    }
                });
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ForgotPasswordEmailVerificationFragment forgotPasswordEmailVerificationFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = forgotPasswordEmailVerificationFragment.activity;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.hideLoader(authMainActivity);
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("callLoginApi() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                forgotPasswordEmailVerificationFragment.processForgotPasswordOtpSuccessResponse(jsonObject);
            } else {
                forgotPasswordEmailVerificationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void callForgotPasswordOtp() {
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        loaderManager.showLoader(authMainActivity);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final ForgotPasswordOtpRequest getForgotPasswordOtpRequest() {
        return new ForgotPasswordOtpRequest(getAuthMainSharedViewModel().getEmail(), "MOBILE");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processForgotPasswordOtpSuccessResponse(JsonObject jSonObject) {
        ForgotPasswordOtpResponse forgotPasswordOtpResponse = (ForgotPasswordOtpResponse) new Gson().fromJson(jSonObject.toString(), ForgotPasswordOtpResponse.class);
        if (forgotPasswordOtpResponse.getMessage().length() > 0) {
            BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
            AuthMainActivity authMainActivity = this.activity;
            CountDownTimer countDownTimer = null;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            AuthMainActivity authMainActivity2 = authMainActivity;
            String string = getString(R.string.info_label);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            String message = forgotPasswordOtpResponse.getMessage();
            String message_local = forgotPasswordOtpResponse.getMessage_local();
            BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) authMainActivity2, string, message, false, !(message_local == null || message_local.length() == 0), forgotPasswordOtpResponse.getMessage_local(), (Function1) null, 72, (Object) null);
            getBinding().emailVerificationResendTextView.setVisibility(8);
            getBinding().emailVerificationResendDescriptionTextView.setVisibility(0);
            CountDownTimer countDownTimer2 = this.countdownTimer;
            if (countDownTimer2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
            } else {
                countDownTimer = countDownTimer2;
            }
            countDownTimer.start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final VerifyOtpPasswordRecoveryRequest getVerifyOtpPasswordRecoveryRequest(String otp) {
        SharedPreferencesTokenProvider sharedPreferencesTokenProvider = getSharedPreferencesTokenProvider();
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        sharedPreferencesTokenProvider.saveDeviceId(AppPreferences.getInstance(authMainActivity).getFcmToken());
        return new VerifyOtpPasswordRecoveryRequest(getAuthMainSharedViewModel().getEmail(), otp, RSAKeyPair.INSTANCE.getPublicKeyString(), getSharedPreferencesTokenProvider().getDeviceId());
    }

    /* compiled from: ForgotPasswordEmailVerificationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callVerifyOtpByCNIC$1", f = "ForgotPasswordEmailVerificationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callVerifyOtpByCNIC$1, reason: invalid class name and case insensitive filesystem */
    static final class C11211 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $otp;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C11211(String str, Continuation<? super C11211> continuation) {
            super(2, continuation);
            this.$otp = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ForgotPasswordEmailVerificationFragment.this.new C11211(this.$otp, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11211) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                AuthMainActivity authMainActivity = ForgotPasswordEmailVerificationFragment.this.activity;
                if (authMainActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    authMainActivity = null;
                }
                APIRequests aPIRequests = new APIRequests(authMainActivity);
                VerifyOtpPasswordRecoveryRequest verifyOtpPasswordRecoveryRequest = ForgotPasswordEmailVerificationFragment.this.getVerifyOtpPasswordRecoveryRequest(this.$otp);
                final ForgotPasswordEmailVerificationFragment forgotPasswordEmailVerificationFragment = ForgotPasswordEmailVerificationFragment.this;
                aPIRequests.verifyOtpByCNIC(verifyOtpPasswordRecoveryRequest, new Function3() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callVerifyOtpByCNIC$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        return ForgotPasswordEmailVerificationFragment.C11211.invokeSuspend$lambda$0(forgotPasswordEmailVerificationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                    }
                });
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ForgotPasswordEmailVerificationFragment forgotPasswordEmailVerificationFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = forgotPasswordEmailVerificationFragment.activity;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.hideLoader(authMainActivity);
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("callLoginApi() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                forgotPasswordEmailVerificationFragment.processVerifyOtpPasswordRecoverySuccessResponse(jsonObject);
            } else {
                forgotPasswordEmailVerificationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void callVerifyOtpByCNIC(String otp) {
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        loaderManager.showLoader(authMainActivity);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11211(otp, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processVerifyOtpPasswordRecoverySuccessResponse(JsonObject jSonObject) {
        final VerifyOtpPasswordRecoveryResponse verifyOtpPasswordRecoveryResponse = (VerifyOtpPasswordRecoveryResponse) new Gson().fromJson(jSonObject.toString(), VerifyOtpPasswordRecoveryResponse.class);
        if (verifyOtpPasswordRecoveryResponse.getMessage().length() > 0) {
            getAuthMainSharedViewModel().setPasswordRecoveryAESKey(verifyOtpPasswordRecoveryResponse.getAesKey());
            BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
            AuthMainActivity authMainActivity = this.activity;
            AuthMainActivity authMainActivity2 = null;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            AuthMainActivity authMainActivity3 = authMainActivity;
            String string = getString(R.string.info_label);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            String message = verifyOtpPasswordRecoveryResponse.getMessage();
            Util util = Util.INSTANCE;
            AuthMainActivity authMainActivity4 = this.activity;
            if (authMainActivity4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity2 = authMainActivity4;
            }
            SpannableString englishTextSpan$default = Util.setEnglishTextSpan$default(util, authMainActivity2, "Proceed", " (آگے بڑھیں)", 0, false, 12, null);
            String message_local = verifyOtpPasswordRecoveryResponse.getMessage_local();
            bottomSheetUtils.showMessageBottomSheet((FragmentActivity) authMainActivity3, string, message, true, (CharSequence) englishTextSpan$default, !(message_local == null || message_local.length() == 0), verifyOtpPasswordRecoveryResponse.getMessage_local(), new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return ForgotPasswordEmailVerificationFragment.processVerifyOtpPasswordRecoverySuccessResponse$lambda$17$lambda$15(verifyOtpPasswordRecoveryResponse, this);
                }
            }, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda6
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return ForgotPasswordEmailVerificationFragment.processVerifyOtpPasswordRecoverySuccessResponse$lambda$17$lambda$16(verifyOtpPasswordRecoveryResponse, this);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0040  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final kotlin.Unit processVerifyOtpPasswordRecoverySuccessResponse$lambda$17$lambda$15(pk.gov.nadra.oneapp.models.register.VerifyOtpPasswordRecoveryResponse r5, pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment r6) {
        /*
            java.lang.String r0 = "this$0"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.lang.String r0 = r5.getStage()
            java.lang.CharSequence r0 = (java.lang.CharSequence) r0
            r1 = 0
            java.lang.String r2 = "activity"
            java.lang.String r3 = "toLowerCase(...)"
            if (r0 == 0) goto L40
            int r0 = r0.length()
            if (r0 != 0) goto L19
            goto L40
        L19:
            java.lang.String r0 = r5.getStage()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            java.util.Locale r4 = java.util.Locale.ROOT
            java.lang.String r0 = r0.toLowerCase(r4)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r3)
            java.lang.String r4 = "facial"
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r4)
            if (r0 == 0) goto L40
            pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity r5 = r6.activity
            if (r5 != 0) goto L39
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r2)
            goto L3a
        L39:
            r1 = r5
        L3a:
            int r5 = pk.gov.nadra.oneapp.auth.main.R.id.verifyRegistrationPhotographFragment
            r1.navigateToFragment(r5)
            goto L75
        L40:
            java.lang.String r0 = r5.getStage()
            java.lang.CharSequence r0 = (java.lang.CharSequence) r0
            if (r0 == 0) goto L75
            int r0 = r0.length()
            if (r0 != 0) goto L4f
            goto L75
        L4f:
            java.lang.String r5 = r5.getStage()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r5)
            java.util.Locale r0 = java.util.Locale.ROOT
            java.lang.String r5 = r5.toLowerCase(r0)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r3)
            java.lang.String r0 = "password-update"
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r0)
            if (r5 == 0) goto L75
            pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity r5 = r6.activity
            if (r5 != 0) goto L6f
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r2)
            goto L70
        L6f:
            r1 = r5
        L70:
            int r5 = pk.gov.nadra.oneapp.auth.main.R.id.forgotPasswordSetNewPasswordFragment
            r1.navigateToFragment(r5)
        L75:
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment.processVerifyOtpPasswordRecoverySuccessResponse$lambda$17$lambda$15(pk.gov.nadra.oneapp.models.register.VerifyOtpPasswordRecoveryResponse, pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment):kotlin.Unit");
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0040  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final kotlin.Unit processVerifyOtpPasswordRecoverySuccessResponse$lambda$17$lambda$16(pk.gov.nadra.oneapp.models.register.VerifyOtpPasswordRecoveryResponse r5, pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment r6) {
        /*
            java.lang.String r0 = "this$0"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.lang.String r0 = r5.getStage()
            java.lang.CharSequence r0 = (java.lang.CharSequence) r0
            r1 = 0
            java.lang.String r2 = "activity"
            java.lang.String r3 = "toLowerCase(...)"
            if (r0 == 0) goto L40
            int r0 = r0.length()
            if (r0 != 0) goto L19
            goto L40
        L19:
            java.lang.String r0 = r5.getStage()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            java.util.Locale r4 = java.util.Locale.ROOT
            java.lang.String r0 = r0.toLowerCase(r4)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r3)
            java.lang.String r4 = "facial"
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r4)
            if (r0 == 0) goto L40
            pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity r5 = r6.activity
            if (r5 != 0) goto L39
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r2)
            goto L3a
        L39:
            r1 = r5
        L3a:
            int r5 = pk.gov.nadra.oneapp.auth.main.R.id.verifyRegistrationPhotographFragment
            r1.navigateToFragment(r5)
            goto L75
        L40:
            java.lang.String r0 = r5.getStage()
            java.lang.CharSequence r0 = (java.lang.CharSequence) r0
            if (r0 == 0) goto L75
            int r0 = r0.length()
            if (r0 != 0) goto L4f
            goto L75
        L4f:
            java.lang.String r5 = r5.getStage()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r5)
            java.util.Locale r0 = java.util.Locale.ROOT
            java.lang.String r5 = r5.toLowerCase(r0)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r3)
            java.lang.String r0 = "password-update"
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r0)
            if (r5 == 0) goto L75
            pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity r5 = r6.activity
            if (r5 != 0) goto L6f
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r2)
            goto L70
        L6f:
            r1 = r5
        L70:
            int r5 = pk.gov.nadra.oneapp.auth.main.R.id.forgotPasswordSetNewPasswordFragment
            r1.navigateToFragment(r5)
        L75:
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment.processVerifyOtpPasswordRecoverySuccessResponse$lambda$17$lambda$16(pk.gov.nadra.oneapp.models.register.VerifyOtpPasswordRecoveryResponse, pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment):kotlin.Unit");
    }

    /* compiled from: ForgotPasswordEmailVerificationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callResendForgotPasswordOtpByCNIC$1", f = "ForgotPasswordEmailVerificationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callResendForgotPasswordOtpByCNIC$1, reason: invalid class name and case insensitive filesystem */
    static final class C11191 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C11191(Continuation<? super C11191> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ForgotPasswordEmailVerificationFragment.this.new C11191(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11191) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                AuthMainActivity authMainActivity = ForgotPasswordEmailVerificationFragment.this.activity;
                if (authMainActivity == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                    authMainActivity = null;
                }
                APIRequests aPIRequests = new APIRequests(authMainActivity);
                CnicForgotPasswordRequest cnicForgotPasswordOtpRequest = ForgotPasswordEmailVerificationFragment.this.getCnicForgotPasswordOtpRequest();
                final ForgotPasswordEmailVerificationFragment forgotPasswordEmailVerificationFragment = ForgotPasswordEmailVerificationFragment.this;
                aPIRequests.resendForgotPasswordOtpByCNIC(cnicForgotPasswordOtpRequest, new Function3() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ForgotPasswordEmailVerificationFragment$callResendForgotPasswordOtpByCNIC$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        return ForgotPasswordEmailVerificationFragment.C11191.invokeSuspend$lambda$0(forgotPasswordEmailVerificationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                    }
                });
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(ForgotPasswordEmailVerificationFragment forgotPasswordEmailVerificationFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = forgotPasswordEmailVerificationFragment.activity;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.hideLoader(authMainActivity);
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("callLoginApi() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                forgotPasswordEmailVerificationFragment.processForgotPasswordOtpSuccessResponse(jsonObject);
            } else {
                forgotPasswordEmailVerificationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void callResendForgotPasswordOtpByCNIC() {
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        loaderManager.showLoader(authMainActivity);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11191(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final CnicForgotPasswordRequest getCnicForgotPasswordOtpRequest() {
        return new CnicForgotPasswordRequest(getAuthMainSharedViewModel().getForgotPasswordCNIC(), getAuthMainSharedViewModel().getEmail(), "MOBILE");
    }
}