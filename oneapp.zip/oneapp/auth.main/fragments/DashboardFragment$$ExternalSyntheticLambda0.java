package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function1;
import pk.gov.nadra.oneapp.digitalvault.presentation.state.UiState;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda0 implements Function1 {
    public /* synthetic */ DashboardFragment$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return DashboardFragment.digitalQrScanLogObserver$lambda$37(this.f$0, (UiState) obj);
    }
}