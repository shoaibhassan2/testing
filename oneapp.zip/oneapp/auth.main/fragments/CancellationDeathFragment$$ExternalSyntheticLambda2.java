package pk.gov.nadra.oneapp.auth.main.fragments;

import android.content.res.Resources;
import android.widget.RadioGroup;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CancellationDeathFragment$$ExternalSyntheticLambda2 implements RadioGroup.OnCheckedChangeListener {
    public /* synthetic */ CancellationDeathFragment$$ExternalSyntheticLambda2() {
    }

    @Override // android.widget.RadioGroup.OnCheckedChangeListener
    public final void onCheckedChanged(RadioGroup radioGroup, int i) throws Resources.NotFoundException {
        CancellationDeathFragment.initViews$lambda$10$lambda$5(binding, radioGroup, i);
    }
}