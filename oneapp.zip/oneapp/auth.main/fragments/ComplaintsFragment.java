package pk.gov.nadra.oneapp.auth.main.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebViewClient;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.google.android.gms.analytics.ecommerce.Promotion;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.chatbot.ChatActivity;
import pk.gov.nadra.oneapp.auth.main.databinding.ComplaintsFragmentBinding;
import pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.Util;

/* compiled from: ComplaintsFragment.kt */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0016J$\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0013H\u0016J\u001a\u0010\u0014\u001a\u00020\t2\u0006\u0010\u0015\u001a\u00020\r2\b\u0010\u0012\u001a\u0004\u0018\u00010\u0013H\u0016J\b\u0010\u0016\u001a\u00020\tH\u0002J\b\u0010\u0017\u001a\u00020\tH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.¢\u0006\u0002\n\u0000¨\u0006\u0018"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/fragments/ComplaintsFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/ComplaintsFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/auth/main/views/AuthMainActivity;", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "attachHeaderViews", "setupWebView", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ComplaintsFragment extends Fragment {
    private AuthMainActivity activity;
    private ComplaintsFragmentBinding binding;

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity");
        this.activity = (AuthMainActivity) fragmentActivityRequireActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        ComplaintsFragmentBinding complaintsFragmentBindingInflate = ComplaintsFragmentBinding.inflate(inflater, container, false);
        this.binding = complaintsFragmentBindingInflate;
        if (complaintsFragmentBindingInflate == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            complaintsFragmentBindingInflate = null;
        }
        ConstraintLayout root = complaintsFragmentBindingInflate.getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        attachHeaderViews();
        setupWebView();
        ComplaintsFragmentBinding complaintsFragmentBinding = this.binding;
        if (complaintsFragmentBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            complaintsFragmentBinding = null;
        }
        complaintsFragmentBinding.complaintWebView.loadUrl(Constant.COMPLAINTS_URL);
    }

    private final void attachHeaderViews() {
        ComplaintsFragmentBinding complaintsFragmentBinding = this.binding;
        AuthMainActivity authMainActivity = null;
        if (complaintsFragmentBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            complaintsFragmentBinding = null;
        }
        TextView textView = complaintsFragmentBinding.complaintsHeaderTitleTextView;
        Util util = Util.INSTANCE;
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        String string = getString(R.string.complaints);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util, authMainActivity, string, " (" + getString(R.string.urdu_complaints) + ")", 0, false, 12, null));
        complaintsFragmentBinding.complaintsHeaderChatImageView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ComplaintsFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ComplaintsFragment.attachHeaderViews$lambda$3$lambda$0(this.f$0, view);
            }
        });
        complaintsFragmentBinding.complaintsHeaderInboxImageView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ComplaintsFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ComplaintsFragment.attachHeaderViews$lambda$3$lambda$1(this.f$0, view);
            }
        });
        complaintsFragmentBinding.complaintsHeaderNotificationImageView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.ComplaintsFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ComplaintsFragment.attachHeaderViews$lambda$3$lambda$2(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachHeaderViews$lambda$3$lambda$0(ComplaintsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        this$0.startActivity(new Intent(authMainActivity, (Class<?>) ChatActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachHeaderViews$lambda$3$lambda$1(ComplaintsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.inboxFragment);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachHeaderViews$lambda$3$lambda$2(ComplaintsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.notificationFragment);
    }

    private final void setupWebView() {
        ComplaintsFragmentBinding complaintsFragmentBinding = this.binding;
        ComplaintsFragmentBinding complaintsFragmentBinding2 = null;
        if (complaintsFragmentBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            complaintsFragmentBinding = null;
        }
        complaintsFragmentBinding.complaintWebView.getSettings().setJavaScriptEnabled(true);
        ComplaintsFragmentBinding complaintsFragmentBinding3 = this.binding;
        if (complaintsFragmentBinding3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        } else {
            complaintsFragmentBinding2 = complaintsFragmentBinding3;
        }
        complaintsFragmentBinding2.complaintWebView.setWebViewClient(new WebViewClient());
    }
}