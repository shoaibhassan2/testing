package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda5 implements Function0 {
    public final /* synthetic */ ForgotPasswordEmailVerificationFragment f$1;

    public /* synthetic */ ForgotPasswordEmailVerificationFragment$$ExternalSyntheticLambda5(ForgotPasswordEmailVerificationFragment forgotPasswordEmailVerificationFragment) {
        this = forgotPasswordEmailVerificationFragment;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return ForgotPasswordEmailVerificationFragment.processVerifyOtpPasswordRecoverySuccessResponse$lambda$17$lambda$15(verifyOtpPasswordRecoveryResponse, this);
    }
}