package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function0;
import pk.gov.nadra.oneapp.digitalvault.domain.model.DigitalIdDocumentItem;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda24 implements Function0 {
    public final /* synthetic */ DashboardFragment f$1;
    public final /* synthetic */ DigitalIdDocumentItem f$2;

    public /* synthetic */ DashboardFragment$$ExternalSyntheticLambda24(DashboardFragment dashboardFragment, DigitalIdDocumentItem digitalIdDocumentItem) {
        this = dashboardFragment;
        activeDocument = digitalIdDocumentItem;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return DashboardFragment.handleResponse$lambda$33(response, this, activeDocument);
    }
}