package pk.gov.nadra.oneapp.auth.main.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ComplaintsFragment$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public /* synthetic */ ComplaintsFragment$$ExternalSyntheticLambda1() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ComplaintsFragment.attachHeaderViews$lambda$3$lambda$1(this.f$0, view);
    }
}