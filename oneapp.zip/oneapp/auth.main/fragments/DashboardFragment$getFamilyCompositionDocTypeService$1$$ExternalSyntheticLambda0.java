package pk.gov.nadra.oneapp.auth.main.fragments;

import com.google.gson.JsonObject;
import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.auth.main.fragments.DashboardFragment;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$getFamilyCompositionDocTypeService$1$$ExternalSyntheticLambda0 implements Function3 {
    public final /* synthetic */ String f$1;
    public final /* synthetic */ boolean f$2;
    public final /* synthetic */ boolean f$3;

    public /* synthetic */ DashboardFragment$getFamilyCompositionDocTypeService$1$$ExternalSyntheticLambda0(String str, boolean z, boolean z2) {
        str = str;
        z = z;
        z2 = z2;
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return DashboardFragment.AnonymousClass1.invokeSuspend$lambda$0(dashboardFragment, str, z, z2, (JsonObject) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}