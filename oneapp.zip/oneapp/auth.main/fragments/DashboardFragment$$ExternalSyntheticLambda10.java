package pk.gov.nadra.oneapp.auth.main.fragments;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda10 implements Runnable {
    public /* synthetic */ DashboardFragment$$ExternalSyntheticLambda10() {
    }

    @Override // java.lang.Runnable
    public final void run() {
        DashboardFragment.onViewCreated$lambda$1(this.f$0);
    }
}