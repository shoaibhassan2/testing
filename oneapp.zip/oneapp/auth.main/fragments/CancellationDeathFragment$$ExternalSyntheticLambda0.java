package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class CancellationDeathFragment$$ExternalSyntheticLambda0 implements Function0 {
    public /* synthetic */ CancellationDeathFragment$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return CancellationDeathFragment.handleFailureCase$lambda$17(this.f$0);
    }
}