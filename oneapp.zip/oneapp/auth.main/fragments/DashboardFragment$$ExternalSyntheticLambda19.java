package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function1;
import pk.gov.nadra.oneapp.digitalvault.data.local.model.DigitalDocumentEntity;
import pk.gov.nadra.oneapp.digitalvault.domain.model.DigitalIdDocumentItem;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda19 implements Function1 {
    public final /* synthetic */ DigitalIdDocumentItem f$1;

    public /* synthetic */ DashboardFragment$$ExternalSyntheticLambda19(DigitalIdDocumentItem digitalIdDocumentItem) {
        activeDocument = digitalIdDocumentItem;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return DashboardFragment.handleResponse$lambda$33$lambda$31(this.f$0, activeDocument, (DigitalDocumentEntity) obj);
    }
}