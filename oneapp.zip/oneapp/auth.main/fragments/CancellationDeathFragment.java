package pk.gov.nadra.oneapp.auth.main.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.auth.main.databinding.CancellationDeathFragmentBinding;
import pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment;
import pk.gov.nadra.oneapp.auth.main.viewModel.AuthMainSharedViewModel;
import pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity;
import pk.gov.nadra.oneapp.cancellation.views.CancellationActivity;
import pk.gov.nadra.oneapp.commonui.CnicMaskWatcher;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.preferences.AppPreferences;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.crms.views.CrmsDeathActivity;
import pk.gov.nadra.oneapp.models.cnicCrmsDeath.CheckCnicCrmsDeathRequest;
import pk.gov.nadra.oneapp.models.cnicCrmsDeath.CheckCnicCrmsDeathResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintRequest;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintResponse;
import pk.gov.nadra.oneapp.models.dashboard.SyncUserWithCrmsResponse;
import pk.gov.nadra.oneapp.models.login.LoginResponse;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: CancellationDeathFragment.kt */
@Metadata(d1 = {"\u0000\u009a\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u001fH\u0016J$\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010%2\b\u0010&\u001a\u0004\u0018\u00010'H\u0016J\u001a\u0010(\u001a\u00020\u001d2\u0006\u0010)\u001a\u00020!2\b\u0010&\u001a\u0004\u0018\u00010'H\u0016J\b\u0010*\u001a\u00020\u001dH\u0002J\b\u0010+\u001a\u00020,H\u0002J\u0010\u0010-\u001a\u00020\u001d2\u0006\u0010.\u001a\u00020\u0014H\u0002J\u0010\u0010/\u001a\u00020\u001d2\u0006\u00100\u001a\u000201H\u0002J\u0010\u00102\u001a\u00020\u001d2\u0006\u0010.\u001a\u00020\u0014H\u0002J\u0010\u00103\u001a\u00020\u001d2\u0006\u00100\u001a\u000201H\u0002J\u0018\u00104\u001a\u00020\u001d2\u0006\u00105\u001a\u0002012\u0006\u00106\u001a\u000207H\u0002J\b\u00108\u001a\u000209H\u0002J0\u0010:\u001a\u00020\u001d2\u0006\u0010;\u001a\u00020\u00142\u0006\u0010<\u001a\u00020\u00142\u0006\u0010=\u001a\u00020,2\u0006\u0010>\u001a\u00020,2\u0006\u0010?\u001a\u00020@H\u0002J\u0010\u0010A\u001a\u00020\u001d2\u0006\u0010B\u001a\u00020\u0014H\u0002J\u0018\u0010C\u001a\u00020\u001d2\u0006\u0010D\u001a\u00020\u00142\u0006\u0010B\u001a\u00020\u0014H\u0002J\u0018\u0010E\u001a\u00020\u001d2\u0006\u00100\u001a\u0002012\u0006\u0010B\u001a\u00020\u0014H\u0002J$\u0010F\u001a\u00020\u001d2\u0006\u0010D\u001a\u00020\u00142\u0006\u0010G\u001a\u00020\u00142\n\u0010H\u001a\u0006\u0012\u0002\b\u00030IH\u0002R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u001b\u0010\u000b\u001a\u00020\f8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000f\u0010\u0010\u001a\u0004\b\r\u0010\u000eR\u000e\u0010\u0011\u001a\u00020\u0012X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R'\u0010\u0016\u001a\u000e\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\u00180\u00178BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u001b\u0010\u0010\u001a\u0004\b\u0019\u0010\u001aR\u001c\u0010J\u001a\u0010\u0012\f\u0012\n M*\u0004\u0018\u00010L0L0KX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006N"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/fragments/CancellationDeathFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/CancellationDeathFragmentBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/auth/main/databinding/CancellationDeathFragmentBinding;", "activity", "Lpk/gov/nadra/oneapp/auth/main/views/AuthMainActivity;", "authMainSharedViewModel", "Lpk/gov/nadra/oneapp/auth/main/viewModel/AuthMainSharedViewModel;", "getAuthMainSharedViewModel", "()Lpk/gov/nadra/oneapp/auth/main/viewModel/AuthMainSharedViewModel;", "authMainSharedViewModel$delegate", "Lkotlin/Lazy;", "userCredentials", "Lpk/gov/nadra/oneapp/models/login/LoginResponse;", "deceasedCitizenNumber", "", "deceasedDocumentType", "fieldToViewMap", "", "Lcom/google/android/material/textfield/TextInputLayout;", "getFieldToViewMap", "()Ljava/util/Map;", "fieldToViewMap$delegate", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "initViews", "isInputValid", "", "checkCnicCrmsDeathService", "cnic", "processCheckCnicCrmsDeathSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "getMySelfDocTypeService", "processGetMySelfDocTypeSuccessResponse", "handleFailureCase", "jsonResponse", "responseCode", "", "getReactNativeData", "Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "startCancellation", "citizenNumber", "applicationType", "applicantFingerprintsExist", "livelinessControl", "verifyFingerprintResponse", "Lpk/gov/nadra/oneapp/models/crc/fingerprint/VerifyFingerprintResponse;", "syncUserWithCrms", "crmsType", "handleCrmsLaunch", "userId", "processSyncUserWithCrmsSuccessResponse", "startCrmsFlow", "appType", "activityClass", "Ljava/lang/Class;", "intentLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class CancellationDeathFragment extends Fragment {
    private CancellationDeathFragmentBinding _binding;
    private AuthMainActivity activity;

    /* renamed from: authMainSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy authMainSharedViewModel;
    private String deceasedCitizenNumber = "";
    private String deceasedDocumentType = "";

    /* renamed from: fieldToViewMap$delegate, reason: from kotlin metadata */
    private final Lazy fieldToViewMap = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda9
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return CancellationDeathFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
        }
    });
    private final ActivityResultLauncher<Intent> intentLauncher;
    private LoginResponse userCredentials;

    public CancellationDeathFragment() {
        final CancellationDeathFragment cancellationDeathFragment = this;
        final Function0 function0 = null;
        this.authMainSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(cancellationDeathFragment, Reflection.getOrCreateKotlinClass(AuthMainSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = cancellationDeathFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = cancellationDeathFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = cancellationDeathFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda10
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                CancellationDeathFragment.intentLauncher$lambda$21(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.intentLauncher = activityResultLauncherRegisterForActivityResult;
    }

    private final CancellationDeathFragmentBinding getBinding() {
        CancellationDeathFragmentBinding cancellationDeathFragmentBinding = this._binding;
        Intrinsics.checkNotNull(cancellationDeathFragmentBinding);
        return cancellationDeathFragmentBinding;
    }

    private final AuthMainSharedViewModel getAuthMainSharedViewModel() {
        return (AuthMainSharedViewModel) this.authMainSharedViewModel.getValue();
    }

    private final Map<String, TextInputLayout> getFieldToViewMap() {
        return (Map) this.fieldToViewMap.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Map fieldToViewMap_delegate$lambda$0(CancellationDeathFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        return MapsKt.mapOf(TuplesKt.to("citizenNumber", this$0.getBinding().deceasedCnicLayout.maskedCnicTextInputLayout));
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.auth.main.views.AuthMainActivity");
        this.activity = (AuthMainActivity) fragmentActivityRequireActivity;
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        this.userCredentials = new SharedPreferencesTokenProvider(authMainActivity).getUserCredentials();
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = CancellationDeathFragmentBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        initViews();
    }

    private final void initViews() {
        final CancellationDeathFragmentBinding binding = getBinding();
        binding.newAppHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                CancellationDeathFragment.initViews$lambda$10$lambda$1(this.f$0, view);
            }
        });
        TextView textView = binding.newAppHeaderLayout.textBackUr;
        AuthMainActivity authMainActivity = this.activity;
        AuthMainActivity authMainActivity2 = null;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        textView.setTypeface(ResourcesCompat.getFont(authMainActivity, R.font.nadra_nastaleeq));
        binding.newAppHeaderLayout.textTitle.setText("Cancellation due to Death");
        binding.newAppHeaderLayout.textSubtitle.setText("وفات کی وجہ سے منسوخی");
        binding.newAppHeaderLayout.iconInfo.setVisibility(0);
        binding.newAppHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                CancellationDeathFragment.initViews$lambda$10$lambda$4(this.f$0, view);
            }
        });
        RadioButton radioButton = binding.rbYes;
        Util util = Util.INSTANCE;
        AuthMainActivity authMainActivity3 = this.activity;
        if (authMainActivity3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity3 = null;
        }
        radioButton.setText(Util.setEnglishTextSpan$default(util, authMainActivity3, "Yes", "  (ہاں)", 0, false, 12, null));
        RadioButton radioButton2 = binding.rbNo;
        Util util2 = Util.INSTANCE;
        AuthMainActivity authMainActivity4 = this.activity;
        if (authMainActivity4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity4 = null;
        }
        radioButton2.setText(Util.setEnglishTextSpan$default(util2, authMainActivity4, "No", "  (نہیں)", 0, false, 12, null));
        binding.rgIdentity.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda2
            @Override // android.widget.RadioGroup.OnCheckedChangeListener
            public final void onCheckedChanged(RadioGroup radioGroup, int i) throws Resources.NotFoundException {
                CancellationDeathFragment.initViews$lambda$10$lambda$5(binding, radioGroup, i);
            }
        });
        TextView textView2 = binding.newAppHeaderLayout.textSubtitle;
        AuthMainActivity authMainActivity5 = this.activity;
        if (authMainActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity5 = null;
        }
        textView2.setTypeface(ResourcesCompat.getFont(authMainActivity5, R.font.nadra_nastaleeq));
        TextView textView3 = binding.tvIdentityNoRecordUrdu;
        AuthMainActivity authMainActivity6 = this.activity;
        if (authMainActivity6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity6 = null;
        }
        textView3.setTypeface(ResourcesCompat.getFont(authMainActivity6, R.font.nadra_nastaleeq));
        TextView textView4 = binding.tvRegisterDeathCivilUrdu;
        AuthMainActivity authMainActivity7 = this.activity;
        if (authMainActivity7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity7 = null;
        }
        textView4.setTypeface(ResourcesCompat.getFont(authMainActivity7, R.font.nadra_nastaleeq));
        TextView textView5 = binding.tvIdentityTypeUrdu;
        AuthMainActivity authMainActivity8 = this.activity;
        if (authMainActivity8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity8 = null;
        }
        textView5.setTypeface(ResourcesCompat.getFont(authMainActivity8, R.font.nadra_nastaleeq));
        TextInputLayout textInputLayout = binding.deceasedCnicLayout.maskedCnicTextInputLayout;
        Util util3 = Util.INSTANCE;
        AuthMainActivity authMainActivity9 = this.activity;
        if (authMainActivity9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity9 = null;
        }
        textInputLayout.setHint(Util.setEnglishTextSpan$default(util3, authMainActivity9, "Deceased Citizen No.", "  (متوفی کا شناختی کارڈ نمبر)", 0, false, 12, null));
        binding.deceasedCnicLayout.maskedCnicEditText.addTextChangedListener(new CnicMaskWatcher("#####-#######-#"));
        Util util4 = Util.INSTANCE;
        AuthMainActivity authMainActivity10 = this.activity;
        if (authMainActivity10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity10 = null;
        }
        TextInputEditText maskedCnicEditText = binding.deceasedCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        TextInputLayout maskedCnicTextInputLayout = binding.deceasedCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        util4.removeErrorOnTextChanged(authMainActivity10, maskedCnicEditText, maskedCnicTextInputLayout);
        ConfigurableButton configurableButton = binding.buttonLayout.commonButton;
        Util util5 = Util.INSTANCE;
        AuthMainActivity authMainActivity11 = this.activity;
        if (authMainActivity11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity11 = null;
        }
        configurableButton.setText(Util.setEnglishTextSpan$default(util5, authMainActivity11, "Fetch Data", "  (ڈیٹا حاصل کریں)", 0, false, 12, null));
        binding.buttonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                CancellationDeathFragment.initViews$lambda$10$lambda$8(this.f$0, view);
            }
        });
        ConfigurableButton configurableButton2 = binding.deathCertificateButtonLayout.commonButton;
        Util util6 = Util.INSTANCE;
        AuthMainActivity authMainActivity12 = this.activity;
        if (authMainActivity12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity2 = authMainActivity12;
        }
        configurableButton2.setText(Util.setEnglishTextSpan$default(util6, authMainActivity2, "Apply for death certificate", "\n  (فوتگی سرٹیفیکیٹ کے لیے درخواست دیں)  ", 0, false, 12, null));
        binding.deathCertificateButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                CancellationDeathFragment.initViews$lambda$10$lambda$9(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initViews$lambda$10$lambda$1(CancellationDeathFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initViews$lambda$10$lambda$4(CancellationDeathFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        int i = R.drawable.ic_alert_line;
        String string = this$0.getString(R.string.nadra_ordinance);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.nadra_ordinance_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        bottomSheetUtils.showMessageBottomSheet(authMainActivity, i, false, "Cancellation of id Card", string, false, true, true, string2, "", new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda11
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda12
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initViews$lambda$10$lambda$5(CancellationDeathFragmentBinding this_apply, RadioGroup radioGroup, int i) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        if (i == pk.gov.nadra.oneapp.auth.main.R.id.rb_yes) {
            Editable text = this_apply.deceasedCnicLayout.maskedCnicEditText.getText();
            if (text != null) {
                text.clear();
            }
            this_apply.deceasedCnicLayout.getRoot().setVisibility(0);
            this_apply.buttonLayout.commonButton.setVisibility(0);
            this_apply.tvIdentityNoRecord.setVisibility(8);
            this_apply.tvIdentityNoRecordUrdu.setVisibility(8);
            this_apply.deathCertificateButtonLayout.commonButton.setVisibility(8);
            this_apply.buttonLayout.commonButton.setDisabled(false);
            this_apply.deathCertificateSample.setVisibility(0);
            return;
        }
        if (i == pk.gov.nadra.oneapp.auth.main.R.id.rb_no) {
            Editable text2 = this_apply.deceasedCnicLayout.maskedCnicEditText.getText();
            if (text2 != null) {
                text2.clear();
            }
            this_apply.deceasedCnicLayout.getRoot().setVisibility(8);
            this_apply.buttonLayout.commonButton.setVisibility(8);
            this_apply.deathCertificateButtonLayout.commonButton.setVisibility(0);
            this_apply.buttonLayout.commonButton.setDisabled(true);
            this_apply.deathCertificateSample.setVisibility(8);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initViews$lambda$10$lambda$8(CancellationDeathFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.isInputValid()) {
            LoginResponse loginResponse = this$0.userCredentials;
            AuthMainActivity authMainActivity = null;
            if (loginResponse == null) {
                Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
                loginResponse = null;
            }
            if (Intrinsics.areEqual(loginResponse.getCitizenNumber(), StringsKt.replace$default(String.valueOf(this$0.getBinding().deceasedCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null))) {
                BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
                AuthMainActivity authMainActivity2 = this$0.activity;
                if (authMainActivity2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                } else {
                    authMainActivity = authMainActivity2;
                }
                int i = pk.gov.nadra.oneapp.commonutils.R.drawable.ic_info;
                String string = this$0.getString(R.string.not_allowed_self);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                String string2 = this$0.getString(R.string.not_allowed_self_urdu);
                Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                bottomSheetUtils.showMessageBottomSheet(authMainActivity, i, false, "Info", string, false, true, true, string2, "", new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda7
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return Unit.INSTANCE;
                    }
                }, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda8
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return Unit.INSTANCE;
                    }
                });
                return;
            }
            this$0.checkCnicCrmsDeathService(StringsKt.trim((CharSequence) StringsKt.replace$default(String.valueOf(this$0.getBinding().deceasedCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null)).toString());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initViews$lambda$10$lambda$9(CancellationDeathFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.syncUserWithCrms(Constant.CRMS_DEATH);
    }

    private final boolean isInputValid() {
        int checkedRadioButtonId = getBinding().rgIdentity.getCheckedRadioButtonId();
        if (checkedRadioButtonId == -1) {
            return false;
        }
        if (checkedRadioButtonId == pk.gov.nadra.oneapp.auth.main.R.id.rb_yes) {
            String string = StringsKt.trim((CharSequence) StringsKt.replace$default(String.valueOf(getBinding().deceasedCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null)).toString();
            if (string.length() == 0) {
                getBinding().deceasedCnicLayout.maskedCnicTextInputLayout.setError("Citizen No. is required");
                getBinding().deceasedCnicLayout.maskedCnicTextInputLayout.setErrorEnabled(true);
                return false;
            }
            if (string.length() != 13) {
                getBinding().deceasedCnicLayout.maskedCnicTextInputLayout.setError("Please enter a valid 13-digit citizen No.");
                getBinding().deceasedCnicLayout.maskedCnicTextInputLayout.setErrorEnabled(true);
                return false;
            }
        }
        return true;
    }

    /* compiled from: CancellationDeathFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$checkCnicCrmsDeathService$1", f = "CancellationDeathFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$checkCnicCrmsDeathService$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $cnic;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$cnic = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return CancellationDeathFragment.this.new AnonymousClass1(this.$cnic, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = CancellationDeathFragment.this.activity;
            AuthMainActivity authMainActivity2 = null;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.showLoader(authMainActivity);
            AuthMainActivity authMainActivity3 = CancellationDeathFragment.this.activity;
            if (authMainActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity2 = authMainActivity3;
            }
            APIRequests aPIRequests = new APIRequests(authMainActivity2);
            CheckCnicCrmsDeathRequest checkCnicCrmsDeathRequest = new CheckCnicCrmsDeathRequest(this.$cnic);
            final CancellationDeathFragment cancellationDeathFragment = CancellationDeathFragment.this;
            aPIRequests.checkCnicCrmsDeath(checkCnicCrmsDeathRequest, new Function3() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$checkCnicCrmsDeathService$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return CancellationDeathFragment.AnonymousClass1.invokeSuspend$lambda$0(cancellationDeathFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(CancellationDeathFragment cancellationDeathFragment, JsonObject jsonObject, String str, int i) throws Resources.NotFoundException {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = cancellationDeathFragment.activity;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.hideLoader(authMainActivity);
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                cancellationDeathFragment.processCheckCnicCrmsDeathSuccessResponse(jsonObject);
            } else {
                cancellationDeathFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void checkCnicCrmsDeathService(String cnic) {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(cnic, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processCheckCnicCrmsDeathSuccessResponse(JsonObject jSonObject) throws Resources.NotFoundException {
        String documentType;
        CheckCnicCrmsDeathResponse checkCnicCrmsDeathResponse = (CheckCnicCrmsDeathResponse) new Gson().fromJson(jSonObject.toString(), CheckCnicCrmsDeathResponse.class);
        String crmsNo = checkCnicCrmsDeathResponse.getCrmsNo();
        if (crmsNo == null || crmsNo.length() == 0 || (documentType = checkCnicCrmsDeathResponse.getDocumentType()) == null || documentType.length() == 0) {
            CancellationDeathFragmentBinding binding = getBinding();
            binding.deceasedCnicLayout.maskedCnicTextInputLayout.setErrorEnabled(true);
            binding.buttonLayout.commonButton.setDisabled(true);
            binding.tvIdentityNoRecord.setVisibility(0);
            binding.tvIdentityNoRecordUrdu.setVisibility(0);
            binding.deathCertificateButtonLayout.commonButton.setVisibility(0);
            binding.deathCertificateSample.setVisibility(8);
            return;
        }
        String upperCase = checkCnicCrmsDeathResponse.getDocumentType().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        this.deceasedDocumentType = upperCase;
        this.deceasedCitizenNumber = StringsKt.trim((CharSequence) StringsKt.replace$default(String.valueOf(getBinding().deceasedCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null)).toString();
        LoginResponse loginResponse = this.userCredentials;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        getMySelfDocTypeService(StringsKt.replace$default(loginResponse.getCitizenNumber(), "-", "", false, 4, (Object) null));
    }

    /* compiled from: CancellationDeathFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$getMySelfDocTypeService$1", f = "CancellationDeathFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$getMySelfDocTypeService$1, reason: invalid class name and case insensitive filesystem */
    static final class C11171 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $cnic;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C11171(String str, Continuation<? super C11171> continuation) {
            super(2, continuation);
            this.$cnic = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return CancellationDeathFragment.this.new C11171(this.$cnic, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11171) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = CancellationDeathFragment.this.activity;
            AuthMainActivity authMainActivity2 = null;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.showLoader(authMainActivity);
            AuthMainActivity authMainActivity3 = CancellationDeathFragment.this.activity;
            if (authMainActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity2 = authMainActivity3;
            }
            APIRequests aPIRequests = new APIRequests(authMainActivity2);
            VerifyFingerprintRequest verifyFingerprintRequest = new VerifyFingerprintRequest(null, this.$cnic, 0, null, null, false, null, false, false, false, false, false, false, null, false, false, false, null, 262141, null);
            final CancellationDeathFragment cancellationDeathFragment = CancellationDeathFragment.this;
            aPIRequests.getMySelfDocType(verifyFingerprintRequest, new Function3() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$getMySelfDocTypeService$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return CancellationDeathFragment.C11171.invokeSuspend$lambda$0(cancellationDeathFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(CancellationDeathFragment cancellationDeathFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = cancellationDeathFragment.activity;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.hideLoader(authMainActivity);
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                cancellationDeathFragment.processGetMySelfDocTypeSuccessResponse(jsonObject);
            } else {
                cancellationDeathFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getMySelfDocTypeService(String cnic) {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11171(cnic, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processGetMySelfDocTypeSuccessResponse(JsonObject jSonObject) throws JsonSyntaxException {
        Object element = new Gson().fromJson(jSonObject.toString(), (Class<Object>) VerifyFingerprintResponse.class);
        VerifyFingerprintResponse verifyFingerprintResponse = (VerifyFingerprintResponse) element;
        LoginResponse loginResponse = this.userCredentials;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        String citizenNumber = loginResponse.getCitizenNumber();
        Intrinsics.checkNotNullExpressionValue(element, "element");
        startCancellation(citizenNumber, "CANCEL_DEATH", true, true, verifyFingerprintResponse);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            AuthMainActivity authMainActivity = null;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    for (ErrorResponse.Error error : errors) {
                        TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                        if (textInputLayout != null) {
                            textInputLayout.setError(String.valueOf(error.getMessage()));
                            textInputLayout.setErrorEnabled(true);
                        }
                    }
                    return;
                }
                return;
            }
            if (Intrinsics.areEqual(errorResponse.getStatus(), "BUSINESS_RULE_FAILED")) {
                NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                AuthMainActivity authMainActivity2 = this.activity;
                if (authMainActivity2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                } else {
                    authMainActivity = authMainActivity2;
                }
                Intrinsics.checkNotNull(errorResponse);
                NetworkErrorHandler.handleError$default(networkErrorHandler, authMainActivity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return CancellationDeathFragment.handleFailureCase$lambda$17(this.f$0);
                    }
                }, 8, null);
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            AuthMainActivity authMainActivity3 = this.activity;
            if (authMainActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity = authMainActivity3;
            }
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler2, authMainActivity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return CancellationDeathFragment.handleFailureCase$lambda$18(this.f$0);
                }
            }, 8, null);
            return;
        }
        AuthMainActivity authMainActivity4 = null;
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        AuthMainActivity authMainActivity5 = this.activity;
        if (authMainActivity5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity4 = authMainActivity5;
        }
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler3, authMainActivity4, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return CancellationDeathFragment.handleFailureCase$lambda$19(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$17(CancellationDeathFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$18(CancellationDeathFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$19(CancellationDeathFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        AuthMainActivity authMainActivity = this$0.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final ReactNativeData getReactNativeData() {
        LoginResponse loginResponse = null;
        ReactNativeData.MobileOperator mobileOperator = new ReactNativeData.MobileOperator(0, null, 3, null);
        LoginResponse loginResponse2 = this.userCredentials;
        if (loginResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse2 = null;
        }
        mobileOperator.setKey(loginResponse2.getMobileOperator().getKey());
        LoginResponse loginResponse3 = this.userCredentials;
        if (loginResponse3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse3 = null;
        }
        mobileOperator.setValue(loginResponse3.getMobileOperator().getValue());
        LoginResponse loginResponse4 = this.userCredentials;
        if (loginResponse4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse4 = null;
        }
        String email = loginResponse4.getEmail();
        LoginResponse loginResponse5 = this.userCredentials;
        if (loginResponse5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse5 = null;
        }
        String fullName = loginResponse5.getFullName();
        LoginResponse loginResponse6 = this.userCredentials;
        if (loginResponse6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse6 = null;
        }
        String mobileNumber = loginResponse6.getMobileNumber();
        LoginResponse loginResponse7 = this.userCredentials;
        if (loginResponse7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse7 = null;
        }
        String refreshToken = loginResponse7.getRefreshToken();
        LoginResponse loginResponse8 = this.userCredentials;
        if (loginResponse8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse8 = null;
        }
        String token = loginResponse8.getToken();
        LoginResponse loginResponse9 = this.userCredentials;
        if (loginResponse9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse9 = null;
        }
        String sessionKey = loginResponse9.getSessionKey();
        LoginResponse loginResponse10 = this.userCredentials;
        if (loginResponse10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse10 = null;
        }
        boolean encryptionDecryptionEnabled = loginResponse10.getEncryptionDecryptionEnabled();
        AuthMainActivity authMainActivity = this.activity;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        String fcmToken = AppPreferences.getInstance(authMainActivity).getFcmToken();
        Intrinsics.checkNotNullExpressionValue(fcmToken, "getFcmToken(...)");
        LoginResponse loginResponse11 = this.userCredentials;
        if (loginResponse11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
        } else {
            loginResponse = loginResponse11;
        }
        return new ReactNativeData(null, email, fullName, mobileNumber, refreshToken, token, "", true, true, true, null, null, false, loginResponse.getCitizenNumber(), mobileOperator, sessionKey, encryptionDecryptionEnabled, fcmToken, false, false, false, false, null, null, false, false, false, null, false, false, null, null, null, false, null, null, null, false, false, null, null, null, null, false, null, null, null, null, null, null, -254975, 262143, null);
    }

    private final void startCancellation(String citizenNumber, String applicationType, boolean applicantFingerprintsExist, boolean livelinessControl, VerifyFingerprintResponse verifyFingerprintResponse) {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setCitizenNumber(citizenNumber);
        reactNativeData.setAppType(applicationType);
        reactNativeData.setApplicantFingerprintsExist(applicantFingerprintsExist);
        reactNativeData.setLivelinessControl(livelinessControl);
        reactNativeData.setVerifyFingerprintResponse(verifyFingerprintResponse);
        reactNativeData.setDocType(this.deceasedDocumentType);
        reactNativeData.setDeceasedCitizenNumber(this.deceasedCitizenNumber);
        AuthMainActivity authMainActivity = this.activity;
        AuthMainActivity authMainActivity2 = null;
        if (authMainActivity == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
            authMainActivity = null;
        }
        authMainActivity.popupFromNavHost();
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity3 = this.activity;
        if (authMainActivity3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity2 = authMainActivity3;
        }
        Intent intent = new Intent(authMainActivity2, (Class<?>) CancellationActivity.class);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        startActivity(intent);
    }

    /* compiled from: CancellationDeathFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$syncUserWithCrms$1", f = "CancellationDeathFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$syncUserWithCrms$1, reason: invalid class name and case insensitive filesystem */
    static final class C11181 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $crmsType;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C11181(String str, Continuation<? super C11181> continuation) {
            super(2, continuation);
            this.$crmsType = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return CancellationDeathFragment.this.new C11181(this.$crmsType, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11181) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = CancellationDeathFragment.this.activity;
            AuthMainActivity authMainActivity2 = null;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.showLoader(authMainActivity);
            AuthMainActivity authMainActivity3 = CancellationDeathFragment.this.activity;
            if (authMainActivity3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity2 = authMainActivity3;
            }
            APIRequests aPIRequests = new APIRequests(authMainActivity2);
            final CancellationDeathFragment cancellationDeathFragment = CancellationDeathFragment.this;
            final String str = this.$crmsType;
            aPIRequests.syncUserWithCrms(new Function3() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.CancellationDeathFragment$syncUserWithCrms$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return CancellationDeathFragment.C11181.invokeSuspend$lambda$0(cancellationDeathFragment, str, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(CancellationDeathFragment cancellationDeathFragment, String str, JsonObject jsonObject, String str2, int i) {
            LoaderManager loaderManager = LoaderManager.INSTANCE;
            AuthMainActivity authMainActivity = cancellationDeathFragment.activity;
            if (authMainActivity == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
                authMainActivity = null;
            }
            loaderManager.hideLoader(authMainActivity);
            if (Intrinsics.areEqual(str2, "SUCCESS")) {
                cancellationDeathFragment.processSyncUserWithCrmsSuccessResponse(jsonObject, str);
            } else {
                cancellationDeathFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void syncUserWithCrms(String crmsType) {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11181(crmsType, null), 3, null);
    }

    private final void handleCrmsLaunch(String userId, String crmsType) {
        if (Intrinsics.areEqual(crmsType, Constant.CRMS_DEATH)) {
            startCrmsFlow(userId, "CRMS_DEATH", CrmsDeathActivity.class);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processSyncUserWithCrmsSuccessResponse(JsonObject jSonObject, String crmsType) {
        handleCrmsLaunch(((SyncUserWithCrmsResponse) new Gson().fromJson(jSonObject.toString(), SyncUserWithCrmsResponse.class)).getUserId(), crmsType);
    }

    private final void startCrmsFlow(String userId, String appType, Class<?> activityClass) {
        ReactNativeData reactNativeData = getReactNativeData();
        reactNativeData.setAppType(appType);
        reactNativeData.setUserId(userId);
        LoginResponse loginResponse = this.userCredentials;
        AuthMainActivity authMainActivity = null;
        if (loginResponse == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse = null;
        }
        reactNativeData.setFacialLivenessControl(loginResponse.getLivenessControl());
        LoginResponse loginResponse2 = this.userCredentials;
        if (loginResponse2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("userCredentials");
            loginResponse2 = null;
        }
        reactNativeData.setCitizenNumber(loginResponse2.getCitizenNumber());
        String json = new Gson().toJson(reactNativeData, ReactNativeData.class);
        AuthMainActivity authMainActivity2 = this.activity;
        if (authMainActivity2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("activity");
        } else {
            authMainActivity = authMainActivity2;
        }
        Intent intent = new Intent(authMainActivity, activityClass);
        intent.putExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA, json);
        this.intentLauncher.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void intentLauncher$lambda$21(CancellationDeathFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        Intent data = result.getData();
        AuthMainActivity authMainActivity = null;
        String stringExtra = data != null ? data.getStringExtra("RESPONSE_TO_REACT_NATIVE") : null;
        if (result.getResultCode() == -1) {
            if (Intrinsics.areEqual(stringExtra, Constant.GO_TO_INBOX) || stringExtra == null) {
                AuthMainActivity authMainActivity2 = this$0.activity;
                if (authMainActivity2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                } else {
                    authMainActivity = authMainActivity2;
                }
                authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.homeFragment);
                return;
            }
            if (Intrinsics.areEqual(stringExtra, Constant.GO_TO_LOGIN)) {
                AuthMainActivity authMainActivity3 = this$0.activity;
                if (authMainActivity3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("activity");
                } else {
                    authMainActivity = authMainActivity3;
                }
                authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.loginFragment);
                return;
            }
            AuthMainActivity authMainActivity4 = this$0.activity;
            if (authMainActivity4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("activity");
            } else {
                authMainActivity = authMainActivity4;
            }
            authMainActivity.navigateToFragment(pk.gov.nadra.oneapp.auth.main.R.id.homeFragment);
        }
    }
}