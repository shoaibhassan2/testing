package pk.gov.nadra.oneapp.auth.main.fragments;

import kotlin.jvm.functions.Function1;
import pk.gov.nadra.oneapp.models.dashboard.DashboardItem;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class DashboardFragment$$ExternalSyntheticLambda7 implements Function1 {
    public /* synthetic */ DashboardFragment$$ExternalSyntheticLambda7() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return DashboardFragment.attachDashboardViews$lambda$6$lambda$3(this.f$0, (DashboardItem.DigitalCard) obj);
    }
}