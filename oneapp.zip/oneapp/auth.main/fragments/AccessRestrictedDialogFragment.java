package pk.gov.nadra.oneapp.auth.main.fragments;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.auth.main.databinding.AccessRestrictedDialogBinding;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.utils.Util;

/* compiled from: AccessRestrictedDialogFragment.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \u00112\u00020\u0001:\u0001\u0011B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0016J\b\u0010\u0010\u001a\u00020\u000bH\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u0016\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/fragments/AccessRestrictedDialogFragment;", "Landroidx/fragment/app/DialogFragment;", "<init>", "()V", "_binding", "Lpk/gov/nadra/oneapp/auth/main/databinding/AccessRestrictedDialogBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/auth/main/databinding/AccessRestrictedDialogBinding;", "onConfirm", "Lkotlin/Function0;", "", "onCreateDialog", "Landroid/app/Dialog;", "savedInstanceState", "Landroid/os/Bundle;", "onDestroyView", "Companion", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AccessRestrictedDialogFragment extends DialogFragment {

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private AccessRestrictedDialogBinding _binding;
    private Function0<Unit> onConfirm;

    private final AccessRestrictedDialogBinding getBinding() {
        AccessRestrictedDialogBinding accessRestrictedDialogBinding = this._binding;
        Intrinsics.checkNotNull(accessRestrictedDialogBinding);
        return accessRestrictedDialogBinding;
    }

    /* compiled from: AccessRestrictedDialogFragment.kt */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0014\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¨\u0006\t"}, d2 = {"Lpk/gov/nadra/oneapp/auth/main/fragments/AccessRestrictedDialogFragment$Companion;", "", "<init>", "()V", "newInstance", "Lpk/gov/nadra/oneapp/auth/main/fragments/AccessRestrictedDialogFragment;", "onConfirm", "Lkotlin/Function0;", "", "authMain_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final AccessRestrictedDialogFragment newInstance(Function0<Unit> onConfirm) {
            Intrinsics.checkNotNullParameter(onConfirm, "onConfirm");
            AccessRestrictedDialogFragment accessRestrictedDialogFragment = new AccessRestrictedDialogFragment();
            accessRestrictedDialogFragment.onConfirm = onConfirm;
            return accessRestrictedDialogFragment;
        }
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Window window;
        setCancelable(false);
        this._binding = AccessRestrictedDialogBinding.inflate(LayoutInflater.from(requireContext()));
        AlertDialog alertDialogCreate = new AlertDialog.Builder(requireContext()).setView(getBinding().getRoot()).create();
        if (alertDialogCreate != null && (window = alertDialogCreate.getWindow()) != null) {
            window.setBackgroundDrawable(new ColorDrawable(0));
        }
        ConfigurableButton configurableButton = getBinding().accessRestrictedVerifyNowButtonLayout;
        Util util = Util.INSTANCE;
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNullExpressionValue(fragmentActivityRequireActivity, "requireActivity(...)");
        String string = getString(R.string.verify_account_now);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util, fragmentActivityRequireActivity, string, " (ابھی اکاؤنٹ کی تصدیق کریں)", 0, false, 12, null));
        getBinding().accessRestrictedVerifyNowButtonLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.AccessRestrictedDialogFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccessRestrictedDialogFragment.onCreateDialog$lambda$0(this.f$0, view);
            }
        });
        ConfigurableButton configurableButton2 = getBinding().accessRestrictedSkipButtonLayout;
        Util util2 = Util.INSTANCE;
        FragmentActivity fragmentActivityRequireActivity2 = requireActivity();
        Intrinsics.checkNotNullExpressionValue(fragmentActivityRequireActivity2, "requireActivity(...)");
        String string2 = getString(R.string.skip);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        configurableButton2.setText(Util.setEnglishTextSpan$default(util2, fragmentActivityRequireActivity2, string2, " (چھوڑیں)", 0, false, 12, null));
        getBinding().accessRestrictedSkipButtonLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.auth.main.fragments.AccessRestrictedDialogFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccessRestrictedDialogFragment.onCreateDialog$lambda$1(this.f$0, view);
            }
        });
        Intrinsics.checkNotNull(alertDialogCreate);
        return alertDialogCreate;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreateDialog$lambda$0(AccessRestrictedDialogFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Function0<Unit> function0 = this$0.onConfirm;
        if (function0 != null) {
            function0.invoke();
        }
        this$0.dismiss();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreateDialog$lambda$1(AccessRestrictedDialogFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dismiss();
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}