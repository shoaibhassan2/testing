package pk.gov.nadra.oneapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewpager.widget.PagerAdapter;
import com.bumptech.glide.Glide;
import com.google.android.gms.analytics.ecommerce.Promotion;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.pakid.databinding.RvOnboardingItemBinding;

/* compiled from: OnboardingAdapter.kt */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\n\u001a\u00020\bH\u0016J\u0018\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016J\u0018\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\bH\u0016J \u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\b2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\t¨\u0006\u0017"}, d2 = {"Lpk/gov/nadra/oneapp/adapters/OnboardingAdapter;", "Landroidx/viewpager/widget/PagerAdapter;", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "sliderAllImages", "", "", "[Ljava/lang/Integer;", "getCount", "isViewFromObject", "", Promotion.ACTION_VIEW, "Landroid/view/View;", "object", "", "instantiateItem", "container", "Landroid/view/ViewGroup;", "position", "destroyItem", "", "app_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class OnboardingAdapter extends PagerAdapter {
    private final Context context;
    private final Integer[] sliderAllImages;

    public OnboardingAdapter(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
        this.sliderAllImages = new Integer[]{Integer.valueOf(R.drawable.onboarding_one_new), Integer.valueOf(R.drawable.onboarding_two_new), Integer.valueOf(R.drawable.onboarding_three_new), Integer.valueOf(R.drawable.onboarding_four_new), Integer.valueOf(R.drawable.onboarding_five_new)};
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public int getCount() {
        return this.sliderAllImages.length;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public boolean isViewFromObject(View view, Object object) {
        Intrinsics.checkNotNullParameter(view, "view");
        Intrinsics.checkNotNullParameter(object, "object");
        return Intrinsics.areEqual(view, (ConstraintLayout) object);
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public Object instantiateItem(ViewGroup container, int position) {
        Intrinsics.checkNotNullParameter(container, "container");
        RvOnboardingItemBinding rvOnboardingItemBindingInflate = RvOnboardingItemBinding.inflate(LayoutInflater.from(this.context), container, false);
        Intrinsics.checkNotNullExpressionValue(rvOnboardingItemBindingInflate, "inflate(...)");
        Glide.with(this.context).load(this.sliderAllImages[position]).into(rvOnboardingItemBindingInflate.imageOnboarding);
        rvOnboardingItemBindingInflate.imageOnboarding.setImageResource(this.sliderAllImages[position].intValue());
        container.addView(rvOnboardingItemBindingInflate.getRoot());
        ConstraintLayout root = rvOnboardingItemBindingInflate.getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public void destroyItem(ViewGroup container, int position, Object object) {
        Intrinsics.checkNotNullParameter(container, "container");
        Intrinsics.checkNotNullParameter(object, "object");
        container.removeView((ConstraintLayout) object);
    }
}