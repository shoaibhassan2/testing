package pk.gov.nadra.oneapp.appointmentsystem;

/* loaded from: classes5.dex */
public final class R {

    public static final class id {
        public static int action_applicant_details_to_date_time = 0x7f0a004f;
        public static int action_center_detail_to_center_near_me = 0x7f0a0063;
        public static int action_center_near_me_to_instruction = 0x7f0a0064;
        public static int action_date_time_to_visit_purpose = 0x7f0a006c;
        public static int action_instruction_to_list = 0x7f0a0085;
        public static int action_location_to_instruction = 0x7f0a0088;
        public static int action_visit_purpose_to_center_detail = 0x7f0a00e2;
        public static int action_visit_purpose_to_location = 0x7f0a00e3;
        public static int add_new_appointment_button_layout = 0x7f0a00f0;
        public static int addressImageView = 0x7f0a0103;
        public static int addressLabelTextView = 0x7f0a0104;
        public static int addressView = 0x7f0a0105;
        public static int application_type_layout = 0x7f0a0139;
        public static int appointmentApplicantDetailsFragment = 0x7f0a0143;
        public static int appointmentCancelIconImageView = 0x7f0a0144;
        public static int appointmentCenterDetailFragment = 0x7f0a0145;
        public static int appointmentCenterNearMeFragment = 0x7f0a0146;
        public static int appointmentCenterTextView = 0x7f0a0147;
        public static int appointmentDateTextView = 0x7f0a0148;
        public static int appointmentDateTimeFragment = 0x7f0a0149;
        public static int appointmentIdTextView = 0x7f0a014a;
        public static int appointmentInstructionsFragment = 0x7f0a014b;
        public static int appointmentLocationsFragment = 0x7f0a014c;
        public static int appointmentNameTextView = 0x7f0a014d;
        public static int appointmentStatusTextView = 0x7f0a014e;
        public static int appointmentSubmissionFragment = 0x7f0a014f;
        public static int appointmentVisitPurposeFragment = 0x7f0a0150;
        public static int appointment_applicant_cnic_layout = 0x7f0a0151;
        public static int appointment_applicant_contact_number_layout = 0x7f0a0152;
        public static int appointment_applicant_contact_number_textInputEditText = 0x7f0a0153;
        public static int appointment_applicant_detail_heading_textView = 0x7f0a0154;
        public static int appointment_applicant_detail_info_icon_imageView = 0x7f0a0155;
        public static int appointment_applicant_detail_info_textView = 0x7f0a0156;
        public static int appointment_applicant_details_next_button_layout = 0x7f0a0157;
        public static int appointment_applicant_email_layout = 0x7f0a0158;
        public static int appointment_applicant_name_layout = 0x7f0a0159;
        public static int appointment_application_scrollView = 0x7f0a015a;
        public static int appointment_arriving_heading_textView = 0x7f0a015b;
        public static int appointment_arriving_urdu_heading_textView = 0x7f0a015c;
        public static int appointment_available_slots_cardView = 0x7f0a015d;
        public static int appointment_available_slots_heading_textView = 0x7f0a015e;
        public static int appointment_available_slots_recyclerView = 0x7f0a015f;
        public static int appointment_center_proceed_button_layout = 0x7f0a0160;
        public static int appointment_choose_datetime_heading_textView = 0x7f0a0161;
        public static int appointment_choose_datetime_urdu_heading_textView = 0x7f0a0162;
        public static int appointment_date_layout = 0x7f0a0163;
        public static int appointment_date_time_heading_textView = 0x7f0a0164;
        public static int appointment_date_time_next_button_layout = 0x7f0a0165;
        public static int appointment_datetime_info_icon_imageView = 0x7f0a0166;
        public static int appointment_datetime_info_textView = 0x7f0a0167;
        public static int appointment_datetime_message_textView = 0x7f0a0168;
        public static int appointment_detail_heading_layout = 0x7f0a0169;
        public static int appointment_detail_next_button_layout = 0x7f0a016a;
        public static int appointment_detail_step_recyclerView = 0x7f0a016b;
        public static int appointment_details_sent_textView = 0x7f0a016c;
        public static int appointment_district_layout = 0x7f0a016d;
        public static int appointment_documents_heading_textView = 0x7f0a016e;
        public static int appointment_documents_urdu_heading_textView = 0x7f0a016f;
        public static int appointment_header_layout = 0x7f0a0170;
        public static int appointment_icon_background = 0x7f0a0171;
        public static int appointment_icon_imageView = 0x7f0a0172;
        public static int appointment_instruction_heading_textView = 0x7f0a0173;
        public static int appointment_instruction_urdu_heading_textView = 0x7f0a0174;
        public static int appointment_instructions_map_next_button_layout = 0x7f0a0175;
        public static int appointment_instructions_next_button_layout = 0x7f0a0176;
        public static int appointment_list_heading_textView = 0x7f0a0177;
        public static int appointment_list_item_cardView = 0x7f0a0178;
        public static int appointment_location_heading_textView = 0x7f0a0179;
        public static int appointment_location_mapView = 0x7f0a017a;
        public static int appointment_locations_recyclerView = 0x7f0a017b;
        public static int appointment_mandatory_document_cardView = 0x7f0a017c;
        public static int appointment_mandatory_document_heading_textView = 0x7f0a017d;
        public static int appointment_mandatory_document_recyclerView = 0x7f0a017e;
        public static int appointment_nav_host_fragment = 0x7f0a017f;
        public static int appointment_option_textView = 0x7f0a0180;
        public static int appointment_payment_mode_cardView = 0x7f0a0181;
        public static int appointment_payment_mode_heading_textView = 0x7f0a0182;
        public static int appointment_payment_mode_icon_imageView = 0x7f0a0183;
        public static int appointment_province_layout = 0x7f0a0184;
        public static int appointment_punctual_heading_textView = 0x7f0a0185;
        public static int appointment_punctual_urdu_heading_textView = 0x7f0a0186;
        public static int appointment_required_documents_textView = 0x7f0a0187;
        public static int appointment_schedule_icon_imageView = 0x7f0a0188;
        public static int appointment_scheduled_heading_textView = 0x7f0a0189;
        public static int appointment_submission_button_layout = 0x7f0a018a;
        public static int appointment_swipeRefresh = 0x7f0a018b;
        public static int appointment_visit_heading_textView = 0x7f0a018c;
        public static int appointmentsListFragment = 0x7f0a018d;
        public static int appointments_list_recyclerView = 0x7f0a018e;
        public static int appointments_list_try_again_imageView = 0x7f0a018f;
        public static int appointments_list_try_again_layout = 0x7f0a0190;
        public static int appointments_list_try_again_textView = 0x7f0a0191;
        public static int arrowIconImageView = 0x7f0a0196;
        public static int centerAddressTextView = 0x7f0a02b4;
        public static int centerDetailMapFragment = 0x7f0a02b6;
        public static int centerPhoneNumberTextView = 0x7f0a02b9;
        public static int centerTimingTextView = 0x7f0a02ba;
        public static int centerTypeImageView = 0x7f0a02bb;
        public static int centerTypeLabelTextView = 0x7f0a02bc;
        public static int centerTypeTextView = 0x7f0a02bd;
        public static int center_list_try_again_layout = 0x7f0a02c2;
        public static int constraintLayoutApprox = 0x7f0a0344;
        public static int document_list_item_icon_imageView = 0x7f0a0516;
        public static int document_list_item_name_textView = 0x7f0a0517;
        public static int document_type_layout = 0x7f0a0519;
        public static int expedite_step_status_item_textView = 0x7f0a059d;
        public static int expedite_step_title_item_textView = 0x7f0a059e;
        public static int frc_list_try_again_imageView = 0x7f0a0675;
        public static int frc_list_try_again_textView = 0x7f0a0677;
        public static int goToDirectionImageView = 0x7f0a0692;
        public static int guidelineBelowMapFragment = 0x7f0a06d5;
        public static int info_icon_imageView = 0x7f0a0796;
        public static int iv_parent_line_icon = 0x7f0a07d4;
        public static int iv_parent_minus_icon = 0x7f0a07d5;
        public static int line_1_view = 0x7f0a080d;
        public static int line_2_view = 0x7f0a080e;
        public static int line_view = 0x7f0a080f;
        public static int list_item_slot_constraintLayout = 0x7f0a083c;
        public static int list_item_slot_textView = 0x7f0a083d;
        public static int location_cardView = 0x7f0a0852;
        public static int location_list_item_calender_icon_imageView = 0x7f0a0853;
        public static int location_list_item_icon_imageView = 0x7f0a0854;
        public static int location_list_item_name_textView = 0x7f0a0855;
        public static int location_list_item_right_arrow_imageView = 0x7f0a0856;
        public static int location_list_item_timing_textView = 0x7f0a0857;
        public static int nav_graph = 0x7f0a0959;
        public static int payment_facility_textView = 0x7f0a0a12;
        public static int payment_icons_linearLayout = 0x7f0a0a17;
        public static int payment_info_icon_imageView = 0x7f0a0a18;
        public static int payment_line_view = 0x7f0a0a19;
        public static int payment_via_raast_textView = 0x7f0a0a2b;
        public static int phoneImageView = 0x7f0a0a45;
        public static int phoneLabelTextView = 0x7f0a0a46;
        public static int phoneView = 0x7f0a0a49;
        public static int pinCodeTextView = 0x7f0a0a54;
        public static int purpose_type_layout = 0x7f0a0ab8;
        public static int shift_time_layout = 0x7f0a0c02;
        public static int slot_list_try_again_layout = 0x7f0a0c25;
        public static int timingImageView = 0x7f0a0d11;
        public static int timingLabelTextView = 0x7f0a0d12;
        public static int timingView = 0x7f0a0d13;
        public static int viewSeparator = 0x7f0a0e6b;

        private id() {
        }
    }

    public static final class layout {
        public static int activity_appointment_system = 0x7f0d001d;
        public static int appointment_document_list_item_layout = 0x7f0d0066;
        public static int appointment_step_item_layout = 0x7f0d0067;
        public static int available_slot_list_item_layout = 0x7f0d006a;
        public static int fragment_appointment_applicant_details = 0x7f0d011c;
        public static int fragment_appointment_center_near_me = 0x7f0d011d;
        public static int fragment_appointment_date_time = 0x7f0d011e;
        public static int fragment_appointment_instructions = 0x7f0d011f;
        public static int fragment_appointment_locations = 0x7f0d0120;
        public static int fragment_appointment_submission = 0x7f0d0121;
        public static int fragment_appointment_visit_purpose = 0x7f0d0122;
        public static int fragment_appointments_list = 0x7f0d0123;
        public static int fragment_center_detail = 0x7f0d0125;
        public static int list_item_appointment = 0x7f0d0178;
        public static int location_list_item_layout = 0x7f0d0183;

        private layout() {
        }
    }

    public static final class navigation {
        public static int appointment_nav_graph = 0x7f110000;

        private navigation() {
        }
    }

    public static final class string {
        public static int applicant_detail = 0x7f140070;
        public static int appointment = 0x7f140092;
        public static int appointment_choose_datetime = 0x7f140093;
        public static int appointment_choose_datetime_urdu = 0x7f140094;
        public static int appointment_date = 0x7f140095;
        public static int appointment_details = 0x7f140096;
        public static int appointment_instructions = 0x7f140098;
        public static int appointment_instructions_arriving = 0x7f140099;
        public static int appointment_instructions_arriving_urdu = 0x7f14009a;
        public static int appointment_instructions_documents = 0x7f14009b;
        public static int appointment_instructions_documents_urdu = 0x7f14009c;
        public static int appointment_instructions_punctual = 0x7f14009d;
        public static int appointment_instructions_punctual_urdu = 0x7f14009e;
        public static int appointment_instructions_punctual_urdu_with_doc = 0x7f14009f;
        public static int appointment_instructions_punctual_with_doc = 0x7f1400a0;
        public static int appointment_instructions_urdu = 0x7f1400a1;
        public static int appointment_required_documents_message = 0x7f1400a2;
        public static int appointment_scheduled = 0x7f1400a3;
        public static int appointment_scheduled_message = 0x7f1400a4;
        public static int appointment_title = 0x7f1400a5;
        public static int available_slots = 0x7f1400c3;
        public static int book_appointment = 0x7f1400e1;
        public static int book_new_appointment = 0x7f1400e2;
        public static int center_near_me = 0x7f140116;
        public static int contact_details_whatsapp = 0x7f140184;
        public static int date_time = 0x7f140350;
        public static int detail_sent_message = 0x7f14037f;
        public static int mandatory_documents = 0x7f14055e;
        public static int ok = 0x7f140622;
        public static int payment_mode = 0x7f140655;
        public static int purpose_of_visit = 0x7f1406df;
        public static int search_center_location = 0x7f140723;
        public static int select_date = 0x7f14073b;
        public static int select_shift = 0x7f140743;
        public static int select_your_location = 0x7f140746;
        public static int submit = 0x7f140778;
        public static int submit_ur = 0x7f14077a;

        private string() {
        }
    }

    public static final class style {
        public static int CircleImage = 0x7f150135;

        private style() {
        }
    }

    private R() {
    }
}