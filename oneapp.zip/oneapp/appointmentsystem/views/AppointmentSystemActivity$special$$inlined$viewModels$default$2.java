package pk.gov.nadra.oneapp.appointmentsystem.views;

import androidx.lifecycle.ViewModelStore;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;

/* compiled from: ActivityViewModelLazy.kt */
@Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u0001\"\n\b\u0000\u0010\u0002\u0018\u0001*\u00020\u0003H\n¢\u0006\u0002\b\u0004¨\u0006\u0005"}, d2 = {"<anonymous>", "Landroidx/lifecycle/ViewModelStore;", "VM", "Landroidx/lifecycle/ViewModel;", "invoke", "androidx/activity/ActivityViewModelLazyKt$viewModels$3"}, k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentSystemActivity$special$$inlined$viewModels$default$2 extends Lambda implements Function0<ViewModelStore> {
    public AppointmentSystemActivity$special$$inlined$viewModels$default$2() {
        super(0);
    }

    @Override // kotlin.jvm.functions.Function0
    public final ViewModelStore invoke() {
        return appointmentSystemActivity.getViewModelStore();
    }
}