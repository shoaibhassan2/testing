package pk.gov.nadra.oneapp.appointmentsystem.views;

import android.R;
import android.app.Application;
import android.os.Bundle;
import android.view.View;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcherKt;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.NavGraph;
import androidx.navigation.fragment.NavHostFragment;
import com.google.gson.Gson;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.ActivityAppointmentSystemBinding;
import pk.gov.nadra.oneapp.appointmentsystem.viewmodel.AppointmentSharedViewModel;
import pk.gov.nadra.oneapp.commonutils.BaseActivity;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.network.common.SharedPreferencesTokenProvider;

/* compiled from: AppointmentSystemActivity.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0013H\u0014J\b\u0010\u0014\u001a\u00020\u0011H\u0002J\b\u0010\u0015\u001a\u00020\u0011H\u0002J\u0006\u0010\u0016\u001a\u00020\u0011J\b\u0010\u0017\u001a\u00020\u0011H\u0016R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u000e\u0010\n\u001a\u00020\u000bX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082.¢\u0006\u0002\n\u0000¨\u0006\u0018"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "Lpk/gov/nadra/oneapp/commonutils/BaseActivity;", "<init>", "()V", "appointmentSharedViewModel", "Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "getAppointmentSharedViewModel", "()Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "appointmentSharedViewModel$delegate", "Lkotlin/Lazy;", "binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/ActivityAppointmentSystemBinding;", "navController", "Landroidx/navigation/NavController;", "navHostFragment", "Landroidx/navigation/fragment/NavHostFragment;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "getIntentData", "initView", "popupFromNavHost", "onBackPressed", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentSystemActivity extends BaseActivity {

    /* renamed from: appointmentSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy appointmentSharedViewModel;
    private ActivityAppointmentSystemBinding binding;
    private NavController navController;
    private NavHostFragment navHostFragment;

    public AppointmentSystemActivity() {
        final AppointmentSystemActivity appointmentSystemActivity = this;
        final Function0 function0 = null;
        this.appointmentSharedViewModel = new ViewModelLazy(Reflection.getOrCreateKotlinClass(AppointmentSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity$special$$inlined$viewModels$default$2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                return appointmentSystemActivity.getViewModelStore();
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity$special$$inlined$viewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                return appointmentSystemActivity.getDefaultViewModelProviderFactory();
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity$special$$inlined$viewModels$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                return (function02 == null || (creationExtras = (CreationExtras) function02.invoke()) == null) ? appointmentSystemActivity.getDefaultViewModelCreationExtras() : creationExtras;
            }
        });
    }

    private final AppointmentSharedViewModel getAppointmentSharedViewModel() {
        return (AppointmentSharedViewModel) this.appointmentSharedViewModel.getValue();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityAppointmentSystemBinding activityAppointmentSystemBindingInflate = ActivityAppointmentSystemBinding.inflate(getLayoutInflater());
        this.binding = activityAppointmentSystemBindingInflate;
        ActivityAppointmentSystemBinding activityAppointmentSystemBinding = null;
        if (activityAppointmentSystemBindingInflate == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityAppointmentSystemBindingInflate = null;
        }
        setContentView(activityAppointmentSystemBindingInflate.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.white));
        new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
        ActivityAppointmentSystemBinding activityAppointmentSystemBinding2 = this.binding;
        if (activityAppointmentSystemBinding2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        } else {
            activityAppointmentSystemBinding = activityAppointmentSystemBinding2;
        }
        activityAppointmentSystemBinding.appointmentHeaderLayout.tvHeaderTitle.setText(getString(pk.gov.nadra.oneapp.appointmentsystem.R.string.appointment));
        activityAppointmentSystemBinding.appointmentHeaderLayout.ivHeaderClose.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AppointmentSystemActivity.onCreate$lambda$1$lambda$0(this.f$0, view);
            }
        });
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        Application application = getApplication();
        Intrinsics.checkNotNullExpressionValue(application, "getApplication(...)");
        loaderManager.initialize(application);
        getIntentData();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$1$lambda$0(AppointmentSystemActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
    }

    private final void getIntentData() {
        if (getIntent() != null && getIntent().hasExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA)) {
            Bundle extras = getIntent().getExtras();
            Intrinsics.checkNotNull(extras);
            getAppointmentSharedViewModel().setReactNativeData((ReactNativeData) new Gson().fromJson(extras.getString(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA), ReactNativeData.class));
            getSharedViewModel().setReactNativeData(getAppointmentSharedViewModel().getReactNativeData());
        }
        SharedPreferencesTokenProvider sharedPreferencesTokenProvider = new SharedPreferencesTokenProvider(this);
        sharedPreferencesTokenProvider.saveToken(getAppointmentSharedViewModel().getReactNativeData().getToken());
        sharedPreferencesTokenProvider.saveRefreshToken(getAppointmentSharedViewModel().getReactNativeData().getRefreshToken());
        sharedPreferencesTokenProvider.saveAesKey(getAppointmentSharedViewModel().getReactNativeData().getSessionKey());
        sharedPreferencesTokenProvider.saveDeviceId(getAppointmentSharedViewModel().getReactNativeData().getDeviceId());
        sharedPreferencesTokenProvider.saveEncryptionEnabled(getAppointmentSharedViewModel().getReactNativeData().getEncryptionEnabled());
        initView();
    }

    private final void initView() {
        Fragment fragmentFindFragmentById = getSupportFragmentManager().findFragmentById(pk.gov.nadra.oneapp.appointmentsystem.R.id.appointment_nav_host_fragment);
        Intrinsics.checkNotNull(fragmentFindFragmentById, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
        NavHostFragment navHostFragment = (NavHostFragment) fragmentFindFragmentById;
        this.navHostFragment = navHostFragment;
        NavController navController = null;
        if (navHostFragment == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navHostFragment");
            navHostFragment = null;
        }
        NavController navController2 = navHostFragment.getNavController();
        this.navController = navController2;
        if (navController2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
            navController2 = null;
        }
        NavGraph navGraphInflate = navController2.getNavInflater().inflate(pk.gov.nadra.oneapp.appointmentsystem.R.navigation.appointment_nav_graph);
        NavController navController3 = this.navController;
        if (navController3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
            navController3 = null;
        }
        navController3.setGraph(navGraphInflate);
        NavController navController4 = this.navController;
        if (navController4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
        } else {
            navController = navController4;
        }
        initBaseView(navController);
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        OnBackPressedDispatcherKt.addCallback$default(getOnBackPressedDispatcher(), this, false, new Function1() { // from class: pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return AppointmentSystemActivity.initView$lambda$2(this.f$0, (OnBackPressedCallback) obj);
            }
        }, 2, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initView$lambda$2(AppointmentSystemActivity this$0, OnBackPressedCallback addCallback) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(addCallback, "$this$addCallback");
        if (!LoaderManager.INSTANCE.isLoaderVisible()) {
            NavController navController = this$0.navController;
            if (navController == null) {
                Intrinsics.throwUninitializedPropertyAccessException("navController");
                navController = null;
            }
            NavDestination currentDestination = navController.getCurrentDestination();
            Integer numValueOf = currentDestination != null ? Integer.valueOf(currentDestination.getId()) : null;
            int i = pk.gov.nadra.oneapp.appointmentsystem.R.id.appointmentsListFragment;
            if (numValueOf != null && numValueOf.intValue() == i) {
                this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
            } else {
                int i2 = pk.gov.nadra.oneapp.appointmentsystem.R.id.appointmentInstructionsFragment;
                if (numValueOf != null && numValueOf.intValue() == i2) {
                    this$0.navigateToFragment(pk.gov.nadra.oneapp.appointmentsystem.R.id.action_instruction_to_list);
                } else {
                    int i3 = pk.gov.nadra.oneapp.appointmentsystem.R.id.appointmentLocationsFragment;
                    if (numValueOf != null && numValueOf.intValue() == i3) {
                        this$0.navigateToFragment(pk.gov.nadra.oneapp.appointmentsystem.R.id.action_location_to_instruction);
                    } else {
                        int i4 = pk.gov.nadra.oneapp.appointmentsystem.R.id.appointmentVisitPurposeFragment;
                        if (numValueOf != null && numValueOf.intValue() == i4) {
                            if (this$0.getAppointmentSharedViewModel().getIsFromCenterNearMe()) {
                                this$0.navigateToFragment(pk.gov.nadra.oneapp.appointmentsystem.R.id.action_visit_purpose_to_center_detail);
                            } else {
                                this$0.navigateToFragment(pk.gov.nadra.oneapp.appointmentsystem.R.id.action_visit_purpose_to_location);
                            }
                        } else {
                            int i5 = pk.gov.nadra.oneapp.appointmentsystem.R.id.appointmentDateTimeFragment;
                            if (numValueOf != null && numValueOf.intValue() == i5) {
                                this$0.navigateToFragment(pk.gov.nadra.oneapp.appointmentsystem.R.id.action_date_time_to_visit_purpose);
                            } else {
                                int i6 = pk.gov.nadra.oneapp.appointmentsystem.R.id.appointmentApplicantDetailsFragment;
                                if (numValueOf != null && numValueOf.intValue() == i6) {
                                    this$0.navigateToFragment(pk.gov.nadra.oneapp.appointmentsystem.R.id.action_applicant_details_to_date_time);
                                } else {
                                    int i7 = pk.gov.nadra.oneapp.appointmentsystem.R.id.appointmentSubmissionFragment;
                                    if (numValueOf != null && numValueOf.intValue() == i7) {
                                        this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
                                    } else {
                                        int i8 = pk.gov.nadra.oneapp.appointmentsystem.R.id.appointmentCenterNearMeFragment;
                                        if (numValueOf != null && numValueOf.intValue() == i8) {
                                            this$0.navigateToFragment(pk.gov.nadra.oneapp.appointmentsystem.R.id.action_center_near_me_to_instruction);
                                        } else {
                                            int i9 = pk.gov.nadra.oneapp.appointmentsystem.R.id.appointmentCenterDetailFragment;
                                            if (numValueOf != null && numValueOf.intValue() == i9) {
                                                this$0.navigateToFragment(pk.gov.nadra.oneapp.appointmentsystem.R.id.action_center_detail_to_center_near_me);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return Unit.INSTANCE;
    }

    public final void popupFromNavHost() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }
}