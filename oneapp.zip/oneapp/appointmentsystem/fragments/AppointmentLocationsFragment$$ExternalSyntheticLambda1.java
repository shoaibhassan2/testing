package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentLocationsFragment$$ExternalSyntheticLambda1 implements Function1 {
    public /* synthetic */ AppointmentLocationsFragment$$ExternalSyntheticLambda1() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return AppointmentLocationsFragment.initializeLocation$lambda$38(this.f$0, (String) obj);
    }
}