package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentsListFragment$$ExternalSyntheticLambda7 implements Function0 {
    public final /* synthetic */ String f$1;

    public /* synthetic */ AppointmentsListFragment$$ExternalSyntheticLambda7(String str) {
        appointmentId = str;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return AppointmentsListFragment.showCancellationConfirmationDialog$lambda$16(this.f$0, appointmentId);
    }
}