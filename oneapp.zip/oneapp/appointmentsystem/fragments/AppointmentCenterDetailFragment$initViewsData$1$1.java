package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.content.Intent;
import android.net.Uri;
import android.text.style.ClickableSpan;
import android.view.View;
import com.google.android.gms.analytics.ecommerce.Promotion;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* compiled from: AppointmentCenterDetailFragment.kt */
@Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\u0006"}, d2 = {"pk/gov/nadra/oneapp/appointmentsystem/fragments/AppointmentCenterDetailFragment$initViewsData$1$1", "Landroid/text/style/ClickableSpan;", "onClick", "", Promotion.ACTION_VIEW, "Landroid/view/View;", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentCenterDetailFragment$initViewsData$1$1 extends ClickableSpan {
    final /* synthetic */ String $phoneNumber;
    final /* synthetic */ AppointmentCenterDetailFragment this$0;

    AppointmentCenterDetailFragment$initViewsData$1$1(String str, AppointmentCenterDetailFragment appointmentCenterDetailFragment) {
        str = str;
        appointmentCenterDetailFragment = appointmentCenterDetailFragment;
    }

    @Override // android.text.style.ClickableSpan
    public void onClick(View view) {
        Intrinsics.checkNotNullParameter(view, "view");
        Intent intent = new Intent("android.intent.action.DIAL");
        intent.setData(Uri.parse("tel:" + StringsKt.replace$default(str, "-", "", false, 4, (Object) null)));
        if (intent.resolveActivity(appointmentCenterDetailFragment.getActivity().getPackageManager()) != null) {
            appointmentCenterDetailFragment.startActivity(intent);
        }
    }
}