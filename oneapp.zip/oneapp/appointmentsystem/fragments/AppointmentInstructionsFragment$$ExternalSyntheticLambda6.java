package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import pk.gov.nadra.rahbar.android.db.backgroundtasks.InsertNrcDataTask;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentInstructionsFragment$$ExternalSyntheticLambda6 implements InsertNrcDataTask.InsertNrcDataCommunicator {
    public /* synthetic */ AppointmentInstructionsFragment$$ExternalSyntheticLambda6() {
    }

    @Override // pk.gov.nadra.rahbar.android.db.backgroundtasks.InsertNrcDataTask.InsertNrcDataCommunicator
    public final void onSuccess(int i) {
        AppointmentInstructionsFragment.insertNrcDataCommunicator$lambda$7(this.f$0, i);
    }
}