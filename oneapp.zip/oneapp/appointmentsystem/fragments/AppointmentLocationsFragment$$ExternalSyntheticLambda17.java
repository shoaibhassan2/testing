package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentLocationsFragment$$ExternalSyntheticLambda17 implements Function0 {
    public /* synthetic */ AppointmentLocationsFragment$$ExternalSyntheticLambda17() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return AppointmentLocationsFragment.initializeLocation$lambda$35(this.f$0);
    }
}