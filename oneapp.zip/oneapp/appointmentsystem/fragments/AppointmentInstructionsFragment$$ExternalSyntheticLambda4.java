package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import java.util.Date;
import pk.gov.nadra.rahbar.android.db.backgroundtasks.GetMaxTimeStampTask;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentInstructionsFragment$$ExternalSyntheticLambda4 implements GetMaxTimeStampTask.GetMaxTimeStampCommunicator {
    public /* synthetic */ AppointmentInstructionsFragment$$ExternalSyntheticLambda4() {
    }

    @Override // pk.gov.nadra.rahbar.android.db.backgroundtasks.GetMaxTimeStampTask.GetMaxTimeStampCommunicator
    public final void onSuccess(Date date) {
        AppointmentInstructionsFragment.getMaxTimeStampCommunicator$lambda$5(this.f$0, date);
    }
}