package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.SpannableString;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.AppointmentAvailableSlotsAdapter;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.AppointmentStepsAdapter;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.model.AppointmentSteps;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentAppointmentDateTimeBinding;
import pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment;
import pk.gov.nadra.oneapp.appointmentsystem.viewmodel.AppointmentSharedViewModel;
import pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.MethodName;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.appointment.AvailableSlots;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;
import pk.gov.nadra.oneapp.models.appointment.SlotHoldRequest;
import pk.gov.nadra.oneapp.models.appointment.SlotHoldResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: AppointmentDateTimeFragment.kt */
@Metadata(d1 = {"\u0000\u008e\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010&\u001a\u00020'2\b\u0010(\u001a\u0004\u0018\u00010)H\u0016J\u0010\u0010*\u001a\u00020'2\u0006\u0010+\u001a\u00020,H\u0016J&\u0010-\u001a\u0004\u0018\u00010.2\u0006\u0010/\u001a\u0002002\b\u00101\u001a\u0004\u0018\u0001022\b\u0010(\u001a\u0004\u0018\u00010)H\u0016J\u001a\u00103\u001a\u00020'2\u0006\u00104\u001a\u00020.2\b\u0010(\u001a\u0004\u0018\u00010)H\u0016J\b\u00105\u001a\u00020'H\u0002J\u0018\u00106\u001a\u00020'2\u0006\u00107\u001a\u00020!2\u0006\u00108\u001a\u00020!H\u0002J\u0010\u00109\u001a\u00020'2\u0006\u0010:\u001a\u00020;H\u0002J\b\u0010<\u001a\u00020=H\u0002J\b\u0010>\u001a\u00020'H\u0002J\u0010\u0010?\u001a\u00020'2\u0006\u0010:\u001a\u00020;H\u0002J\u0018\u0010@\u001a\u00020'2\u0006\u0010A\u001a\u00020;2\u0006\u0010B\u001a\u00020CH\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R'\u0010\u001f\u001a\u000e\u0012\u0004\u0012\u00020!\u0012\u0004\u0012\u00020\"0 8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b%\u0010\t\u001a\u0004\b#\u0010$¨\u0006D"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/fragments/AppointmentDateTimeFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "appointmentSharedViewModel", "Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "getAppointmentSharedViewModel", "()Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "appointmentSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentDateTimeBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentDateTimeBinding;", "activity", "Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;)V", "dropdownCalling", "Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;", "appointmentAvailableSlotsAdapter", "Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentAvailableSlotsAdapter;", "selectedCenter", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data;", "selectedDocumentType", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType;", "selectedApplicationType", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType$ApplicationType;", "fieldToViewMap", "", "", "Lcom/google/android/material/textfield/TextInputLayout;", "getFieldToViewMap", "()Ljava/util/Map;", "fieldToViewMap$delegate", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onAttach", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "onViewCreated", Promotion.ACTION_VIEW, "initViewsData", "getAvailableSlotsByCenter", "centerId", "appointmentDate", "processSlotsSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "holdSlotRequest", "Lpk/gov/nadra/oneapp/models/appointment/SlotHoldRequest;", "holdSlotApiCall", "processHoldSlotSuccessResponse", "handleFailureCase", "jsonResponse", "responseCode", "", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentDateTimeFragment extends Fragment {
    private FragmentAppointmentDateTimeBinding _binding;
    public AppointmentSystemActivity activity;
    private AppointmentAvailableSlotsAdapter appointmentAvailableSlotsAdapter;

    /* renamed from: appointmentSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy appointmentSharedViewModel;
    private MethodName dropdownCalling = MethodName.DISTRICT;
    private CentersResponse.Data selectedCenter = new CentersResponse.Data(null, null, null, null, null, 31, null);
    private CentersResponse.Data.DocumentType selectedDocumentType = new CentersResponse.Data.DocumentType(null, null, null, 7, null);
    private CentersResponse.Data.DocumentType.ApplicationType selectedApplicationType = new CentersResponse.Data.DocumentType.ApplicationType(null, null, 3, null);

    /* renamed from: fieldToViewMap$delegate, reason: from kotlin metadata */
    private final Lazy fieldToViewMap = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$$ExternalSyntheticLambda8
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return AppointmentDateTimeFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
        }
    });

    public AppointmentDateTimeFragment() {
        final AppointmentDateTimeFragment appointmentDateTimeFragment = this;
        final Function0 function0 = null;
        this.appointmentSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(appointmentDateTimeFragment, Reflection.getOrCreateKotlinClass(AppointmentSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = appointmentDateTimeFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = appointmentDateTimeFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = appointmentDateTimeFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final AppointmentSharedViewModel getAppointmentSharedViewModel() {
        return (AppointmentSharedViewModel) this.appointmentSharedViewModel.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final FragmentAppointmentDateTimeBinding getBinding() {
        FragmentAppointmentDateTimeBinding fragmentAppointmentDateTimeBinding = this._binding;
        Intrinsics.checkNotNull(fragmentAppointmentDateTimeBinding);
        return fragmentAppointmentDateTimeBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final AppointmentSystemActivity getActivity() {
        AppointmentSystemActivity appointmentSystemActivity = this.activity;
        if (appointmentSystemActivity != null) {
            return appointmentSystemActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(AppointmentSystemActivity appointmentSystemActivity) {
        Intrinsics.checkNotNullParameter(appointmentSystemActivity, "<set-?>");
        this.activity = appointmentSystemActivity;
    }

    private final Map<String, TextInputLayout> getFieldToViewMap() {
        return (Map) this.fieldToViewMap.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Map fieldToViewMap_delegate$lambda$0(AppointmentDateTimeFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        return MapsKt.mapOf(TuplesKt.to("selectedDate", this$0.getBinding().appointmentDateLayout.textInputLayout));
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity");
        setActivity((AppointmentSystemActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentAppointmentDateTimeBinding.inflate(inflater, container, false);
        return getBinding().getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        this.selectedCenter = getAppointmentSharedViewModel().getSelectedCenterData();
        this.selectedDocumentType = getAppointmentSharedViewModel().getSelectedDocumentType();
        this.selectedApplicationType = getAppointmentSharedViewModel().getSelectedApplicationType();
        final FragmentAppointmentDateTimeBinding binding = getBinding();
        binding.appointmentHeaderLayout.textTitle.setText(getString(R.string.appointment));
        binding.appointmentHeaderLayout.textSubtitle.setText("پیشگی وقت");
        binding.appointmentHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.textBackUr.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentDateTimeFragment.onViewCreated$lambda$9$lambda$1(this.f$0, view2);
            }
        });
        binding.appointmentHeaderLayout.iconInfo.setVisibility(0);
        binding.appointmentHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentDateTimeFragment.onViewCreated$lambda$9$lambda$2(this.f$0, view2);
            }
        });
        TextView textView = binding.appointmentDetailHeadingLayout.tvStepAction;
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        String string = getString(R.string.appointment_details);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util, activity, string, " (پیشگی وقت  کی  تفصیلات) ", 0, false, 12, null));
        binding.appointmentDetailHeadingLayout.imageView.setVisibility(4);
        binding.appointmentDetailHeadingLayout.linearLayoutInfo.setVisibility(4);
        ArrayList arrayList = new ArrayList();
        arrayList.add(new AppointmentSteps(new SpannableString(""), ""));
        arrayList.add(new AppointmentSteps(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Location Selected ", " (علاقہ منتخب ہو گیاہے)", 0, false, 12, null), Util.INSTANCE.capitalizeWords(this.selectedCenter.getName())));
        arrayList.add(new AppointmentSteps(new SpannableString(""), ""));
        binding.appointmentDateTimeHeadingTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Select date and time", "  (تاریخ اور وقت منتخب کریں) ", 0, false, 12, null));
        binding.appointmentAvailableSlotsHeadingTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Available Time", " (دستیاب اوقات کار) ", 0, false, 12, null));
        binding.appointmentDetailStepRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.appointmentDetailStepRecyclerView.setAdapter(new AppointmentStepsAdapter(arrayList, true));
        TextInputLayout textInputLayout = binding.appointmentDateLayout.textInputLayout;
        Util util2 = Util.INSTANCE;
        AppointmentSystemActivity activity2 = getActivity();
        String string2 = getString(R.string.select_date);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textInputLayout.setHint(Util.setEnglishTextSpan$default(util2, activity2, string2, " (تاریخ منتخب کریں) ", 0, false, 12, null));
        binding.appointmentDateLayout.textInputEditText.setFocusableInTouchMode(false);
        binding.appointmentDateLayout.textInputEditText.setFocusable(false);
        binding.appointmentDateLayout.textInputEditText.setClickable(true);
        binding.appointmentDateLayout.textInputLayout.setEndIconMode(-1);
        binding.appointmentDateLayout.textInputLayout.setEndIconDrawable(ContextCompat.getDrawable(getActivity(), pk.gov.nadra.oneapp.commonui.R.drawable.ic_calendar_check));
        AppointmentAvailableSlotsAdapter appointmentAvailableSlotsAdapter = null;
        binding.appointmentDateLayout.textInputLayout.setEndIconTintList(null);
        binding.appointmentDateLayout.textInputEditText.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentDateTimeFragment.onViewCreated$lambda$9$lambda$4(this.f$0, binding, view2);
            }
        });
        Util util3 = Util.INSTANCE;
        AppointmentSystemActivity activity3 = getActivity();
        TextInputEditText textInputEditText = binding.appointmentDateLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        TextInputLayout textInputLayout2 = binding.appointmentDateLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        util3.removeErrorOnTextChanged(activity3, textInputEditText, textInputLayout2);
        TextInputLayout textInputLayout3 = binding.shiftTimeLayout.textInputLayout;
        Util util4 = Util.INSTANCE;
        AppointmentSystemActivity activity4 = getActivity();
        String string3 = getString(R.string.select_shift);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        textInputLayout3.setHint(Util.setEnglishTextSpan$default(util4, activity4, string3, " (شفٹ منتخب کریں) ", 0, true, 4, null));
        binding.shiftTimeLayout.autoCompleteTextView.setClickable(true);
        binding.shiftTimeLayout.autoCompleteTextView.setFocusable(false);
        binding.shiftTimeLayout.autoCompleteTextView.setFocusableInTouchMode(false);
        binding.shiftTimeLayout.textInputLayout.setEndIconDrawable(pk.gov.nadra.oneapp.commonui.R.drawable.ic_clock);
        binding.shiftTimeLayout.textInputLayout.setEndIconMode(-1);
        binding.shiftTimeLayout.textInputLayout.setEndIconTintList(null);
        binding.shiftTimeLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentDateTimeFragment.onViewCreated$lambda$9$lambda$5(this.f$0, view2);
            }
        });
        Util util5 = Util.INSTANCE;
        AppointmentSystemActivity activity5 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView = binding.shiftTimeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        TextInputLayout textInputLayout4 = binding.shiftTimeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout4, "textInputLayout");
        util5.removeErrorOnAutoCompleteTextChanged(activity5, autoCompleteTextView, textInputLayout4);
        binding.appointmentAvailableSlotsHeadingTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Available Times", " (دستیاب اوقات کار) ", 0, false, 12, null));
        for (AvailableSlots.Data data : getAppointmentSharedViewModel().getAvailableSlotsList()) {
            if (data.getId() == getAppointmentSharedViewModel().getSelectedSlotData().getId()) {
                data.setSelected(true);
                getBinding().appointmentDateTimeNextButtonLayout.commonButton.setDisabled(false);
            }
        }
        binding.appointmentAvailableSlotsRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 4));
        this.appointmentAvailableSlotsAdapter = new AppointmentAvailableSlotsAdapter(getActivity(), new ArrayList(), new Function1() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return AppointmentDateTimeFragment.onViewCreated$lambda$9$lambda$7(this.f$0, (AvailableSlots.Data) obj);
            }
        });
        RecyclerView recyclerView = binding.appointmentAvailableSlotsRecyclerView;
        AppointmentAvailableSlotsAdapter appointmentAvailableSlotsAdapter2 = this.appointmentAvailableSlotsAdapter;
        if (appointmentAvailableSlotsAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("appointmentAvailableSlotsAdapter");
        } else {
            appointmentAvailableSlotsAdapter = appointmentAvailableSlotsAdapter2;
        }
        recyclerView.setAdapter(appointmentAvailableSlotsAdapter);
        ConfigurableButton configurableButton = binding.appointmentDateTimeNextButtonLayout.commonButton;
        Util util6 = Util.INSTANCE;
        AppointmentSystemActivity activity6 = getActivity();
        String string4 = getString(pk.gov.nadra.oneapp.commonui.R.string.attestation_next_button);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util6, activity6, string4, " (آگے بڑھیں) ", 0, false, 12, null));
        binding.appointmentDateTimeNextButtonLayout.commonButton.setFilled(true);
        binding.appointmentDateTimeNextButtonLayout.commonButton.setDisabled(true);
        binding.appointmentDateTimeNextButtonLayout.commonButton.setInsetTop(0);
        binding.appointmentDateTimeNextButtonLayout.commonButton.setInsetBottom(0);
        binding.appointmentDateTimeNextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentDateTimeFragment.onViewCreated$lambda$9$lambda$8(this.f$0, view2);
            }
        });
        initViewsData();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$9$lambda$1(AppointmentDateTimeFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$9$lambda$2(AppointmentDateTimeFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = this$0.getActivity();
        String string = this$0.getString(pk.gov.nadra.oneapp.commonui.R.string.appointment_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.APPOINTMENT_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$9$lambda$4(final AppointmentDateTimeFragment this$0, final FragmentAppointmentDateTimeBinding this_apply, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        Util.INSTANCE.showExpiryDateWithMaxDatePickerDialog(this$0.getActivity(), new Function1() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return AppointmentDateTimeFragment.onViewCreated$lambda$9$lambda$4$lambda$3(this_apply, this$0, (Date) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$9$lambda$4$lambda$3(FragmentAppointmentDateTimeBinding this_apply, AppointmentDateTimeFragment this$0, Date selectedDate) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(selectedDate, "selectedDate");
        this_apply.appointmentDateLayout.textInputEditText.setText(Util.INSTANCE.dateFormat(selectedDate));
        this$0.getAppointmentSharedViewModel().setSelectedDate(Util.INSTANCE.dateFormat(selectedDate));
        this$0.getBinding().appointmentDateTimeNextButtonLayout.commonButton.setDisabled(true);
        this$0.getAppointmentSharedViewModel().setSelectedSlotData(new AvailableSlots.Data(0, null, false, 7, null));
        this$0.getAvailableSlotsByCenter(this$0.selectedCenter.getCenterId(), Util.INSTANCE.dateFormatYearMonthDate(this$0.getAppointmentSharedViewModel().getSelectedDate()));
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$9$lambda$5(AppointmentDateTimeFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.DISTRICT;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$9$lambda$7(AppointmentDateTimeFragment this$0, AvailableSlots.Data it) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(it, "it");
        this$0.getBinding().appointmentDateTimeNextButtonLayout.commonButton.setDisabled(false);
        this$0.getAppointmentSharedViewModel().setSelectedSlotData(it);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$9$lambda$8(AppointmentDateTimeFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.getAppointmentSharedViewModel().getSelectedSlotData().isSelected()) {
            this$0.holdSlotApiCall();
        }
    }

    private final void initViewsData() throws Resources.NotFoundException {
        if (getAppointmentSharedViewModel().getSelectedDate().length() > 0) {
            getBinding().appointmentDateLayout.textInputEditText.setText(getAppointmentSharedViewModel().getSelectedDate());
            ArrayList<AvailableSlots.Data> availableSlotsList = getAppointmentSharedViewModel().getAvailableSlotsList();
            for (AvailableSlots.Data data : availableSlotsList) {
                if (data.getId() == getAppointmentSharedViewModel().getSelectedSlotData().getId()) {
                    data.setSelected(true);
                    getBinding().appointmentAvailableSlotsCardView.setVisibility(0);
                    getBinding().appointmentAvailableSlotsHeadingTextView.setVisibility(0);
                    getBinding().appointmentDateTimeNextButtonLayout.commonButton.setDisabled(false);
                }
            }
            AppointmentAvailableSlotsAdapter appointmentAvailableSlotsAdapter = this.appointmentAvailableSlotsAdapter;
            if (appointmentAvailableSlotsAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("appointmentAvailableSlotsAdapter");
                appointmentAvailableSlotsAdapter = null;
            }
            appointmentAvailableSlotsAdapter.updateAvailableSlots(availableSlotsList);
        }
    }

    private final void getAvailableSlotsByCenter(String centerId, String appointmentDate) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(centerId, appointmentDate, null), 3, null);
    }

    /* compiled from: AppointmentDateTimeFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$getAvailableSlotsByCenter$1", f = "AppointmentDateTimeFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$getAvailableSlotsByCenter$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $appointmentDate;
        final /* synthetic */ String $centerId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, String str2, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$centerId = str;
            this.$appointmentDate = str2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AppointmentDateTimeFragment.this.new AnonymousClass1(this.$centerId, this.$appointmentDate, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(AppointmentDateTimeFragment.this.getActivity());
            String str = this.$centerId;
            String str2 = this.$appointmentDate;
            final AppointmentDateTimeFragment appointmentDateTimeFragment = AppointmentDateTimeFragment.this;
            aPIRequests.getAvailableSlotsByCenter(str, str2, new Function3() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$getAvailableSlotsByCenter$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return AppointmentDateTimeFragment.AnonymousClass1.invokeSuspend$lambda$0(appointmentDateTimeFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(AppointmentDateTimeFragment appointmentDateTimeFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException, Resources.NotFoundException {
            LoaderManager.INSTANCE.hideLoader(appointmentDateTimeFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getAvailableSlotsByCenter() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                appointmentDateTimeFragment.getBinding().slotListTryAgainLayout.setVisibility(8);
                appointmentDateTimeFragment.getBinding().appointmentAvailableSlotsCardView.setVisibility(0);
                appointmentDateTimeFragment.getBinding().appointmentAvailableSlotsHeadingTextView.setVisibility(0);
                appointmentDateTimeFragment.getBinding().appointmentAvailableSlotsRecyclerView.setVisibility(0);
                appointmentDateTimeFragment.processSlotsSuccessResponse(jsonObject);
            } else {
                appointmentDateTimeFragment.getBinding().appointmentAvailableSlotsCardView.setVisibility(8);
                appointmentDateTimeFragment.getBinding().appointmentAvailableSlotsHeadingTextView.setVisibility(8);
                appointmentDateTimeFragment.getBinding().appointmentDateTimeNextButtonLayout.commonButton.setDisabled(true);
                appointmentDateTimeFragment.getBinding().appointmentDateLayout.textInputEditText.setText("");
                appointmentDateTimeFragment.getAppointmentSharedViewModel().setSelectedDate("");
                appointmentDateTimeFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processSlotsSuccessResponse(JsonObject jSonObject) {
        AvailableSlots availableSlots = (AvailableSlots) new Gson().fromJson(jSonObject.toString(), AvailableSlots.class);
        if (!availableSlots.getData().isEmpty()) {
            getAppointmentSharedViewModel().getAvailableSlotsList().clear();
            getAppointmentSharedViewModel().getAvailableSlotsList().addAll(availableSlots.getData());
            AppointmentAvailableSlotsAdapter appointmentAvailableSlotsAdapter = this.appointmentAvailableSlotsAdapter;
            if (appointmentAvailableSlotsAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("appointmentAvailableSlotsAdapter");
                appointmentAvailableSlotsAdapter = null;
            }
            appointmentAvailableSlotsAdapter.updateAvailableSlots(availableSlots.getData());
            return;
        }
        getBinding().appointmentAvailableSlotsCardView.setVisibility(0);
        getBinding().appointmentAvailableSlotsRecyclerView.setVisibility(8);
        getBinding().slotListTryAgainLayout.setVisibility(0);
        getBinding().frcListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_documents);
        getBinding().frcListTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "No slot found against this date!\n", " اس تاریخ میں کوئی وقت دستیاب نہیں ہے! ", 0, false, 12, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final SlotHoldRequest holdSlotRequest() {
        SlotHoldRequest slotHoldRequest = new SlotHoldRequest(null, 0, 3, null);
        slotHoldRequest.setSelectedDate(Util.INSTANCE.dateFormatYearMonthDate(getAppointmentSharedViewModel().getSelectedDate()));
        slotHoldRequest.setSlotId(getAppointmentSharedViewModel().getSelectedSlotData().getId());
        return slotHoldRequest;
    }

    private final void holdSlotApiCall() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11001(null), 3, null);
    }

    /* compiled from: AppointmentDateTimeFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$holdSlotApiCall$1", f = "AppointmentDateTimeFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$holdSlotApiCall$1, reason: invalid class name and case insensitive filesystem */
    static final class C11001 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C11001(Continuation<? super C11001> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AppointmentDateTimeFragment.this.new C11001(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11001) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(AppointmentDateTimeFragment.this.getActivity());
            SlotHoldRequest slotHoldRequestHoldSlotRequest = AppointmentDateTimeFragment.this.holdSlotRequest();
            final AppointmentDateTimeFragment appointmentDateTimeFragment = AppointmentDateTimeFragment.this;
            aPIRequests.slotHoldRequest(slotHoldRequestHoldSlotRequest, new Function3() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$holdSlotApiCall$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return AppointmentDateTimeFragment.C11001.invokeSuspend$lambda$0(appointmentDateTimeFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(AppointmentDateTimeFragment appointmentDateTimeFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(appointmentDateTimeFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("holdSlotApiCall() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                appointmentDateTimeFragment.processHoldSlotSuccessResponse(jsonObject);
            } else {
                appointmentDateTimeFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processHoldSlotSuccessResponse(JsonObject jSonObject) {
        getAppointmentSharedViewModel().setSlotHoldResponse(((SlotHoldResponse) new Gson().fromJson(jSonObject.toString(), SlotHoldResponse.class)).getData());
        getActivity().navigateToFragment(R.id.appointmentApplicantDetailsFragment);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) throws JsonSyntaxException {
        Object element = new Gson().fromJson(jsonResponse.toString(), (Class<Object>) ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            ErrorResponse errorResponse = (ErrorResponse) element;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    ArrayList arrayList = new ArrayList();
                    ArrayList arrayList2 = new ArrayList();
                    for (ErrorResponse.Error error : errors) {
                        TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                        if (textInputLayout != null) {
                            textInputLayout.setError(String.valueOf(error.getMessage()));
                            textInputLayout.setErrorEnabled(true);
                        } else {
                            arrayList.add(String.valueOf(error.getMessage()));
                            String message_local = error.getMessage_local();
                            if (message_local == null) {
                                message_local = "";
                            }
                            arrayList2.add(message_local);
                        }
                    }
                    if (arrayList.isEmpty()) {
                        return;
                    }
                    BottomSheetUtils.showMessageBottomSheet$default(BottomSheetUtils.INSTANCE, (FragmentActivity) getActivity(), "Alert", CollectionsKt.joinToString$default(arrayList, "\n", null, null, 0, null, null, 62, null), false, true, CollectionsKt.joinToString$default(arrayList2, "\n", null, null, 0, null, null, 62, null), (Function1) null, 72, (Object) null);
                    return;
                }
                NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                AppointmentSystemActivity activity = getActivity();
                Intrinsics.checkNotNullExpressionValue(element, "element");
                NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$$ExternalSyntheticLambda9
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return AppointmentDateTimeFragment.handleFailureCase$lambda$19$lambda$18(this.f$0);
                    }
                }, 8, null);
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            AppointmentSystemActivity activity2 = getActivity();
            Intrinsics.checkNotNullExpressionValue(element, "element");
            NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return AppointmentDateTimeFragment.handleFailureCase$lambda$20(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        AppointmentSystemActivity activity3 = getActivity();
        Intrinsics.checkNotNullExpressionValue(element, "element");
        NetworkErrorHandler.handleError$default(networkErrorHandler3, activity3, (ErrorResponse) element, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentDateTimeFragment.handleFailureCase$lambda$21(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$19$lambda$18(AppointmentDateTimeFragment this_run) {
        Intrinsics.checkNotNullParameter(this_run, "$this_run");
        this_run.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$20(AppointmentDateTimeFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$21(AppointmentDateTimeFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }
}