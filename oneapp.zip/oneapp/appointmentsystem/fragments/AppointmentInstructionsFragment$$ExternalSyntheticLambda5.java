package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import pk.gov.nadra.rahbar.android.data.ServiceResponse;
import pk.gov.nadra.rahbar.android.util.ICommunicator;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentInstructionsFragment$$ExternalSyntheticLambda5 implements ICommunicator {
    public /* synthetic */ AppointmentInstructionsFragment$$ExternalSyntheticLambda5() {
    }

    @Override // pk.gov.nadra.rahbar.android.util.ICommunicator
    public final void onResponse(ServiceResponse serviceResponse) {
        AppointmentInstructionsFragment.iCommunicatorNrcDataServiceResult$lambda$6(this.f$0, serviceResponse);
    }
}