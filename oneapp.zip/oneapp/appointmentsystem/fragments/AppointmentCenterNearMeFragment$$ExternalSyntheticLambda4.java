package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.location.Location;
import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentCenterNearMeFragment$$ExternalSyntheticLambda4 implements Function1 {
    public /* synthetic */ AppointmentCenterNearMeFragment$$ExternalSyntheticLambda4() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return AppointmentCenterNearMeFragment.initializeLocation$lambda$5(this.f$0, (Location) obj);
    }
}