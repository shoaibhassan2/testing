package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.location.Location;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import java.io.IOException;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.appointment.ProvinceDistrictRequest;

/* compiled from: AppointmentLocationsFragment.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$initializeLocation$1$1", f = "AppointmentLocationsFragment.kt", i = {}, l = {TypedValues.PositionType.TYPE_SIZE_PERCENT}, m = "invokeSuspend", n = {}, s = {})
/* loaded from: classes5.dex */
final class AppointmentLocationsFragment$initializeLocation$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ Location $location;
    int label;
    final /* synthetic */ AppointmentLocationsFragment this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AppointmentLocationsFragment$initializeLocation$1$1(AppointmentLocationsFragment appointmentLocationsFragment, Location location, Continuation<? super AppointmentLocationsFragment$initializeLocation$1$1> continuation) {
        super(2, continuation);
        this.this$0 = appointmentLocationsFragment;
        this.$location = location;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new AppointmentLocationsFragment$initializeLocation$1$1(this.this$0, this.$location, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((AppointmentLocationsFragment$initializeLocation$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object obj) throws IOException {
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            this.label = 1;
            obj = Util.INSTANCE.getAddressFromLatLng(this.this$0.getActivity(), this.$location.getLatitude(), this.$location.getLongitude(), this);
            if (obj == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
        }
        String str = (String) obj;
        if (str != null) {
            this.this$0.getCentersListFromDistrictName(new ProvinceDistrictRequest(str));
        } else {
            LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
        }
        return Unit.INSTANCE;
    }
}