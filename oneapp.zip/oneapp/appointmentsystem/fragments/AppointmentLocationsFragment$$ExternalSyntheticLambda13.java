package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentLocationsFragment$$ExternalSyntheticLambda13 implements View.OnClickListener {
    public /* synthetic */ AppointmentLocationsFragment$$ExternalSyntheticLambda13() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AppointmentLocationsFragment.onViewCreated$lambda$6$lambda$4(this.f$0, view);
    }
}