package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.SpannableString;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.farrakhj.stringpickerlibrary.views.StringPickerActivity;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputLayout;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.AppointmentRequiredDocumentsAdapter;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.AppointmentStepsAdapter;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.model.AppointmentSteps;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentAppointmentVisitPurposeBinding;
import pk.gov.nadra.oneapp.appointmentsystem.viewmodel.AppointmentSharedViewModel;
import pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.MethodName;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;

/* compiled from: AppointmentVisitPurposeFragment.kt */
@Metadata(d1 = {"\u0000\u008c\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010!\u001a\u00020\"2\b\u0010#\u001a\u0004\u0018\u00010$H\u0016J\u0010\u0010%\u001a\u00020\"2\u0006\u0010&\u001a\u00020'H\u0016J&\u0010(\u001a\u0004\u0018\u00010)2\u0006\u0010*\u001a\u00020+2\b\u0010,\u001a\u0004\u0018\u00010-2\b\u0010#\u001a\u0004\u0018\u00010$H\u0016J\u001a\u0010.\u001a\u00020\"2\u0006\u0010/\u001a\u00020)2\b\u0010#\u001a\u0004\u0018\u00010$H\u0016J\b\u00100\u001a\u00020\"H\u0002J\b\u00101\u001a\u00020\"H\u0002J\b\u00102\u001a\u000203H\u0002J%\u00104\u001a\u00020\"2\u0016\u00105\u001a\u0012\u0012\u0004\u0012\u00020\u00190\u0018j\b\u0012\u0004\u0012\u00020\u0019`6H\u0002¢\u0006\u0002\u00107R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00190\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00190\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u00108\u001a\u0010\u0012\f\u0012\n ;*\u0004\u0018\u00010:0:09X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006<"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/fragments/AppointmentVisitPurposeFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "appointmentSharedViewModel", "Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "getAppointmentSharedViewModel", "()Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "appointmentSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentVisitPurposeBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentVisitPurposeBinding;", "activity", "Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;)V", "dropdownCalling", "Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;", "applicationTypeArray", "Ljava/util/ArrayList;", "", "documentTypeArray", "selectedCenter", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data;", "selectedDocumentType", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType;", "selectedApplicationType", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType$ApplicationType;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onAttach", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "onViewCreated", Promotion.ACTION_VIEW, "attachLayoutViews", "initViewsData", "validateViews", "", "launchStringPickerActivity", "arrayList", "Lkotlin/collections/ArrayList;", "(Ljava/util/ArrayList;)V", "startForResult", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentVisitPurposeFragment extends Fragment {
    private FragmentAppointmentVisitPurposeBinding _binding;
    public AppointmentSystemActivity activity;

    /* renamed from: appointmentSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy appointmentSharedViewModel;
    private final ActivityResultLauncher<Intent> startForResult;
    private MethodName dropdownCalling = MethodName.DOCUMENT_TYPE;
    private ArrayList<String> applicationTypeArray = new ArrayList<>();
    private ArrayList<String> documentTypeArray = new ArrayList<>();
    private CentersResponse.Data selectedCenter = new CentersResponse.Data(null, null, null, null, null, 31, null);
    private CentersResponse.Data.DocumentType selectedDocumentType = new CentersResponse.Data.DocumentType(null, null, null, 7, null);
    private CentersResponse.Data.DocumentType.ApplicationType selectedApplicationType = new CentersResponse.Data.DocumentType.ApplicationType(null, null, 3, null);

    /* compiled from: AppointmentVisitPurposeFragment.kt */
    @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[MethodName.values().length];
            try {
                iArr[MethodName.DOCUMENT_TYPE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[MethodName.APPLICATION_TYPE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public AppointmentVisitPurposeFragment() {
        final AppointmentVisitPurposeFragment appointmentVisitPurposeFragment = this;
        final Function0 function0 = null;
        this.appointmentSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(appointmentVisitPurposeFragment, Reflection.getOrCreateKotlinClass(AppointmentSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentVisitPurposeFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = appointmentVisitPurposeFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentVisitPurposeFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = appointmentVisitPurposeFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentVisitPurposeFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = appointmentVisitPurposeFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentVisitPurposeFragment$$ExternalSyntheticLambda0
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                AppointmentVisitPurposeFragment.startForResult$lambda$19(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.startForResult = activityResultLauncherRegisterForActivityResult;
    }

    private final AppointmentSharedViewModel getAppointmentSharedViewModel() {
        return (AppointmentSharedViewModel) this.appointmentSharedViewModel.getValue();
    }

    private final FragmentAppointmentVisitPurposeBinding getBinding() {
        FragmentAppointmentVisitPurposeBinding fragmentAppointmentVisitPurposeBinding = this._binding;
        Intrinsics.checkNotNull(fragmentAppointmentVisitPurposeBinding);
        return fragmentAppointmentVisitPurposeBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final AppointmentSystemActivity getActivity() {
        AppointmentSystemActivity appointmentSystemActivity = this.activity;
        if (appointmentSystemActivity != null) {
            return appointmentSystemActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(AppointmentSystemActivity appointmentSystemActivity) {
        Intrinsics.checkNotNullParameter(appointmentSystemActivity, "<set-?>");
        this.activity = appointmentSystemActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity");
        setActivity((AppointmentSystemActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentAppointmentVisitPurposeBinding.inflate(inflater, container, false);
        return getBinding().getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        this.selectedCenter = getAppointmentSharedViewModel().getSelectedCenterData();
        attachLayoutViews();
    }

    private final void attachLayoutViews() throws Resources.NotFoundException {
        FragmentAppointmentVisitPurposeBinding binding = getBinding();
        binding.appointmentHeaderLayout.textTitle.setText(getString(R.string.appointment));
        binding.appointmentHeaderLayout.textSubtitle.setText(" پیشگی وقت ");
        binding.appointmentHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.textBackUr.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentVisitPurposeFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AppointmentVisitPurposeFragment.attachLayoutViews$lambda$7$lambda$0(this.f$0, view);
            }
        });
        binding.appointmentHeaderLayout.iconInfo.setVisibility(0);
        binding.appointmentHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentVisitPurposeFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AppointmentVisitPurposeFragment.attachLayoutViews$lambda$7$lambda$1(this.f$0, view);
            }
        });
        TextView textView = binding.appointmentDetailHeadingLayout.tvStepAction;
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        String string = getString(R.string.appointment_details);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util, activity, string, " (پیشگی وقت کی تفصیلات) ", 0, false, 12, null));
        binding.appointmentDetailHeadingLayout.imageView.setVisibility(4);
        binding.appointmentDetailHeadingLayout.linearLayoutInfo.setVisibility(4);
        ArrayList arrayList = new ArrayList();
        arrayList.add(new AppointmentSteps(new SpannableString(""), ""));
        arrayList.add(new AppointmentSteps(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Location Selected ", " (علاقہ منتخب ہوگیا)", 0, false, 12, null), Util.INSTANCE.capitalizeWords(this.selectedCenter.getName())));
        arrayList.add(new AppointmentSteps(new SpannableString(""), ""));
        TextInputLayout textInputLayout = binding.documentTypeLayout.textInputLayout;
        Util util2 = Util.INSTANCE;
        AppointmentSystemActivity activity2 = getActivity();
        String string2 = getString(pk.gov.nadra.oneapp.commonui.R.string.document_type);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textInputLayout.setHint(Util.setEnglishTextSpan$default(util2, activity2, string2, " دستاویز کی نوعیت ", 0, true, 4, null));
        Util util3 = Util.INSTANCE;
        AppointmentSystemActivity activity3 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView = binding.documentTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        TextInputLayout textInputLayout2 = binding.documentTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        util3.removeErrorOnAutoCompleteTextChanged(activity3, autoCompleteTextView, textInputLayout2);
        binding.documentTypeLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentVisitPurposeFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AppointmentVisitPurposeFragment.attachLayoutViews$lambda$7$lambda$4(this.f$0, view);
            }
        });
        TextInputLayout textInputLayout3 = binding.applicationTypeLayout.textInputLayout;
        Util util4 = Util.INSTANCE;
        AppointmentSystemActivity activity4 = getActivity();
        String string3 = getString(pk.gov.nadra.oneapp.commonui.R.string.application_type);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        textInputLayout3.setHint(Util.setEnglishTextSpan$default(util4, activity4, string3, " درخواست کی نوعیت ", 0, true, 4, null));
        Util util5 = Util.INSTANCE;
        AppointmentSystemActivity activity5 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView2 = binding.applicationTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView2, "autoCompleteTextView");
        TextInputLayout textInputLayout4 = binding.applicationTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout4, "textInputLayout");
        util5.removeErrorOnAutoCompleteTextChanged(activity5, autoCompleteTextView2, textInputLayout4);
        binding.applicationTypeLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentVisitPurposeFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AppointmentVisitPurposeFragment.attachLayoutViews$lambda$7$lambda$5(this.f$0, view);
            }
        });
        Util util6 = Util.INSTANCE;
        AppointmentSystemActivity activity6 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView3 = binding.applicationTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView3, "autoCompleteTextView");
        TextInputLayout textInputLayout5 = binding.applicationTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout5, "textInputLayout");
        util6.removeErrorOnAutoCompleteTextChanged(activity6, autoCompleteTextView3, textInputLayout5);
        binding.appointmentDetailStepRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.appointmentDetailStepRecyclerView.setAdapter(new AppointmentStepsAdapter(arrayList, true));
        binding.paymentFacilityTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Available payment methods at selected facility", "\nمنتخب کردہ دفتر میں ادائیگی کے لئے دستیاب طریقہ کار", com.intuit.sdp.R.dimen._10sdp, false, 8, null));
        binding.paymentViaRaastTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Facility for Payment via Raast is also available", "\nادائیگی بذریعہ راست کرنے کی سہولت بھی موجود ہے", com.intuit.sdp.R.dimen._10sdp, false, 8, null));
        binding.appointmentPaymentModeHeadingTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Payment Mode ", "(ادائیگی کا طریقہ)", 0, false, 12, null));
        ArrayList arrayList2 = new ArrayList();
        binding.appointmentMandatoryDocumentRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.appointmentMandatoryDocumentRecyclerView.setAdapter(new AppointmentRequiredDocumentsAdapter(arrayList2));
        ConfigurableButton configurableButton = binding.appointmentDetailNextButtonLayout.commonButton;
        Util util7 = Util.INSTANCE;
        AppointmentSystemActivity activity7 = getActivity();
        String string4 = getString(pk.gov.nadra.oneapp.commonui.R.string.attestation_next_button);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util7, activity7, string4, " (آگے بڑھیں) ", 0, false, 12, null));
        binding.appointmentDetailNextButtonLayout.commonButton.setFilled(true);
        binding.appointmentDetailNextButtonLayout.commonButton.setInsetTop(0);
        binding.appointmentDetailNextButtonLayout.commonButton.setInsetBottom(0);
        binding.appointmentDetailNextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentVisitPurposeFragment$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AppointmentVisitPurposeFragment.attachLayoutViews$lambda$7$lambda$6(this.f$0, view);
            }
        });
        initViewsData();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$7$lambda$0(AppointmentVisitPurposeFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$7$lambda$1(AppointmentVisitPurposeFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = this$0.getActivity();
        String string = this$0.getString(pk.gov.nadra.oneapp.commonui.R.string.appointment_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.APPOINTMENT_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$7$lambda$4(AppointmentVisitPurposeFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.DOCUMENT_TYPE;
        List<CentersResponse.Data.DocumentType> documentTypes = this$0.selectedCenter.getDocumentTypes();
        ArrayList<String> arrayList = new ArrayList<>(CollectionsKt.collectionSizeOrDefault(documentTypes, 10));
        Iterator<T> it = documentTypes.iterator();
        while (it.hasNext()) {
            String name = ((CentersResponse.Data.DocumentType) it.next()).getName();
            if (name.length() > 0) {
                StringBuilder sb = new StringBuilder();
                String strValueOf = String.valueOf(name.charAt(0));
                Intrinsics.checkNotNull(strValueOf, "null cannot be cast to non-null type java.lang.String");
                String upperCase = strValueOf.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                StringBuilder sbAppend = sb.append((Object) upperCase);
                String strSubstring = name.substring(1);
                Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                name = sbAppend.append(strSubstring).toString();
            }
            arrayList.add(name);
        }
        ArrayList<String> arrayList2 = arrayList;
        this$0.documentTypeArray = arrayList2;
        if (arrayList2.isEmpty()) {
            return;
        }
        this$0.launchStringPickerActivity(this$0.documentTypeArray);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$7$lambda$5(AppointmentVisitPurposeFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.APPLICATION_TYPE;
        if (this$0.applicationTypeArray.isEmpty()) {
            return;
        }
        this$0.launchStringPickerActivity(this$0.applicationTypeArray);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$7$lambda$6(AppointmentVisitPurposeFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToFragment(R.id.appointmentDateTimeFragment);
    }

    private final void initViewsData() {
        if (getAppointmentSharedViewModel().getSelectedDocumentType().getId().length() > 0) {
            CentersResponse.Data.DocumentType selectedDocumentType = getAppointmentSharedViewModel().getSelectedDocumentType();
            this.selectedDocumentType = selectedDocumentType;
            List<CentersResponse.Data.DocumentType.ApplicationType> applicationTypes = selectedDocumentType.getApplicationTypes();
            ArrayList<String> arrayList = new ArrayList<>(CollectionsKt.collectionSizeOrDefault(applicationTypes, 10));
            Iterator<T> it = applicationTypes.iterator();
            while (it.hasNext()) {
                String name = ((CentersResponse.Data.DocumentType.ApplicationType) it.next()).getName();
                if (name.length() > 0) {
                    StringBuilder sb = new StringBuilder();
                    String strValueOf = String.valueOf(name.charAt(0));
                    Intrinsics.checkNotNull(strValueOf, "null cannot be cast to non-null type java.lang.String");
                    String upperCase = strValueOf.toUpperCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                    StringBuilder sbAppend = sb.append((Object) upperCase);
                    String strSubstring = name.substring(1);
                    Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                    name = sbAppend.append(strSubstring).toString();
                }
                arrayList.add(name);
            }
            this.applicationTypeArray = arrayList;
            MaterialAutoCompleteTextView materialAutoCompleteTextView = getBinding().documentTypeLayout.autoCompleteTextView;
            String name2 = this.selectedDocumentType.getName();
            if (name2.length() > 0) {
                StringBuilder sb2 = new StringBuilder();
                String strValueOf2 = String.valueOf(name2.charAt(0));
                Intrinsics.checkNotNull(strValueOf2, "null cannot be cast to non-null type java.lang.String");
                String upperCase2 = strValueOf2.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
                StringBuilder sbAppend2 = sb2.append((Object) upperCase2);
                String strSubstring2 = name2.substring(1);
                Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
                name2 = sbAppend2.append(strSubstring2).toString();
            }
            materialAutoCompleteTextView.setText(name2);
        }
        if (getAppointmentSharedViewModel().getSelectedApplicationType().getId().length() > 0) {
            this.selectedApplicationType = getAppointmentSharedViewModel().getSelectedApplicationType();
            MaterialAutoCompleteTextView materialAutoCompleteTextView2 = getBinding().applicationTypeLayout.autoCompleteTextView;
            String name3 = this.selectedApplicationType.getName();
            if (name3.length() > 0) {
                StringBuilder sb3 = new StringBuilder();
                String strValueOf3 = String.valueOf(name3.charAt(0));
                Intrinsics.checkNotNull(strValueOf3, "null cannot be cast to non-null type java.lang.String");
                String upperCase3 = strValueOf3.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase3, "toUpperCase(...)");
                StringBuilder sbAppend3 = sb3.append((Object) upperCase3);
                String strSubstring3 = name3.substring(1);
                Intrinsics.checkNotNullExpressionValue(strSubstring3, "substring(...)");
                name3 = sbAppend3.append(strSubstring3).toString();
            }
            materialAutoCompleteTextView2.setText(name3);
        }
    }

    private final boolean validateViews() {
        FragmentAppointmentVisitPurposeBinding binding = getBinding();
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        TextInputLayout textInputLayout = binding.documentTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView = binding.documentTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        if (!util.validateAutoCompleteTextView(activity, textInputLayout, autoCompleteTextView)) {
            return false;
        }
        Util util2 = Util.INSTANCE;
        AppointmentSystemActivity activity2 = getActivity();
        TextInputLayout textInputLayout2 = binding.applicationTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        MaterialAutoCompleteTextView autoCompleteTextView2 = binding.applicationTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView2, "autoCompleteTextView");
        return util2.validateAutoCompleteTextView(activity2, textInputLayout2, autoCompleteTextView2);
    }

    private final void launchStringPickerActivity(ArrayList<String> arrayList) {
        Intent intent = new Intent(getActivity(), (Class<?>) StringPickerActivity.class);
        intent.putStringArrayListExtra("INTENT_STRING_LIST", arrayList);
        this.startForResult.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startForResult$lambda$19(AppointmentVisitPurposeFragment this$0, ActivityResult result) {
        Intent data;
        String stringExtra;
        Object next;
        Object next2;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || (data = result.getData()) == null || !data.hasExtra("INTENT_STRING_ITEM") || (stringExtra = data.getStringExtra("INTENT_STRING_ITEM")) == null) {
            return;
        }
        int i = WhenMappings.$EnumSwitchMapping$0[this$0.dropdownCalling.ordinal()];
        if (i != 1) {
            if (i != 2) {
                return;
            }
            Iterator<T> it = this$0.selectedDocumentType.getApplicationTypes().iterator();
            while (true) {
                if (!it.hasNext()) {
                    next2 = null;
                    break;
                }
                next2 = it.next();
                String lowerCase = ((CentersResponse.Data.DocumentType.ApplicationType) next2).getName().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                String lowerCase2 = stringExtra.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                if (Intrinsics.areEqual(lowerCase, lowerCase2)) {
                    break;
                }
            }
            CentersResponse.Data.DocumentType.ApplicationType applicationType = (CentersResponse.Data.DocumentType.ApplicationType) next2;
            if (applicationType == null) {
                applicationType = new CentersResponse.Data.DocumentType.ApplicationType(null, null, 3, null);
            }
            this$0.selectedApplicationType = applicationType;
            MaterialAutoCompleteTextView materialAutoCompleteTextView = this$0.getBinding().applicationTypeLayout.autoCompleteTextView;
            String name = this$0.selectedApplicationType.getName();
            if (name.length() > 0) {
                StringBuilder sb = new StringBuilder();
                String strValueOf = String.valueOf(name.charAt(0));
                Intrinsics.checkNotNull(strValueOf, "null cannot be cast to non-null type java.lang.String");
                String upperCase = strValueOf.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                StringBuilder sbAppend = sb.append((Object) upperCase);
                String strSubstring = name.substring(1);
                Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                name = sbAppend.append(strSubstring).toString();
            }
            materialAutoCompleteTextView.setText(name);
            this$0.getAppointmentSharedViewModel().setSelectedApplicationType(this$0.selectedApplicationType);
            return;
        }
        Iterator<T> it2 = this$0.selectedCenter.getDocumentTypes().iterator();
        while (true) {
            if (!it2.hasNext()) {
                next = null;
                break;
            }
            next = it2.next();
            String lowerCase3 = ((CentersResponse.Data.DocumentType) next).getName().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
            String lowerCase4 = stringExtra.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase4, "toLowerCase(...)");
            if (Intrinsics.areEqual(lowerCase3, lowerCase4)) {
                break;
            }
        }
        Intrinsics.checkNotNull(next);
        CentersResponse.Data.DocumentType documentType = (CentersResponse.Data.DocumentType) next;
        this$0.selectedDocumentType = documentType;
        List<CentersResponse.Data.DocumentType.ApplicationType> applicationTypes = documentType.getApplicationTypes();
        ArrayList<String> arrayList = new ArrayList<>(CollectionsKt.collectionSizeOrDefault(applicationTypes, 10));
        Iterator<T> it3 = applicationTypes.iterator();
        while (it3.hasNext()) {
            String name2 = ((CentersResponse.Data.DocumentType.ApplicationType) it3.next()).getName();
            if (name2.length() > 0) {
                StringBuilder sb2 = new StringBuilder();
                String strValueOf2 = String.valueOf(name2.charAt(0));
                Intrinsics.checkNotNull(strValueOf2, "null cannot be cast to non-null type java.lang.String");
                String upperCase2 = strValueOf2.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
                StringBuilder sbAppend2 = sb2.append((Object) upperCase2);
                String strSubstring2 = name2.substring(1);
                Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
                name2 = sbAppend2.append(strSubstring2).toString();
            }
            arrayList.add(name2);
        }
        this$0.applicationTypeArray = arrayList;
        MaterialAutoCompleteTextView materialAutoCompleteTextView2 = this$0.getBinding().documentTypeLayout.autoCompleteTextView;
        String name3 = this$0.selectedDocumentType.getName();
        if (name3.length() > 0) {
            StringBuilder sb3 = new StringBuilder();
            String strValueOf3 = String.valueOf(name3.charAt(0));
            Intrinsics.checkNotNull(strValueOf3, "null cannot be cast to non-null type java.lang.String");
            String upperCase3 = strValueOf3.toUpperCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(upperCase3, "toUpperCase(...)");
            StringBuilder sbAppend3 = sb3.append((Object) upperCase3);
            String strSubstring3 = name3.substring(1);
            Intrinsics.checkNotNullExpressionValue(strSubstring3, "substring(...)");
            name3 = sbAppend3.append(strSubstring3).toString();
        }
        materialAutoCompleteTextView2.setText(name3);
        this$0.getAppointmentSharedViewModel().setSelectedDocumentType(this$0.selectedDocumentType);
        this$0.getBinding().applicationTypeLayout.autoCompleteTextView.setText("");
        this$0.selectedApplicationType = new CentersResponse.Data.DocumentType.ApplicationType(null, null, 3, null);
        this$0.getAppointmentSharedViewModel().setSelectedApplicationType(new CentersResponse.Data.DocumentType.ApplicationType(null, null, 3, null));
    }
}