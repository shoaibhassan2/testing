package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda1 implements ActivityResultCallback {
    public /* synthetic */ AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda1() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        AppointmentApplicantDetailsFragment.startForResult$lambda$19(this.f$0, (ActivityResult) obj);
    }
}