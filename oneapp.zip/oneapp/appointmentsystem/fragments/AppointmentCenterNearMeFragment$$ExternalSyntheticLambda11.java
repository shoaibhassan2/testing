package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentCenterNearMeFragment$$ExternalSyntheticLambda11 implements ActivityResultCallback {
    public /* synthetic */ AppointmentCenterNearMeFragment$$ExternalSyntheticLambda11() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        AppointmentCenterNearMeFragment.setupLocationOrGpsPermissionLaunchers$lambda$4(this.f$0, (ActivityResult) obj);
    }
}