package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentLocationsFragment$$ExternalSyntheticLambda4 implements Function0 {
    public /* synthetic */ AppointmentLocationsFragment$$ExternalSyntheticLambda4() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return AppointmentLocationsFragment.handleFailureCase$lambda$30(this.f$0);
    }
}