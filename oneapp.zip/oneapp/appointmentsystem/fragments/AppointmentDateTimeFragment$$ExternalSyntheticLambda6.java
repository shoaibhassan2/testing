package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import kotlin.jvm.functions.Function1;
import pk.gov.nadra.oneapp.models.appointment.AvailableSlots;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentDateTimeFragment$$ExternalSyntheticLambda6 implements Function1 {
    public /* synthetic */ AppointmentDateTimeFragment$$ExternalSyntheticLambda6() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return AppointmentDateTimeFragment.onViewCreated$lambda$9$lambda$7(this.f$0, (AvailableSlots.Data) obj);
    }
}