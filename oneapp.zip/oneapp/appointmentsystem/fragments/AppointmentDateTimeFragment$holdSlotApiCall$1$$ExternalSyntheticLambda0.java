package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import com.google.gson.JsonObject;
import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentDateTimeFragment;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentDateTimeFragment$holdSlotApiCall$1$$ExternalSyntheticLambda0 implements Function3 {
    public /* synthetic */ AppointmentDateTimeFragment$holdSlotApiCall$1$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return AppointmentDateTimeFragment.C11001.invokeSuspend$lambda$0(appointmentDateTimeFragment, (JsonObject) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}