package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentCenterDetailFragment$$ExternalSyntheticLambda0 implements Function0 {
    public /* synthetic */ AppointmentCenterDetailFragment$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return AppointmentCenterDetailFragment.handleFailureCase$lambda$13$lambda$12(this.f$0);
    }
}