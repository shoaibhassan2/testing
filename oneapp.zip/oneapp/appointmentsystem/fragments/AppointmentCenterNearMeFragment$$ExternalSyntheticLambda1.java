package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentCenterNearMeFragment$$ExternalSyntheticLambda1 implements GoogleMap.OnMapLongClickListener {
    public /* synthetic */ AppointmentCenterNearMeFragment$$ExternalSyntheticLambda1() {
    }

    @Override // com.google.android.gms.maps.GoogleMap.OnMapLongClickListener
    public final void onMapLongClick(LatLng latLng) {
        AppointmentCenterNearMeFragment.onMapReady$lambda$13(this.f$0, latLng);
    }
}