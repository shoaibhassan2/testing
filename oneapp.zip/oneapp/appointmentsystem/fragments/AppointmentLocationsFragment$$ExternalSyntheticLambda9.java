package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import androidx.activity.result.ActivityResultCallback;
import java.util.Map;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentLocationsFragment$$ExternalSyntheticLambda9 implements ActivityResultCallback {
    public /* synthetic */ AppointmentLocationsFragment$$ExternalSyntheticLambda9() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        AppointmentLocationsFragment.setupLocationOrGpsPermissionLaunchers$lambda$31(this.f$0, (Map) obj);
    }
}