package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentLocationsFragment$$ExternalSyntheticLambda6 implements ActivityResultCallback {
    public /* synthetic */ AppointmentLocationsFragment$$ExternalSyntheticLambda6() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        AppointmentLocationsFragment.startForResult$lambda$17(this.f$0, (ActivityResult) obj);
    }
}