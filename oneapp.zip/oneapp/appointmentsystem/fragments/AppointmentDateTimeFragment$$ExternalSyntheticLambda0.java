package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import java.util.Date;
import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentDateTimeFragment$$ExternalSyntheticLambda0 implements Function1 {
    public final /* synthetic */ AppointmentDateTimeFragment f$1;

    public /* synthetic */ AppointmentDateTimeFragment$$ExternalSyntheticLambda0(AppointmentDateTimeFragment appointmentDateTimeFragment) {
        this$0 = appointmentDateTimeFragment;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return AppointmentDateTimeFragment.onViewCreated$lambda$9$lambda$4$lambda$3(this_apply, this$0, (Date) obj);
    }
}