package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentInstructionsFragment$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public /* synthetic */ AppointmentInstructionsFragment$$ExternalSyntheticLambda1() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AppointmentInstructionsFragment.onViewCreated$lambda$4$lambda$1(this.f$0, view);
    }
}