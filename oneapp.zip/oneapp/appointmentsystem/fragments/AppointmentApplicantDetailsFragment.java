package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.SpannableString;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.farrakhj.stringpickerlibrary.views.StringPickerActivity;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.common.net.HttpHeaders;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import org.apache.commons.imaging.formats.jpeg.iptc.IptcConstants;
import org.apache.commons.lang3.StringUtils;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.AppointmentStepsAdapter;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.model.AppointmentSteps;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentAppointmentApplicantDetailsBinding;
import pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment;
import pk.gov.nadra.oneapp.appointmentsystem.viewmodel.AppointmentSharedViewModel;
import pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity;
import pk.gov.nadra.oneapp.commonui.CnicMaskWatcher;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.MethodName;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.appointment.AvailableSlots;
import pk.gov.nadra.oneapp.models.appointment.BookAppointmentRequest;
import pk.gov.nadra.oneapp.models.appointment.BookAppointmentResponse;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;
import pk.gov.nadra.oneapp.models.appointment.SlotHoldResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.library.LibraryResponse;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;
import pk.gov.nadra.oneapp.phonenumberkit.PhoneNumberKit;
import pk.gov.nadra.oneapp.phonenumberkit.api.Country;
import pk.gov.nadra.oneapp.phonenumberkit.internal.interfaces.CountryChangeListener;

/* compiled from: AppointmentApplicantDetailsFragment.kt */
@Metadata(d1 = {"\u0000Ø\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u00012\u00020\u0002B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u0012\u00105\u001a\u0002062\b\u00107\u001a\u0004\u0018\u000108H\u0016J\u0010\u00109\u001a\u0002062\u0006\u0010:\u001a\u00020;H\u0016J&\u0010<\u001a\u0004\u0018\u00010=2\u0006\u0010>\u001a\u00020?2\b\u0010@\u001a\u0004\u0018\u00010A2\b\u00107\u001a\u0004\u0018\u000108H\u0016J\u001a\u0010B\u001a\u0002062\u0006\u0010C\u001a\u00020=2\b\u00107\u001a\u0004\u0018\u000108H\u0016J\b\u0010D\u001a\u000206H\u0002J\b\u0010E\u001a\u00020FH\u0002J\b\u0010G\u001a\u000206H\u0002J\b\u0010H\u001a\u00020IH\u0002J\b\u0010J\u001a\u000206H\u0002J\u0010\u0010K\u001a\u0002062\u0006\u0010L\u001a\u00020MH\u0002J\u0018\u0010N\u001a\u0002062\u0006\u0010O\u001a\u00020M2\u0006\u0010P\u001a\u00020QH\u0002J\u0010\u0010R\u001a\u0002062\u0006\u0010S\u001a\u00020TH\u0016J\b\u0010U\u001a\u000206H\u0002J%\u0010V\u001a\u0002062\u0016\u0010W\u001a\u0012\u0012\u0004\u0012\u00020+01j\b\u0012\u0004\u0012\u00020+`XH\u0002¢\u0006\u0002\u0010YR\u001b\u0010\u0005\u001a\u00020\u00068BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\bR\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\u00020\f8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0010\u001a\u00020\u0011X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010#\u001a\u00020$X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b%\u0010&\"\u0004\b'\u0010(R'\u0010)\u001a\u000e\u0012\u0004\u0012\u00020+\u0012\u0004\u0012\u00020,0*8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b/\u0010\n\u001a\u0004\b-\u0010.R\u0014\u00100\u001a\b\u0012\u0004\u0012\u00020\u001701X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00102\u001a\u000203X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010Z\u001a\u0010\u0012\f\u0012\n ]*\u0004\u0018\u00010\\0\\0[X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006^"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/fragments/AppointmentApplicantDetailsFragment;", "Landroidx/fragment/app/Fragment;", "Lpk/gov/nadra/oneapp/phonenumberkit/internal/interfaces/CountryChangeListener;", "<init>", "()V", "appointmentSharedViewModel", "Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "getAppointmentSharedViewModel", "()Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "appointmentSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentApplicantDetailsBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentApplicantDetailsBinding;", "activity", "Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;)V", "selectedProvince", "Lpk/gov/nadra/oneapp/models/crc/library/LibraryResponse;", "selectedDistrict", "selectedCenter", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data;", "selectedDocumentType", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType;", "selectedApplicationType", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType$ApplicationType;", "selectedSlot", "Lpk/gov/nadra/oneapp/models/appointment/AvailableSlots$Data;", "slotHoldResponse", "Lpk/gov/nadra/oneapp/models/appointment/SlotHoldResponse$Data;", "phoneNumberKit", "Lpk/gov/nadra/oneapp/phonenumberkit/PhoneNumberKit;", "getPhoneNumberKit", "()Lpk/gov/nadra/oneapp/phonenumberkit/PhoneNumberKit;", "setPhoneNumberKit", "(Lpk/gov/nadra/oneapp/phonenumberkit/PhoneNumberKit;)V", "fieldToViewMap", "", "", "Lcom/google/android/material/textfield/TextInputLayout;", "getFieldToViewMap", "()Ljava/util/Map;", "fieldToViewMap$delegate", "purposeOfVisitList", "Ljava/util/ArrayList;", "dropdownCalling", "Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;", "selectedPurpose", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onAttach", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "onViewCreated", Promotion.ACTION_VIEW, "initViewsData", "validateViews", "", "updateViewsData", "bookAppointmentRequest", "Lpk/gov/nadra/oneapp/models/appointment/BookAppointmentRequest;", "bookAppointmentApiCall", "processBookAppointmentSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "handleFailureCase", "jsonResponse", "responseCode", "", "onCountryChanged", "country", "Lpk/gov/nadra/oneapp/phonenumberkit/api/Country;", "addPurposeOfVisit", "launchStringPickerActivity", "arrayList", "Lkotlin/collections/ArrayList;", "(Ljava/util/ArrayList;)V", "startForResult", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentApplicantDetailsFragment extends Fragment implements CountryChangeListener {
    private FragmentAppointmentApplicantDetailsBinding _binding;
    public AppointmentSystemActivity activity;

    /* renamed from: appointmentSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy appointmentSharedViewModel;
    public PhoneNumberKit phoneNumberKit;
    private final ActivityResultLauncher<Intent> startForResult;
    private LibraryResponse selectedProvince = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private CentersResponse.Data selectedCenter = new CentersResponse.Data(null, null, null, null, null, 31, null);
    private CentersResponse.Data.DocumentType selectedDocumentType = new CentersResponse.Data.DocumentType(null, null, null, 7, null);
    private CentersResponse.Data.DocumentType.ApplicationType selectedApplicationType = new CentersResponse.Data.DocumentType.ApplicationType(null, null, 3, null);
    private AvailableSlots.Data selectedSlot = new AvailableSlots.Data(0, null, false, 7, null);
    private SlotHoldResponse.Data slotHoldResponse = new SlotHoldResponse.Data(null, null, 0, null, null, null, null, 0, 255, null);

    /* renamed from: fieldToViewMap$delegate, reason: from kotlin metadata */
    private final Lazy fieldToViewMap = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return AppointmentApplicantDetailsFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
        }
    });
    private ArrayList<LibraryResponse> purposeOfVisitList = new ArrayList<>();
    private MethodName dropdownCalling = MethodName.PURPOSE_OF_VISIT;
    private LibraryResponse selectedPurpose = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);

    /* compiled from: AppointmentApplicantDetailsFragment.kt */
    @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[MethodName.values().length];
            try {
                iArr[MethodName.PURPOSE_OF_VISIT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public AppointmentApplicantDetailsFragment() {
        final AppointmentApplicantDetailsFragment appointmentApplicantDetailsFragment = this;
        final Function0 function0 = null;
        this.appointmentSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(appointmentApplicantDetailsFragment, Reflection.getOrCreateKotlinClass(AppointmentSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = appointmentApplicantDetailsFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = appointmentApplicantDetailsFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = appointmentApplicantDetailsFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda1
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                AppointmentApplicantDetailsFragment.startForResult$lambda$19(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.startForResult = activityResultLauncherRegisterForActivityResult;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final AppointmentSharedViewModel getAppointmentSharedViewModel() {
        return (AppointmentSharedViewModel) this.appointmentSharedViewModel.getValue();
    }

    private final FragmentAppointmentApplicantDetailsBinding getBinding() {
        FragmentAppointmentApplicantDetailsBinding fragmentAppointmentApplicantDetailsBinding = this._binding;
        Intrinsics.checkNotNull(fragmentAppointmentApplicantDetailsBinding);
        return fragmentAppointmentApplicantDetailsBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final AppointmentSystemActivity getActivity() {
        AppointmentSystemActivity appointmentSystemActivity = this.activity;
        if (appointmentSystemActivity != null) {
            return appointmentSystemActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(AppointmentSystemActivity appointmentSystemActivity) {
        Intrinsics.checkNotNullParameter(appointmentSystemActivity, "<set-?>");
        this.activity = appointmentSystemActivity;
    }

    public final PhoneNumberKit getPhoneNumberKit() {
        PhoneNumberKit phoneNumberKit = this.phoneNumberKit;
        if (phoneNumberKit != null) {
            return phoneNumberKit;
        }
        Intrinsics.throwUninitializedPropertyAccessException("phoneNumberKit");
        return null;
    }

    public final void setPhoneNumberKit(PhoneNumberKit phoneNumberKit) {
        Intrinsics.checkNotNullParameter(phoneNumberKit, "<set-?>");
        this.phoneNumberKit = phoneNumberKit;
    }

    private final Map<String, TextInputLayout> getFieldToViewMap() {
        return (Map) this.fieldToViewMap.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Map fieldToViewMap_delegate$lambda$0(AppointmentApplicantDetailsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        return MapsKt.mapOf(TuplesKt.to("name", this$0.getBinding().appointmentApplicantNameLayout.textInputLayout), TuplesKt.to("citizenNumber", this$0.getBinding().appointmentApplicantCnicLayout.maskedCnicTextInputLayout), TuplesKt.to("mobileNumber", this$0.getBinding().appointmentApplicantContactNumberLayout), TuplesKt.to("email", this$0.getBinding().appointmentApplicantEmailLayout.textInputLayout), TuplesKt.to("purpose", this$0.getBinding().purposeTypeLayout.textInputLayout));
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity");
        setActivity((AppointmentSystemActivity) fragmentActivityRequireActivity);
        setPhoneNumberKit(new PhoneNumberKit.Builder(getActivity()).setIconEnabled(true).excludeCountries(CollectionsKt.listOf((Object[]) new String[]{"in", "il"})).build());
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentAppointmentApplicantDetailsBinding.inflate(inflater, container, false);
        return getBinding().getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        this.selectedProvince = getAppointmentSharedViewModel().getSelectedProvince();
        this.selectedDistrict = getAppointmentSharedViewModel().getSelectedDistrict();
        this.selectedCenter = getAppointmentSharedViewModel().getSelectedCenterData();
        this.selectedDocumentType = getAppointmentSharedViewModel().getSelectedDocumentType();
        this.selectedApplicationType = getAppointmentSharedViewModel().getSelectedApplicationType();
        this.selectedSlot = getAppointmentSharedViewModel().getSelectedSlotData();
        this.slotHoldResponse = getAppointmentSharedViewModel().getSlotHoldResponse();
        FragmentAppointmentApplicantDetailsBinding binding = getBinding();
        binding.appointmentHeaderLayout.textTitle.setText(getString(R.string.appointment));
        binding.appointmentHeaderLayout.textSubtitle.setText(" پیشگی وقت ");
        binding.appointmentHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.textBackUr.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentApplicantDetailsFragment.onViewCreated$lambda$6$lambda$1(this.f$0, view2);
            }
        });
        binding.appointmentHeaderLayout.iconInfo.setVisibility(0);
        binding.appointmentHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentApplicantDetailsFragment.onViewCreated$lambda$6$lambda$2(this.f$0, view2);
            }
        });
        TextView textView = binding.appointmentDetailHeadingLayout.tvStepAction;
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        String string = getString(R.string.appointment_details);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util, activity, string, " (پیشگی وقت کی تفصیلات) ", 0, false, 12, null));
        binding.appointmentDetailHeadingLayout.imageView.setVisibility(4);
        binding.appointmentDetailHeadingLayout.linearLayoutInfo.setVisibility(4);
        TextView textView2 = binding.appointmentApplicantDetailHeadingTextView;
        Util util2 = Util.INSTANCE;
        AppointmentSystemActivity activity2 = getActivity();
        String string2 = getString(R.string.applicant_detail);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textView2.setText(Util.setEnglishTextSpan$default(util2, activity2, string2, " (درخواست گزار کی تفصیلات) ", 0, false, 12, null));
        binding.appointmentApplicantDetailInfoTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Please enter your details or those of family member below.\n", " برائے کرم اپنی تفصیلات یا کسی خاندان کے فرد کی تفصیلات نیچے درج کریں۔ ", com.intuit.sdp.R.dimen._10sdp, false, 8, null));
        ArrayList arrayList = new ArrayList();
        arrayList.add(new AppointmentSteps(new SpannableString(""), ""));
        arrayList.add(new AppointmentSteps(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Location Selected ", " (علاقہ منتخب ہو گیا)", 0, false, 12, null), Util.INSTANCE.capitalizeWords(this.selectedCenter.getName())));
        arrayList.add(new AppointmentSteps(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Date & Time", " (تاریخ اور وقت)", 0, false, 12, null), getAppointmentSharedViewModel().getSelectedDate() + StringUtils.SPACE + Util.INSTANCE.convertTimeToAmPm(this.selectedSlot.getSlot())));
        arrayList.add(new AppointmentSteps(new SpannableString(""), ""));
        binding.appointmentDetailStepRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.appointmentDetailStepRecyclerView.setAdapter(new AppointmentStepsAdapter(arrayList, true));
        TextInputLayout textInputLayout = binding.appointmentApplicantNameLayout.textInputLayout;
        Util util3 = Util.INSTANCE;
        AppointmentSystemActivity activity3 = getActivity();
        String string3 = getString(pk.gov.nadra.oneapp.commonui.R.string.full_name);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        textInputLayout.setHint(Util.setEnglishTextSpan$default(util3, activity3, string3, " (مکمل نام) ", 0, false, 12, null));
        binding.appointmentApplicantNameLayout.textInputEditText.setImeOptions(5);
        Util util4 = Util.INSTANCE;
        AppointmentSystemActivity activity4 = getActivity();
        TextInputEditText textInputEditText = binding.appointmentApplicantNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        TextInputLayout textInputLayout2 = binding.appointmentApplicantNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        util4.removeErrorOnTextChanged(activity4, textInputEditText, textInputLayout2);
        TextInputLayout textInputLayout3 = binding.appointmentApplicantCnicLayout.maskedCnicTextInputLayout;
        Util util5 = Util.INSTANCE;
        AppointmentSystemActivity activity5 = getActivity();
        String string4 = getString(pk.gov.nadra.oneapp.commonui.R.string.citizen_number);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        textInputLayout3.setHint(Util.setEnglishTextSpan$default(util5, activity5, string4, "  (شناختی کارڈ نمبر)  ", 0, false, 12, null));
        binding.appointmentApplicantCnicLayout.maskedCnicEditText.addTextChangedListener(new CnicMaskWatcher("#####-#######-#"));
        binding.appointmentApplicantCnicLayout.maskedCnicEditText.setImeOptions(5);
        Util util6 = Util.INSTANCE;
        AppointmentSystemActivity activity6 = getActivity();
        TextInputEditText maskedCnicEditText = binding.appointmentApplicantCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        TextInputLayout maskedCnicTextInputLayout = binding.appointmentApplicantCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        util6.removeErrorOnTextChanged(activity6, maskedCnicEditText, maskedCnicTextInputLayout);
        TextInputLayout textInputLayout4 = binding.appointmentApplicantContactNumberLayout;
        Util util7 = Util.INSTANCE;
        AppointmentSystemActivity activity7 = getActivity();
        String string5 = getString(R.string.contact_details_whatsapp);
        Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
        textInputLayout4.setHint(Util.setEnglishTextSpan$default(util7, activity7, string5, "(رابطہ نمبر) ", 0, true, 4, null));
        binding.appointmentApplicantContactNumberTextInputEditText.setImeOptions(5);
        binding.appointmentApplicantContactNumberTextInputEditText.setInputType(2);
        binding.appointmentApplicantContactNumberTextInputEditText.setFilters(new InputFilter.LengthFilter[]{new InputFilter.LengthFilter(18)});
        Util util8 = Util.INSTANCE;
        AppointmentSystemActivity activity8 = getActivity();
        TextInputEditText appointmentApplicantContactNumberTextInputEditText = binding.appointmentApplicantContactNumberTextInputEditText;
        Intrinsics.checkNotNullExpressionValue(appointmentApplicantContactNumberTextInputEditText, "appointmentApplicantContactNumberTextInputEditText");
        TextInputLayout appointmentApplicantContactNumberLayout = binding.appointmentApplicantContactNumberLayout;
        Intrinsics.checkNotNullExpressionValue(appointmentApplicantContactNumberLayout, "appointmentApplicantContactNumberLayout");
        util8.removeErrorOnTextChanged(activity8, appointmentApplicantContactNumberTextInputEditText, appointmentApplicantContactNumberLayout);
        BuildersKt__Builders_commonKt.launch$default(LifecycleOwnerKt.getLifecycleScope(this), null, null, new AppointmentApplicantDetailsFragment$onViewCreated$1$3(this, binding, null), 3, null);
        TextInputLayout textInputLayout5 = binding.appointmentApplicantEmailLayout.textInputLayout;
        Util util9 = Util.INSTANCE;
        AppointmentSystemActivity activity9 = getActivity();
        String string6 = getString(pk.gov.nadra.oneapp.commonui.R.string.email);
        Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
        textInputLayout5.setHint(Util.setEnglishTextSpan$default(util9, activity9, string6, " ای میل ", 0, false, 12, null).toString());
        binding.appointmentApplicantEmailLayout.textInputEditText.setImeOptions(6);
        binding.appointmentApplicantEmailLayout.textInputEditText.setInputType(32);
        Util util10 = Util.INSTANCE;
        AppointmentSystemActivity activity10 = getActivity();
        TextInputEditText textInputEditText2 = binding.appointmentApplicantEmailLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        TextInputLayout textInputLayout6 = binding.appointmentApplicantEmailLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout6, "textInputLayout");
        util10.removeErrorOnTextChanged(activity10, textInputEditText2, textInputLayout6);
        ConfigurableButton configurableButton = binding.appointmentApplicantDetailsNextButtonLayout.commonButton;
        Util util11 = Util.INSTANCE;
        AppointmentSystemActivity activity11 = getActivity();
        String string7 = getString(R.string.submit);
        Intrinsics.checkNotNullExpressionValue(string7, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util11, activity11, string7, " (جمع کریں) ", 0, false, 12, null));
        binding.appointmentApplicantDetailsNextButtonLayout.commonButton.setFilled(true);
        binding.appointmentApplicantDetailsNextButtonLayout.commonButton.setInsetTop(0);
        binding.appointmentApplicantDetailsNextButtonLayout.commonButton.setInsetBottom(0);
        binding.appointmentApplicantDetailsNextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentApplicantDetailsFragment.onViewCreated$lambda$6$lambda$3(this.f$0, view2);
            }
        });
        binding.purposeTypeLayout.textInputLayout.setHint(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), HttpHeaders.PURPOSE, " (مقصد) ", 0, true, 4, null));
        Util util12 = Util.INSTANCE;
        AppointmentSystemActivity activity12 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView = binding.purposeTypeLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        TextInputLayout textInputLayout7 = binding.purposeTypeLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout7, "textInputLayout");
        util12.removeErrorOnAutoCompleteTextChanged(activity12, autoCompleteTextView, textInputLayout7);
        binding.purposeTypeLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentApplicantDetailsFragment.onViewCreated$lambda$6$lambda$5(this.f$0, view2);
            }
        });
        addPurposeOfVisit();
        initViewsData();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$1(AppointmentApplicantDetailsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$2(AppointmentApplicantDetailsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = this$0.getActivity();
        String string = this$0.getString(pk.gov.nadra.oneapp.commonui.R.string.appointment_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.APPOINTMENT_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$3(AppointmentApplicantDetailsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.updateViewsData();
        this$0.bookAppointmentApiCall();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$5(AppointmentApplicantDetailsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        new ArrayList();
        ArrayList<LibraryResponse> arrayList = this$0.purposeOfVisitList;
        ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList, 10));
        Iterator<T> it = arrayList.iterator();
        while (it.hasNext()) {
            arrayList2.add(((LibraryResponse) it.next()).getValue());
        }
        this$0.dropdownCalling = MethodName.PURPOSE_OF_VISIT;
        this$0.launchStringPickerActivity(arrayList2);
    }

    private final void initViewsData() {
        getBinding().appointmentApplicantNameLayout.textInputEditText.setText(getAppointmentSharedViewModel().getName());
        getBinding().appointmentApplicantCnicLayout.maskedCnicEditText.setText(getAppointmentSharedViewModel().getCitizenNumber());
        getBinding().appointmentApplicantEmailLayout.textInputEditText.setText(getAppointmentSharedViewModel().getEmail());
        getBinding().appointmentApplicantContactNumberTextInputEditText.setCompoundDrawablesWithIntrinsicBounds(getPhoneNumberKit().getFlagIcon(getAppointmentSharedViewModel().getAlpha2()), (Drawable) null, (Drawable) null, (Drawable) null);
        getBinding().appointmentApplicantContactNumberTextInputEditText.setCompoundDrawablePadding(30);
        getBinding().appointmentApplicantContactNumberTextInputEditText.setText(getAppointmentSharedViewModel().getMobileNumber());
        String citizenNumber = getAppointmentSharedViewModel().getCitizenNumber();
        if (citizenNumber == null || citizenNumber.length() == 0) {
            getBinding().appointmentApplicantCnicLayout.maskedCnicEditText.setText(getAppointmentSharedViewModel().getReactNativeData().getAccountHolderCnic());
        }
        String name = getAppointmentSharedViewModel().getName();
        if (name == null || name.length() == 0) {
            getBinding().appointmentApplicantNameLayout.textInputEditText.setText(getAppointmentSharedViewModel().getReactNativeData().getFullName());
        }
    }

    private final boolean validateViews() {
        FragmentAppointmentApplicantDetailsBinding binding = getBinding();
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        TextInputLayout textInputLayout = binding.appointmentApplicantNameLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout, "textInputLayout");
        TextInputEditText textInputEditText = binding.appointmentApplicantNameLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText, "textInputEditText");
        if (!util.validateEditText(activity, textInputLayout, textInputEditText)) {
            return false;
        }
        Util util2 = Util.INSTANCE;
        AppointmentSystemActivity activity2 = getActivity();
        TextInputLayout maskedCnicTextInputLayout = binding.appointmentApplicantCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        TextInputEditText maskedCnicEditText = binding.appointmentApplicantCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        if (!util2.validateEditText(activity2, maskedCnicTextInputLayout, maskedCnicEditText)) {
            return false;
        }
        Util util3 = Util.INSTANCE;
        AppointmentSystemActivity activity3 = getActivity();
        TextInputLayout appointmentApplicantContactNumberLayout = binding.appointmentApplicantContactNumberLayout;
        Intrinsics.checkNotNullExpressionValue(appointmentApplicantContactNumberLayout, "appointmentApplicantContactNumberLayout");
        TextInputEditText appointmentApplicantContactNumberTextInputEditText = binding.appointmentApplicantContactNumberTextInputEditText;
        Intrinsics.checkNotNullExpressionValue(appointmentApplicantContactNumberTextInputEditText, "appointmentApplicantContactNumberTextInputEditText");
        if (!util3.validateEditText(activity3, appointmentApplicantContactNumberLayout, appointmentApplicantContactNumberTextInputEditText)) {
            return false;
        }
        Util util4 = Util.INSTANCE;
        AppointmentSystemActivity activity4 = getActivity();
        TextInputLayout textInputLayout2 = binding.appointmentApplicantEmailLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        TextInputEditText textInputEditText2 = binding.appointmentApplicantEmailLayout.textInputEditText;
        Intrinsics.checkNotNullExpressionValue(textInputEditText2, "textInputEditText");
        return util4.validateEditText(activity4, textInputLayout2, textInputEditText2);
    }

    private final void updateViewsData() {
        getAppointmentSharedViewModel().setName(StringsKt.trim((CharSequence) String.valueOf(getBinding().appointmentApplicantNameLayout.textInputEditText.getText())).toString());
        getAppointmentSharedViewModel().setCitizenNumber(StringsKt.replace$default(StringsKt.trim((CharSequence) String.valueOf(getBinding().appointmentApplicantCnicLayout.maskedCnicEditText.getText())).toString(), "-", "", false, 4, (Object) null));
        getAppointmentSharedViewModel().setMobileNumber(StringsKt.trim((CharSequence) String.valueOf(getBinding().appointmentApplicantContactNumberTextInputEditText.getText())).toString());
        getAppointmentSharedViewModel().setEmail(StringsKt.trim((CharSequence) String.valueOf(getBinding().appointmentApplicantEmailLayout.textInputEditText.getText())).toString());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final BookAppointmentRequest bookAppointmentRequest() {
        BookAppointmentRequest bookAppointmentRequest = new BookAppointmentRequest(null, null, null, null, null, null, null, null, null, null, 0, null, 4095, null);
        bookAppointmentRequest.setName(StringsKt.trim((CharSequence) String.valueOf(getBinding().appointmentApplicantNameLayout.textInputEditText.getText())).toString());
        bookAppointmentRequest.setCitizenNumber(StringsKt.replace$default(StringsKt.trim((CharSequence) String.valueOf(getBinding().appointmentApplicantCnicLayout.maskedCnicEditText.getText())).toString(), "-", "", false, 4, (Object) null));
        bookAppointmentRequest.setMobileNumber(StringsKt.replace$default(StringsKt.trim((CharSequence) String.valueOf(getBinding().appointmentApplicantContactNumberTextInputEditText.getText())).toString(), StringUtils.SPACE, "", false, 4, (Object) null));
        bookAppointmentRequest.setEmail(StringsKt.trim((CharSequence) String.valueOf(getBinding().appointmentApplicantEmailLayout.textInputEditText.getText())).toString());
        bookAppointmentRequest.setApplicationType(this.selectedApplicationType.getId());
        bookAppointmentRequest.setDocumentType(this.selectedDocumentType.getId());
        bookAppointmentRequest.setAppointmentDate(Util.INSTANCE.dateFormatYearMonthDate(getAppointmentSharedViewModel().getSelectedDate()));
        bookAppointmentRequest.setSlot(this.slotHoldResponse.getId());
        bookAppointmentRequest.setCenterId(this.selectedCenter.getCenterId());
        bookAppointmentRequest.setProvince(this.selectedProvince.getKey());
        bookAppointmentRequest.setDistrict(this.selectedDistrict.getKey());
        bookAppointmentRequest.setPurpose(this.selectedPurpose.getKey());
        return bookAppointmentRequest;
    }

    private final void bookAppointmentApiCall() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(null), 3, null);
    }

    /* compiled from: AppointmentApplicantDetailsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$bookAppointmentApiCall$1", f = "AppointmentApplicantDetailsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$bookAppointmentApiCall$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AppointmentApplicantDetailsFragment.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(AppointmentApplicantDetailsFragment.this.getActivity());
            BookAppointmentRequest bookAppointmentRequest = AppointmentApplicantDetailsFragment.this.bookAppointmentRequest();
            final AppointmentApplicantDetailsFragment appointmentApplicantDetailsFragment = AppointmentApplicantDetailsFragment.this;
            aPIRequests.bookAppointmentRequest(bookAppointmentRequest, new Function3() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$bookAppointmentApiCall$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return AppointmentApplicantDetailsFragment.AnonymousClass1.invokeSuspend$lambda$0(appointmentApplicantDetailsFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(AppointmentApplicantDetailsFragment appointmentApplicantDetailsFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(appointmentApplicantDetailsFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("bookAppointmentApiCall() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                appointmentApplicantDetailsFragment.processBookAppointmentSuccessResponse(jsonObject);
            } else {
                appointmentApplicantDetailsFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processBookAppointmentSuccessResponse(JsonObject jSonObject) {
        getAppointmentSharedViewModel().setBookAppointmentResponse(((BookAppointmentResponse) new Gson().fromJson(jSonObject.toString(), BookAppointmentResponse.class)).getData());
        getActivity().navigateToFragment(R.id.appointmentSubmissionFragment);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) throws JsonSyntaxException {
        Object element = new Gson().fromJson(jsonResponse.toString(), (Class<Object>) ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            ErrorResponse errorResponse = (ErrorResponse) element;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    ArrayList arrayList = new ArrayList();
                    ArrayList arrayList2 = new ArrayList();
                    for (ErrorResponse.Error error : errors) {
                        TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                        if (textInputLayout != null) {
                            textInputLayout.setError(String.valueOf(error.getMessage()));
                            textInputLayout.setErrorEnabled(true);
                        } else {
                            arrayList.add(String.valueOf(error.getMessage()));
                            String message_local = error.getMessage_local();
                            if (message_local == null) {
                                message_local = "";
                            }
                            arrayList2.add(message_local);
                        }
                    }
                    if (arrayList.isEmpty()) {
                        return;
                    }
                    BottomSheetUtils.showMessageBottomSheet$default(BottomSheetUtils.INSTANCE, (FragmentActivity) getActivity(), "Alert", CollectionsKt.joinToString$default(arrayList, "\n", null, null, 0, null, null, 62, null), false, true, CollectionsKt.joinToString$default(arrayList2, "\n", null, null, 0, null, null, 62, null), (Function1) null, 72, (Object) null);
                    return;
                }
                NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                AppointmentSystemActivity activity = getActivity();
                Intrinsics.checkNotNullExpressionValue(element, "element");
                NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return AppointmentApplicantDetailsFragment.handleFailureCase$lambda$15$lambda$14(this.f$0);
                    }
                }, 8, null);
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            AppointmentSystemActivity activity2 = getActivity();
            Intrinsics.checkNotNullExpressionValue(element, "element");
            NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return AppointmentApplicantDetailsFragment.handleFailureCase$lambda$16(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        AppointmentSystemActivity activity3 = getActivity();
        Intrinsics.checkNotNullExpressionValue(element, "element");
        NetworkErrorHandler.handleError$default(networkErrorHandler3, activity3, (ErrorResponse) element, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentApplicantDetailsFragment.handleFailureCase$lambda$17(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$15$lambda$14(AppointmentApplicantDetailsFragment this_run) {
        Intrinsics.checkNotNullParameter(this_run, "$this_run");
        this_run.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$16(AppointmentApplicantDetailsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$17(AppointmentApplicantDetailsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* compiled from: AppointmentApplicantDetailsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$onCountryChanged$1", f = "AppointmentApplicantDetailsFragment.kt", i = {}, l = {367}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$onCountryChanged$1, reason: invalid class name and case insensitive filesystem */
    static final class C10991 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Country $country;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C10991(Country country, Continuation<? super C10991> continuation) {
            super(2, continuation);
            this.$country = country;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AppointmentApplicantDetailsFragment.this.new C10991(this.$country, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C10991) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* compiled from: AppointmentApplicantDetailsFragment.kt */
        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
        @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$onCountryChanged$1$1", f = "AppointmentApplicantDetailsFragment.kt", i = {}, l = {368}, m = "invokeSuspend", n = {}, s = {})
        /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$onCountryChanged$1$1, reason: invalid class name and collision with other inner class name */
        static final class C02021 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ Country $country;
            Object L$0;
            int label;
            final /* synthetic */ AppointmentApplicantDetailsFragment this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C02021(AppointmentApplicantDetailsFragment appointmentApplicantDetailsFragment, Country country, Continuation<? super C02021> continuation) {
                super(2, continuation);
                this.this$0 = appointmentApplicantDetailsFragment;
                this.$country = country;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new C02021(this.this$0, this.$country, continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return ((C02021) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object obj) {
                AppointmentSharedViewModel appointmentSharedViewModel;
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.label;
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    AppointmentSharedViewModel appointmentSharedViewModel2 = this.this$0.getAppointmentSharedViewModel();
                    this.L$0 = appointmentSharedViewModel2;
                    this.label = 1;
                    Object iso2ByIso3 = this.this$0.getPhoneNumberKit().getIso2ByIso3(this.$country.getIso3(), this);
                    if (iso2ByIso3 == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    appointmentSharedViewModel = appointmentSharedViewModel2;
                    obj = iso2ByIso3;
                } else {
                    if (i != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    appointmentSharedViewModel = (AppointmentSharedViewModel) this.L$0;
                    ResultKt.throwOnFailure(obj);
                }
                String str = (String) obj;
                if (str == null) {
                    str = "pk";
                }
                appointmentSharedViewModel.setAlpha2(str);
                return Unit.INSTANCE;
            }
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (BuildersKt.withContext(Dispatchers.getIO(), new C02021(AppointmentApplicantDetailsFragment.this, this.$country, null), this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            return Unit.INSTANCE;
        }
    }

    @Override // pk.gov.nadra.oneapp.phonenumberkit.internal.interfaces.CountryChangeListener
    public void onCountryChanged(Country country) {
        Intrinsics.checkNotNullParameter(country, "country");
        Log.e(Constant.TAG, "attachLayoutViews: ISO: " + country);
        BuildersKt__Builders_commonKt.launch$default(LifecycleOwnerKt.getLifecycleScope(this), null, null, new C10991(country, null), 3, null);
        Intrinsics.areEqual(country.getIso3(), "PAK");
    }

    private final void addPurposeOfVisit() {
        this.purposeOfVisitList.add(new LibraryResponse(0, "BIOMETRIC_UPDATE", "Biometric Update (بایومیٹرک اپ ڈیٹ)", null, null, false, 0, 0, 0, null, 1017, null));
        this.purposeOfVisitList.add(new LibraryResponse(0, "DUP_MARKING", "Dup Marking (دہرے کارڈ کی نشاندہی)", null, null, false, 0, 0, 0, null, 1017, null));
        this.purposeOfVisitList.add(new LibraryResponse(0, "REJECTION_REMOVAL", "Rejection Removal (اعتراض کا خاتمہ )", null, null, false, 0, 0, 0, null, 1017, null));
        this.purposeOfVisitList.add(new LibraryResponse(0, "OTHER", "Other (متفرق)", null, null, false, 0, 0, 0, null, 1017, null));
    }

    private final void launchStringPickerActivity(ArrayList<String> arrayList) {
        Intent intent = new Intent(getActivity(), (Class<?>) StringPickerActivity.class);
        intent.putStringArrayListExtra("INTENT_STRING_LIST", arrayList);
        this.startForResult.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startForResult$lambda$19(AppointmentApplicantDetailsFragment this$0, ActivityResult result) {
        Intent data;
        String stringExtra;
        Object next;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || (data = result.getData()) == null || !data.hasExtra("INTENT_STRING_ITEM") || (stringExtra = data.getStringExtra("INTENT_STRING_ITEM")) == null) {
            return;
        }
        if (WhenMappings.$EnumSwitchMapping$0[this$0.dropdownCalling.ordinal()] == 1) {
            Iterator<T> it = this$0.purposeOfVisitList.iterator();
            while (true) {
                if (!it.hasNext()) {
                    next = null;
                    break;
                } else {
                    next = it.next();
                    if (Intrinsics.areEqual(((LibraryResponse) next).getValue(), stringExtra)) {
                        break;
                    }
                }
            }
            Intrinsics.checkNotNull(next);
            this$0.selectedPurpose = (LibraryResponse) next;
            this$0.getBinding().purposeTypeLayout.autoCompleteTextView.setText(stringExtra);
        }
    }
}