package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import com.google.android.material.textfield.TextInputLayout;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentAppointmentApplicantDetailsBinding;
import pk.gov.nadra.oneapp.phonenumberkit.PhoneNumberKit;

/* compiled from: AppointmentApplicantDetailsFragment.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$onViewCreated$1$3", f = "AppointmentApplicantDetailsFragment.kt", i = {}, l = {186}, m = "invokeSuspend", n = {}, s = {})
/* loaded from: classes5.dex */
final class AppointmentApplicantDetailsFragment$onViewCreated$1$3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ FragmentAppointmentApplicantDetailsBinding $this_apply;
    int label;
    final /* synthetic */ AppointmentApplicantDetailsFragment this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AppointmentApplicantDetailsFragment$onViewCreated$1$3(AppointmentApplicantDetailsFragment appointmentApplicantDetailsFragment, FragmentAppointmentApplicantDetailsBinding fragmentAppointmentApplicantDetailsBinding, Continuation<? super AppointmentApplicantDetailsFragment$onViewCreated$1$3> continuation) {
        super(2, continuation);
        this.this$0 = appointmentApplicantDetailsFragment;
        this.$this_apply = fragmentAppointmentApplicantDetailsBinding;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new AppointmentApplicantDetailsFragment$onViewCreated$1$3(this.this$0, this.$this_apply, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((AppointmentApplicantDetailsFragment$onViewCreated$1$3) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    /* compiled from: AppointmentApplicantDetailsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$onViewCreated$1$3$1", f = "AppointmentApplicantDetailsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentApplicantDetailsFragment$onViewCreated$1$3$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ FragmentAppointmentApplicantDetailsBinding $this_apply;
        int label;
        final /* synthetic */ AppointmentApplicantDetailsFragment this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(AppointmentApplicantDetailsFragment appointmentApplicantDetailsFragment, FragmentAppointmentApplicantDetailsBinding fragmentAppointmentApplicantDetailsBinding, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.this$0 = appointmentApplicantDetailsFragment;
            this.$this_apply = fragmentAppointmentApplicantDetailsBinding;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new AnonymousClass1(this.this$0, this.$this_apply, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            PhoneNumberKit phoneNumberKit = this.this$0.getPhoneNumberKit();
            TextInputLayout appointmentApplicantContactNumberLayout = this.$this_apply.appointmentApplicantContactNumberLayout;
            Intrinsics.checkNotNullExpressionValue(appointmentApplicantContactNumberLayout, "appointmentApplicantContactNumberLayout");
            phoneNumberKit.attachToInput(appointmentApplicantContactNumberLayout, this.this$0.getAppointmentSharedViewModel().getAlpha2());
            PhoneNumberKit.setupCountryPicker$default(this.this$0.getPhoneNumberKit(), this.this$0.getActivity(), 0, true, 2, null);
            this.this$0.getPhoneNumberKit().addListener(this.this$0);
            return Unit.INSTANCE;
        }
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object obj) {
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            this.label = 1;
            if (BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass1(this.this$0, this.$this_apply, null), this) == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
        }
        return Unit.INSTANCE;
    }
}