package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.util.ArrayList;
import java.util.List;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import org.apache.commons.imaging.formats.jpeg.iptc.IptcConstants;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.ActionType;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.AppointmentsListAdapter;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentAppointmentsListBinding;
import pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment;
import pk.gov.nadra.oneapp.appointmentsystem.viewmodel.AppointmentSharedViewModel;
import pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.appointment.AvailableSlots;
import pk.gov.nadra.oneapp.models.appointment.BookAppointmentResponse;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;
import pk.gov.nadra.oneapp.models.appointment.SlotHoldResponse;
import pk.gov.nadra.oneapp.models.appointment.UserAppointmentResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.library.LibraryResponse;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: AppointmentsListFragment.kt */
@Metadata(d1 = {"\u0000x\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\b\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u001fH\u0016J&\u0010 \u001a\u0004\u0018\u00010!2\u0006\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010%2\b\u0010&\u001a\u0004\u0018\u00010'H\u0016J\u001a\u0010(\u001a\u00020\u001d2\u0006\u0010)\u001a\u00020!2\b\u0010&\u001a\u0004\u0018\u00010'H\u0016J\b\u0010*\u001a\u00020\u001dH\u0002J\u0010\u0010+\u001a\u00020\u001d2\u0006\u0010,\u001a\u00020-H\u0002J\u0018\u0010.\u001a\u00020\u001d2\u0006\u0010/\u001a\u00020-2\u0006\u00100\u001a\u000201H\u0002J\"\u00102\u001a\u00020\u001d2\u0006\u00103\u001a\u0002042\u0006\u00105\u001a\u0002042\b\b\u0002\u00106\u001a\u000201H\u0002J\u0010\u00107\u001a\u00020\u001d2\u0006\u00103\u001a\u000204H\u0002J\u0010\u00108\u001a\u00020\u001d2\u0006\u00103\u001a\u000204H\u0002J\u0010\u00109\u001a\u00020\u001d2\u0006\u0010,\u001a\u00020-H\u0002J\b\u0010:\u001a\u00020\u001dH\u0002J\b\u0010;\u001a\u00020\u001dH\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R \u0010\u0015\u001a\u0012\u0012\u0004\u0012\u00020\u00170\u0018j\b\u0012\u0004\u0012\u00020\u0017`\u0016X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u0019R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082.¢\u0006\u0002\n\u0000¨\u0006<"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/fragments/AppointmentsListFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "appointmentSharedViewModel", "Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "getAppointmentSharedViewModel", "()Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "appointmentSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentsListBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentsListBinding;", "activity", "Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;)V", "appointmentsList", "Lkotlin/collections/ArrayList;", "Lpk/gov/nadra/oneapp/models/appointment/UserAppointmentResponse$Data;", "Ljava/util/ArrayList;", "Ljava/util/ArrayList;", "appointmentsListAdapter", "Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentsListAdapter;", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "getAppointments", "processAppointmentSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "handleFailureCase", "jsonResponse", "responseCode", "", "generateQRCode", "appointmentId", "", "pinCode", "size", "showCancellationConfirmationDialog", "deleteAppointments", "processDeleteAppointmentSuccessResponse", "showCancelledSuccessDialog", "clearSharedViewModelData", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentsListFragment extends Fragment {
    private FragmentAppointmentsListBinding _binding;
    public AppointmentSystemActivity activity;

    /* renamed from: appointmentSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy appointmentSharedViewModel;
    private ArrayList<UserAppointmentResponse.Data> appointmentsList = new ArrayList<>();
    private AppointmentsListAdapter appointmentsListAdapter;

    /* compiled from: AppointmentsListFragment.kt */
    @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[ActionType.values().length];
            try {
                iArr[ActionType.VIEW.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[ActionType.CANCEL.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public AppointmentsListFragment() {
        final AppointmentsListFragment appointmentsListFragment = this;
        final Function0 function0 = null;
        this.appointmentSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(appointmentsListFragment, Reflection.getOrCreateKotlinClass(AppointmentSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = appointmentsListFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = appointmentsListFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = appointmentsListFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    private final AppointmentSharedViewModel getAppointmentSharedViewModel() {
        return (AppointmentSharedViewModel) this.appointmentSharedViewModel.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final FragmentAppointmentsListBinding getBinding() {
        FragmentAppointmentsListBinding fragmentAppointmentsListBinding = this._binding;
        Intrinsics.checkNotNull(fragmentAppointmentsListBinding);
        return fragmentAppointmentsListBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final AppointmentSystemActivity getActivity() {
        AppointmentSystemActivity appointmentSystemActivity = this.activity;
        if (appointmentSystemActivity != null) {
            return appointmentSystemActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(AppointmentSystemActivity appointmentSystemActivity) {
        Intrinsics.checkNotNullParameter(appointmentSystemActivity, "<set-?>");
        this.activity = appointmentSystemActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity");
        setActivity((AppointmentSystemActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentAppointmentsListBinding.inflate(inflater, container, false);
        return getBinding().getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        final FragmentAppointmentsListBinding binding = getBinding();
        binding.appointmentHeaderLayout.textTitle.setText(getString(R.string.appointment));
        binding.appointmentHeaderLayout.textSubtitle.setText(" پیشگی وقت ");
        binding.appointmentHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.textBackUr.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda14
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentsListFragment.onViewCreated$lambda$6$lambda$0(this.f$0, view2);
            }
        });
        binding.appointmentHeaderLayout.iconInfo.setVisibility(0);
        binding.appointmentHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentsListFragment.onViewCreated$lambda$6$lambda$1(this.f$0, view2);
            }
        });
        binding.appointmentListHeadingTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Your Appointments  ", " (آپ کے پیشگی اوقات)", 0, false, 12, null));
        binding.appointmentsListRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.appointmentsListAdapter = new AppointmentsListAdapter(getActivity(), this.appointmentsList, new Function2() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return AppointmentsListFragment.onViewCreated$lambda$6$lambda$2(this.f$0, (ActionType) obj, (UserAppointmentResponse.Data) obj2);
            }
        });
        RecyclerView recyclerView = binding.appointmentsListRecyclerView;
        AppointmentsListAdapter appointmentsListAdapter = this.appointmentsListAdapter;
        if (appointmentsListAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("appointmentsListAdapter");
            appointmentsListAdapter = null;
        }
        recyclerView.setAdapter(appointmentsListAdapter);
        ConfigurableButton configurableButton = binding.addNewAppointmentButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        String string = getString(R.string.book_new_appointment);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util, activity, string, " (پیشگی وقت طے کریں) ", 0, false, 12, null));
        binding.addNewAppointmentButtonLayout.commonButton.setFilled(true);
        binding.addNewAppointmentButtonLayout.commonButton.setInsetTop(0);
        binding.addNewAppointmentButtonLayout.commonButton.setInsetBottom(0);
        binding.addNewAppointmentButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentsListFragment.onViewCreated$lambda$6$lambda$3(this.f$0, view2);
            }
        });
        binding.appointmentsListTryAgainLayout.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentsListFragment.onViewCreated$lambda$6$lambda$4(this.f$0, view2);
            }
        });
        binding.appointmentSwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda5
            @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
            public final void onRefresh() {
                AppointmentsListFragment.onViewCreated$lambda$6$lambda$5(this.f$0, binding);
            }
        });
        getAppointments();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$0(AppointmentsListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$1(AppointmentsListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = this$0.getActivity();
        String string = this$0.getString(pk.gov.nadra.oneapp.commonui.R.string.appointment_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.APPOINTMENT_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$6$lambda$2(AppointmentsListFragment this$0, ActionType actionType, UserAppointmentResponse.Data appointment) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(actionType, "actionType");
        Intrinsics.checkNotNullParameter(appointment, "appointment");
        int i = WhenMappings.$EnumSwitchMapping$0[actionType.ordinal()];
        if (i == 1) {
            generateQRCode$default(this$0, String.valueOf(appointment.getAppointmentId()), String.valueOf(appointment.getPincode()), 0, 4, null);
        } else {
            if (i != 2) {
                throw new NoWhenBranchMatchedException();
            }
            this$0.showCancellationConfirmationDialog(String.valueOf(appointment.getAppointmentId()));
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$3(AppointmentsListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.clearSharedViewModelData();
        this$0.getActivity().navigateToFragment(R.id.appointmentInstructionsFragment);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$4(AppointmentsListFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getAppointments();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$5(AppointmentsListFragment this$0, FragmentAppointmentsListBinding this_apply) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        this$0.getAppointments();
        this_apply.appointmentSwipeRefresh.setRefreshing(false);
    }

    private final void getAppointments() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11041(null), 3, null);
    }

    /* compiled from: AppointmentsListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$getAppointments$1", f = "AppointmentsListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$getAppointments$1, reason: invalid class name and case insensitive filesystem */
    static final class C11041 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C11041(Continuation<? super C11041> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AppointmentsListFragment.this.new C11041(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11041) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(AppointmentsListFragment.this.getActivity());
            final AppointmentsListFragment appointmentsListFragment = AppointmentsListFragment.this;
            aPIRequests.getUserAppointmentsList(new Function3() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$getAppointments$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return AppointmentsListFragment.C11041.invokeSuspend$lambda$0(appointmentsListFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(AppointmentsListFragment appointmentsListFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(appointmentsListFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getAppointments() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                appointmentsListFragment.getBinding().appointmentListHeadingTextView.setVisibility(0);
                appointmentsListFragment.getBinding().appointmentsListRecyclerView.setVisibility(0);
                appointmentsListFragment.getBinding().appointmentsListTryAgainLayout.setVisibility(8);
                appointmentsListFragment.processAppointmentSuccessResponse(jsonObject);
            } else {
                appointmentsListFragment.getBinding().appointmentListHeadingTextView.setVisibility(4);
                appointmentsListFragment.getBinding().appointmentsListRecyclerView.setVisibility(8);
                appointmentsListFragment.getBinding().appointmentsListTryAgainLayout.setVisibility(0);
                appointmentsListFragment.getBinding().appointmentsListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_try_again);
                appointmentsListFragment.getBinding().appointmentsListTryAgainTextView.setText("Something went wrong. Try Again");
                appointmentsListFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processAppointmentSuccessResponse(JsonObject jSonObject) {
        UserAppointmentResponse userAppointmentResponse = (UserAppointmentResponse) new Gson().fromJson(jSonObject.toString(), UserAppointmentResponse.class);
        if (!userAppointmentResponse.getData().isEmpty()) {
            AppointmentsListAdapter appointmentsListAdapter = this.appointmentsListAdapter;
            if (appointmentsListAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("appointmentsListAdapter");
                appointmentsListAdapter = null;
            }
            appointmentsListAdapter.updateUserAppointmentsList(userAppointmentResponse.getData());
            return;
        }
        getBinding().appointmentListHeadingTextView.setVisibility(4);
        getBinding().appointmentsListRecyclerView.setVisibility(8);
        getBinding().appointmentsListTryAgainLayout.setVisibility(0);
        getBinding().appointmentsListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_documents);
        getBinding().appointmentsListTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "No appointments made yet \n", "ابھی تک کوئی پیشگی وقت موجود نہیں", 0, false, 12, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) throws JsonSyntaxException {
        Object element = new Gson().fromJson(jsonResponse.toString(), (Class<Object>) ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            ErrorResponse errorResponse = (ErrorResponse) element;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    ArrayList arrayList = new ArrayList();
                    ArrayList arrayList2 = new ArrayList();
                    for (ErrorResponse.Error error : errors) {
                        arrayList.add(String.valueOf(error.getMessage()));
                        String message_local = error.getMessage_local();
                        if (message_local == null) {
                            message_local = "";
                        }
                        arrayList2.add(message_local);
                    }
                    if (arrayList.isEmpty()) {
                        return;
                    }
                    BottomSheetUtils.showMessageBottomSheet$default(BottomSheetUtils.INSTANCE, (FragmentActivity) getActivity(), "Alert", CollectionsKt.joinToString$default(arrayList, "\n", null, null, 0, null, null, 62, null), false, true, CollectionsKt.joinToString$default(arrayList2, "\n", null, null, 0, null, null, 62, null), (Function1) null, 72, (Object) null);
                    return;
                }
                NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                AppointmentSystemActivity activity = getActivity();
                Intrinsics.checkNotNullExpressionValue(element, "element");
                NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda9
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return AppointmentsListFragment.handleFailureCase$lambda$11$lambda$10(this.f$0);
                    }
                }, 8, null);
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            AppointmentSystemActivity activity2 = getActivity();
            Intrinsics.checkNotNullExpressionValue(element, "element");
            NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return AppointmentsListFragment.handleFailureCase$lambda$12(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        AppointmentSystemActivity activity3 = getActivity();
        Intrinsics.checkNotNullExpressionValue(element, "element");
        NetworkErrorHandler.handleError$default(networkErrorHandler3, activity3, (ErrorResponse) element, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda11
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentsListFragment.handleFailureCase$lambda$13(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$11$lambda$10(AppointmentsListFragment this_run) {
        Intrinsics.checkNotNullParameter(this_run, "$this_run");
        this_run.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$12(AppointmentsListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$13(AppointmentsListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    static /* synthetic */ void generateQRCode$default(AppointmentsListFragment appointmentsListFragment, String str, String str2, int i, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            i = 500;
        }
        appointmentsListFragment.generateQRCode(str, str2, i);
    }

    private final void generateQRCode(String appointmentId, String pinCode, int size) {
        try {
            BitMatrix bitMatrixEncode = new QRCodeWriter().encode(appointmentId + "/" + pinCode, BarcodeFormat.QR_CODE, size, size);
            Intrinsics.checkNotNullExpressionValue(bitMatrixEncode, "encode(...)");
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565);
            Intrinsics.checkNotNullExpressionValue(bitmapCreateBitmap, "createBitmap(...)");
            for (int i = 0; i < size; i++) {
                for (int i2 = 0; i2 < size; i2++) {
                    bitmapCreateBitmap.setPixel(i, i2, bitMatrixEncode.get(i, i2) ? -16777216 : -1);
                }
            }
            BottomSheetUtils.INSTANCE.showMessageBottomSheet((FragmentActivity) getActivity(), bitmapCreateBitmap, true, "", "Appointment Id: " + appointmentId + "\nPin Code: " + pinCode, true, false, (CharSequence) "OK", new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda12
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return Unit.INSTANCE;
                }
            }, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda13
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return Unit.INSTANCE;
                }
            });
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }

    private final void showCancellationConfirmationDialog(final String appointmentId) {
        BottomSheetUtils.INSTANCE.showMessageBottomSheet((FragmentActivity) getActivity(), "Cancel", "Are you sure you want to cancel this appointment?", true, (CharSequence) "Confirm", true, "کیا آپ واقعی پیشگی وقت  کومنسوخ کرنا چاہتے ہیں؟", new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentsListFragment.showCancellationConfirmationDialog$lambda$16(this.f$0, appointmentId);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit showCancellationConfirmationDialog$lambda$16(AppointmentsListFragment this$0, String appointmentId) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(appointmentId, "$appointmentId");
        this$0.deleteAppointments(appointmentId);
        return Unit.INSTANCE;
    }

    private final void deleteAppointments(String appointmentId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(appointmentId, null), 3, null);
    }

    /* compiled from: AppointmentsListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$deleteAppointments$1", f = "AppointmentsListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$deleteAppointments$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $appointmentId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$appointmentId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AppointmentsListFragment.this.new AnonymousClass1(this.$appointmentId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(AppointmentsListFragment.this.getActivity());
            String str = this.$appointmentId;
            final AppointmentsListFragment appointmentsListFragment = AppointmentsListFragment.this;
            aPIRequests.deleteAppointment(str, new Function3() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$deleteAppointments$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return AppointmentsListFragment.AnonymousClass1.invokeSuspend$lambda$0(appointmentsListFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(AppointmentsListFragment appointmentsListFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(appointmentsListFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getAppointments() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                appointmentsListFragment.getBinding().appointmentListHeadingTextView.setVisibility(0);
                appointmentsListFragment.getBinding().appointmentsListRecyclerView.setVisibility(0);
                appointmentsListFragment.getBinding().appointmentsListTryAgainLayout.setVisibility(8);
                appointmentsListFragment.processDeleteAppointmentSuccessResponse(jsonObject);
            } else {
                appointmentsListFragment.getBinding().appointmentListHeadingTextView.setVisibility(4);
                appointmentsListFragment.getBinding().appointmentsListRecyclerView.setVisibility(8);
                appointmentsListFragment.getBinding().appointmentsListTryAgainLayout.setVisibility(0);
                appointmentsListFragment.getBinding().appointmentsListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_try_again);
                appointmentsListFragment.getBinding().appointmentsListTryAgainTextView.setText("Something went wrong. Try Again");
                appointmentsListFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processDeleteAppointmentSuccessResponse(JsonObject jSonObject) {
        showCancelledSuccessDialog();
    }

    private final void showCancelledSuccessDialog() {
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        String string = getString(pk.gov.nadra.oneapp.commonui.R.string.your_appointment_has);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = getString(pk.gov.nadra.oneapp.commonui.R.string.your_appointment_has_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        bottomSheetUtils.showMessageBottomSheet((FragmentActivity) activity, "Cancelled", string, true, (CharSequence) "Done", true, string2, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentsListFragment.showCancelledSuccessDialog$lambda$19(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentsListFragment$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentsListFragment.showCancelledSuccessDialog$lambda$20(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit showCancelledSuccessDialog$lambda$19(AppointmentsListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getAppointments();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit showCancelledSuccessDialog$lambda$20(AppointmentsListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getAppointments();
        return Unit.INSTANCE;
    }

    private final void clearSharedViewModelData() {
        getAppointmentSharedViewModel().setSelectedProvince(new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null));
        getAppointmentSharedViewModel().setSelectedDistrict(new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null));
        getAppointmentSharedViewModel().setSelectedCenterData(new CentersResponse.Data(null, null, null, null, null, 31, null));
        getAppointmentSharedViewModel().setSelectedDate("");
        getAppointmentSharedViewModel().setAvailableSlotsList(new ArrayList<>());
        getAppointmentSharedViewModel().setSelectedSlotData(new AvailableSlots.Data(0, null, false, 7, null));
        getAppointmentSharedViewModel().setSlotHoldResponse(new SlotHoldResponse.Data(null, null, 0, null, null, null, null, 0, 255, null));
        getAppointmentSharedViewModel().setBookAppointmentResponse(new BookAppointmentResponse.Data(null, null, null, null, null, null, 0, null, null, null, null, null, null, null, null, null, null, 0, 262143, null));
        getAppointmentSharedViewModel().setName("");
        getAppointmentSharedViewModel().setCitizenNumber("");
        getAppointmentSharedViewModel().setMobileNumber("");
    }
}