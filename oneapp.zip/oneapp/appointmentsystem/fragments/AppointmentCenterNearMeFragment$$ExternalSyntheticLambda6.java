package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentCenterNearMeFragment$$ExternalSyntheticLambda6 implements Function0 {
    public /* synthetic */ AppointmentCenterNearMeFragment$$ExternalSyntheticLambda6() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return AppointmentCenterNearMeFragment.initializeLocation$lambda$7(this.f$0);
    }
}