package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentLocationsFragment$$ExternalSyntheticLambda11 implements View.OnClickListener {
    public /* synthetic */ AppointmentLocationsFragment$$ExternalSyntheticLambda11() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AppointmentLocationsFragment.onViewCreated$lambda$6$lambda$2(this.f$0, view);
    }
}