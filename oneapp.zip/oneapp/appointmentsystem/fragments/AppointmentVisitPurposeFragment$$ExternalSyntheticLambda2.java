package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentVisitPurposeFragment$$ExternalSyntheticLambda2 implements View.OnClickListener {
    public /* synthetic */ AppointmentVisitPurposeFragment$$ExternalSyntheticLambda2() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AppointmentVisitPurposeFragment.attachLayoutViews$lambda$7$lambda$1(this.f$0, view);
    }
}