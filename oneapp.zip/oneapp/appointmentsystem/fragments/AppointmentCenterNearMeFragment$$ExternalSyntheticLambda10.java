package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import androidx.activity.result.ActivityResultCallback;
import java.util.Map;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentCenterNearMeFragment$$ExternalSyntheticLambda10 implements ActivityResultCallback {
    public /* synthetic */ AppointmentCenterNearMeFragment$$ExternalSyntheticLambda10() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        AppointmentCenterNearMeFragment.setupLocationOrGpsPermissionLaunchers$lambda$3(this.f$0, (Map) obj);
    }
}