package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda0 implements Function0 {
    public /* synthetic */ AppointmentApplicantDetailsFragment$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return AppointmentApplicantDetailsFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
    }
}