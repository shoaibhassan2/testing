package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentAppointmentsListBinding;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentsListFragment$$ExternalSyntheticLambda5 implements SwipeRefreshLayout.OnRefreshListener {
    public final /* synthetic */ FragmentAppointmentsListBinding f$1;

    public /* synthetic */ AppointmentsListFragment$$ExternalSyntheticLambda5(FragmentAppointmentsListBinding fragmentAppointmentsListBinding) {
        binding = fragmentAppointmentsListBinding;
    }

    @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
    public final void onRefresh() {
        AppointmentsListFragment.onViewCreated$lambda$6$lambda$5(this.f$0, binding);
    }
}