package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.farrakhj.stringpickerlibrary.views.StringPickerActivity;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import org.apache.commons.imaging.formats.jpeg.iptc.IptcConstants;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.AppointmentLocationsAdapter;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentAppointmentLocationsBinding;
import pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment;
import pk.gov.nadra.oneapp.appointmentsystem.viewmodel.AppointmentSharedViewModel;
import pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.LocationHelper;
import pk.gov.nadra.oneapp.commonutils.utils.MethodName;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.appointment.CentersRequest;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;
import pk.gov.nadra.oneapp.models.appointment.ProvinceDistrictRequest;
import pk.gov.nadra.oneapp.models.appointment.ProvinceDistrictResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.library.LibraryResponse;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: AppointmentLocationsFragment.kt */
@Metadata(d1 = {"\u0000¼\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u00101\u001a\u0002022\b\u00103\u001a\u0004\u0018\u000104H\u0016J\u0010\u00105\u001a\u0002022\u0006\u00106\u001a\u000207H\u0016J&\u00108\u001a\u0004\u0018\u0001092\u0006\u0010:\u001a\u00020;2\b\u0010<\u001a\u0004\u0018\u00010=2\b\u00103\u001a\u0004\u0018\u000104H\u0016J\u001a\u0010>\u001a\u0002022\u0006\u0010?\u001a\u0002092\b\u00103\u001a\u0004\u0018\u000104H\u0016J\b\u0010@\u001a\u000202H\u0002J\b\u0010A\u001a\u000202H\u0002J\u0010\u0010B\u001a\u0002022\u0006\u0010C\u001a\u00020&H\u0002J\u0010\u0010D\u001a\u0002022\u0006\u0010E\u001a\u00020FH\u0002J\u0018\u0010G\u001a\u0002022\u0006\u0010H\u001a\u00020F2\u0006\u0010I\u001a\u00020JH\u0002J%\u0010K\u001a\u0002022\u0016\u0010L\u001a\u0012\u0012\u0004\u0012\u00020&0\u0018j\b\u0012\u0004\u0012\u00020&`\u001eH\u0002¢\u0006\u0002\u0010MJ\b\u0010P\u001a\u00020QH\u0002J\u0010\u0010R\u001a\u0002022\u0006\u0010S\u001a\u00020TH\u0002J\u0010\u0010U\u001a\u0002022\u0006\u0010E\u001a\u00020VH\u0002J\b\u0010W\u001a\u000202H\u0002J\u0010\u0010X\u001a\u0002022\u0006\u0010E\u001a\u00020VH\u0002J\u0018\u0010Y\u001a\u0002022\u0006\u0010H\u001a\u00020V2\u0006\u0010I\u001a\u00020JH\u0002J\b\u0010Z\u001a\u000202H\u0002J\b\u0010[\u001a\u000202H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00190\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00190\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\u001d\u001a\u0012\u0012\u0004\u0012\u00020\u001f0\u0018j\b\u0012\u0004\u0012\u00020\u001f`\u001eX\u0082\u000e¢\u0006\u0004\n\u0002\u0010 R\u000e\u0010!\u001a\u00020\"X\u0082.¢\u0006\u0002\n\u0000R\u001a\u0010#\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020&0%0$X\u0082.¢\u0006\u0002\n\u0000R\u0014\u0010'\u001a\b\u0012\u0004\u0012\u00020(0$X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020*X\u0082.¢\u0006\u0002\n\u0000R'\u0010+\u001a\u000e\u0012\u0004\u0012\u00020&\u0012\u0004\u0012\u00020-0,8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b0\u0010\t\u001a\u0004\b.\u0010/R\u001c\u0010N\u001a\u0010\u0012\f\u0012\n O*\u0004\u0018\u00010(0(0$X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\\"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/fragments/AppointmentLocationsFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "appointmentSharedViewModel", "Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "getAppointmentSharedViewModel", "()Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "appointmentSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentLocationsBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentLocationsBinding;", "activity", "Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;)V", "dropdownCalling", "Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;", "provincesList", "Ljava/util/ArrayList;", "Lpk/gov/nadra/oneapp/models/crc/library/LibraryResponse;", "districtsList", "selectedProvince", "selectedDistrict", "centersList", "Lkotlin/collections/ArrayList;", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data;", "Ljava/util/ArrayList;", "locationHelper", "Lpk/gov/nadra/oneapp/commonutils/utils/LocationHelper;", "permissionLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "", "", "gpsLauncher", "Landroid/content/Intent;", "locationsListAdapter", "Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentLocationsAdapter;", "fieldToViewMap", "", "Lcom/google/android/material/textfield/TextInputLayout;", "getFieldToViewMap", "()Ljava/util/Map;", "fieldToViewMap$delegate", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onAttach", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "onViewCreated", Promotion.ACTION_VIEW, "initViewData", "getProvincesList", "getDistrictsList", "provinceId", "processLibrarySuccessResponse", "jSonObject", "Lcom/google/gson/JsonArray;", "handleFailureCaseJsonArray", "jsonResponse", "responseCode", "", "launchStringPickerActivity", "arrayList", "(Ljava/util/ArrayList;)V", "startForResult", "kotlin.jvm.PlatformType", "getCentersRequest", "Lpk/gov/nadra/oneapp/models/appointment/CentersRequest;", "getCentersListFromDistrictName", "districtName", "Lpk/gov/nadra/oneapp/models/appointment/ProvinceDistrictRequest;", "processProvinceDistrictSuccessResponse", "Lcom/google/gson/JsonObject;", "getCentersList", "processCentersSuccessResponse", "handleFailureCase", "setupLocationOrGpsPermissionLaunchers", "initializeLocation", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentLocationsFragment extends Fragment {
    private FragmentAppointmentLocationsBinding _binding;
    public AppointmentSystemActivity activity;

    /* renamed from: appointmentSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy appointmentSharedViewModel;
    private ActivityResultLauncher<Intent> gpsLauncher;
    private LocationHelper locationHelper;
    private AppointmentLocationsAdapter locationsListAdapter;
    private ActivityResultLauncher<String[]> permissionLauncher;
    private final ActivityResultLauncher<Intent> startForResult;
    private MethodName dropdownCalling = MethodName.PROVINCE;
    private ArrayList<LibraryResponse> provincesList = new ArrayList<>();
    private ArrayList<LibraryResponse> districtsList = new ArrayList<>();
    private LibraryResponse selectedProvince = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private ArrayList<CentersResponse.Data> centersList = new ArrayList<>();

    /* renamed from: fieldToViewMap$delegate, reason: from kotlin metadata */
    private final Lazy fieldToViewMap = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return AppointmentLocationsFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
        }
    });

    /* compiled from: AppointmentLocationsFragment.kt */
    @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[MethodName.values().length];
            try {
                iArr[MethodName.PROVINCE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[MethodName.DISTRICT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public AppointmentLocationsFragment() {
        final AppointmentLocationsFragment appointmentLocationsFragment = this;
        final Function0 function0 = null;
        this.appointmentSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(appointmentLocationsFragment, Reflection.getOrCreateKotlinClass(AppointmentSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = appointmentLocationsFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = appointmentLocationsFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = appointmentLocationsFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda6
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                AppointmentLocationsFragment.startForResult$lambda$17(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.startForResult = activityResultLauncherRegisterForActivityResult;
    }

    private final AppointmentSharedViewModel getAppointmentSharedViewModel() {
        return (AppointmentSharedViewModel) this.appointmentSharedViewModel.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final FragmentAppointmentLocationsBinding getBinding() {
        FragmentAppointmentLocationsBinding fragmentAppointmentLocationsBinding = this._binding;
        Intrinsics.checkNotNull(fragmentAppointmentLocationsBinding);
        return fragmentAppointmentLocationsBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final AppointmentSystemActivity getActivity() {
        AppointmentSystemActivity appointmentSystemActivity = this.activity;
        if (appointmentSystemActivity != null) {
            return appointmentSystemActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(AppointmentSystemActivity appointmentSystemActivity) {
        Intrinsics.checkNotNullParameter(appointmentSystemActivity, "<set-?>");
        this.activity = appointmentSystemActivity;
    }

    private final Map<String, TextInputLayout> getFieldToViewMap() {
        return (Map) this.fieldToViewMap.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Map fieldToViewMap_delegate$lambda$0(AppointmentLocationsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        return MapsKt.mapOf(TuplesKt.to("province", this$0.getBinding().appointmentProvinceLayout.textInputLayout), TuplesKt.to("district", this$0.getBinding().appointmentDistrictLayout.textInputLayout));
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupLocationOrGpsPermissionLaunchers();
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity");
        setActivity((AppointmentSystemActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentAppointmentLocationsBinding.inflate(inflater, container, false);
        return getBinding().getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        if (getAppointmentSharedViewModel().getSelectedDistrict().getKey().length() == 0) {
            initializeLocation();
        }
        FragmentAppointmentLocationsBinding binding = getBinding();
        binding.appointmentHeaderLayout.textTitle.setText(getString(R.string.appointment));
        binding.appointmentHeaderLayout.textSubtitle.setText(" پیشگی وقت ");
        binding.appointmentHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.textBackUr.setTypeface(ResourcesCompat.getFont(getActivity(), R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentLocationsFragment.onViewCreated$lambda$6$lambda$1(this.f$0, view2);
            }
        });
        binding.appointmentHeaderLayout.iconInfo.setVisibility(0);
        binding.appointmentHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentLocationsFragment.onViewCreated$lambda$6$lambda$2(this.f$0, view2);
            }
        });
        TextView textView = binding.appointmentLocationHeadingTextView;
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        String string = getString(pk.gov.nadra.oneapp.appointmentsystem.R.string.select_your_location);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util, activity, string, "  (اپنا علاقہ منتخب کریں) ", 0, false, 12, null));
        TextInputLayout textInputLayout = binding.appointmentProvinceLayout.textInputLayout;
        Util util2 = Util.INSTANCE;
        AppointmentSystemActivity activity2 = getActivity();
        String string2 = getString(R.string.select_province);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textInputLayout.setHint(Util.setEnglishTextSpan$default(util2, activity2, string2, " (صوبہ/علاقہ) ", 0, false, 12, null));
        binding.appointmentProvinceLayout.autoCompleteTextView.setClickable(true);
        binding.appointmentProvinceLayout.autoCompleteTextView.setFocusable(false);
        binding.appointmentProvinceLayout.autoCompleteTextView.setFocusableInTouchMode(false);
        binding.appointmentProvinceLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentLocationsFragment.onViewCreated$lambda$6$lambda$3(this.f$0, view2);
            }
        });
        Util util3 = Util.INSTANCE;
        AppointmentSystemActivity activity3 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView = binding.appointmentProvinceLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView, "autoCompleteTextView");
        TextInputLayout textInputLayout2 = binding.appointmentProvinceLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout2, "textInputLayout");
        util3.removeErrorOnAutoCompleteTextChanged(activity3, autoCompleteTextView, textInputLayout2);
        TextInputLayout textInputLayout3 = binding.appointmentDistrictLayout.textInputLayout;
        Util util4 = Util.INSTANCE;
        AppointmentSystemActivity activity4 = getActivity();
        String string3 = getString(R.string.select_district);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        textInputLayout3.setHint(Util.setEnglishTextSpan$default(util4, activity4, string3, " (ضلع) ", 0, false, 12, null));
        binding.appointmentDistrictLayout.autoCompleteTextView.setClickable(true);
        binding.appointmentDistrictLayout.autoCompleteTextView.setFocusable(false);
        binding.appointmentDistrictLayout.autoCompleteTextView.setFocusableInTouchMode(false);
        binding.appointmentDistrictLayout.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentLocationsFragment.onViewCreated$lambda$6$lambda$4(this.f$0, view2);
            }
        });
        Util util5 = Util.INSTANCE;
        AppointmentSystemActivity activity5 = getActivity();
        MaterialAutoCompleteTextView autoCompleteTextView2 = binding.appointmentDistrictLayout.autoCompleteTextView;
        Intrinsics.checkNotNullExpressionValue(autoCompleteTextView2, "autoCompleteTextView");
        TextInputLayout textInputLayout4 = binding.appointmentDistrictLayout.textInputLayout;
        Intrinsics.checkNotNullExpressionValue(textInputLayout4, "textInputLayout");
        util5.removeErrorOnAutoCompleteTextChanged(activity5, autoCompleteTextView2, textInputLayout4);
        getBinding().appointmentLocationsRecyclerView.setVisibility(8);
        getBinding().centerListTryAgainLayout.setVisibility(0);
        getBinding().frcListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_documents);
        getBinding().frcListTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "No province selected yet!\n", " ابھی کوئی صوبہ منتخب نہیں کیا گیا۔ ", 0, false, 12, null));
        binding.appointmentLocationsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.locationsListAdapter = new AppointmentLocationsAdapter(this.centersList, new Function1() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return AppointmentLocationsFragment.onViewCreated$lambda$6$lambda$5(this.f$0, (CentersResponse.Data) obj);
            }
        });
        RecyclerView recyclerView = binding.appointmentLocationsRecyclerView;
        AppointmentLocationsAdapter appointmentLocationsAdapter = this.locationsListAdapter;
        if (appointmentLocationsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("locationsListAdapter");
            appointmentLocationsAdapter = null;
        }
        recyclerView.setAdapter(appointmentLocationsAdapter);
        initViewData();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$1(AppointmentLocationsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$2(AppointmentLocationsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = this$0.getActivity();
        String string = this$0.getString(R.string.appointment_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.APPOINTMENT_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$3(AppointmentLocationsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.PROVINCE;
        this$0.getProvincesList();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$6$lambda$4(AppointmentLocationsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.DISTRICT;
        this$0.getDistrictsList(this$0.selectedProvince.getKey());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$6$lambda$5(AppointmentLocationsFragment this$0, CentersResponse.Data location) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(location, "location");
        this$0.getAppointmentSharedViewModel().setSelectedCenterData(location);
        this$0.getAppointmentSharedViewModel().setSelectedProvince(this$0.selectedProvince);
        this$0.getAppointmentSharedViewModel().setSelectedDistrict(this$0.selectedDistrict);
        this$0.getActivity().navigateToFragment(pk.gov.nadra.oneapp.appointmentsystem.R.id.appointmentVisitPurposeFragment);
        return Unit.INSTANCE;
    }

    private final void initViewData() {
        if (getAppointmentSharedViewModel().getSelectedProvince().getKey().length() > 0) {
            this.selectedProvince = getAppointmentSharedViewModel().getSelectedProvince();
            getBinding().appointmentProvinceLayout.autoCompleteTextView.setText(this.selectedProvince.getValue());
            getBinding().appointmentDistrictLayout.autoCompleteTextView.setText("");
            this.selectedDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
            getBinding().appointmentDistrictLayout.getRoot().setVisibility(0);
            getBinding().appointmentLocationsRecyclerView.setVisibility(8);
            getBinding().centerListTryAgainLayout.setVisibility(0);
            getBinding().frcListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_documents);
            getBinding().frcListTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "\"No district selected yet!\"\n", "  ابھی کوئی ضلع منتخب نہیں کیا گیا۔ ", 0, false, 12, null));
        }
        if (getAppointmentSharedViewModel().getSelectedDistrict().getKey().length() > 0) {
            this.selectedDistrict = getAppointmentSharedViewModel().getSelectedDistrict();
            getBinding().appointmentDistrictLayout.autoCompleteTextView.setText(this.selectedDistrict.getValue());
            getCentersList();
        }
    }

    private final void getProvincesList() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11031(null), 3, null);
    }

    /* compiled from: AppointmentLocationsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getProvincesList$1", f = "AppointmentLocationsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getProvincesList$1, reason: invalid class name and case insensitive filesystem */
    static final class C11031 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C11031(Continuation<? super C11031> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AppointmentLocationsFragment.this.new C11031(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11031) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(AppointmentLocationsFragment.this.getActivity());
            final AppointmentLocationsFragment appointmentLocationsFragment = AppointmentLocationsFragment.this;
            aPIRequests.getProvincesList(new Function3() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getProvincesList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return AppointmentLocationsFragment.C11031.invokeSuspend$lambda$0(appointmentLocationsFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(AppointmentLocationsFragment appointmentLocationsFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(appointmentLocationsFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getProvincesList() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                appointmentLocationsFragment.processLibrarySuccessResponse(jsonArray);
            } else {
                appointmentLocationsFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getDistrictsList(String provinceId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11021(provinceId, null), 3, null);
    }

    /* compiled from: AppointmentLocationsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getDistrictsList$1", f = "AppointmentLocationsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getDistrictsList$1, reason: invalid class name and case insensitive filesystem */
    static final class C11021 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $provinceId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C11021(String str, Continuation<? super C11021> continuation) {
            super(2, continuation);
            this.$provinceId = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AppointmentLocationsFragment.this.new C11021(this.$provinceId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11021) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(AppointmentLocationsFragment.this.getActivity());
            String str = this.$provinceId;
            final AppointmentLocationsFragment appointmentLocationsFragment = AppointmentLocationsFragment.this;
            aPIRequests.getDistrictsList(str, new Function3() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getDistrictsList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return AppointmentLocationsFragment.C11021.invokeSuspend$lambda$0(appointmentLocationsFragment, (JsonArray) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(AppointmentLocationsFragment appointmentLocationsFragment, JsonArray jsonArray, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(appointmentLocationsFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getDistrictsList() Response: " + jsonArray));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                appointmentLocationsFragment.processLibrarySuccessResponse(jsonArray);
            } else {
                appointmentLocationsFragment.handleFailureCaseJsonArray(jsonArray, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processLibrarySuccessResponse(JsonArray jSonObject) throws JsonSyntaxException {
        Object objFromJson = new Gson().fromJson(jSonObject.toString(), (Class<Object>) LibraryResponse[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List mutableList = ArraysKt.toMutableList((Object[]) objFromJson);
        ArrayList arrayList = new ArrayList<>();
        int i = WhenMappings.$EnumSwitchMapping$0[this.dropdownCalling.ordinal()];
        if (i == 1) {
            this.provincesList = new ArrayList<>();
            Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
            ArrayList<LibraryResponse> arrayList2 = (ArrayList) mutableList;
            this.provincesList = arrayList2;
            ArrayList<LibraryResponse> arrayList3 = arrayList2;
            ArrayList arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList3, 10));
            Iterator<T> it = arrayList3.iterator();
            while (it.hasNext()) {
                arrayList4.add(((LibraryResponse) it.next()).getValue());
            }
            arrayList = arrayList4;
        } else if (i == 2) {
            this.districtsList = new ArrayList<>();
            Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.models.crc.library.LibraryResponse>");
            ArrayList<LibraryResponse> arrayList5 = (ArrayList) mutableList;
            this.districtsList = arrayList5;
            ArrayList<LibraryResponse> arrayList6 = arrayList5;
            ArrayList arrayList7 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList6, 10));
            Iterator<T> it2 = arrayList6.iterator();
            while (it2.hasNext()) {
                arrayList7.add(((LibraryResponse) it2.next()).getValue());
            }
            arrayList = arrayList7;
        }
        if (arrayList.isEmpty()) {
            return;
        }
        launchStringPickerActivity(arrayList);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCaseJsonArray(JsonArray jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson((JsonElement) jsonResponse.get(0).getAsJsonObject(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    for (ErrorResponse.Error error : errors) {
                        TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                        if (textInputLayout != null) {
                            textInputLayout.setError(String.valueOf(error.getMessage()));
                            textInputLayout.setErrorEnabled(true);
                        }
                    }
                    return;
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            AppointmentSystemActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return AppointmentLocationsFragment.handleFailureCaseJsonArray$lambda$13(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        AppointmentSystemActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentLocationsFragment.handleFailureCaseJsonArray$lambda$14(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$13(AppointmentLocationsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCaseJsonArray$lambda$14(AppointmentLocationsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final void launchStringPickerActivity(ArrayList<String> arrayList) {
        Intent intent = new Intent(getActivity(), (Class<?>) StringPickerActivity.class);
        intent.putStringArrayListExtra("INTENT_STRING_LIST", arrayList);
        this.startForResult.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startForResult$lambda$17(AppointmentLocationsFragment this$0, ActivityResult result) {
        Intent data;
        String stringExtra;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || (data = result.getData()) == null || !data.hasExtra("INTENT_STRING_ITEM") || (stringExtra = data.getStringExtra("INTENT_STRING_ITEM")) == null) {
            return;
        }
        int i = WhenMappings.$EnumSwitchMapping$0[this$0.dropdownCalling.ordinal()];
        Object obj = null;
        if (i != 1) {
            if (i != 2) {
                return;
            }
            Iterator<T> it = this$0.districtsList.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (Intrinsics.areEqual(((LibraryResponse) next).getValue(), stringExtra)) {
                    obj = next;
                    break;
                }
            }
            Intrinsics.checkNotNull(obj);
            this$0.selectedDistrict = (LibraryResponse) obj;
            this$0.getBinding().appointmentDistrictLayout.autoCompleteTextView.setText(stringExtra);
            this$0.getCentersList();
            return;
        }
        Iterator<T> it2 = this$0.provincesList.iterator();
        while (true) {
            if (!it2.hasNext()) {
                break;
            }
            Object next2 = it2.next();
            if (Intrinsics.areEqual(((LibraryResponse) next2).getValue(), stringExtra)) {
                obj = next2;
                break;
            }
        }
        Intrinsics.checkNotNull(obj);
        this$0.selectedProvince = (LibraryResponse) obj;
        this$0.getBinding().appointmentProvinceLayout.autoCompleteTextView.setText(stringExtra);
        this$0.getBinding().appointmentDistrictLayout.autoCompleteTextView.setText("");
        this$0.selectedDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
        this$0.getBinding().appointmentDistrictLayout.getRoot().setVisibility(0);
        this$0.getBinding().appointmentLocationsRecyclerView.setVisibility(8);
        this$0.getBinding().centerListTryAgainLayout.setVisibility(0);
        this$0.getBinding().frcListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_documents);
        this$0.getBinding().frcListTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, this$0.getActivity(), "No district selected yet!\n", "  ابھی کوئی ضلع منتخب نہیں کیا گیا۔ ", 0, false, 12, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final CentersRequest getCentersRequest() {
        CentersRequest centersRequest = new CentersRequest(null, null, 3, null);
        centersRequest.setDistrictId(this.selectedDistrict.getKey());
        return centersRequest;
    }

    /* compiled from: AppointmentLocationsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getCentersListFromDistrictName$1", f = "AppointmentLocationsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getCentersListFromDistrictName$1, reason: invalid class name and case insensitive filesystem */
    static final class C11011 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ ProvinceDistrictRequest $districtName;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C11011(ProvinceDistrictRequest provinceDistrictRequest, Continuation<? super C11011> continuation) {
            super(2, continuation);
            this.$districtName = provinceDistrictRequest;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AppointmentLocationsFragment.this.new C11011(this.$districtName, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11011) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(AppointmentLocationsFragment.this.getActivity());
            ProvinceDistrictRequest provinceDistrictRequest = this.$districtName;
            final AppointmentLocationsFragment appointmentLocationsFragment = AppointmentLocationsFragment.this;
            aPIRequests.getProvinceDistrictFromDistrictName(provinceDistrictRequest, new Function3() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getCentersListFromDistrictName$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return AppointmentLocationsFragment.C11011.invokeSuspend$lambda$0(appointmentLocationsFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(AppointmentLocationsFragment appointmentLocationsFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(appointmentLocationsFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getDistrictsList() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                appointmentLocationsFragment.getBinding().appointmentLocationsRecyclerView.setVisibility(0);
                appointmentLocationsFragment.getBinding().centerListTryAgainLayout.setVisibility(8);
                appointmentLocationsFragment.processProvinceDistrictSuccessResponse(jsonObject);
            } else {
                appointmentLocationsFragment.getBinding().appointmentLocationsRecyclerView.setVisibility(8);
                appointmentLocationsFragment.getBinding().centerListTryAgainLayout.setVisibility(0);
                appointmentLocationsFragment.getBinding().frcListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_try_again);
                appointmentLocationsFragment.getBinding().frcListTryAgainTextView.setText("Something went wrong. Try Again");
                appointmentLocationsFragment.getBinding().appointmentDistrictLayout.autoCompleteTextView.setText("");
                appointmentLocationsFragment.selectedDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
                appointmentLocationsFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void getCentersListFromDistrictName(ProvinceDistrictRequest districtName) {
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11011(districtName, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processProvinceDistrictSuccessResponse(JsonObject jSonObject) {
        String id;
        String name;
        ProvinceDistrictResponse.Data.District district;
        String name2;
        ProvinceDistrictResponse.Data.District district2;
        ProvinceDistrictResponse.Data.District district3;
        String id2;
        String name3;
        String name4;
        ProvinceDistrictResponse.Data.Province province;
        ProvinceDistrictResponse.Data.Province province2;
        ProvinceDistrictResponse.Data.Province province3;
        ProvinceDistrictResponse provinceDistrictResponse = (ProvinceDistrictResponse) new Gson().fromJson(jSonObject.toString(), ProvinceDistrictResponse.class);
        if (provinceDistrictResponse.getData() != null) {
            ProvinceDistrictResponse.Data data = provinceDistrictResponse.getData();
            String str = "";
            if ((data != null ? data.getProvince() : null) != null) {
                LibraryResponse libraryResponse = this.selectedProvince;
                ProvinceDistrictResponse.Data data2 = provinceDistrictResponse.getData();
                if (data2 == null || (province3 = data2.getProvince()) == null || (id2 = province3.getId()) == null) {
                    id2 = "";
                }
                libraryResponse.setKey(id2);
                ProvinceDistrictResponse.Data data3 = provinceDistrictResponse.getData();
                if (data3 == null || (province2 = data3.getProvince()) == null || (name3 = province2.getName()) == null) {
                    name3 = "";
                }
                libraryResponse.setValue(name3);
                MaterialAutoCompleteTextView materialAutoCompleteTextView = getBinding().appointmentProvinceLayout.autoCompleteTextView;
                ProvinceDistrictResponse.Data data4 = provinceDistrictResponse.getData();
                if (data4 == null || (province = data4.getProvince()) == null || (name4 = province.getName()) == null) {
                    name4 = "";
                }
                materialAutoCompleteTextView.setText(name4);
            }
            ProvinceDistrictResponse.Data data5 = provinceDistrictResponse.getData();
            if ((data5 != null ? data5.getDistrict() : null) != null) {
                LibraryResponse libraryResponse2 = this.selectedDistrict;
                ProvinceDistrictResponse.Data data6 = provinceDistrictResponse.getData();
                if (data6 == null || (district3 = data6.getDistrict()) == null || (id = district3.getId()) == null) {
                    id = "";
                }
                libraryResponse2.setKey(id);
                ProvinceDistrictResponse.Data data7 = provinceDistrictResponse.getData();
                if (data7 == null || (district2 = data7.getDistrict()) == null || (name = district2.getName()) == null) {
                    name = "";
                }
                libraryResponse2.setValue(name);
                getBinding().appointmentDistrictLayout.getRoot().setVisibility(0);
                MaterialAutoCompleteTextView materialAutoCompleteTextView2 = getBinding().appointmentDistrictLayout.autoCompleteTextView;
                ProvinceDistrictResponse.Data data8 = provinceDistrictResponse.getData();
                if (data8 != null && (district = data8.getDistrict()) != null && (name2 = district.getName()) != null) {
                    str = name2;
                }
                materialAutoCompleteTextView2.setText(str);
            }
            getCentersList();
        }
    }

    private final void getCentersList() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(null), 3, null);
    }

    /* compiled from: AppointmentLocationsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getCentersList$1", f = "AppointmentLocationsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getCentersList$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AppointmentLocationsFragment.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(AppointmentLocationsFragment.this.getActivity());
            CentersRequest centersRequest = AppointmentLocationsFragment.this.getCentersRequest();
            final AppointmentLocationsFragment appointmentLocationsFragment = AppointmentLocationsFragment.this;
            aPIRequests.getCentersList(centersRequest, new Function3() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$getCentersList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return AppointmentLocationsFragment.AnonymousClass1.invokeSuspend$lambda$0(appointmentLocationsFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(AppointmentLocationsFragment appointmentLocationsFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(appointmentLocationsFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getDistrictsList() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                appointmentLocationsFragment.getBinding().appointmentLocationsRecyclerView.setVisibility(0);
                appointmentLocationsFragment.getBinding().centerListTryAgainLayout.setVisibility(8);
                appointmentLocationsFragment.processCentersSuccessResponse(jsonObject);
            } else {
                appointmentLocationsFragment.getBinding().appointmentLocationsRecyclerView.setVisibility(8);
                appointmentLocationsFragment.getBinding().centerListTryAgainLayout.setVisibility(0);
                appointmentLocationsFragment.getBinding().frcListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_try_again);
                appointmentLocationsFragment.getBinding().frcListTryAgainTextView.setText("Something went wrong. Try Again");
                appointmentLocationsFragment.getBinding().appointmentDistrictLayout.autoCompleteTextView.setText("");
                appointmentLocationsFragment.selectedDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
                appointmentLocationsFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processCentersSuccessResponse(JsonObject jSonObject) {
        CentersResponse centersResponse = (CentersResponse) new Gson().fromJson(jSonObject.toString(), CentersResponse.class);
        if (!centersResponse.getData().isEmpty()) {
            AppointmentLocationsAdapter appointmentLocationsAdapter = this.locationsListAdapter;
            if (appointmentLocationsAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("locationsListAdapter");
                appointmentLocationsAdapter = null;
            }
            appointmentLocationsAdapter.updateLocationList(centersResponse.getData());
            return;
        }
        getBinding().appointmentLocationsRecyclerView.setVisibility(8);
        getBinding().centerListTryAgainLayout.setVisibility(0);
        getBinding().frcListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_documents);
        getBinding().frcListTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Currently no appointments are available at the selected location.\n", " اس مقام پر فی الحال کوئی پیشگی وقت  دستیاب نہیں ہیں۔ ", 0, false, 12, null));
        this.selectedDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) throws JsonSyntaxException {
        Object element = new Gson().fromJson(jsonResponse.toString(), (Class<Object>) ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            ErrorResponse errorResponse = (ErrorResponse) element;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    ArrayList arrayList = new ArrayList();
                    ArrayList arrayList2 = new ArrayList();
                    for (ErrorResponse.Error error : errors) {
                        TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                        if (textInputLayout != null) {
                            textInputLayout.setError(String.valueOf(error.getMessage()));
                            textInputLayout.setErrorEnabled(true);
                        } else {
                            arrayList.add(String.valueOf(error.getMessage()));
                            String message_local = error.getMessage_local();
                            if (message_local == null) {
                                message_local = "";
                            }
                            arrayList2.add(message_local);
                        }
                    }
                    if (arrayList.isEmpty()) {
                        return;
                    }
                    BottomSheetUtils.showMessageBottomSheet$default(BottomSheetUtils.INSTANCE, (FragmentActivity) getActivity(), "Alert", CollectionsKt.joinToString$default(arrayList, "\n", null, null, 0, null, null, 62, null), false, true, CollectionsKt.joinToString$default(arrayList2, "\n", null, null, 0, null, null, 62, null), (Function1) null, 72, (Object) null);
                    return;
                }
                NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                AppointmentSystemActivity activity = getActivity();
                Intrinsics.checkNotNullExpressionValue(element, "element");
                NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return AppointmentLocationsFragment.handleFailureCase$lambda$28$lambda$27(this.f$0);
                    }
                }, 8, null);
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            AppointmentSystemActivity activity2 = getActivity();
            Intrinsics.checkNotNullExpressionValue(element, "element");
            NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return AppointmentLocationsFragment.handleFailureCase$lambda$29(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        AppointmentSystemActivity activity3 = getActivity();
        Intrinsics.checkNotNullExpressionValue(element, "element");
        NetworkErrorHandler.handleError$default(networkErrorHandler3, activity3, (ErrorResponse) element, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentLocationsFragment.handleFailureCase$lambda$30(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$28$lambda$27(AppointmentLocationsFragment this_run) {
        Intrinsics.checkNotNullParameter(this_run, "$this_run");
        this_run.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$29(AppointmentLocationsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$30(AppointmentLocationsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    private final void setupLocationOrGpsPermissionLaunchers() {
        this.permissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda9
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                AppointmentLocationsFragment.setupLocationOrGpsPermissionLaunchers$lambda$31(this.f$0, (Map) obj);
            }
        });
        this.gpsLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda10
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                AppointmentLocationsFragment.setupLocationOrGpsPermissionLaunchers$lambda$32(this.f$0, (ActivityResult) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setupLocationOrGpsPermissionLaunchers$lambda$31(AppointmentLocationsFragment this$0, Map permissions) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(permissions, "permissions");
        LocationHelper locationHelper = this$0.locationHelper;
        if (locationHelper == null) {
            Intrinsics.throwUninitializedPropertyAccessException("locationHelper");
            locationHelper = null;
        }
        locationHelper.handlePermissionsResult(permissions);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setupLocationOrGpsPermissionLaunchers$lambda$32(AppointmentLocationsFragment this$0, ActivityResult it) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(it, "it");
        LocationHelper locationHelper = this$0.locationHelper;
        if (locationHelper == null) {
            Intrinsics.throwUninitializedPropertyAccessException("locationHelper");
            locationHelper = null;
        }
        locationHelper.onGpsActivityResult();
    }

    private final void initializeLocation() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        AppointmentSystemActivity activity = getActivity();
        AppointmentLocationsFragment appointmentLocationsFragment = this;
        ActivityResultLauncher<String[]> activityResultLauncher = this.permissionLauncher;
        LocationHelper locationHelper = null;
        if (activityResultLauncher == null) {
            Intrinsics.throwUninitializedPropertyAccessException("permissionLauncher");
            activityResultLauncher = null;
        }
        ActivityResultLauncher<Intent> activityResultLauncher2 = this.gpsLauncher;
        if (activityResultLauncher2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("gpsLauncher");
            activityResultLauncher2 = null;
        }
        LocationHelper locationHelper2 = new LocationHelper(activity, appointmentLocationsFragment, activityResultLauncher, activityResultLauncher2);
        this.locationHelper = locationHelper2;
        locationHelper2.setup(new Function1() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda15
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return AppointmentLocationsFragment.initializeLocation$lambda$33(this.f$0, (Location) obj);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda16
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentLocationsFragment.initializeLocation$lambda$34(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda17
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentLocationsFragment.initializeLocation$lambda$35(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda18
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentLocationsFragment.initializeLocation$lambda$36(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda19
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentLocationsFragment.initializeLocation$lambda$37(this.f$0);
            }
        }, new Function1() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentLocationsFragment$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return AppointmentLocationsFragment.initializeLocation$lambda$38(this.f$0, (String) obj);
            }
        });
        LocationHelper locationHelper3 = this.locationHelper;
        if (locationHelper3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("locationHelper");
        } else {
            locationHelper = locationHelper3;
        }
        locationHelper.fetchLocation();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$33(AppointmentLocationsFragment this$0, Location location) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(location, "location");
        BuildersKt__Builders_commonKt.launch$default(LifecycleOwnerKt.getLifecycleScope(this$0), null, null, new AppointmentLocationsFragment$initializeLocation$1$1(this$0, location, null), 3, null);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$34(AppointmentLocationsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$35(AppointmentLocationsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$36(AppointmentLocationsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$37(AppointmentLocationsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$38(AppointmentLocationsFragment this$0, String it) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(it, "it");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        return Unit.INSTANCE;
    }
}