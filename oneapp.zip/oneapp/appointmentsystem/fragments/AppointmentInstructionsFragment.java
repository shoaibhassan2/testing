package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import java.util.ArrayList;
import java.util.Date;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import org.apache.commons.imaging.formats.jpeg.iptc.IptcConstants;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentAppointmentInstructionsBinding;
import pk.gov.nadra.oneapp.appointmentsystem.viewmodel.AppointmentSharedViewModel;
import pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.appointment.AvailableSlots;
import pk.gov.nadra.oneapp.models.appointment.BookAppointmentResponse;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;
import pk.gov.nadra.oneapp.models.appointment.SlotHoldResponse;
import pk.gov.nadra.oneapp.models.crc.library.LibraryResponse;
import pk.gov.nadra.rahbar.android.data.NrcData;
import pk.gov.nadra.rahbar.android.data.NrcDataRequest;
import pk.gov.nadra.rahbar.android.data.NrcDataResponse;
import pk.gov.nadra.rahbar.android.data.ServiceResponse;
import pk.gov.nadra.rahbar.android.db.backgroundtasks.GetMaxTimeStampTask;
import pk.gov.nadra.rahbar.android.db.backgroundtasks.InsertNrcDataTask;
import pk.gov.nadra.rahbar.android.service.NrcDataService;
import pk.gov.nadra.rahbar.android.util.ICommunicator;

/* compiled from: AppointmentInstructionsFragment.kt */
@Metadata(d1 = {"\u0000\u0088\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0018H\u0016J\u0010\u0010\u0019\u001a\u00020\u00162\u0006\u0010\u001a\u001a\u00020\u001bH\u0016J&\u0010\u001c\u001a\u0004\u0018\u00010\u001d2\u0006\u0010\u001e\u001a\u00020\u001f2\b\u0010 \u001a\u0004\u0018\u00010!2\b\u0010\u0017\u001a\u0004\u0018\u00010\u0018H\u0016J\u001a\u0010\"\u001a\u00020\u00162\u0006\u0010#\u001a\u00020\u001d2\b\u0010\u0017\u001a\u0004\u0018\u00010\u0018H\u0016J\b\u0010$\u001a\u00020\u0016H\u0002J\b\u0010%\u001a\u00020\u0016H\u0002J\u0010\u0010(\u001a\u00020\u00162\u0006\u0010)\u001a\u00020*H\u0002J\u0012\u0010-\u001a\u0004\u0018\u00010.2\u0006\u0010)\u001a\u00020*H\u0002J\u0010\u0010/\u001a\u00020\u00162\u0006\u00100\u001a\u000201H\u0002J%\u00102\u001a\u00020\u00162\u0016\u00103\u001a\u0012\u0012\u0004\u0012\u00020506j\b\u0012\u0004\u0012\u000205`4H\u0002¢\u0006\u0002\u00107J\b\u0010:\u001a\u00020\u0016H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u000e\u0010&\u001a\u00020'X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020,X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00108\u001a\u000209X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006;"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/fragments/AppointmentInstructionsFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "appointmentSharedViewModel", "Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "getAppointmentSharedViewModel", "()Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "appointmentSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentInstructionsBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentInstructionsBinding;", "activity", "Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;)V", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onAttach", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "onViewCreated", Promotion.ACTION_VIEW, "updateRequiredDocumentsMessage", "syncNadraCenters", "getMaxTimeStampCommunicator", "Lpk/gov/nadra/rahbar/android/db/backgroundtasks/GetMaxTimeStampTask$GetMaxTimeStampCommunicator;", "callNrcDataService", "maxTimeStamp", "Ljava/util/Date;", "iCommunicatorNrcDataServiceResult", "Lpk/gov/nadra/rahbar/android/util/ICommunicator;", "getNrcDataRequest", "Lpk/gov/nadra/rahbar/android/data/NrcDataRequest;", "processNrcDataServiceResponse", "serviceResponse", "Lpk/gov/nadra/rahbar/android/data/ServiceResponse;", "insertNrcDataInDB", "nrcDataList", "Lkotlin/collections/ArrayList;", "Lpk/gov/nadra/rahbar/android/data/NrcData;", "Ljava/util/ArrayList;", "(Ljava/util/ArrayList;)V", "insertNrcDataCommunicator", "Lpk/gov/nadra/rahbar/android/db/backgroundtasks/InsertNrcDataTask$InsertNrcDataCommunicator;", "clearSharedViewModelData", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentInstructionsFragment extends Fragment {
    private FragmentAppointmentInstructionsBinding _binding;
    public AppointmentSystemActivity activity;

    /* renamed from: appointmentSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy appointmentSharedViewModel;
    private GetMaxTimeStampTask.GetMaxTimeStampCommunicator getMaxTimeStampCommunicator = new GetMaxTimeStampTask.GetMaxTimeStampCommunicator() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentInstructionsFragment$$ExternalSyntheticLambda4
        @Override // pk.gov.nadra.rahbar.android.db.backgroundtasks.GetMaxTimeStampTask.GetMaxTimeStampCommunicator
        public final void onSuccess(Date date) {
            AppointmentInstructionsFragment.getMaxTimeStampCommunicator$lambda$5(this.f$0, date);
        }
    };
    private ICommunicator iCommunicatorNrcDataServiceResult = new ICommunicator() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentInstructionsFragment$$ExternalSyntheticLambda5
        @Override // pk.gov.nadra.rahbar.android.util.ICommunicator
        public final void onResponse(ServiceResponse serviceResponse) {
            AppointmentInstructionsFragment.iCommunicatorNrcDataServiceResult$lambda$6(this.f$0, serviceResponse);
        }
    };
    private InsertNrcDataTask.InsertNrcDataCommunicator insertNrcDataCommunicator = new InsertNrcDataTask.InsertNrcDataCommunicator() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentInstructionsFragment$$ExternalSyntheticLambda6
        @Override // pk.gov.nadra.rahbar.android.db.backgroundtasks.InsertNrcDataTask.InsertNrcDataCommunicator
        public final void onSuccess(int i) {
            AppointmentInstructionsFragment.insertNrcDataCommunicator$lambda$7(this.f$0, i);
        }
    };

    public AppointmentInstructionsFragment() {
        final AppointmentInstructionsFragment appointmentInstructionsFragment = this;
        final Function0 function0 = null;
        this.appointmentSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(appointmentInstructionsFragment, Reflection.getOrCreateKotlinClass(AppointmentSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentInstructionsFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = appointmentInstructionsFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentInstructionsFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = appointmentInstructionsFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentInstructionsFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = appointmentInstructionsFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    private final AppointmentSharedViewModel getAppointmentSharedViewModel() {
        return (AppointmentSharedViewModel) this.appointmentSharedViewModel.getValue();
    }

    private final FragmentAppointmentInstructionsBinding getBinding() {
        FragmentAppointmentInstructionsBinding fragmentAppointmentInstructionsBinding = this._binding;
        Intrinsics.checkNotNull(fragmentAppointmentInstructionsBinding);
        return fragmentAppointmentInstructionsBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final AppointmentSystemActivity getActivity() {
        AppointmentSystemActivity appointmentSystemActivity = this.activity;
        if (appointmentSystemActivity != null) {
            return appointmentSystemActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(AppointmentSystemActivity appointmentSystemActivity) {
        Intrinsics.checkNotNullParameter(appointmentSystemActivity, "<set-?>");
        this.activity = appointmentSystemActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity");
        setActivity((AppointmentSystemActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentAppointmentInstructionsBinding.inflate(inflater, container, false);
        return getBinding().getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        FragmentAppointmentInstructionsBinding binding = getBinding();
        binding.appointmentHeaderLayout.textTitle.setText(getString(R.string.appointment));
        binding.appointmentHeaderLayout.textSubtitle.setText(" پیشگی وقت ");
        binding.appointmentHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.textBackUr.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentInstructionsFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentInstructionsFragment.onViewCreated$lambda$4$lambda$0(this.f$0, view2);
            }
        });
        binding.appointmentHeaderLayout.iconInfo.setVisibility(0);
        binding.appointmentHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentInstructionsFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentInstructionsFragment.onViewCreated$lambda$4$lambda$1(this.f$0, view2);
            }
        });
        binding.appointmentInstructionUrduHeadingTextView.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentChooseDatetimeUrduHeadingTextView.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentPunctualUrduHeadingTextView.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentArrivingUrduHeadingTextView.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentDocumentsUrduHeadingTextView.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentOptionTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Or", " (یا) ", 0, false, 12, null));
        ConfigurableButton configurableButton = binding.appointmentInstructionsNextButtonLayout.commonButton;
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        String string = getString(R.string.search_center_location);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util, activity, string, "\n (مقام کے مطابق مرکز تلاش کریں) ", 0, false, 12, null));
        binding.appointmentInstructionsNextButtonLayout.commonButton.setFilled(true);
        binding.appointmentInstructionsNextButtonLayout.commonButton.setInsetTop(0);
        binding.appointmentInstructionsNextButtonLayout.commonButton.setInsetBottom(0);
        binding.appointmentInstructionsNextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentInstructionsFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentInstructionsFragment.onViewCreated$lambda$4$lambda$2(this.f$0, view2);
            }
        });
        ConfigurableButton configurableButton2 = binding.appointmentInstructionsMapNextButtonLayout.commonButton;
        Util util2 = Util.INSTANCE;
        AppointmentSystemActivity activity2 = getActivity();
        String string2 = getString(R.string.center_near_me);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        configurableButton2.setText(Util.setEnglishTextSpan$default(util2, activity2, string2, "\n (میرے قریب مرکز) ", 0, false, 12, null));
        binding.appointmentInstructionsMapNextButtonLayout.commonButton.setFilled(true);
        binding.appointmentInstructionsMapNextButtonLayout.commonButton.setInsetTop(0);
        binding.appointmentInstructionsMapNextButtonLayout.commonButton.setInsetBottom(0);
        binding.appointmentInstructionsMapNextButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentInstructionsFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentInstructionsFragment.onViewCreated$lambda$4$lambda$3(this.f$0, view2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$0(AppointmentInstructionsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$1(AppointmentInstructionsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = this$0.getActivity();
        String string = this$0.getString(pk.gov.nadra.oneapp.commonui.R.string.appointment_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.APPOINTMENT_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$2(AppointmentInstructionsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getAppointmentSharedViewModel().setFromCenterNearMe(false);
        this$0.clearSharedViewModelData();
        this$0.getActivity().navigateToFragment(R.id.appointmentLocationsFragment);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$3(AppointmentInstructionsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.clearSharedViewModelData();
        this$0.syncNadraCenters();
    }

    private final void updateRequiredDocumentsMessage() {
        try {
            String string = getString(R.string.appointment_required_documents_message);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            final String str = Constant.DOWNLOAD_URL;
            int iIndexOf$default = StringsKt.indexOf$default((CharSequence) string, Constant.DOWNLOAD_URL, 0, false, 6, (Object) null);
            int length = Constant.DOWNLOAD_URL.length() + iIndexOf$default;
            SpannableString spannableString = new SpannableString(string);
            spannableString.setSpan(new UnderlineSpan(), iIndexOf$default, length, 33);
            spannableString.setSpan(new ClickableSpan() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentInstructionsFragment$updateRequiredDocumentsMessage$clickableSpan$1
                @Override // android.text.style.ClickableSpan
                public void onClick(View widget) {
                    Intrinsics.checkNotNullParameter(widget, "widget");
                    Util.INSTANCE.openUrlInBrowser(this.this$0.getActivity(), str);
                }
            }, iIndexOf$default, length, 33);
            getBinding().appointmentRequiredDocumentsTextView.setText(spannableString);
            getBinding().appointmentRequiredDocumentsTextView.setMovementMethod(LinkMovementMethod.getInstance());
        } catch (Exception unused) {
        }
    }

    private final void syncNadraCenters() {
        new GetMaxTimeStampTask(getActivity(), this.getMaxTimeStampCommunicator).execute();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void getMaxTimeStampCommunicator$lambda$5(AppointmentInstructionsFragment this$0, Date date) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (date == null) {
            this$0.getActivity().navigateToFragment(R.id.appointmentCenterNearMeFragment);
        } else {
            this$0.callNrcDataService(date);
        }
    }

    private final void callNrcDataService(Date maxTimeStamp) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        new NrcDataService(this.iCommunicatorNrcDataServiceResult, getActivity(), new Object[]{getNrcDataRequest(maxTimeStamp)}).syncNrcData();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void iCommunicatorNrcDataServiceResult$lambda$6(AppointmentInstructionsFragment this$0, ServiceResponse serviceResponse) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(serviceResponse, "serviceResponse");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        if (serviceResponse.getStatus() == 200) {
            this$0.processNrcDataServiceResponse(serviceResponse);
        } else {
            this$0.getActivity().navigateToFragment(R.id.appointmentCenterNearMeFragment);
        }
    }

    private final NrcDataRequest getNrcDataRequest(Date maxTimeStamp) {
        String strConvertDateToString = pk.gov.nadra.rahbar.android.util.Util.convertDateToString(maxTimeStamp);
        NrcDataRequest nrcDataRequest = new NrcDataRequest();
        nrcDataRequest.setSyncDate(strConvertDateToString);
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d(Constant.TAG, nrcDataRequest.toString());
        }
        return nrcDataRequest;
    }

    private final void processNrcDataServiceResponse(ServiceResponse serviceResponse) {
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d(Constant.TAG, serviceResponse.getNrcDataResponse().toString());
        }
        NrcDataResponse nrcDataResponse = serviceResponse.getNrcDataResponse();
        if (nrcDataResponse.getCode() != null) {
            String code = nrcDataResponse.getCode();
            Intrinsics.checkNotNullExpressionValue(code, "getCode(...)");
            if (code.length() != 0) {
                if (nrcDataResponse.getNrcDataList() != null && nrcDataResponse.getNrcDataList().size() > 0) {
                    ArrayList<NrcData> nrcDataList = nrcDataResponse.getNrcDataList();
                    Intrinsics.checkNotNullExpressionValue(nrcDataList, "getNrcDataList(...)");
                    insertNrcDataInDB(nrcDataList);
                    return;
                }
                getActivity().navigateToFragment(R.id.appointmentCenterNearMeFragment);
                return;
            }
        }
        getActivity().navigateToFragment(R.id.appointmentCenterNearMeFragment);
    }

    private final void insertNrcDataInDB(ArrayList<NrcData> nrcDataList) {
        Object[] objArr = {nrcDataList};
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d(Constant.TAG, "NrcDataService() Response Size: " + nrcDataList.size());
        }
        new InsertNrcDataTask(getActivity(), this.insertNrcDataCommunicator).execute(objArr);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void insertNrcDataCommunicator$lambda$7(AppointmentInstructionsFragment this$0, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToFragment(R.id.appointmentCenterNearMeFragment);
    }

    private final void clearSharedViewModelData() {
        getAppointmentSharedViewModel().setSelectedProvince(new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null));
        getAppointmentSharedViewModel().setSelectedDistrict(new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null));
        getAppointmentSharedViewModel().setSelectedCenterData(new CentersResponse.Data(null, null, null, null, null, 31, null));
        getAppointmentSharedViewModel().setSelectedDate("");
        getAppointmentSharedViewModel().setAvailableSlotsList(new ArrayList<>());
        getAppointmentSharedViewModel().setSelectedSlotData(new AvailableSlots.Data(0, null, false, 7, null));
        getAppointmentSharedViewModel().setSlotHoldResponse(new SlotHoldResponse.Data(null, null, 0, null, null, null, null, 0, 255, null));
        getAppointmentSharedViewModel().setBookAppointmentResponse(new BookAppointmentResponse.Data(null, null, null, null, null, null, 0, null, null, null, null, null, null, null, null, null, null, 0, 262143, null));
        getAppointmentSharedViewModel().setName("");
        getAppointmentSharedViewModel().setCitizenNumber("");
        getAppointmentSharedViewModel().setMobileNumber("");
    }
}