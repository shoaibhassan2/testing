package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import kotlin.jvm.functions.Function2;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.ActionType;
import pk.gov.nadra.oneapp.models.appointment.UserAppointmentResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentsListFragment$$ExternalSyntheticLambda2 implements Function2 {
    public /* synthetic */ AppointmentsListFragment$$ExternalSyntheticLambda2() {
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return AppointmentsListFragment.onViewCreated$lambda$6$lambda$2(this.f$0, (ActionType) obj, (UserAppointmentResponse.Data) obj2);
    }
}