package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import java.util.List;
import pk.gov.nadra.rahbar.android.db.backgroundtasks.GetAllCentersTask;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentCenterNearMeFragment$$ExternalSyntheticLambda0 implements GetAllCentersTask.GetAllCentersCommunicator {
    public /* synthetic */ AppointmentCenterNearMeFragment$$ExternalSyntheticLambda0() {
    }

    @Override // pk.gov.nadra.rahbar.android.db.backgroundtasks.GetAllCentersTask.GetAllCentersCommunicator
    public final void onSuccess(List list) {
        AppointmentCenterNearMeFragment.getAllCentersCommunicator$lambda$11(this.f$0, list);
    }
}