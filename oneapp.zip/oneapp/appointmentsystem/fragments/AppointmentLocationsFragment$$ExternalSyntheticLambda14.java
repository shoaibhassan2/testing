package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import kotlin.jvm.functions.Function1;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentLocationsFragment$$ExternalSyntheticLambda14 implements Function1 {
    public /* synthetic */ AppointmentLocationsFragment$$ExternalSyntheticLambda14() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return AppointmentLocationsFragment.onViewCreated$lambda$6$lambda$5(this.f$0, (CentersResponse.Data) obj);
    }
}