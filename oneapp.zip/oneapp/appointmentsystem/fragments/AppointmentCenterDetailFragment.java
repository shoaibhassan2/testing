package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import org.apache.commons.imaging.formats.jpeg.iptc.IptcConstants;
import org.apache.commons.lang3.StringUtils;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentCenterDetailBinding;
import pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment;
import pk.gov.nadra.oneapp.appointmentsystem.viewmodel.AppointmentSharedViewModel;
import pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;
import pk.gov.nadra.oneapp.models.appointment.ProvinceDistrictRequest;
import pk.gov.nadra.oneapp.models.appointment.ProvinceDistrictResponse;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.library.LibraryResponse;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;
import pk.gov.nadra.rahbar.android.data.NrcDataRDB;

/* compiled from: AppointmentCenterDetailFragment.kt */
@Metadata(d1 = {"\u0000\u009a\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\u0018\u00002\u00020\u00012\u00020\u0002B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u0012\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010%H\u0016J\u0010\u0010&\u001a\u00020#2\u0006\u0010'\u001a\u00020(H\u0016J&\u0010)\u001a\u0004\u0018\u00010*2\u0006\u0010+\u001a\u00020,2\b\u0010-\u001a\u0004\u0018\u00010.2\b\u0010$\u001a\u0004\u0018\u00010%H\u0016J\u001a\u0010/\u001a\u00020#2\u0006\u00100\u001a\u00020*2\b\u0010$\u001a\u0004\u0018\u00010%H\u0016J\u0010\u00101\u001a\u00020#2\u0006\u00102\u001a\u00020\u001fH\u0016J\b\u00103\u001a\u00020#H\u0002J\u0012\u00104\u001a\u00020#2\b\u0010 \u001a\u0004\u0018\u00010!H\u0002J\b\u00105\u001a\u00020#H\u0002J\u0010\u00106\u001a\u0002072\u0006\u00108\u001a\u000207H\u0002J\u0012\u00109\u001a\u00020#2\b\u0010 \u001a\u0004\u0018\u00010!H\u0002J\u0010\u0010:\u001a\u00020;2\u0006\u0010 \u001a\u00020!H\u0002J\u0010\u0010<\u001a\u00020#2\u0006\u0010=\u001a\u00020>H\u0002J\u0010\u0010?\u001a\u00020#2\u0006\u0010@\u001a\u00020AH\u0002J\u0018\u0010B\u001a\u00020#2\u0006\u0010C\u001a\u00020A2\u0006\u0010D\u001a\u00020EH\u0002R\u001b\u0010\u0005\u001a\u00020\u00068BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\bR\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\u00020\f8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0010\u001a\u00020\u0011X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\u0019\u001a\u0012\u0012\u0004\u0012\u00020\u001b0\u001cj\b\u0012\u0004\u0012\u00020\u001b`\u001aX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u001dR\u000e\u0010\u001e\u001a\u00020\u001fX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020!X\u0082.¢\u0006\u0002\n\u0000¨\u0006F"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/fragments/AppointmentCenterDetailFragment;", "Landroidx/fragment/app/Fragment;", "Lcom/google/android/gms/maps/OnMapReadyCallback;", "<init>", "()V", "appointmentSharedViewModel", "Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "getAppointmentSharedViewModel", "()Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "appointmentSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentCenterDetailBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentCenterDetailBinding;", "activity", "Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;)V", "selectedProvince", "Lpk/gov/nadra/oneapp/models/crc/library/LibraryResponse;", "selectedDistrict", "centersList", "Lkotlin/collections/ArrayList;", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data;", "Ljava/util/ArrayList;", "Ljava/util/ArrayList;", "mMap", "Lcom/google/android/gms/maps/GoogleMap;", "nrcDataRDB", "Lpk/gov/nadra/rahbar/android/data/NrcDataRDB;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onAttach", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "onViewCreated", Promotion.ACTION_VIEW, "onMapReady", "googleMap", "setUpMap", "performGotoClickAction", "initViewsData", "getFormattedTimings", "", "time", "getOfficeTimings", "getProcessingType", "Landroid/text/SpannableString;", "getCentersListFromDistrictName", "districtName", "Lpk/gov/nadra/oneapp/models/appointment/ProvinceDistrictRequest;", "processProvinceDistrictSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "handleFailureCase", "jsonResponse", "responseCode", "", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentCenterDetailFragment extends Fragment implements OnMapReadyCallback {
    private FragmentCenterDetailBinding _binding;
    public AppointmentSystemActivity activity;

    /* renamed from: appointmentSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy appointmentSharedViewModel;
    private GoogleMap mMap;
    private NrcDataRDB nrcDataRDB;
    private LibraryResponse selectedProvince = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private ArrayList<CentersResponse.Data> centersList = new ArrayList<>();

    public AppointmentCenterDetailFragment() {
        final AppointmentCenterDetailFragment appointmentCenterDetailFragment = this;
        final Function0 function0 = null;
        this.appointmentSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(appointmentCenterDetailFragment, Reflection.getOrCreateKotlinClass(AppointmentSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = appointmentCenterDetailFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = appointmentCenterDetailFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = appointmentCenterDetailFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    private final AppointmentSharedViewModel getAppointmentSharedViewModel() {
        return (AppointmentSharedViewModel) this.appointmentSharedViewModel.getValue();
    }

    private final FragmentCenterDetailBinding getBinding() {
        FragmentCenterDetailBinding fragmentCenterDetailBinding = this._binding;
        Intrinsics.checkNotNull(fragmentCenterDetailBinding);
        return fragmentCenterDetailBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final AppointmentSystemActivity getActivity() {
        AppointmentSystemActivity appointmentSystemActivity = this.activity;
        if (appointmentSystemActivity != null) {
            return appointmentSystemActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(AppointmentSystemActivity appointmentSystemActivity) {
        Intrinsics.checkNotNullParameter(appointmentSystemActivity, "<set-?>");
        this.activity = appointmentSystemActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity");
        setActivity((AppointmentSystemActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentCenterDetailBinding.inflate(inflater, container, false);
        return getBinding().getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        this.nrcDataRDB = getAppointmentSharedViewModel().getSelectedNrcDataRDB();
        Fragment fragmentFindFragmentById = getChildFragmentManager().findFragmentById(R.id.centerDetailMapFragment);
        Intrinsics.checkNotNull(fragmentFindFragmentById, "null cannot be cast to non-null type com.google.android.gms.maps.SupportMapFragment");
        ((SupportMapFragment) fragmentFindFragmentById).getMapAsync(this);
        FragmentCenterDetailBinding binding = getBinding();
        binding.appointmentHeaderLayout.textTitle.setText(getString(pk.gov.nadra.oneapp.commonui.R.string.appointment));
        binding.appointmentHeaderLayout.textSubtitle.setText(" پیشگی وقت ");
        binding.appointmentHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.textBackUr.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentCenterDetailFragment.onViewCreated$lambda$4$lambda$0(this.f$0, view2);
            }
        });
        binding.appointmentHeaderLayout.iconInfo.setVisibility(0);
        binding.appointmentHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentCenterDetailFragment.onViewCreated$lambda$4$lambda$1(this.f$0, view2);
            }
        });
        TextView textView = binding.addressLabelTextView;
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        String string = getString(pk.gov.nadra.rahbar.android.R.string.center_address);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util, activity, string, " (پتہ) ", 0, false, 12, null));
        TextView textView2 = binding.phoneLabelTextView;
        Util util2 = Util.INSTANCE;
        AppointmentSystemActivity activity2 = getActivity();
        String string2 = getString(pk.gov.nadra.rahbar.android.R.string.center_phone_number);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textView2.setText(Util.setEnglishTextSpan$default(util2, activity2, string2, " (فون نمبر) ", 0, false, 12, null));
        TextView textView3 = binding.timingLabelTextView;
        Util util3 = Util.INSTANCE;
        AppointmentSystemActivity activity3 = getActivity();
        String string3 = getString(pk.gov.nadra.rahbar.android.R.string.timing);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        textView3.setText(Util.setEnglishTextSpan$default(util3, activity3, string3, " (اوقات) ", 0, false, 12, null));
        TextView textView4 = binding.centerTypeLabelTextView;
        Util util4 = Util.INSTANCE;
        AppointmentSystemActivity activity4 = getActivity();
        String string4 = getString(pk.gov.nadra.rahbar.android.R.string.center_type);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        textView4.setText(Util.setEnglishTextSpan$default(util4, activity4, string4, " (مرکز کی نوعیت) ", 0, false, 12, null));
        binding.appointmentCenterProceedButtonLayout.commonButton.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Proceed", " (آگے بڑھیں)", 0, false, 12, null));
        binding.appointmentCenterProceedButtonLayout.commonButton.setFilled(true);
        binding.appointmentCenterProceedButtonLayout.commonButton.setInsetTop(0);
        binding.appointmentCenterProceedButtonLayout.commonButton.setInsetBottom(0);
        binding.appointmentCenterProceedButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentCenterDetailFragment.onViewCreated$lambda$4$lambda$2(this.f$0, view2);
            }
        });
        binding.goToDirectionImageView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentCenterDetailFragment.onViewCreated$lambda$4$lambda$3(this.f$0, view2);
            }
        });
        initViewsData();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$0(AppointmentCenterDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$1(AppointmentCenterDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = this$0.getActivity();
        String string = this$0.getString(pk.gov.nadra.oneapp.commonui.R.string.appointment_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.APPOINTMENT_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$2(AppointmentCenterDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        NrcDataRDB nrcDataRDB = this$0.nrcDataRDB;
        if (nrcDataRDB == null) {
            Intrinsics.throwUninitializedPropertyAccessException("nrcDataRDB");
            nrcDataRDB = null;
        }
        String districtName = nrcDataRDB.getDistrictName();
        Intrinsics.checkNotNullExpressionValue(districtName, "getDistrictName(...)");
        this$0.getCentersListFromDistrictName(new ProvinceDistrictRequest(districtName));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$4$lambda$3(AppointmentCenterDetailFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        NrcDataRDB nrcDataRDB = this$0.nrcDataRDB;
        if (nrcDataRDB == null) {
            Intrinsics.throwUninitializedPropertyAccessException("nrcDataRDB");
            nrcDataRDB = null;
        }
        this$0.performGotoClickAction(nrcDataRDB);
    }

    @Override // com.google.android.gms.maps.OnMapReadyCallback
    public void onMapReady(GoogleMap googleMap) {
        Intrinsics.checkNotNullParameter(googleMap, "googleMap");
        this.mMap = googleMap;
        setUpMap();
        BitmapDescriptor bitmapDescriptorFromResource = BitmapDescriptorFactory.fromResource(pk.gov.nadra.rahbar.android.R.drawable.marker_single_shift);
        Intrinsics.checkNotNullExpressionValue(bitmapDescriptorFromResource, "fromResource(...)");
        NrcDataRDB nrcDataRDB = this.nrcDataRDB;
        GoogleMap googleMap2 = null;
        if (nrcDataRDB == null) {
            Intrinsics.throwUninitializedPropertyAccessException("nrcDataRDB");
            nrcDataRDB = null;
        }
        double stringToDouble = pk.gov.nadra.rahbar.android.util.Util.parseStringToDouble(nrcDataRDB.getLatitude());
        NrcDataRDB nrcDataRDB2 = this.nrcDataRDB;
        if (nrcDataRDB2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("nrcDataRDB");
            nrcDataRDB2 = null;
        }
        LatLng latLng = new LatLng(stringToDouble, pk.gov.nadra.rahbar.android.util.Util.parseStringToDouble(nrcDataRDB2.getLongitude()));
        GoogleMap googleMap3 = this.mMap;
        if (googleMap3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap3 = null;
        }
        googleMap3.addMarker(new MarkerOptions().position(latLng).icon(bitmapDescriptorFromResource));
        GoogleMap googleMap4 = this.mMap;
        if (googleMap4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
        } else {
            googleMap2 = googleMap4;
        }
        googleMap2.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
    }

    private final void setUpMap() {
        GoogleMap googleMap = this.mMap;
        GoogleMap googleMap2 = null;
        if (googleMap == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap = null;
        }
        UiSettings uiSettings = googleMap.getUiSettings();
        Intrinsics.checkNotNullExpressionValue(uiSettings, "getUiSettings(...)");
        uiSettings.setCompassEnabled(true);
        uiSettings.setRotateGesturesEnabled(false);
        uiSettings.setTiltGesturesEnabled(true);
        uiSettings.setZoomControlsEnabled(false);
        GoogleMap googleMap3 = this.mMap;
        if (googleMap3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap3 = null;
        }
        googleMap3.setTrafficEnabled(false);
        GoogleMap googleMap4 = this.mMap;
        if (googleMap4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap4 = null;
        }
        googleMap4.setIndoorEnabled(false);
        GoogleMap googleMap5 = this.mMap;
        if (googleMap5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap5 = null;
        }
        googleMap5.setBuildingsEnabled(false);
        GoogleMap googleMap6 = this.mMap;
        if (googleMap6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap6 = null;
        }
        googleMap6.setPadding(0, 200, 0, 0);
        try {
            GoogleMap googleMap7 = this.mMap;
            if (googleMap7 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mMap");
            } else {
                googleMap2 = googleMap7;
            }
            googleMap2.setMapStyle(MapStyleOptions.loadRawResourceStyle(getActivity(), pk.gov.nadra.rahbar.android.R.raw.map_style));
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
        }
        uiSettings.setMapToolbarEnabled(false);
    }

    private final void performGotoClickAction(NrcDataRDB nrcDataRDB) {
        if (nrcDataRDB == null || nrcDataRDB.getLatitude() == null) {
            return;
        }
        String latitude = nrcDataRDB.getLatitude();
        Intrinsics.checkNotNullExpressionValue(latitude, "getLatitude(...)");
        if (latitude.length() == 0 || nrcDataRDB.getLongitude() == null) {
            return;
        }
        String longitude = nrcDataRDB.getLongitude();
        Intrinsics.checkNotNullExpressionValue(longitude, "getLongitude(...)");
        if (longitude.length() == 0) {
            return;
        }
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://maps.google.com/maps?saddr=&daddr=" + nrcDataRDB.getLatitude() + "," + nrcDataRDB.getLongitude() + "&mode=d"));
        if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivity(intent);
        } else {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.maps")));
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x00b0  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final void initViewsData() {
        /*
            r12 = this;
            pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentCenterDetailBinding r0 = r12.getBinding()
            android.widget.TextView r1 = r0.centerAddressTextView
            pk.gov.nadra.oneapp.commonutils.utils.Util r2 = pk.gov.nadra.oneapp.commonutils.utils.Util.INSTANCE
            pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity r3 = r12.getActivity()
            android.content.Context r3 = (android.content.Context) r3
            pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity r4 = r12.getActivity()
            android.content.Context r4 = (android.content.Context) r4
            pk.gov.nadra.rahbar.android.data.NrcDataRDB r5 = r12.nrcDataRDB
            r10 = 0
            java.lang.String r11 = "nrcDataRDB"
            if (r5 != 0) goto L1f
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r11)
            r5 = r10
        L1f:
            java.lang.String r5 = r5.getAdditionalAddress()
            java.lang.String r4 = pk.gov.nadra.rahbar.android.util.Util.isValid(r4, r5)
            java.lang.String r5 = "isValid(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r5)
            pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity r5 = r12.getActivity()
            android.content.Context r5 = (android.content.Context) r5
            pk.gov.nadra.rahbar.android.data.NrcDataRDB r6 = r12.nrcDataRDB
            if (r6 != 0) goto L3a
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r11)
            r6 = r10
        L3a:
            java.lang.String r6 = r6.getAdditionalAddressLocal()
            java.lang.String r5 = pk.gov.nadra.rahbar.android.util.Util.isValid(r5, r6)
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            java.lang.String r7 = "\n"
            r6.<init>(r7)
            java.lang.StringBuilder r5 = r6.append(r5)
            java.lang.String r5 = r5.toString()
            r8 = 12
            r9 = 0
            r6 = 0
            r7 = 0
            android.text.SpannableString r2 = pk.gov.nadra.oneapp.commonutils.utils.Util.setEnglishTextSpan$default(r2, r3, r4, r5, r6, r7, r8, r9)
            java.lang.CharSequence r2 = (java.lang.CharSequence) r2
            r1.setText(r2)
            pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity r1 = r12.getActivity()
            android.content.Context r1 = (android.content.Context) r1
            pk.gov.nadra.rahbar.android.data.NrcDataRDB r2 = r12.nrcDataRDB
            if (r2 != 0) goto L6d
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r11)
            r2 = r10
        L6d:
            java.lang.String r2 = r2.getPhone()
            java.lang.String r1 = pk.gov.nadra.rahbar.android.util.Util.isValid(r1, r2)
            if (r1 == 0) goto Lb0
            r2 = r1
            java.lang.CharSequence r2 = (java.lang.CharSequence) r2
            int r3 = r2.length()
            if (r3 != 0) goto L81
            goto Lb0
        L81:
            java.lang.String r3 = "00000"
            r4 = 1
            boolean r3 = kotlin.text.StringsKt.equals(r1, r3, r4)
            if (r3 != 0) goto Lb0
            android.text.SpannableString r3 = new android.text.SpannableString
            r3.<init>(r2)
            pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$initViewsData$1$1 r2 = new pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$initViewsData$1$1
            r2.<init>()
            int r1 = r1.length()
            r4 = 0
            r3.setSpan(r2, r4, r1, r4)
            android.widget.TextView r1 = r0.centerPhoneNumberTextView
            java.lang.CharSequence r3 = (java.lang.CharSequence) r3
            r1.setText(r3)
            android.widget.TextView r1 = r0.centerPhoneNumberTextView
            android.text.method.LinkMovementMethod r2 = new android.text.method.LinkMovementMethod
            r2.<init>()
            android.text.method.MovementMethod r2 = (android.text.method.MovementMethod) r2
            r1.setMovementMethod(r2)
            goto Lb9
        Lb0:
            android.widget.TextView r1 = r0.centerPhoneNumberTextView
            java.lang.String r2 = "-"
            java.lang.CharSequence r2 = (java.lang.CharSequence) r2
            r1.setText(r2)
        Lb9:
            pk.gov.nadra.rahbar.android.data.NrcDataRDB r1 = r12.nrcDataRDB
            if (r1 != 0) goto Lc1
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r11)
            r1 = r10
        Lc1:
            r12.getOfficeTimings(r1)
            android.widget.TextView r0 = r0.centerTypeTextView
            pk.gov.nadra.rahbar.android.data.NrcDataRDB r1 = r12.nrcDataRDB
            if (r1 != 0) goto Lce
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r11)
            goto Lcf
        Lce:
            r10 = r1
        Lcf:
            android.text.SpannableString r1 = r12.getProcessingType(r10)
            java.lang.CharSequence r1 = (java.lang.CharSequence) r1
            r0.setText(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment.initViewsData():void");
    }

    private final String getFormattedTimings(String time) {
        if (time == "") {
            return "";
        }
        try {
            String upperCase = new SimpleDateFormat("h:mm a").format(new SimpleDateFormat("HH:mm:ss").parse(time));
            if (upperCase.length() > 0) {
                Intrinsics.checkNotNull(upperCase);
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue(locale, "getDefault(...)");
                upperCase = upperCase.toUpperCase(locale);
                Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            }
            Intrinsics.checkNotNull(upperCase);
            return upperCase;
        } catch (Exception unused) {
            return "";
        }
    }

    private final void getOfficeTimings(NrcDataRDB nrcDataRDB) {
        if (nrcDataRDB != null && nrcDataRDB.getShiftType() != null) {
            String shiftType = nrcDataRDB.getShiftType();
            Intrinsics.checkNotNullExpressionValue(shiftType, "getShiftType(...)");
            if (shiftType.length() != 0) {
                String shiftType2 = nrcDataRDB.getShiftType();
                if (StringsKt.equals(shiftType2, "single", true)) {
                    String morningTime = nrcDataRDB.getMorningTime();
                    String morningEndTime = nrcDataRDB.getMorningEndTime();
                    TextView textView = getBinding().centerTimingTextView;
                    Intrinsics.checkNotNull(morningTime);
                    String formattedTimings = getFormattedTimings(morningTime);
                    Intrinsics.checkNotNull(morningEndTime);
                    textView.setText(formattedTimings + " To " + getFormattedTimings(morningEndTime));
                    return;
                }
                if (StringsKt.equals(shiftType2, "double", true)) {
                    String morningTime2 = nrcDataRDB.getMorningTime();
                    String eveningEndTime = nrcDataRDB.getEveningEndTime();
                    TextView textView2 = getBinding().centerTimingTextView;
                    Intrinsics.checkNotNull(morningTime2);
                    String formattedTimings2 = getFormattedTimings(morningTime2);
                    Intrinsics.checkNotNull(eveningEndTime);
                    textView2.setText(formattedTimings2 + " To " + getFormattedTimings(eveningEndTime));
                    return;
                }
                if (StringsKt.equals(shiftType2, "three", true)) {
                    getBinding().centerTimingTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "24 Hours", " (گھنٹے 24) ", 0, false, 12, null));
                    return;
                } else {
                    getBinding().centerTimingTextView.setText("");
                    return;
                }
            }
        }
        getBinding().centerTimingTextView.setText("-");
    }

    private final SpannableString getProcessingType(NrcDataRDB nrcDataRDB) {
        String str;
        String strIsValid = pk.gov.nadra.rahbar.android.util.Util.isValid(getActivity(), nrcDataRDB.getProcesingType());
        Intrinsics.checkNotNullExpressionValue(strIsValid, "isValid(...)");
        String str2 = strIsValid;
        int length = str2.length() - 1;
        int i = 0;
        boolean z = false;
        while (i <= length) {
            boolean z2 = Intrinsics.compare((int) str2.charAt(!z ? i : length), 32) <= 0;
            if (z) {
                if (!z2) {
                    break;
                }
                length--;
            } else if (z2) {
                i++;
            } else {
                z = true;
            }
        }
        if (StringsKt.equals(str2.subSequence(i, length + 1).toString(), "executive", true)) {
            str = " ایگزیکٹو ";
        } else {
            str = " نارمل ";
        }
        String str3 = str;
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        Util util2 = Util.INSTANCE;
        String strIsValid2 = pk.gov.nadra.rahbar.android.util.Util.isValid(getActivity(), nrcDataRDB.getProcesingType());
        Intrinsics.checkNotNullExpressionValue(strIsValid2, "isValid(...)");
        return Util.setEnglishTextSpan$default(util, activity, util2.capitalizeWords(strIsValid2), str3, 0, false, 12, null);
    }

    /* compiled from: AppointmentCenterDetailFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$getCentersListFromDistrictName$1", f = "AppointmentCenterDetailFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$getCentersListFromDistrictName$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ ProvinceDistrictRequest $districtName;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(ProvinceDistrictRequest provinceDistrictRequest, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$districtName = provinceDistrictRequest;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AppointmentCenterDetailFragment.this.new AnonymousClass1(this.$districtName, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(AppointmentCenterDetailFragment.this.getActivity());
            ProvinceDistrictRequest provinceDistrictRequest = this.$districtName;
            final AppointmentCenterDetailFragment appointmentCenterDetailFragment = AppointmentCenterDetailFragment.this;
            aPIRequests.getProvinceDistrictFromDistrictName(provinceDistrictRequest, new Function3() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$getCentersListFromDistrictName$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return AppointmentCenterDetailFragment.AnonymousClass1.invokeSuspend$lambda$0(appointmentCenterDetailFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(AppointmentCenterDetailFragment appointmentCenterDetailFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(appointmentCenterDetailFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("getDistrictsList() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                appointmentCenterDetailFragment.processProvinceDistrictSuccessResponse(jsonObject);
            } else {
                appointmentCenterDetailFragment.selectedDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
                appointmentCenterDetailFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void getCentersListFromDistrictName(ProvinceDistrictRequest districtName) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(districtName, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processProvinceDistrictSuccessResponse(JsonObject jSonObject) {
        String id;
        ProvinceDistrictResponse.Data.District district;
        String name;
        ProvinceDistrictResponse.Data.District district2;
        String id2;
        String name2;
        ProvinceDistrictResponse.Data.Province province;
        ProvinceDistrictResponse.Data.Province province2;
        ProvinceDistrictResponse provinceDistrictResponse = (ProvinceDistrictResponse) new Gson().fromJson(jSonObject.toString(), ProvinceDistrictResponse.class);
        if (provinceDistrictResponse.getData() != null) {
            ProvinceDistrictResponse.Data data = provinceDistrictResponse.getData();
            NrcDataRDB nrcDataRDB = null;
            String str = "";
            if ((data != null ? data.getProvince() : null) != null) {
                LibraryResponse libraryResponse = this.selectedProvince;
                ProvinceDistrictResponse.Data data2 = provinceDistrictResponse.getData();
                if (data2 == null || (province2 = data2.getProvince()) == null || (id2 = province2.getId()) == null) {
                    id2 = "";
                }
                libraryResponse.setKey(id2);
                ProvinceDistrictResponse.Data data3 = provinceDistrictResponse.getData();
                if (data3 == null || (province = data3.getProvince()) == null || (name2 = province.getName()) == null) {
                    name2 = "";
                }
                libraryResponse.setValue(name2);
                getAppointmentSharedViewModel().setSelectedProvince(this.selectedProvince);
            }
            ProvinceDistrictResponse.Data data4 = provinceDistrictResponse.getData();
            if ((data4 != null ? data4.getDistrict() : null) != null) {
                LibraryResponse libraryResponse2 = this.selectedDistrict;
                ProvinceDistrictResponse.Data data5 = provinceDistrictResponse.getData();
                if (data5 == null || (district2 = data5.getDistrict()) == null || (id = district2.getId()) == null) {
                    id = "";
                }
                libraryResponse2.setKey(id);
                ProvinceDistrictResponse.Data data6 = provinceDistrictResponse.getData();
                if (data6 != null && (district = data6.getDistrict()) != null && (name = district.getName()) != null) {
                    str = name;
                }
                libraryResponse2.setValue(str);
                getAppointmentSharedViewModel().setSelectedDistrict(this.selectedDistrict);
            }
            getAppointmentSharedViewModel().setFromCenterNearMe(true);
            AppointmentSharedViewModel appointmentSharedViewModel = getAppointmentSharedViewModel();
            NrcDataRDB nrcDataRDB2 = this.nrcDataRDB;
            if (nrcDataRDB2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("nrcDataRDB");
                nrcDataRDB2 = null;
            }
            String locationCode = nrcDataRDB2.getLocationCode();
            Intrinsics.checkNotNullExpressionValue(locationCode, "getLocationCode(...)");
            NrcDataRDB nrcDataRDB3 = this.nrcDataRDB;
            if (nrcDataRDB3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("nrcDataRDB");
            } else {
                nrcDataRDB = nrcDataRDB3;
            }
            String locationName = nrcDataRDB.getLocationName();
            Intrinsics.checkNotNullExpressionValue(locationName, "getLocationName(...)");
            appointmentSharedViewModel.setSelectedCenterData(new CentersResponse.Data(locationCode, null, null, locationName, null, 22, null));
            getActivity().navigateToFragment(R.id.appointmentVisitPurposeFragment);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) throws JsonSyntaxException {
        Object element = new Gson().fromJson(jsonResponse.toString(), (Class<Object>) ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            ErrorResponse errorResponse = (ErrorResponse) element;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors != null) {
                    ArrayList arrayList = new ArrayList();
                    ArrayList arrayList2 = new ArrayList();
                    for (ErrorResponse.Error error : errors) {
                        arrayList.add(error.getField() + StringUtils.SPACE + error.getMessage());
                        String field = error.getField();
                        String message_local = error.getMessage_local();
                        if (message_local == null) {
                            message_local = "";
                        }
                        arrayList2.add(field + ": " + message_local);
                    }
                    if (arrayList.isEmpty()) {
                        return;
                    }
                    BottomSheetUtils.showMessageBottomSheet$default(BottomSheetUtils.INSTANCE, (FragmentActivity) getActivity(), "Alert", CollectionsKt.joinToString$default(arrayList, "\n", null, null, 0, null, null, 62, null), false, true, CollectionsKt.joinToString$default(arrayList2, "\n", null, null, 0, null, null, 62, null), (Function1) null, 72, (Object) null);
                    return;
                }
                NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                AppointmentSystemActivity activity = getActivity();
                Intrinsics.checkNotNullExpressionValue(element, "element");
                NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return AppointmentCenterDetailFragment.handleFailureCase$lambda$13$lambda$12(this.f$0);
                    }
                }, 8, null);
                return;
            }
            NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
            AppointmentSystemActivity activity2 = getActivity();
            Intrinsics.checkNotNullExpressionValue(element, "element");
            NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return AppointmentCenterDetailFragment.handleFailureCase$lambda$14(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
        AppointmentSystemActivity activity3 = getActivity();
        Intrinsics.checkNotNullExpressionValue(element, "element");
        NetworkErrorHandler.handleError$default(networkErrorHandler3, activity3, (ErrorResponse) element, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterDetailFragment$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentCenterDetailFragment.handleFailureCase$lambda$15(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$13$lambda$12(AppointmentCenterDetailFragment this_run) {
        Intrinsics.checkNotNullParameter(this_run, "$this_run");
        this_run.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$14(AppointmentCenterDetailFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$15(AppointmentCenterDetailFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }
}