package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import kotlin.jvm.functions.Function1;
import pk.gov.nadra.rahbar.android.data.NrcDataRDB;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentCenterNearMeFragment$$ExternalSyntheticLambda12 implements Function1 {
    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return Boolean.valueOf(AppointmentCenterNearMeFragment.filterCenters$lambda$15((NrcDataRDB) obj));
    }
}