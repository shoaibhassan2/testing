package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import org.apache.commons.imaging.formats.jpeg.iptc.IptcConstants;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.AppointmentLocationsAdapter;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentAppointmentCenterNearMeBinding;
import pk.gov.nadra.oneapp.appointmentsystem.viewmodel.AppointmentSharedViewModel;
import pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.LocationHelper;
import pk.gov.nadra.oneapp.commonutils.utils.MethodName;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;
import pk.gov.nadra.oneapp.models.crc.library.LibraryResponse;
import pk.gov.nadra.rahbar.android.data.ColumnNames;
import pk.gov.nadra.rahbar.android.data.NrcDataRDB;
import pk.gov.nadra.rahbar.android.db.backgroundtasks.GetAllCentersTask;

/* compiled from: AppointmentCenterNearMeFragment.kt */
@Metadata(d1 = {"\u0000Ò\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u0003B\u0007¢\u0006\u0004\b\u0004\u0010\u0005J\u0012\u00106\u001a\u0002072\b\u00108\u001a\u0004\u0018\u000109H\u0016J\u0010\u0010:\u001a\u0002072\u0006\u0010;\u001a\u00020<H\u0016J&\u0010=\u001a\u0004\u0018\u00010>2\u0006\u0010?\u001a\u00020@2\b\u0010A\u001a\u0004\u0018\u00010B2\b\u00108\u001a\u0004\u0018\u000109H\u0016J\u001a\u0010C\u001a\u0002072\u0006\u0010D\u001a\u00020>2\b\u00108\u001a\u0004\u0018\u000109H\u0016J\b\u0010E\u001a\u000207H\u0002J\b\u0010F\u001a\u000207H\u0002J\"\u0010G\u001a\u0002072\u0006\u0010H\u001a\u00020I2\u0006\u0010J\u001a\u00020I2\b\b\u0002\u0010K\u001a\u00020LH\u0002J\u0010\u0010O\u001a\u0002072\u0006\u0010P\u001a\u00020.H\u0016J\b\u0010Q\u001a\u000207H\u0002J\u0010\u0010R\u001a\u00020S2\u0006\u0010T\u001a\u00020UH\u0016J\b\u0010V\u001a\u000207H\u0002J\u0016\u0010W\u001a\u0002072\f\u00103\u001a\b\u0012\u0004\u0012\u00020504H\u0002R\u001b\u0010\u0006\u001a\u00020\u00078BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\n\u0010\u000b\u001a\u0004\b\b\u0010\tR\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\u00020\r8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R\u001a\u0010\u0011\u001a\u00020\u0012X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u0014\"\u0004\b\u0015\u0010\u0016R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\u001f\u001a\u0012\u0012\u0004\u0012\u00020!0\u001aj\b\u0012\u0004\u0012\u00020!` X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\"R\u000e\u0010#\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000R\u001a\u0010%\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020(0'0&X\u0082.¢\u0006\u0002\n\u0000R\u0014\u0010)\u001a\b\u0012\u0004\u0012\u00020*0&X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020,X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020.X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u000200X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u000202X\u0082D¢\u0006\u0002\n\u0000R\u0014\u00103\u001a\b\u0012\u0004\u0012\u00020504X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010M\u001a\u00020NX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006X"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/fragments/AppointmentCenterNearMeFragment;", "Landroidx/fragment/app/Fragment;", "Lcom/google/android/gms/maps/OnMapReadyCallback;", "Lcom/google/android/gms/maps/GoogleMap$OnMarkerClickListener;", "<init>", "()V", "appointmentSharedViewModel", "Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "getAppointmentSharedViewModel", "()Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "appointmentSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentCenterNearMeBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentCenterNearMeBinding;", "activity", "Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;)V", "dropdownCalling", "Lpk/gov/nadra/oneapp/commonutils/utils/MethodName;", "provincesList", "Ljava/util/ArrayList;", "Lpk/gov/nadra/oneapp/models/crc/library/LibraryResponse;", "districtsList", "selectedProvince", "selectedDistrict", "centersList", "Lkotlin/collections/ArrayList;", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data;", "Ljava/util/ArrayList;", "locationHelper", "Lpk/gov/nadra/oneapp/commonutils/utils/LocationHelper;", "permissionLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "", "", "gpsLauncher", "Landroid/content/Intent;", "currentLocation", "Landroid/location/Location;", "mMap", "Lcom/google/android/gms/maps/GoogleMap;", "locationsListAdapter", "Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentLocationsAdapter;", "DEFAULT_ZOOM", "", "nrcDataRDBList", "", "Lpk/gov/nadra/rahbar/android/data/NrcDataRDB;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onAttach", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "onViewCreated", Promotion.ACTION_VIEW, "setupLocationOrGpsPermissionLaunchers", "initializeLocation", "getAllCentersFromDB", ColumnNames.LATITUDE, "", ColumnNames.LONGITUDE, "distanceRange", "", "getAllCentersCommunicator", "Lpk/gov/nadra/rahbar/android/db/backgroundtasks/GetAllCentersTask$GetAllCentersCommunicator;", "onMapReady", "googleMap", "setUpMap", "onMarkerClick", "", "marker", "Lcom/google/android/gms/maps/model/Marker;", "adjustMapZoom", "filterCenters", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentCenterNearMeFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {
    private FragmentAppointmentCenterNearMeBinding _binding;
    public AppointmentSystemActivity activity;

    /* renamed from: appointmentSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy appointmentSharedViewModel;
    private Location currentLocation;
    private ActivityResultLauncher<Intent> gpsLauncher;
    private LocationHelper locationHelper;
    private AppointmentLocationsAdapter locationsListAdapter;
    private GoogleMap mMap;
    private ActivityResultLauncher<String[]> permissionLauncher;
    private MethodName dropdownCalling = MethodName.PROVINCE;
    private ArrayList<LibraryResponse> provincesList = new ArrayList<>();
    private ArrayList<LibraryResponse> districtsList = new ArrayList<>();
    private LibraryResponse selectedProvince = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private ArrayList<CentersResponse.Data> centersList = new ArrayList<>();
    private final float DEFAULT_ZOOM = 15.0f;
    private List<NrcDataRDB> nrcDataRDBList = new ArrayList();
    private final GetAllCentersTask.GetAllCentersCommunicator getAllCentersCommunicator = new GetAllCentersTask.GetAllCentersCommunicator() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda0
        @Override // pk.gov.nadra.rahbar.android.db.backgroundtasks.GetAllCentersTask.GetAllCentersCommunicator
        public final void onSuccess(List list) {
            AppointmentCenterNearMeFragment.getAllCentersCommunicator$lambda$11(this.f$0, list);
        }
    };

    public AppointmentCenterNearMeFragment() {
        final AppointmentCenterNearMeFragment appointmentCenterNearMeFragment = this;
        final Function0 function0 = null;
        this.appointmentSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(appointmentCenterNearMeFragment, Reflection.getOrCreateKotlinClass(AppointmentSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = appointmentCenterNearMeFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = appointmentCenterNearMeFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = appointmentCenterNearMeFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final AppointmentSharedViewModel getAppointmentSharedViewModel() {
        return (AppointmentSharedViewModel) this.appointmentSharedViewModel.getValue();
    }

    private final FragmentAppointmentCenterNearMeBinding getBinding() {
        FragmentAppointmentCenterNearMeBinding fragmentAppointmentCenterNearMeBinding = this._binding;
        Intrinsics.checkNotNull(fragmentAppointmentCenterNearMeBinding);
        return fragmentAppointmentCenterNearMeBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final AppointmentSystemActivity getActivity() {
        AppointmentSystemActivity appointmentSystemActivity = this.activity;
        if (appointmentSystemActivity != null) {
            return appointmentSystemActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(AppointmentSystemActivity appointmentSystemActivity) {
        Intrinsics.checkNotNullParameter(appointmentSystemActivity, "<set-?>");
        this.activity = appointmentSystemActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupLocationOrGpsPermissionLaunchers();
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity");
        setActivity((AppointmentSystemActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentAppointmentCenterNearMeBinding.inflate(inflater, container, false);
        return getBinding().getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        Fragment fragmentFindFragmentById = getChildFragmentManager().findFragmentById(R.id.appointment_location_mapView);
        Intrinsics.checkNotNull(fragmentFindFragmentById, "null cannot be cast to non-null type com.google.android.gms.maps.SupportMapFragment");
        ((SupportMapFragment) fragmentFindFragmentById).getMapAsync(this);
        initializeLocation();
        FragmentAppointmentCenterNearMeBinding binding = getBinding();
        binding.appointmentHeaderLayout.textTitle.setText(getString(pk.gov.nadra.oneapp.commonui.R.string.appointment));
        binding.appointmentHeaderLayout.textSubtitle.setText(" پیشگی وقت ");
        binding.appointmentHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.textBackUr.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentCenterNearMeFragment.onViewCreated$lambda$2$lambda$0(this.f$0, view2);
            }
        });
        binding.appointmentHeaderLayout.iconInfo.setVisibility(0);
        binding.appointmentHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentCenterNearMeFragment.onViewCreated$lambda$2$lambda$1(this.f$0, view2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$2$lambda$0(AppointmentCenterNearMeFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$2$lambda$1(AppointmentCenterNearMeFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = this$0.getActivity();
        String string = this$0.getString(pk.gov.nadra.oneapp.commonui.R.string.appointment_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.APPOINTMENT_GUIDELINES_URL, "");
    }

    private final void setupLocationOrGpsPermissionLaunchers() {
        this.permissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda10
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                AppointmentCenterNearMeFragment.setupLocationOrGpsPermissionLaunchers$lambda$3(this.f$0, (Map) obj);
            }
        });
        this.gpsLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda11
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                AppointmentCenterNearMeFragment.setupLocationOrGpsPermissionLaunchers$lambda$4(this.f$0, (ActivityResult) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setupLocationOrGpsPermissionLaunchers$lambda$3(AppointmentCenterNearMeFragment this$0, Map permissions) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(permissions, "permissions");
        LocationHelper locationHelper = this$0.locationHelper;
        if (locationHelper == null) {
            Intrinsics.throwUninitializedPropertyAccessException("locationHelper");
            locationHelper = null;
        }
        locationHelper.handlePermissionsResult(permissions);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setupLocationOrGpsPermissionLaunchers$lambda$4(AppointmentCenterNearMeFragment this$0, ActivityResult it) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(it, "it");
        LocationHelper locationHelper = this$0.locationHelper;
        if (locationHelper == null) {
            Intrinsics.throwUninitializedPropertyAccessException("locationHelper");
            locationHelper = null;
        }
        locationHelper.onGpsActivityResult();
    }

    private final void initializeLocation() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        AppointmentSystemActivity activity = getActivity();
        AppointmentCenterNearMeFragment appointmentCenterNearMeFragment = this;
        ActivityResultLauncher<String[]> activityResultLauncher = this.permissionLauncher;
        LocationHelper locationHelper = null;
        if (activityResultLauncher == null) {
            Intrinsics.throwUninitializedPropertyAccessException("permissionLauncher");
            activityResultLauncher = null;
        }
        ActivityResultLauncher<Intent> activityResultLauncher2 = this.gpsLauncher;
        if (activityResultLauncher2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("gpsLauncher");
            activityResultLauncher2 = null;
        }
        LocationHelper locationHelper2 = new LocationHelper(activity, appointmentCenterNearMeFragment, activityResultLauncher, activityResultLauncher2);
        this.locationHelper = locationHelper2;
        locationHelper2.setup(new Function1() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return AppointmentCenterNearMeFragment.initializeLocation$lambda$5(this.f$0, (Location) obj);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentCenterNearMeFragment.initializeLocation$lambda$6(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentCenterNearMeFragment.initializeLocation$lambda$7(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentCenterNearMeFragment.initializeLocation$lambda$8(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AppointmentCenterNearMeFragment.initializeLocation$lambda$9(this.f$0);
            }
        }, new Function1() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda9
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return AppointmentCenterNearMeFragment.initializeLocation$lambda$10(this.f$0, (String) obj);
            }
        });
        LocationHelper locationHelper3 = this.locationHelper;
        if (locationHelper3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("locationHelper");
        } else {
            locationHelper = locationHelper3;
        }
        locationHelper.fetchLocation();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$5(AppointmentCenterNearMeFragment this$0, Location location) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(location, "location");
        this$0.setUpMap();
        this$0.currentLocation = location;
        getAllCentersFromDB$default(this$0, location.getLatitude(), location.getLongitude(), 0, 4, null);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$6(AppointmentCenterNearMeFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$7(AppointmentCenterNearMeFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$8(AppointmentCenterNearMeFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$9(AppointmentCenterNearMeFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initializeLocation$lambda$10(AppointmentCenterNearMeFragment this$0, String it) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(it, "it");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        return Unit.INSTANCE;
    }

    static /* synthetic */ void getAllCentersFromDB$default(AppointmentCenterNearMeFragment appointmentCenterNearMeFragment, double d, double d2, int i, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            i = 20;
        }
        appointmentCenterNearMeFragment.getAllCentersFromDB(d, d2, i);
    }

    private final void getAllCentersFromDB(double latitude, double longitude, int distanceRange) {
        new GetAllCentersTask(requireActivity(), this.getAllCentersCommunicator).execute(new Object[]{Double.valueOf(latitude), Double.valueOf(longitude), Integer.valueOf(distanceRange)});
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void getAllCentersCommunicator$lambda$11(AppointmentCenterNearMeFragment this$0, List list) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        LoaderManager.INSTANCE.hideLoader(this$0.getActivity());
        this$0.nrcDataRDBList = list;
        this$0.filterCenters(list);
        GoogleMap googleMap = this$0.mMap;
        if (googleMap == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap = null;
        }
        googleMap.clear();
        Location location = this$0.currentLocation;
        if (location == null) {
            Intrinsics.throwUninitializedPropertyAccessException("currentLocation");
            location = null;
        }
        double latitude = location.getLatitude();
        Location location2 = this$0.currentLocation;
        if (location2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("currentLocation");
            location2 = null;
        }
        LatLng latLng = new LatLng(latitude, location2.getLongitude());
        GoogleMap googleMap2 = this$0.mMap;
        if (googleMap2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap2 = null;
        }
        googleMap2.addMarker(new MarkerOptions().position(latLng).icon(BitmapDescriptorFactory.fromResource(pk.gov.nadra.rahbar.android.R.drawable.current_location_pin)));
        GoogleMap googleMap3 = this$0.mMap;
        if (googleMap3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap3 = null;
        }
        googleMap3.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, this$0.DEFAULT_ZOOM));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            NrcDataRDB nrcDataRDB = (NrcDataRDB) it.next();
            BitmapDescriptor bitmapDescriptorFromResource = BitmapDescriptorFactory.fromResource(pk.gov.nadra.rahbar.android.R.drawable.marker_single_shift);
            Intrinsics.checkNotNullExpressionValue(bitmapDescriptorFromResource, "fromResource(...)");
            GoogleMap googleMap4 = this$0.mMap;
            if (googleMap4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mMap");
                googleMap4 = null;
            }
            googleMap4.addMarker(new MarkerOptions().position(new LatLng(pk.gov.nadra.rahbar.android.util.Util.parseStringToDouble(nrcDataRDB.getLatitude()), pk.gov.nadra.rahbar.android.util.Util.parseStringToDouble(nrcDataRDB.getLongitude()))).icon(bitmapDescriptorFromResource));
        }
        this$0.adjustMapZoom();
    }

    @Override // com.google.android.gms.maps.OnMapReadyCallback
    public void onMapReady(GoogleMap googleMap) {
        Intrinsics.checkNotNullParameter(googleMap, "googleMap");
        this.mMap = googleMap;
        GoogleMap googleMap2 = null;
        if (googleMap == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap = null;
        }
        googleMap.getUiSettings().setMyLocationButtonEnabled(true);
        GoogleMap googleMap3 = this.mMap;
        if (googleMap3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap3 = null;
        }
        googleMap3.getUiSettings().setZoomControlsEnabled(true);
        GoogleMap googleMap4 = this.mMap;
        if (googleMap4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap4 = null;
        }
        googleMap4.getUiSettings().setMyLocationButtonEnabled(true);
        GoogleMap googleMap5 = this.mMap;
        if (googleMap5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
        } else {
            googleMap2 = googleMap5;
        }
        googleMap2.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda1
            @Override // com.google.android.gms.maps.GoogleMap.OnMapLongClickListener
            public final void onMapLongClick(LatLng latLng) {
                AppointmentCenterNearMeFragment.onMapReady$lambda$13(this.f$0, latLng);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onMapReady$lambda$13(AppointmentCenterNearMeFragment this$0, LatLng it) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(it, "it");
        GoogleMap googleMap = this$0.mMap;
        GoogleMap googleMap2 = null;
        if (googleMap == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap = null;
        }
        googleMap.clear();
        GoogleMap googleMap3 = this$0.mMap;
        if (googleMap3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
        } else {
            googleMap2 = googleMap3;
        }
        googleMap2.addMarker(new MarkerOptions().position(it));
        Location location = new Location("");
        location.setLatitude(it.latitude);
        location.setLongitude(it.longitude);
        this$0.currentLocation = location;
    }

    private final void setUpMap() {
        GoogleMap googleMap = this.mMap;
        GoogleMap googleMap2 = null;
        if (googleMap == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap = null;
        }
        UiSettings uiSettings = googleMap.getUiSettings();
        Intrinsics.checkNotNullExpressionValue(uiSettings, "getUiSettings(...)");
        uiSettings.setCompassEnabled(false);
        uiSettings.setRotateGesturesEnabled(false);
        uiSettings.setTiltGesturesEnabled(true);
        uiSettings.setZoomControlsEnabled(false);
        uiSettings.setMapToolbarEnabled(false);
        GoogleMap googleMap3 = this.mMap;
        if (googleMap3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap3 = null;
        }
        googleMap3.setTrafficEnabled(false);
        GoogleMap googleMap4 = this.mMap;
        if (googleMap4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap4 = null;
        }
        googleMap4.setIndoorEnabled(false);
        GoogleMap googleMap5 = this.mMap;
        if (googleMap5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap5 = null;
        }
        googleMap5.setBuildingsEnabled(false);
        GoogleMap googleMap6 = this.mMap;
        if (googleMap6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap6 = null;
        }
        googleMap6.setPadding(0, 200, 0, 0);
        GoogleMap googleMap7 = this.mMap;
        if (googleMap7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap7 = null;
        }
        googleMap7.setMinZoomPreference(10.0f);
        GoogleMap googleMap8 = this.mMap;
        if (googleMap8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap8 = null;
        }
        googleMap8.setMaxZoomPreference(18.0f);
        GoogleMap googleMap9 = this.mMap;
        if (googleMap9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap9 = null;
        }
        googleMap9.setOnMarkerClickListener(this);
        try {
            GoogleMap googleMap10 = this.mMap;
            if (googleMap10 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mMap");
            } else {
                googleMap2 = googleMap10;
            }
            googleMap2.setMapStyle(MapStyleOptions.loadRawResourceStyle(getActivity(), pk.gov.nadra.rahbar.android.R.raw.map_style));
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override // com.google.android.gms.maps.GoogleMap.OnMarkerClickListener
    public boolean onMarkerClick(Marker marker) {
        GoogleMap googleMap;
        Object next;
        Intrinsics.checkNotNullParameter(marker, "marker");
        Iterator<T> it = this.nrcDataRDBList.iterator();
        while (true) {
            googleMap = null;
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            NrcDataRDB nrcDataRDB = (NrcDataRDB) next;
            if (Intrinsics.areEqual(nrcDataRDB.getLatitude(), String.valueOf(marker.getPosition().latitude)) && Intrinsics.areEqual(nrcDataRDB.getLongitude(), String.valueOf(marker.getPosition().longitude))) {
                break;
            }
        }
        final NrcDataRDB nrcDataRDB2 = (NrcDataRDB) next;
        if (nrcDataRDB2 == null) {
            return true;
        }
        GoogleMap googleMap2 = this.mMap;
        if (googleMap2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
        } else {
            googleMap = googleMap2;
        }
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(pk.gov.nadra.rahbar.android.util.Util.parseStringToDouble(nrcDataRDB2.getLatitude()), pk.gov.nadra.rahbar.android.util.Util.parseStringToDouble(nrcDataRDB2.getLongitude())), 16), new GoogleMap.CancelableCallback() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment.onMarkerClick.1
            @Override // com.google.android.gms.maps.GoogleMap.CancelableCallback
            public void onCancel() {
            }

            @Override // com.google.android.gms.maps.GoogleMap.CancelableCallback
            public void onFinish() {
                AppointmentCenterNearMeFragment.this.getAppointmentSharedViewModel().setSelectedNrcDataRDB(nrcDataRDB2);
                AppointmentCenterNearMeFragment.this.getActivity().navigateToFragment(R.id.appointmentCenterDetailFragment);
            }
        });
        return true;
    }

    private final void adjustMapZoom() {
        double dMin = Double.MAX_VALUE;
        double dMax = Double.MIN_VALUE;
        double dMax2 = Double.MIN_VALUE;
        double dMin2 = Double.MAX_VALUE;
        for (NrcDataRDB nrcDataRDB : this.nrcDataRDBList) {
            double stringToDouble = pk.gov.nadra.rahbar.android.util.Util.parseStringToDouble(nrcDataRDB.getLatitude());
            double stringToDouble2 = pk.gov.nadra.rahbar.android.util.Util.parseStringToDouble(nrcDataRDB.getLongitude());
            dMin = Math.min(dMin, stringToDouble);
            dMin2 = Math.min(dMin2, stringToDouble2);
            dMax = Math.max(dMax, stringToDouble);
            dMax2 = Math.max(dMax2, stringToDouble2);
        }
        GoogleMap googleMap = this.mMap;
        if (googleMap == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mMap");
            googleMap = null;
        }
        double d = dMax + dMin;
        double d2 = 2;
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(d / d2, (dMax2 + dMin2) / d2), 9));
    }

    private final void filterCenters(List<NrcDataRDB> nrcDataRDBList) {
        CollectionsKt.retainAll((List) nrcDataRDBList, new Function1() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentCenterNearMeFragment$$ExternalSyntheticLambda12
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return Boolean.valueOf(AppointmentCenterNearMeFragment.filterCenters$lambda$15((NrcDataRDB) obj));
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean filterCenters$lambda$15(NrcDataRDB center) {
        Intrinsics.checkNotNullParameter(center, "center");
        String locationType = center.getLocationType();
        return locationType != null && StringsKt.equals(locationType, "nrc", true);
    }
}