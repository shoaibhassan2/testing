package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.google.android.gms.analytics.ecommerce.Promotion;
import java.util.Arrays;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.StringsKt;
import org.apache.commons.lang3.StringUtils;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentAppointmentSubmissionBinding;
import pk.gov.nadra.oneapp.appointmentsystem.viewmodel.AppointmentSharedViewModel;
import pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.appointment.AvailableSlots;
import pk.gov.nadra.oneapp.models.appointment.BookAppointmentResponse;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;
import pk.gov.nadra.oneapp.models.appointment.SlotHoldResponse;

/* compiled from: AppointmentSubmissionFragment.kt */
@Metadata(d1 = {"\u0000z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010)\u001a\u00020*2\b\u0010+\u001a\u0004\u0018\u00010,H\u0016J\u0010\u0010-\u001a\u00020*2\u0006\u0010.\u001a\u00020/H\u0016J&\u00100\u001a\u0004\u0018\u0001012\u0006\u00102\u001a\u0002032\b\u00104\u001a\u0004\u0018\u0001052\b\u0010+\u001a\u0004\u0018\u00010,H\u0016J\u001a\u00106\u001a\u00020*2\u0006\u00107\u001a\u0002012\b\u0010+\u001a\u0004\u0018\u00010,H\u0016J\u0016\u00108\u001a\u00020*2\u0006\u00109\u001a\u00020\u00162\u0006\u0010:\u001a\u00020;R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u001a\u0010\u0015\u001a\u00020\u0016X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001aR\u001a\u0010\u001b\u001a\u00020\u001cX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R\u000e\u0010!\u001a\u00020\"X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020&X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020(X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006<"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/fragments/AppointmentSubmissionFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "appointmentSharedViewModel", "Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "getAppointmentSharedViewModel", "()Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "appointmentSharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentSubmissionBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/appointmentsystem/databinding/FragmentAppointmentSubmissionBinding;", "activity", "Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/appointmentsystem/views/AppointmentSystemActivity;)V", "formattedMessage", "", "getFormattedMessage", "()Ljava/lang/String;", "setFormattedMessage", "(Ljava/lang/String;)V", "spannable", "Landroid/text/Spannable;", "getSpannable", "()Landroid/text/Spannable;", "setSpannable", "(Landroid/text/Spannable;)V", "selectedCenter", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data;", "selectedSlot", "Lpk/gov/nadra/oneapp/models/appointment/AvailableSlots$Data;", "slotHoldResponse", "Lpk/gov/nadra/oneapp/models/appointment/SlotHoldResponse$Data;", "bookAppointmentResponse", "Lpk/gov/nadra/oneapp/models/appointment/BookAppointmentResponse$Data;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onAttach", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "onViewCreated", Promotion.ACTION_VIEW, "applySpan", "text", TypedValues.Custom.S_COLOR, "", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentSubmissionFragment extends Fragment {
    private FragmentAppointmentSubmissionBinding _binding;
    public AppointmentSystemActivity activity;

    /* renamed from: appointmentSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy appointmentSharedViewModel;
    public Spannable spannable;
    private String formattedMessage = "";
    private CentersResponse.Data selectedCenter = new CentersResponse.Data(null, null, null, null, null, 31, null);
    private AvailableSlots.Data selectedSlot = new AvailableSlots.Data(0, null, false, 7, null);
    private SlotHoldResponse.Data slotHoldResponse = new SlotHoldResponse.Data(null, null, 0, null, null, null, null, 0, 255, null);
    private BookAppointmentResponse.Data bookAppointmentResponse = new BookAppointmentResponse.Data(null, null, null, null, null, null, 0, null, null, null, null, null, null, null, null, null, null, 0, 262143, null);

    public AppointmentSubmissionFragment() {
        final AppointmentSubmissionFragment appointmentSubmissionFragment = this;
        final Function0 function0 = null;
        this.appointmentSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(appointmentSubmissionFragment, Reflection.getOrCreateKotlinClass(AppointmentSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentSubmissionFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = appointmentSubmissionFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentSubmissionFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = appointmentSubmissionFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentSubmissionFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = appointmentSubmissionFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    private final AppointmentSharedViewModel getAppointmentSharedViewModel() {
        return (AppointmentSharedViewModel) this.appointmentSharedViewModel.getValue();
    }

    private final FragmentAppointmentSubmissionBinding getBinding() {
        FragmentAppointmentSubmissionBinding fragmentAppointmentSubmissionBinding = this._binding;
        Intrinsics.checkNotNull(fragmentAppointmentSubmissionBinding);
        return fragmentAppointmentSubmissionBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final AppointmentSystemActivity getActivity() {
        AppointmentSystemActivity appointmentSystemActivity = this.activity;
        if (appointmentSystemActivity != null) {
            return appointmentSystemActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(AppointmentSystemActivity appointmentSystemActivity) {
        Intrinsics.checkNotNullParameter(appointmentSystemActivity, "<set-?>");
        this.activity = appointmentSystemActivity;
    }

    public final String getFormattedMessage() {
        return this.formattedMessage;
    }

    public final void setFormattedMessage(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.formattedMessage = str;
    }

    public final Spannable getSpannable() {
        Spannable spannable = this.spannable;
        if (spannable != null) {
            return spannable;
        }
        Intrinsics.throwUninitializedPropertyAccessException("spannable");
        return null;
    }

    public final void setSpannable(Spannable spannable) {
        Intrinsics.checkNotNullParameter(spannable, "<set-?>");
        this.spannable = spannable;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.appointmentsystem.views.AppointmentSystemActivity");
        setActivity((AppointmentSystemActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentAppointmentSubmissionBinding.inflate(inflater, container, false);
        return getBinding().getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        this.selectedCenter = getAppointmentSharedViewModel().getSelectedCenterData();
        this.selectedSlot = getAppointmentSharedViewModel().getSelectedSlotData();
        this.slotHoldResponse = getAppointmentSharedViewModel().getSlotHoldResponse();
        this.bookAppointmentResponse = getAppointmentSharedViewModel().getBookAppointmentResponse();
        FragmentAppointmentSubmissionBinding binding = getBinding();
        binding.appointmentHeaderLayout.textTitle.setText(getString(R.string.appointment));
        binding.appointmentHeaderLayout.textSubtitle.setText(" پیشگی وقت ");
        binding.appointmentHeaderLayout.textSubtitle.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.textBackUr.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        binding.appointmentHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentSubmissionFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentSubmissionFragment.onViewCreated$lambda$3$lambda$0(this.f$0, view2);
            }
        });
        binding.appointmentHeaderLayout.iconInfo.setVisibility(0);
        binding.appointmentHeaderLayout.iconInfo.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentSubmissionFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentSubmissionFragment.onViewCreated$lambda$3$lambda$1(this.f$0, view2);
            }
        });
        TextView textView = binding.appointmentScheduledHeadingTextView;
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = getActivity();
        String string = getString(R.string.appointment_scheduled);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util, activity, string, " (آپ کا پیشگی وقت طے ہو گیاہے) ", 0, false, 12, null));
        binding.appointmentPunctualUrduHeadingTextView.setTypeface(ResourcesCompat.getFont(getActivity(), pk.gov.nadra.oneapp.commonui.R.font.nadra_nastaleeq));
        String str = getAppointmentSharedViewModel().getSelectedDate() + StringUtils.SPACE + Util.INSTANCE.convertTimeToAmPm(this.selectedSlot.getSlot());
        String strCapitalizeWords = Util.INSTANCE.capitalizeWords(this.selectedCenter.getName());
        String strValueOf = String.valueOf(this.bookAppointmentResponse.getId());
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        String string2 = getString(R.string.appointment_scheduled_message);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        String str2 = String.format(string2, Arrays.copyOf(new Object[]{str, strCapitalizeWords, strValueOf}, 3));
        Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
        this.formattedMessage = str2;
        setSpannable(new SpannableStringBuilder(this.formattedMessage));
        applySpan(str, Color.parseColor("#197AE9"));
        applySpan(strCapitalizeWords, Color.parseColor("#197AE9"));
        applySpan(strValueOf, Color.parseColor("#197AE9"));
        binding.appointmentDatetimeMessageTextView.setText(getSpannable());
        ConfigurableButton configurableButton = binding.appointmentSubmissionButtonLayout.commonButton;
        Util util2 = Util.INSTANCE;
        AppointmentSystemActivity activity2 = getActivity();
        String string3 = getString(R.string.ok);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util2, activity2, string3, " (ٹھیک ہے) ", 0, false, 12, null));
        binding.appointmentSubmissionButtonLayout.commonButton.setFilled(true);
        binding.appointmentSubmissionButtonLayout.commonButton.setInsetTop(0);
        binding.appointmentSubmissionButtonLayout.commonButton.setInsetBottom(0);
        binding.appointmentSubmissionButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.fragments.AppointmentSubmissionFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                AppointmentSubmissionFragment.onViewCreated$lambda$3$lambda$2(this.f$0, view2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$3$lambda$0(AppointmentSubmissionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToFragment(R.id.appointmentsListFragment);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$3$lambda$1(AppointmentSubmissionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Util util = Util.INSTANCE;
        AppointmentSystemActivity activity = this$0.getActivity();
        String string = this$0.getString(pk.gov.nadra.oneapp.commonui.R.string.appointment_guidelines);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        util.navigateToViewGuidelines(activity, string, Constant.APPOINTMENT_GUIDELINES_URL, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$3$lambda$2(AppointmentSubmissionFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToFragment(R.id.appointmentsListFragment);
    }

    public final void applySpan(String text, int color) {
        Intrinsics.checkNotNullParameter(text, "text");
        int iIndexOf$default = StringsKt.indexOf$default((CharSequence) this.formattedMessage, text, 0, false, 6, (Object) null);
        if (iIndexOf$default != -1) {
            getSpannable().setSpan(new StyleSpan(1), iIndexOf$default, text.length() + iIndexOf$default, 33);
            getSpannable().setSpan(new ForegroundColorSpan(color), iIndexOf$default, text.length() + iIndexOf$default, 33);
        }
    }
}