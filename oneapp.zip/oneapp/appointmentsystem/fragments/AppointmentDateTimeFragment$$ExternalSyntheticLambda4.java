package pk.gov.nadra.oneapp.appointmentsystem.fragments;

import android.view.View;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.FragmentAppointmentDateTimeBinding;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentDateTimeFragment$$ExternalSyntheticLambda4 implements View.OnClickListener {
    public final /* synthetic */ FragmentAppointmentDateTimeBinding f$1;

    public /* synthetic */ AppointmentDateTimeFragment$$ExternalSyntheticLambda4(FragmentAppointmentDateTimeBinding fragmentAppointmentDateTimeBinding) {
        binding = fragmentAppointmentDateTimeBinding;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AppointmentDateTimeFragment.onViewCreated$lambda$9$lambda$4(this.f$0, binding, view);
    }
}