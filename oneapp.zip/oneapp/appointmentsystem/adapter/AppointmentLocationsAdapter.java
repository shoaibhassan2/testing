package pk.gov.nadra.oneapp.appointmentsystem.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.LocationListItemLayoutBinding;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;

/* compiled from: AppointmentLocationsAdapter.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\b\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001\u0016B)\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\u0004\b\t\u0010\nJ\u001c\u0010\u000b\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016J\u0014\u0010\u0010\u001a\u00020\b2\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004J\b\u0010\u0012\u001a\u00020\u000fH\u0016J\u001c\u0010\u0013\u001a\u00020\b2\n\u0010\u0014\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u000fH\u0016R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0017"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentLocationsAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentLocationsAdapter$ViewHolder;", "locationsList", "", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data;", "onItemClicked", "Lkotlin/Function1;", "", "<init>", "(Ljava/util/List;Lkotlin/jvm/functions/Function1;)V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "updateLocationList", "updatedLocationList", "getItemCount", "onBindViewHolder", "holder", "position", "ViewHolder", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentLocationsAdapter extends RecyclerView.Adapter<ViewHolder> {
    private List<CentersResponse.Data> locationsList;
    private final Function1<CentersResponse.Data, Unit> onItemClicked;

    /* JADX WARN: Multi-variable type inference failed */
    public AppointmentLocationsAdapter(List<CentersResponse.Data> locationsList, Function1<? super CentersResponse.Data, Unit> onItemClicked) {
        Intrinsics.checkNotNullParameter(locationsList, "locationsList");
        Intrinsics.checkNotNullParameter(onItemClicked, "onItemClicked");
        this.locationsList = locationsList;
        this.onItemClicked = onItemClicked;
    }

    /* compiled from: AppointmentLocationsAdapter.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentLocationsAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/LocationListItemLayoutBinding;", "<init>", "(Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentLocationsAdapter;Lpk/gov/nadra/oneapp/appointmentsystem/databinding/LocationListItemLayoutBinding;)V", "getBinding", "()Lpk/gov/nadra/oneapp/appointmentsystem/databinding/LocationListItemLayoutBinding;", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public final class ViewHolder extends RecyclerView.ViewHolder {
        private final LocationListItemLayoutBinding binding;
        final /* synthetic */ AppointmentLocationsAdapter this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ViewHolder(AppointmentLocationsAdapter appointmentLocationsAdapter, LocationListItemLayoutBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.this$0 = appointmentLocationsAdapter;
            this.binding = binding;
        }

        public final LocationListItemLayoutBinding getBinding() {
            return this.binding;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        LocationListItemLayoutBinding locationListItemLayoutBindingInflate = LocationListItemLayoutBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(locationListItemLayoutBindingInflate, "inflate(...)");
        return new ViewHolder(this, locationListItemLayoutBindingInflate);
    }

    public final void updateLocationList(List<CentersResponse.Data> updatedLocationList) {
        Intrinsics.checkNotNullParameter(updatedLocationList, "updatedLocationList");
        this.locationsList = updatedLocationList;
        notifyDataSetChanged();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.locationsList.size();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder holder, final int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        CentersResponse.Data data = this.locationsList.get(position);
        LocationListItemLayoutBinding binding = holder.getBinding();
        binding.locationListItemNameTextView.setText(Util.INSTANCE.capitalizeWords(data.getName()));
        binding.locationListItemTimingTextView.setText(Util.INSTANCE.convertTimeWithSecondsToAmPm(data.getStartTime()) + " - " + Util.INSTANCE.convertTimeWithSecondsToAmPm(data.getEndTime()));
        binding.locationCardView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.appointmentsystem.adapter.AppointmentLocationsAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AppointmentLocationsAdapter.onBindViewHolder$lambda$3$lambda$2$lambda$1$lambda$0(this.f$0, position, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$3$lambda$2$lambda$1$lambda$0(AppointmentLocationsAdapter this$0, int i, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.onItemClicked.invoke(this$0.locationsList.get(i));
    }
}