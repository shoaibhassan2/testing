package pk.gov.nadra.oneapp.appointmentsystem.adapter;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentsListAdapter$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public final /* synthetic */ AppointmentsListAdapter f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ AppointmentsListAdapter$$ExternalSyntheticLambda1(AppointmentsListAdapter appointmentsListAdapter, int i) {
        this = appointmentsListAdapter;
        position = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AppointmentsListAdapter.onBindViewHolder$lambda$4$lambda$3$lambda$2$lambda$1(data, this, position, view);
    }
}