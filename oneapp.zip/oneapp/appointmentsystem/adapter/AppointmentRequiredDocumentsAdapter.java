package pk.gov.nadra.oneapp.appointmentsystem.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.appointmentsystem.databinding.AppointmentDocumentListItemLayoutBinding;
import pk.gov.nadra.oneapp.models.supportingDocument.RequiredDocuments;

/* compiled from: AppointmentRequiredDocumentsAdapter.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001\u0014B\u001f\u0012\u0016\u0010\u0003\u001a\u0012\u0012\u0004\u0012\u00020\u00050\u0006j\b\u0012\u0004\u0012\u00020\u0005`\u0004¢\u0006\u0004\b\u0007\u0010\bJ\u001c\u0010\n\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0016J\b\u0010\u000f\u001a\u00020\u000eH\u0016J\u001c\u0010\u0010\u001a\u00020\u00112\n\u0010\u0012\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u000eH\u0016R \u0010\u0003\u001a\u0012\u0012\u0004\u0012\u00020\u00050\u0006j\b\u0012\u0004\u0012\u00020\u0005`\u0004X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\t¨\u0006\u0015"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentRequiredDocumentsAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentRequiredDocumentsAdapter$ViewHolder;", "documentsList", "Lkotlin/collections/ArrayList;", "Lpk/gov/nadra/oneapp/models/supportingDocument/RequiredDocuments$RequiredDocumentType;", "Ljava/util/ArrayList;", "<init>", "(Ljava/util/ArrayList;)V", "Ljava/util/ArrayList;", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "getItemCount", "onBindViewHolder", "", "holder", "position", "ViewHolder", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentRequiredDocumentsAdapter extends RecyclerView.Adapter<ViewHolder> {
    private ArrayList<RequiredDocuments.RequiredDocumentType> documentsList;

    public AppointmentRequiredDocumentsAdapter(ArrayList<RequiredDocuments.RequiredDocumentType> documentsList) {
        Intrinsics.checkNotNullParameter(documentsList, "documentsList");
        this.documentsList = documentsList;
    }

    /* compiled from: AppointmentRequiredDocumentsAdapter.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentRequiredDocumentsAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lpk/gov/nadra/oneapp/appointmentsystem/databinding/AppointmentDocumentListItemLayoutBinding;", "<init>", "(Lpk/gov/nadra/oneapp/appointmentsystem/adapter/AppointmentRequiredDocumentsAdapter;Lpk/gov/nadra/oneapp/appointmentsystem/databinding/AppointmentDocumentListItemLayoutBinding;)V", "getBinding", "()Lpk/gov/nadra/oneapp/appointmentsystem/databinding/AppointmentDocumentListItemLayoutBinding;", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public final class ViewHolder extends RecyclerView.ViewHolder {
        private final AppointmentDocumentListItemLayoutBinding binding;
        final /* synthetic */ AppointmentRequiredDocumentsAdapter this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ViewHolder(AppointmentRequiredDocumentsAdapter appointmentRequiredDocumentsAdapter, AppointmentDocumentListItemLayoutBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.this$0 = appointmentRequiredDocumentsAdapter;
            this.binding = binding;
        }

        public final AppointmentDocumentListItemLayoutBinding getBinding() {
            return this.binding;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        AppointmentDocumentListItemLayoutBinding appointmentDocumentListItemLayoutBindingInflate = AppointmentDocumentListItemLayoutBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(appointmentDocumentListItemLayoutBindingInflate, "inflate(...)");
        return new ViewHolder(this, appointmentDocumentListItemLayoutBindingInflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.documentsList.size();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder holder, int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        holder.getBinding().documentListItemNameTextView.setText(this.documentsList.get(position).getName());
    }
}