package pk.gov.nadra.oneapp.appointmentsystem.adapter;

import android.view.View;
import pk.gov.nadra.oneapp.appointmentsystem.adapter.AppointmentAvailableSlotsAdapter;
import pk.gov.nadra.oneapp.models.appointment.AvailableSlots;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentAvailableSlotsAdapter$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ AppointmentAvailableSlotsAdapter.ViewHolder f$1;
    public final /* synthetic */ AvailableSlots.Data f$2;

    public /* synthetic */ AppointmentAvailableSlotsAdapter$$ExternalSyntheticLambda0(AppointmentAvailableSlotsAdapter.ViewHolder viewHolder, AvailableSlots.Data data) {
        holder = viewHolder;
        data = data;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AppointmentAvailableSlotsAdapter.onBindViewHolder$lambda$3$lambda$2$lambda$1$lambda$0(this.f$0, holder, data, view);
    }
}