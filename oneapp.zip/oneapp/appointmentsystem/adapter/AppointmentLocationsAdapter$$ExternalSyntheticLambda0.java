package pk.gov.nadra.oneapp.appointmentsystem.adapter;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class AppointmentLocationsAdapter$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ int f$1;

    public /* synthetic */ AppointmentLocationsAdapter$$ExternalSyntheticLambda0(int i) {
        position = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AppointmentLocationsAdapter.onBindViewHolder$lambda$3$lambda$2$lambda$1$lambda$0(this.f$0, position, view);
    }
}