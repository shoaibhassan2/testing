package pk.gov.nadra.oneapp.appointmentsystem.viewmodel;

import androidx.lifecycle.ViewModel;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.apache.commons.imaging.formats.jpeg.iptc.IptcConstants;
import pk.gov.nadra.oneapp.models.appointment.AvailableSlots;
import pk.gov.nadra.oneapp.models.appointment.BookAppointmentResponse;
import pk.gov.nadra.oneapp.models.appointment.CentersResponse;
import pk.gov.nadra.oneapp.models.appointment.SlotHoldResponse;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;
import pk.gov.nadra.oneapp.models.crc.library.LibraryResponse;
import pk.gov.nadra.rahbar.android.data.NrcDataRDB;

/* compiled from: AppointmentSharedViewModel.kt */
@Metadata(d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0014\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001a\u0010\n\u001a\u00020\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0010\u001a\u00020\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\r\"\u0004\b\u0012\u0010\u000fR\u001a\u0010\u0013\u001a\u00020\u0014X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R\u001a\u0010\u0019\u001a\u00020\u001aX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR\u001a\u0010\u001f\u001a\u00020 X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\"\"\u0004\b#\u0010$R\u001a\u0010%\u001a\u00020&X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b'\u0010(\"\u0004\b)\u0010*R,\u0010+\u001a\u0012\u0012\u0004\u0012\u00020-0.j\b\u0012\u0004\u0012\u00020-`,X\u0086\u000e¢\u0006\u0010\n\u0002\u00103\u001a\u0004\b/\u00100\"\u0004\b1\u00102R\u001a\u00104\u001a\u00020-X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b5\u00106\"\u0004\b7\u00108R\u001a\u00109\u001a\u00020:X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b;\u0010<\"\u0004\b=\u0010>R\u001a\u0010?\u001a\u00020@X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bA\u0010B\"\u0004\bC\u0010DR\u001a\u0010E\u001a\u00020&X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bF\u0010(\"\u0004\bG\u0010*R\u001a\u0010H\u001a\u00020&X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bI\u0010(\"\u0004\bJ\u0010*R\u001a\u0010K\u001a\u00020&X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bL\u0010(\"\u0004\bM\u0010*R\u001a\u0010N\u001a\u00020&X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bO\u0010(\"\u0004\bP\u0010*R\u001a\u0010Q\u001a\u00020&X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bR\u0010(\"\u0004\bS\u0010*R\u001a\u0010T\u001a\u00020UX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bV\u0010W\"\u0004\bX\u0010YR\u001a\u0010Z\u001a\u00020[X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bZ\u0010\\\"\u0004\b]\u0010^¨\u0006_"}, d2 = {"Lpk/gov/nadra/oneapp/appointmentsystem/viewmodel/AppointmentSharedViewModel;", "Landroidx/lifecycle/ViewModel;", "<init>", "()V", "reactNativeData", "Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "getReactNativeData", "()Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "setReactNativeData", "(Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;)V", "selectedProvince", "Lpk/gov/nadra/oneapp/models/crc/library/LibraryResponse;", "getSelectedProvince", "()Lpk/gov/nadra/oneapp/models/crc/library/LibraryResponse;", "setSelectedProvince", "(Lpk/gov/nadra/oneapp/models/crc/library/LibraryResponse;)V", "selectedDistrict", "getSelectedDistrict", "setSelectedDistrict", "selectedCenterData", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data;", "getSelectedCenterData", "()Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data;", "setSelectedCenterData", "(Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data;)V", "selectedDocumentType", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType;", "getSelectedDocumentType", "()Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType;", "setSelectedDocumentType", "(Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType;)V", "selectedApplicationType", "Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType$ApplicationType;", "getSelectedApplicationType", "()Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType$ApplicationType;", "setSelectedApplicationType", "(Lpk/gov/nadra/oneapp/models/appointment/CentersResponse$Data$DocumentType$ApplicationType;)V", "selectedDate", "", "getSelectedDate", "()Ljava/lang/String;", "setSelectedDate", "(Ljava/lang/String;)V", "availableSlotsList", "Lkotlin/collections/ArrayList;", "Lpk/gov/nadra/oneapp/models/appointment/AvailableSlots$Data;", "Ljava/util/ArrayList;", "getAvailableSlotsList", "()Ljava/util/ArrayList;", "setAvailableSlotsList", "(Ljava/util/ArrayList;)V", "Ljava/util/ArrayList;", "selectedSlotData", "getSelectedSlotData", "()Lpk/gov/nadra/oneapp/models/appointment/AvailableSlots$Data;", "setSelectedSlotData", "(Lpk/gov/nadra/oneapp/models/appointment/AvailableSlots$Data;)V", "slotHoldResponse", "Lpk/gov/nadra/oneapp/models/appointment/SlotHoldResponse$Data;", "getSlotHoldResponse", "()Lpk/gov/nadra/oneapp/models/appointment/SlotHoldResponse$Data;", "setSlotHoldResponse", "(Lpk/gov/nadra/oneapp/models/appointment/SlotHoldResponse$Data;)V", "bookAppointmentResponse", "Lpk/gov/nadra/oneapp/models/appointment/BookAppointmentResponse$Data;", "getBookAppointmentResponse", "()Lpk/gov/nadra/oneapp/models/appointment/BookAppointmentResponse$Data;", "setBookAppointmentResponse", "(Lpk/gov/nadra/oneapp/models/appointment/BookAppointmentResponse$Data;)V", "name", "getName", "setName", "citizenNumber", "getCitizenNumber", "setCitizenNumber", "mobileNumber", "getMobileNumber", "setMobileNumber", "email", "getEmail", "setEmail", "alpha2", "getAlpha2", "setAlpha2", "selectedNrcDataRDB", "Lpk/gov/nadra/rahbar/android/data/NrcDataRDB;", "getSelectedNrcDataRDB", "()Lpk/gov/nadra/rahbar/android/data/NrcDataRDB;", "setSelectedNrcDataRDB", "(Lpk/gov/nadra/rahbar/android/data/NrcDataRDB;)V", "isFromCenterNearMe", "", "()Z", "setFromCenterNearMe", "(Z)V", "appointmentSystem_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppointmentSharedViewModel extends ViewModel {
    private boolean isFromCenterNearMe;
    private ReactNativeData reactNativeData = new ReactNativeData(null, null, null, null, null, null, null, false, false, false, null, null, false, null, null, null, false, null, false, false, false, false, null, null, false, false, false, null, false, false, null, null, null, false, null, null, null, false, false, null, null, null, null, false, null, null, null, null, null, null, -1, 262143, null);
    private LibraryResponse selectedProvince = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private LibraryResponse selectedDistrict = new LibraryResponse(0, null, null, null, null, false, 0, 0, 0, null, IptcConstants.IMAGE_RESOURCE_BLOCK_OBSOLETE_PHOTOSHOP_TAG2, null);
    private CentersResponse.Data selectedCenterData = new CentersResponse.Data(null, null, null, null, null, 31, null);
    private CentersResponse.Data.DocumentType selectedDocumentType = new CentersResponse.Data.DocumentType(null, "smartid", "National Identity Card", 1, null);
    private CentersResponse.Data.DocumentType.ApplicationType selectedApplicationType = new CentersResponse.Data.DocumentType.ApplicationType("new", "New");
    private String selectedDate = "";
    private ArrayList<AvailableSlots.Data> availableSlotsList = new ArrayList<>();
    private AvailableSlots.Data selectedSlotData = new AvailableSlots.Data(0, null, false, 7, null);
    private SlotHoldResponse.Data slotHoldResponse = new SlotHoldResponse.Data(null, null, 0, null, null, null, null, 0, 255, null);
    private BookAppointmentResponse.Data bookAppointmentResponse = new BookAppointmentResponse.Data(null, null, null, null, null, null, 0, null, null, null, null, null, null, null, null, null, null, 0, 262143, null);
    private String name = "";
    private String citizenNumber = "";
    private String mobileNumber = "";
    private String email = "noreply@nadra.gov.pk";
    private String alpha2 = "pk";
    private NrcDataRDB selectedNrcDataRDB = new NrcDataRDB();

    public final ReactNativeData getReactNativeData() {
        return this.reactNativeData;
    }

    public final void setReactNativeData(ReactNativeData reactNativeData) {
        Intrinsics.checkNotNullParameter(reactNativeData, "<set-?>");
        this.reactNativeData = reactNativeData;
    }

    public final LibraryResponse getSelectedProvince() {
        return this.selectedProvince;
    }

    public final void setSelectedProvince(LibraryResponse libraryResponse) {
        Intrinsics.checkNotNullParameter(libraryResponse, "<set-?>");
        this.selectedProvince = libraryResponse;
    }

    public final LibraryResponse getSelectedDistrict() {
        return this.selectedDistrict;
    }

    public final void setSelectedDistrict(LibraryResponse libraryResponse) {
        Intrinsics.checkNotNullParameter(libraryResponse, "<set-?>");
        this.selectedDistrict = libraryResponse;
    }

    public final CentersResponse.Data getSelectedCenterData() {
        return this.selectedCenterData;
    }

    public final void setSelectedCenterData(CentersResponse.Data data) {
        Intrinsics.checkNotNullParameter(data, "<set-?>");
        this.selectedCenterData = data;
    }

    public final CentersResponse.Data.DocumentType getSelectedDocumentType() {
        return this.selectedDocumentType;
    }

    public final void setSelectedDocumentType(CentersResponse.Data.DocumentType documentType) {
        Intrinsics.checkNotNullParameter(documentType, "<set-?>");
        this.selectedDocumentType = documentType;
    }

    public final CentersResponse.Data.DocumentType.ApplicationType getSelectedApplicationType() {
        return this.selectedApplicationType;
    }

    public final void setSelectedApplicationType(CentersResponse.Data.DocumentType.ApplicationType applicationType) {
        Intrinsics.checkNotNullParameter(applicationType, "<set-?>");
        this.selectedApplicationType = applicationType;
    }

    public final String getSelectedDate() {
        return this.selectedDate;
    }

    public final void setSelectedDate(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.selectedDate = str;
    }

    public final ArrayList<AvailableSlots.Data> getAvailableSlotsList() {
        return this.availableSlotsList;
    }

    public final void setAvailableSlotsList(ArrayList<AvailableSlots.Data> arrayList) {
        Intrinsics.checkNotNullParameter(arrayList, "<set-?>");
        this.availableSlotsList = arrayList;
    }

    public final AvailableSlots.Data getSelectedSlotData() {
        return this.selectedSlotData;
    }

    public final void setSelectedSlotData(AvailableSlots.Data data) {
        Intrinsics.checkNotNullParameter(data, "<set-?>");
        this.selectedSlotData = data;
    }

    public final SlotHoldResponse.Data getSlotHoldResponse() {
        return this.slotHoldResponse;
    }

    public final void setSlotHoldResponse(SlotHoldResponse.Data data) {
        Intrinsics.checkNotNullParameter(data, "<set-?>");
        this.slotHoldResponse = data;
    }

    public final BookAppointmentResponse.Data getBookAppointmentResponse() {
        return this.bookAppointmentResponse;
    }

    public final void setBookAppointmentResponse(BookAppointmentResponse.Data data) {
        Intrinsics.checkNotNullParameter(data, "<set-?>");
        this.bookAppointmentResponse = data;
    }

    public final String getName() {
        return this.name;
    }

    public final void setName(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.name = str;
    }

    public final String getCitizenNumber() {
        return this.citizenNumber;
    }

    public final void setCitizenNumber(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.citizenNumber = str;
    }

    public final String getMobileNumber() {
        return this.mobileNumber;
    }

    public final void setMobileNumber(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.mobileNumber = str;
    }

    public final String getEmail() {
        return this.email;
    }

    public final void setEmail(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.email = str;
    }

    public final String getAlpha2() {
        return this.alpha2;
    }

    public final void setAlpha2(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.alpha2 = str;
    }

    public final NrcDataRDB getSelectedNrcDataRDB() {
        return this.selectedNrcDataRDB;
    }

    public final void setSelectedNrcDataRDB(NrcDataRDB nrcDataRDB) {
        Intrinsics.checkNotNullParameter(nrcDataRDB, "<set-?>");
        this.selectedNrcDataRDB = nrcDataRDB;
    }

    /* renamed from: isFromCenterNearMe, reason: from getter */
    public final boolean getIsFromCenterNearMe() {
        return this.isFromCenterNearMe;
    }

    public final void setFromCenterNearMe(boolean z) {
        this.isFromCenterNearMe = z;
    }
}