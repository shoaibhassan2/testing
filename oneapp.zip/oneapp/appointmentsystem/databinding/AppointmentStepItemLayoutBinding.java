package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.appointmentsystem.R;

/* loaded from: classes5.dex */
public final class AppointmentStepItemLayoutBinding implements ViewBinding {
    public final TextView expediteStepStatusItemTextView;
    public final TextView expediteStepTitleItemTextView;
    public final ImageView ivParentLineIcon;
    public final ImageView ivParentMinusIcon;
    private final MaterialCardView rootView;

    private AppointmentStepItemLayoutBinding(MaterialCardView materialCardView, TextView textView, TextView textView2, ImageView imageView, ImageView imageView2) {
        this.rootView = materialCardView;
        this.expediteStepStatusItemTextView = textView;
        this.expediteStepTitleItemTextView = textView2;
        this.ivParentLineIcon = imageView;
        this.ivParentMinusIcon = imageView2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static AppointmentStepItemLayoutBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static AppointmentStepItemLayoutBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.appointment_step_item_layout, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static AppointmentStepItemLayoutBinding bind(View view) {
        int i = R.id.expedite_step_status_item_textView;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.expedite_step_title_item_textView;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView2 != null) {
                i = R.id.iv_parent_line_icon;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                if (imageView != null) {
                    i = R.id.iv_parent_minus_icon;
                    ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                    if (imageView2 != null) {
                        return new AppointmentStepItemLayoutBinding((MaterialCardView) view, textView, textView2, imageView, imageView2);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}