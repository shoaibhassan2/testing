package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Guideline;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class FragmentCenterDetailBinding implements ViewBinding {
    public final ImageView addressImageView;
    public final TextView addressLabelTextView;
    public final View addressView;
    public final ButtonLayoutBinding appointmentCenterProceedButtonLayout;
    public final UpdatedHeaderLayoutBackTitleBinding appointmentHeaderLayout;
    public final TextView centerAddressTextView;
    public final TextView centerPhoneNumberTextView;
    public final TextView centerTimingTextView;
    public final ImageView centerTypeImageView;
    public final TextView centerTypeLabelTextView;
    public final TextView centerTypeTextView;
    public final ConstraintLayout constraintLayoutApprox;
    public final ImageView goToDirectionImageView;
    public final Guideline guidelineBelowMapFragment;
    public final ImageView phoneImageView;
    public final TextView phoneLabelTextView;
    public final View phoneView;
    private final ConstraintLayout rootView;
    public final ImageView timingImageView;
    public final TextView timingLabelTextView;
    public final View timingView;
    public final View viewSeparator;

    private FragmentCenterDetailBinding(ConstraintLayout constraintLayout, ImageView imageView, TextView textView, View view, ButtonLayoutBinding buttonLayoutBinding, UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBinding, TextView textView2, TextView textView3, TextView textView4, ImageView imageView2, TextView textView5, TextView textView6, ConstraintLayout constraintLayout2, ImageView imageView3, Guideline guideline, ImageView imageView4, TextView textView7, View view2, ImageView imageView5, TextView textView8, View view3, View view4) {
        this.rootView = constraintLayout;
        this.addressImageView = imageView;
        this.addressLabelTextView = textView;
        this.addressView = view;
        this.appointmentCenterProceedButtonLayout = buttonLayoutBinding;
        this.appointmentHeaderLayout = updatedHeaderLayoutBackTitleBinding;
        this.centerAddressTextView = textView2;
        this.centerPhoneNumberTextView = textView3;
        this.centerTimingTextView = textView4;
        this.centerTypeImageView = imageView2;
        this.centerTypeLabelTextView = textView5;
        this.centerTypeTextView = textView6;
        this.constraintLayoutApprox = constraintLayout2;
        this.goToDirectionImageView = imageView3;
        this.guidelineBelowMapFragment = guideline;
        this.phoneImageView = imageView4;
        this.phoneLabelTextView = textView7;
        this.phoneView = view2;
        this.timingImageView = imageView5;
        this.timingLabelTextView = textView8;
        this.timingView = view3;
        this.viewSeparator = view4;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentCenterDetailBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentCenterDetailBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_center_detail, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentCenterDetailBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        View viewFindChildViewById4;
        View viewFindChildViewById5;
        int i = R.id.addressImageView;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
        if (imageView != null) {
            i = R.id.addressLabelTextView;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.addressView))) != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.appointment_center_proceed_button_layout))) != null) {
                ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById2);
                i = R.id.appointment_header_layout;
                View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById6 != null) {
                    UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById6);
                    i = R.id.centerAddressTextView;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView2 != null) {
                        i = R.id.centerPhoneNumberTextView;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView3 != null) {
                            i = R.id.centerTimingTextView;
                            TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView4 != null) {
                                i = R.id.centerTypeImageView;
                                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                                if (imageView2 != null) {
                                    i = R.id.centerTypeLabelTextView;
                                    TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView5 != null) {
                                        i = R.id.centerTypeTextView;
                                        TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i);
                                        if (textView6 != null) {
                                            i = R.id.constraintLayoutApprox;
                                            ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(view, i);
                                            if (constraintLayout != null) {
                                                i = R.id.goToDirectionImageView;
                                                ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                if (imageView3 != null) {
                                                    i = R.id.guidelineBelowMapFragment;
                                                    Guideline guideline = (Guideline) ViewBindings.findChildViewById(view, i);
                                                    if (guideline != null) {
                                                        i = R.id.phoneImageView;
                                                        ImageView imageView4 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                        if (imageView4 != null) {
                                                            i = R.id.phoneLabelTextView;
                                                            TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i);
                                                            if (textView7 != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(view, (i = R.id.phoneView))) != null) {
                                                                i = R.id.timingImageView;
                                                                ImageView imageView5 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                                if (imageView5 != null) {
                                                                    i = R.id.timingLabelTextView;
                                                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                    if (textView8 != null && (viewFindChildViewById4 = ViewBindings.findChildViewById(view, (i = R.id.timingView))) != null && (viewFindChildViewById5 = ViewBindings.findChildViewById(view, (i = R.id.viewSeparator))) != null) {
                                                                        return new FragmentCenterDetailBinding((ConstraintLayout) view, imageView, textView, viewFindChildViewById, buttonLayoutBindingBind, updatedHeaderLayoutBackTitleBindingBind, textView2, textView3, textView4, imageView2, textView5, textView6, constraintLayout, imageView3, guideline, imageView4, textView7, viewFindChildViewById3, imageView5, textView8, viewFindChildViewById4, viewFindChildViewById5);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}