package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class FragmentAppointmentVisitPurposeBinding implements ViewBinding {
    public final AutocompletetextviewLayoutBinding applicationTypeLayout;
    public final NestedScrollView appointmentApplicationScrollView;
    public final StepActionLayoutBinding appointmentDetailHeadingLayout;
    public final ButtonLayoutBinding appointmentDetailNextButtonLayout;
    public final RecyclerView appointmentDetailStepRecyclerView;
    public final UpdatedHeaderLayoutBackTitleBinding appointmentHeaderLayout;
    public final MaterialCardView appointmentMandatoryDocumentCardView;
    public final TextView appointmentMandatoryDocumentHeadingTextView;
    public final RecyclerView appointmentMandatoryDocumentRecyclerView;
    public final MaterialCardView appointmentPaymentModeCardView;
    public final TextView appointmentPaymentModeHeadingTextView;
    public final ImageView appointmentPaymentModeIconImageView;
    public final TextView appointmentVisitHeadingTextView;
    public final AutocompletetextviewLayoutBinding documentTypeLayout;
    public final ImageView infoIconImageView;
    public final View lineView;
    public final TextView paymentFacilityTextView;
    public final LinearLayout paymentIconsLinearLayout;
    public final ImageView paymentInfoIconImageView;
    public final View paymentLineView;
    public final TextView paymentViaRaastTextView;
    private final ConstraintLayout rootView;

    private FragmentAppointmentVisitPurposeBinding(ConstraintLayout constraintLayout, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding, NestedScrollView nestedScrollView, StepActionLayoutBinding stepActionLayoutBinding, ButtonLayoutBinding buttonLayoutBinding, RecyclerView recyclerView, UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBinding, MaterialCardView materialCardView, TextView textView, RecyclerView recyclerView2, MaterialCardView materialCardView2, TextView textView2, ImageView imageView, TextView textView3, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding2, ImageView imageView2, View view, TextView textView4, LinearLayout linearLayout, ImageView imageView3, View view2, TextView textView5) {
        this.rootView = constraintLayout;
        this.applicationTypeLayout = autocompletetextviewLayoutBinding;
        this.appointmentApplicationScrollView = nestedScrollView;
        this.appointmentDetailHeadingLayout = stepActionLayoutBinding;
        this.appointmentDetailNextButtonLayout = buttonLayoutBinding;
        this.appointmentDetailStepRecyclerView = recyclerView;
        this.appointmentHeaderLayout = updatedHeaderLayoutBackTitleBinding;
        this.appointmentMandatoryDocumentCardView = materialCardView;
        this.appointmentMandatoryDocumentHeadingTextView = textView;
        this.appointmentMandatoryDocumentRecyclerView = recyclerView2;
        this.appointmentPaymentModeCardView = materialCardView2;
        this.appointmentPaymentModeHeadingTextView = textView2;
        this.appointmentPaymentModeIconImageView = imageView;
        this.appointmentVisitHeadingTextView = textView3;
        this.documentTypeLayout = autocompletetextviewLayoutBinding2;
        this.infoIconImageView = imageView2;
        this.lineView = view;
        this.paymentFacilityTextView = textView4;
        this.paymentIconsLinearLayout = linearLayout;
        this.paymentInfoIconImageView = imageView3;
        this.paymentLineView = view2;
        this.paymentViaRaastTextView = textView5;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentAppointmentVisitPurposeBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentAppointmentVisitPurposeBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_appointment_visit_purpose, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentAppointmentVisitPurposeBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        View viewFindChildViewById4;
        View viewFindChildViewById5;
        int i = R.id.application_type_layout;
        View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById6 != null) {
            AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById6);
            i = R.id.appointment_application_scrollView;
            NestedScrollView nestedScrollView = (NestedScrollView) ViewBindings.findChildViewById(view, i);
            if (nestedScrollView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.appointment_detail_heading_layout))) != null) {
                StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById);
                i = R.id.appointment_detail_next_button_layout;
                View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById7 != null) {
                    ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById7);
                    i = R.id.appointment_detail_step_recyclerView;
                    RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
                    if (recyclerView != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.appointment_header_layout))) != null) {
                        UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById2);
                        i = R.id.appointment_mandatory_document_cardView;
                        MaterialCardView materialCardView = (MaterialCardView) ViewBindings.findChildViewById(view, i);
                        if (materialCardView != null) {
                            i = R.id.appointment_mandatory_document_heading_textView;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView != null) {
                                i = R.id.appointment_mandatory_document_recyclerView;
                                RecyclerView recyclerView2 = (RecyclerView) ViewBindings.findChildViewById(view, i);
                                if (recyclerView2 != null) {
                                    i = R.id.appointment_payment_mode_cardView;
                                    MaterialCardView materialCardView2 = (MaterialCardView) ViewBindings.findChildViewById(view, i);
                                    if (materialCardView2 != null) {
                                        i = R.id.appointment_payment_mode_heading_textView;
                                        TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                                        if (textView2 != null) {
                                            i = R.id.appointment_payment_mode_icon_imageView;
                                            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                                            if (imageView != null) {
                                                i = R.id.appointment_visit_heading_textView;
                                                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                                                if (textView3 != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(view, (i = R.id.document_type_layout))) != null) {
                                                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind2 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById3);
                                                    i = R.id.info_icon_imageView;
                                                    ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                    if (imageView2 != null && (viewFindChildViewById4 = ViewBindings.findChildViewById(view, (i = R.id.line_view))) != null) {
                                                        i = R.id.payment_facility_textView;
                                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                                                        if (textView4 != null) {
                                                            i = R.id.payment_icons_linearLayout;
                                                            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                                                            if (linearLayout != null) {
                                                                i = R.id.payment_info_icon_imageView;
                                                                ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                                if (imageView3 != null && (viewFindChildViewById5 = ViewBindings.findChildViewById(view, (i = R.id.payment_line_view))) != null) {
                                                                    i = R.id.payment_via_raast_textView;
                                                                    TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                    if (textView5 != null) {
                                                                        return new FragmentAppointmentVisitPurposeBinding((ConstraintLayout) view, autocompletetextviewLayoutBindingBind, nestedScrollView, stepActionLayoutBindingBind, buttonLayoutBindingBind, recyclerView, updatedHeaderLayoutBackTitleBindingBind, materialCardView, textView, recyclerView2, materialCardView2, textView2, imageView, textView3, autocompletetextviewLayoutBindingBind2, imageView2, viewFindChildViewById4, textView4, linearLayout, imageView3, viewFindChildViewById5, textView5);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}