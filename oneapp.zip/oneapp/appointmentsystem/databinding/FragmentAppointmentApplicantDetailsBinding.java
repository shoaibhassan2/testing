package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class FragmentAppointmentApplicantDetailsBinding implements ViewBinding {
    public final MaskedEdittextLayoutBinding appointmentApplicantCnicLayout;
    public final TextInputLayout appointmentApplicantContactNumberLayout;
    public final TextInputEditText appointmentApplicantContactNumberTextInputEditText;
    public final TextView appointmentApplicantDetailHeadingTextView;
    public final ImageView appointmentApplicantDetailInfoIconImageView;
    public final TextView appointmentApplicantDetailInfoTextView;
    public final ButtonLayoutBinding appointmentApplicantDetailsNextButtonLayout;
    public final EdittextLayoutBinding appointmentApplicantEmailLayout;
    public final EdittextLayoutBinding appointmentApplicantNameLayout;
    public final ScrollView appointmentApplicationScrollView;
    public final StepActionLayoutBinding appointmentDetailHeadingLayout;
    public final RecyclerView appointmentDetailStepRecyclerView;
    public final UpdatedHeaderLayoutBackTitleBinding appointmentHeaderLayout;
    public final AutocompletetextviewLayoutBinding purposeTypeLayout;
    private final ConstraintLayout rootView;

    private FragmentAppointmentApplicantDetailsBinding(ConstraintLayout constraintLayout, MaskedEdittextLayoutBinding maskedEdittextLayoutBinding, TextInputLayout textInputLayout, TextInputEditText textInputEditText, TextView textView, ImageView imageView, TextView textView2, ButtonLayoutBinding buttonLayoutBinding, EdittextLayoutBinding edittextLayoutBinding, EdittextLayoutBinding edittextLayoutBinding2, ScrollView scrollView, StepActionLayoutBinding stepActionLayoutBinding, RecyclerView recyclerView, UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding) {
        this.rootView = constraintLayout;
        this.appointmentApplicantCnicLayout = maskedEdittextLayoutBinding;
        this.appointmentApplicantContactNumberLayout = textInputLayout;
        this.appointmentApplicantContactNumberTextInputEditText = textInputEditText;
        this.appointmentApplicantDetailHeadingTextView = textView;
        this.appointmentApplicantDetailInfoIconImageView = imageView;
        this.appointmentApplicantDetailInfoTextView = textView2;
        this.appointmentApplicantDetailsNextButtonLayout = buttonLayoutBinding;
        this.appointmentApplicantEmailLayout = edittextLayoutBinding;
        this.appointmentApplicantNameLayout = edittextLayoutBinding2;
        this.appointmentApplicationScrollView = scrollView;
        this.appointmentDetailHeadingLayout = stepActionLayoutBinding;
        this.appointmentDetailStepRecyclerView = recyclerView;
        this.appointmentHeaderLayout = updatedHeaderLayoutBackTitleBinding;
        this.purposeTypeLayout = autocompletetextviewLayoutBinding;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentAppointmentApplicantDetailsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentAppointmentApplicantDetailsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_appointment_applicant_details, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentAppointmentApplicantDetailsBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        int i = R.id.appointment_applicant_cnic_layout;
        View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById4 != null) {
            MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById4);
            i = R.id.appointment_applicant_contact_number_layout;
            TextInputLayout textInputLayout = (TextInputLayout) ViewBindings.findChildViewById(view, i);
            if (textInputLayout != null) {
                i = R.id.appointment_applicant_contact_number_textInputEditText;
                TextInputEditText textInputEditText = (TextInputEditText) ViewBindings.findChildViewById(view, i);
                if (textInputEditText != null) {
                    i = R.id.appointment_applicant_detail_heading_textView;
                    TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView != null) {
                        i = R.id.appointment_applicant_detail_info_icon_imageView;
                        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                        if (imageView != null) {
                            i = R.id.appointment_applicant_detail_info_textView;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.appointment_applicant_details_next_button_layout))) != null) {
                                ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById);
                                i = R.id.appointment_applicant_email_layout;
                                View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                                if (viewFindChildViewById5 != null) {
                                    EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById5);
                                    i = R.id.appointment_applicant_name_layout;
                                    View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                                    if (viewFindChildViewById6 != null) {
                                        EdittextLayoutBinding edittextLayoutBindingBind2 = EdittextLayoutBinding.bind(viewFindChildViewById6);
                                        i = R.id.appointment_application_scrollView;
                                        ScrollView scrollView = (ScrollView) ViewBindings.findChildViewById(view, i);
                                        if (scrollView != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.appointment_detail_heading_layout))) != null) {
                                            StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById2);
                                            i = R.id.appointment_detail_step_recyclerView;
                                            RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
                                            if (recyclerView != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(view, (i = R.id.appointment_header_layout))) != null) {
                                                UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById3);
                                                i = R.id.purpose_type_layout;
                                                View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                                                if (viewFindChildViewById7 != null) {
                                                    return new FragmentAppointmentApplicantDetailsBinding((ConstraintLayout) view, maskedEdittextLayoutBindingBind, textInputLayout, textInputEditText, textView, imageView, textView2, buttonLayoutBindingBind, edittextLayoutBindingBind, edittextLayoutBindingBind2, scrollView, stepActionLayoutBindingBind, recyclerView, updatedHeaderLayoutBackTitleBindingBind, AutocompletetextviewLayoutBinding.bind(viewFindChildViewById7));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}