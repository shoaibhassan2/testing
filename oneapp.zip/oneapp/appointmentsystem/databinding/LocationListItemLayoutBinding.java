package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.appointmentsystem.R;

/* loaded from: classes5.dex */
public final class LocationListItemLayoutBinding implements ViewBinding {
    public final MaterialCardView locationCardView;
    public final ImageView locationListItemCalenderIconImageView;
    public final ImageView locationListItemIconImageView;
    public final TextView locationListItemNameTextView;
    public final ImageView locationListItemRightArrowImageView;
    public final TextView locationListItemTimingTextView;
    private final MaterialCardView rootView;

    private LocationListItemLayoutBinding(MaterialCardView materialCardView, MaterialCardView materialCardView2, ImageView imageView, ImageView imageView2, TextView textView, ImageView imageView3, TextView textView2) {
        this.rootView = materialCardView;
        this.locationCardView = materialCardView2;
        this.locationListItemCalenderIconImageView = imageView;
        this.locationListItemIconImageView = imageView2;
        this.locationListItemNameTextView = textView;
        this.locationListItemRightArrowImageView = imageView3;
        this.locationListItemTimingTextView = textView2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static LocationListItemLayoutBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static LocationListItemLayoutBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.location_list_item_layout, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static LocationListItemLayoutBinding bind(View view) {
        MaterialCardView materialCardView = (MaterialCardView) view;
        int i = R.id.location_list_item_calender_icon_imageView;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
        if (imageView != null) {
            i = R.id.location_list_item_icon_imageView;
            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
            if (imageView2 != null) {
                i = R.id.location_list_item_name_textView;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    i = R.id.location_list_item_right_arrow_imageView;
                    ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i);
                    if (imageView3 != null) {
                        i = R.id.location_list_item_timing_textView;
                        TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView2 != null) {
                            return new LocationListItemLayoutBinding(materialCardView, materialCardView, imageView, imageView2, textView, imageView3, textView2);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}