package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.appointmentsystem.R;

/* loaded from: classes5.dex */
public final class AvailableSlotListItemLayoutBinding implements ViewBinding {
    public final MaterialCardView appointmentAvailableSlotsCardView;
    public final ConstraintLayout listItemSlotConstraintLayout;
    public final TextView listItemSlotTextView;
    private final MaterialCardView rootView;

    private AvailableSlotListItemLayoutBinding(MaterialCardView materialCardView, MaterialCardView materialCardView2, ConstraintLayout constraintLayout, TextView textView) {
        this.rootView = materialCardView;
        this.appointmentAvailableSlotsCardView = materialCardView2;
        this.listItemSlotConstraintLayout = constraintLayout;
        this.listItemSlotTextView = textView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static AvailableSlotListItemLayoutBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static AvailableSlotListItemLayoutBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.available_slot_list_item_layout, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static AvailableSlotListItemLayoutBinding bind(View view) {
        MaterialCardView materialCardView = (MaterialCardView) view;
        int i = R.id.list_item_slot_constraintLayout;
        ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(view, i);
        if (constraintLayout != null) {
            i = R.id.list_item_slot_textView;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView != null) {
                return new AvailableSlotListItemLayoutBinding(materialCardView, materialCardView, constraintLayout, textView);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}