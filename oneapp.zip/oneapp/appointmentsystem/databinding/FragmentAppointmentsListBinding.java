package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class FragmentAppointmentsListBinding implements ViewBinding {
    public final ButtonLayoutBinding addNewAppointmentButtonLayout;
    public final UpdatedHeaderLayoutBackTitleBinding appointmentHeaderLayout;
    public final TextView appointmentListHeadingTextView;
    public final SwipeRefreshLayout appointmentSwipeRefresh;
    public final RecyclerView appointmentsListRecyclerView;
    public final ImageView appointmentsListTryAgainImageView;
    public final LinearLayout appointmentsListTryAgainLayout;
    public final TextView appointmentsListTryAgainTextView;
    private final ConstraintLayout rootView;

    private FragmentAppointmentsListBinding(ConstraintLayout constraintLayout, ButtonLayoutBinding buttonLayoutBinding, UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBinding, TextView textView, SwipeRefreshLayout swipeRefreshLayout, RecyclerView recyclerView, ImageView imageView, LinearLayout linearLayout, TextView textView2) {
        this.rootView = constraintLayout;
        this.addNewAppointmentButtonLayout = buttonLayoutBinding;
        this.appointmentHeaderLayout = updatedHeaderLayoutBackTitleBinding;
        this.appointmentListHeadingTextView = textView;
        this.appointmentSwipeRefresh = swipeRefreshLayout;
        this.appointmentsListRecyclerView = recyclerView;
        this.appointmentsListTryAgainImageView = imageView;
        this.appointmentsListTryAgainLayout = linearLayout;
        this.appointmentsListTryAgainTextView = textView2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentAppointmentsListBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentAppointmentsListBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_appointments_list, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentAppointmentsListBinding bind(View view) {
        int i = R.id.add_new_appointment_button_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById);
            i = R.id.appointment_header_layout;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById2 != null) {
                UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById2);
                i = R.id.appointment_list_heading_textView;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    i = R.id.appointment_swipeRefresh;
                    SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) ViewBindings.findChildViewById(view, i);
                    if (swipeRefreshLayout != null) {
                        i = R.id.appointments_list_recyclerView;
                        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
                        if (recyclerView != null) {
                            i = R.id.appointments_list_try_again_imageView;
                            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                            if (imageView != null) {
                                i = R.id.appointments_list_try_again_layout;
                                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                                if (linearLayout != null) {
                                    i = R.id.appointments_list_try_again_textView;
                                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView2 != null) {
                                        return new FragmentAppointmentsListBinding((ConstraintLayout) view, buttonLayoutBindingBind, updatedHeaderLayoutBackTitleBindingBind, textView, swipeRefreshLayout, recyclerView, imageView, linearLayout, textView2);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}