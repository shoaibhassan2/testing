package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class FragmentAppointmentLocationsBinding implements ViewBinding {
    public final AutocompletetextviewLayoutBinding appointmentDistrictLayout;
    public final UpdatedHeaderLayoutBackTitleBinding appointmentHeaderLayout;
    public final TextView appointmentLocationHeadingTextView;
    public final RecyclerView appointmentLocationsRecyclerView;
    public final AutocompletetextviewLayoutBinding appointmentProvinceLayout;
    public final LinearLayout centerListTryAgainLayout;
    public final ImageView frcListTryAgainImageView;
    public final TextView frcListTryAgainTextView;
    private final ConstraintLayout rootView;

    private FragmentAppointmentLocationsBinding(ConstraintLayout constraintLayout, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding, UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBinding, TextView textView, RecyclerView recyclerView, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding2, LinearLayout linearLayout, ImageView imageView, TextView textView2) {
        this.rootView = constraintLayout;
        this.appointmentDistrictLayout = autocompletetextviewLayoutBinding;
        this.appointmentHeaderLayout = updatedHeaderLayoutBackTitleBinding;
        this.appointmentLocationHeadingTextView = textView;
        this.appointmentLocationsRecyclerView = recyclerView;
        this.appointmentProvinceLayout = autocompletetextviewLayoutBinding2;
        this.centerListTryAgainLayout = linearLayout;
        this.frcListTryAgainImageView = imageView;
        this.frcListTryAgainTextView = textView2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentAppointmentLocationsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentAppointmentLocationsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_appointment_locations, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentAppointmentLocationsBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.appointment_district_layout;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById2 != null) {
            AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById2);
            i = R.id.appointment_header_layout;
            View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById3 != null) {
                UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById3);
                i = R.id.appointment_location_heading_textView;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    i = R.id.appointment_locations_recyclerView;
                    RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
                    if (recyclerView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.appointment_province_layout))) != null) {
                        AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind2 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById);
                        i = R.id.center_list_try_again_layout;
                        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                        if (linearLayout != null) {
                            i = R.id.frc_list_try_again_imageView;
                            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                            if (imageView != null) {
                                i = R.id.frc_list_try_again_textView;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                                if (textView2 != null) {
                                    return new FragmentAppointmentLocationsBinding((ConstraintLayout) view, autocompletetextviewLayoutBindingBind, updatedHeaderLayoutBackTitleBindingBind, textView, recyclerView, autocompletetextviewLayoutBindingBind2, linearLayout, imageView, textView2);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}