package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class FragmentAppointmentInstructionsBinding implements ViewBinding {
    public final TextView appointmentArrivingHeadingTextView;
    public final TextView appointmentArrivingUrduHeadingTextView;
    public final TextView appointmentChooseDatetimeHeadingTextView;
    public final TextView appointmentChooseDatetimeUrduHeadingTextView;
    public final TextView appointmentDocumentsHeadingTextView;
    public final TextView appointmentDocumentsUrduHeadingTextView;
    public final UpdatedHeaderLayoutBackTitleBinding appointmentHeaderLayout;
    public final TextView appointmentInstructionHeadingTextView;
    public final TextView appointmentInstructionUrduHeadingTextView;
    public final ButtonLayoutBinding appointmentInstructionsMapNextButtonLayout;
    public final ButtonLayoutBinding appointmentInstructionsNextButtonLayout;
    public final TextView appointmentOptionTextView;
    public final TextView appointmentPunctualHeadingTextView;
    public final TextView appointmentPunctualUrduHeadingTextView;
    public final TextView appointmentRequiredDocumentsTextView;
    public final ImageView appointmentScheduleIconImageView;
    public final View line1View;
    public final View line2View;
    private final ConstraintLayout rootView;

    private FragmentAppointmentInstructionsBinding(ConstraintLayout constraintLayout, TextView textView, TextView textView2, TextView textView3, TextView textView4, TextView textView5, TextView textView6, UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBinding, TextView textView7, TextView textView8, ButtonLayoutBinding buttonLayoutBinding, ButtonLayoutBinding buttonLayoutBinding2, TextView textView9, TextView textView10, TextView textView11, TextView textView12, ImageView imageView, View view, View view2) {
        this.rootView = constraintLayout;
        this.appointmentArrivingHeadingTextView = textView;
        this.appointmentArrivingUrduHeadingTextView = textView2;
        this.appointmentChooseDatetimeHeadingTextView = textView3;
        this.appointmentChooseDatetimeUrduHeadingTextView = textView4;
        this.appointmentDocumentsHeadingTextView = textView5;
        this.appointmentDocumentsUrduHeadingTextView = textView6;
        this.appointmentHeaderLayout = updatedHeaderLayoutBackTitleBinding;
        this.appointmentInstructionHeadingTextView = textView7;
        this.appointmentInstructionUrduHeadingTextView = textView8;
        this.appointmentInstructionsMapNextButtonLayout = buttonLayoutBinding;
        this.appointmentInstructionsNextButtonLayout = buttonLayoutBinding2;
        this.appointmentOptionTextView = textView9;
        this.appointmentPunctualHeadingTextView = textView10;
        this.appointmentPunctualUrduHeadingTextView = textView11;
        this.appointmentRequiredDocumentsTextView = textView12;
        this.appointmentScheduleIconImageView = imageView;
        this.line1View = view;
        this.line2View = view2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentAppointmentInstructionsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentAppointmentInstructionsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_appointment_instructions, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentAppointmentInstructionsBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        View viewFindChildViewById4;
        int i = R.id.appointment_arriving_heading_textView;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.appointment_arriving_urdu_heading_textView;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView2 != null) {
                i = R.id.appointment_choose_datetime_heading_textView;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView3 != null) {
                    i = R.id.appointment_choose_datetime_urdu_heading_textView;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView4 != null) {
                        i = R.id.appointment_documents_heading_textView;
                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView5 != null) {
                            i = R.id.appointment_documents_urdu_heading_textView;
                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView6 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.appointment_header_layout))) != null) {
                                UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
                                i = R.id.appointment_instruction_heading_textView;
                                TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i);
                                if (textView7 != null) {
                                    i = R.id.appointment_instruction_urdu_heading_textView;
                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView8 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.appointment_instructions_map_next_button_layout))) != null) {
                                        ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById2);
                                        i = R.id.appointment_instructions_next_button_layout;
                                        View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                                        if (viewFindChildViewById5 != null) {
                                            ButtonLayoutBinding buttonLayoutBindingBind2 = ButtonLayoutBinding.bind(viewFindChildViewById5);
                                            i = R.id.appointment_option_textView;
                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i);
                                            if (textView9 != null) {
                                                i = R.id.appointment_punctual_heading_textView;
                                                TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i);
                                                if (textView10 != null) {
                                                    i = R.id.appointment_punctual_urdu_heading_textView;
                                                    TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i);
                                                    if (textView11 != null) {
                                                        i = R.id.appointment_required_documents_textView;
                                                        TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i);
                                                        if (textView12 != null) {
                                                            i = R.id.appointment_schedule_icon_imageView;
                                                            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                                                            if (imageView != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(view, (i = R.id.line_1_view))) != null && (viewFindChildViewById4 = ViewBindings.findChildViewById(view, (i = R.id.line_2_view))) != null) {
                                                                return new FragmentAppointmentInstructionsBinding((ConstraintLayout) view, textView, textView2, textView3, textView4, textView5, textView6, updatedHeaderLayoutBackTitleBindingBind, textView7, textView8, buttonLayoutBindingBind, buttonLayoutBindingBind2, textView9, textView10, textView11, textView12, imageView, viewFindChildViewById3, viewFindChildViewById4);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}