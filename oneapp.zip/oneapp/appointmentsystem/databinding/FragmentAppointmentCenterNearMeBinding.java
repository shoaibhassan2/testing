package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class FragmentAppointmentCenterNearMeBinding implements ViewBinding {
    public final UpdatedHeaderLayoutBackTitleBinding appointmentHeaderLayout;
    private final ConstraintLayout rootView;

    private FragmentAppointmentCenterNearMeBinding(ConstraintLayout constraintLayout, UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBinding) {
        this.rootView = constraintLayout;
        this.appointmentHeaderLayout = updatedHeaderLayoutBackTitleBinding;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentAppointmentCenterNearMeBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentAppointmentCenterNearMeBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_appointment_center_near_me, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentAppointmentCenterNearMeBinding bind(View view) {
        int i = R.id.appointment_header_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            return new FragmentAppointmentCenterNearMeBinding((ConstraintLayout) view, UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById));
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}