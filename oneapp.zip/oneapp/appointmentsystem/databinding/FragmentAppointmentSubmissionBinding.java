package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class FragmentAppointmentSubmissionBinding implements ViewBinding {
    public final TextView appointmentDatetimeMessageTextView;
    public final TextView appointmentDetailsSentTextView;
    public final UpdatedHeaderLayoutBackTitleBinding appointmentHeaderLayout;
    public final TextView appointmentPunctualHeadingTextView;
    public final TextView appointmentPunctualUrduHeadingTextView;
    public final ImageView appointmentScheduleIconImageView;
    public final TextView appointmentScheduledHeadingTextView;
    public final ButtonLayoutBinding appointmentSubmissionButtonLayout;
    public final View line1View;
    public final View line2View;
    private final ConstraintLayout rootView;

    private FragmentAppointmentSubmissionBinding(ConstraintLayout constraintLayout, TextView textView, TextView textView2, UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBinding, TextView textView3, TextView textView4, ImageView imageView, TextView textView5, ButtonLayoutBinding buttonLayoutBinding, View view, View view2) {
        this.rootView = constraintLayout;
        this.appointmentDatetimeMessageTextView = textView;
        this.appointmentDetailsSentTextView = textView2;
        this.appointmentHeaderLayout = updatedHeaderLayoutBackTitleBinding;
        this.appointmentPunctualHeadingTextView = textView3;
        this.appointmentPunctualUrduHeadingTextView = textView4;
        this.appointmentScheduleIconImageView = imageView;
        this.appointmentScheduledHeadingTextView = textView5;
        this.appointmentSubmissionButtonLayout = buttonLayoutBinding;
        this.line1View = view;
        this.line2View = view2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentAppointmentSubmissionBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentAppointmentSubmissionBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_appointment_submission, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentAppointmentSubmissionBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        int i = R.id.appointment_datetime_message_textView;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.appointment_details_sent_textView;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.appointment_header_layout))) != null) {
                UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById);
                i = R.id.appointment_punctual_heading_textView;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView3 != null) {
                    i = R.id.appointment_punctual_urdu_heading_textView;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView4 != null) {
                        i = R.id.appointment_schedule_icon_imageView;
                        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                        if (imageView != null) {
                            i = R.id.appointment_scheduled_heading_textView;
                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView5 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.appointment_submission_button_layout))) != null) {
                                ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById2);
                                i = R.id.line_1_view;
                                View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                                if (viewFindChildViewById4 != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(view, (i = R.id.line_2_view))) != null) {
                                    return new FragmentAppointmentSubmissionBinding((ConstraintLayout) view, textView, textView2, updatedHeaderLayoutBackTitleBindingBind, textView3, textView4, imageView, textView5, buttonLayoutBindingBind, viewFindChildViewById4, viewFindChildViewById3);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}