package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.imageview.ShapeableImageView;
import pk.gov.nadra.oneapp.appointmentsystem.R;

/* loaded from: classes5.dex */
public final class ListItemAppointmentBinding implements ViewBinding {
    public final ImageView appointmentCancelIconImageView;
    public final TextView appointmentCenterTextView;
    public final TextView appointmentDateTextView;
    public final ShapeableImageView appointmentIconBackground;
    public final ImageView appointmentIconImageView;
    public final TextView appointmentIdTextView;
    public final MaterialCardView appointmentListItemCardView;
    public final TextView appointmentNameTextView;
    public final TextView appointmentStatusTextView;
    public final ImageView arrowIconImageView;
    public final TextView pinCodeTextView;
    private final MaterialCardView rootView;

    private ListItemAppointmentBinding(MaterialCardView materialCardView, ImageView imageView, TextView textView, TextView textView2, ShapeableImageView shapeableImageView, ImageView imageView2, TextView textView3, MaterialCardView materialCardView2, TextView textView4, TextView textView5, ImageView imageView3, TextView textView6) {
        this.rootView = materialCardView;
        this.appointmentCancelIconImageView = imageView;
        this.appointmentCenterTextView = textView;
        this.appointmentDateTextView = textView2;
        this.appointmentIconBackground = shapeableImageView;
        this.appointmentIconImageView = imageView2;
        this.appointmentIdTextView = textView3;
        this.appointmentListItemCardView = materialCardView2;
        this.appointmentNameTextView = textView4;
        this.appointmentStatusTextView = textView5;
        this.arrowIconImageView = imageView3;
        this.pinCodeTextView = textView6;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static ListItemAppointmentBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ListItemAppointmentBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.list_item_appointment, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ListItemAppointmentBinding bind(View view) {
        int i = R.id.appointmentCancelIconImageView;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
        if (imageView != null) {
            i = R.id.appointmentCenterTextView;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView != null) {
                i = R.id.appointmentDateTextView;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView2 != null) {
                    i = R.id.appointment_icon_background;
                    ShapeableImageView shapeableImageView = (ShapeableImageView) ViewBindings.findChildViewById(view, i);
                    if (shapeableImageView != null) {
                        i = R.id.appointment_icon_imageView;
                        ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                        if (imageView2 != null) {
                            i = R.id.appointmentIdTextView;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView3 != null) {
                                MaterialCardView materialCardView = (MaterialCardView) view;
                                i = R.id.appointmentNameTextView;
                                TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                                if (textView4 != null) {
                                    i = R.id.appointmentStatusTextView;
                                    TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView5 != null) {
                                        i = R.id.arrowIconImageView;
                                        ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i);
                                        if (imageView3 != null) {
                                            i = R.id.pinCodeTextView;
                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i);
                                            if (textView6 != null) {
                                                return new ListItemAppointmentBinding(materialCardView, imageView, textView, textView2, shapeableImageView, imageView2, textView3, materialCardView, textView4, textView5, imageView3, textView6);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}