package pk.gov.nadra.oneapp.appointmentsystem.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.card.MaterialCardView;
import pk.gov.nadra.oneapp.appointmentsystem.R;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.EdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBackTitleBinding;

/* loaded from: classes5.dex */
public final class FragmentAppointmentDateTimeBinding implements ViewBinding {
    public final NestedScrollView appointmentApplicationScrollView;
    public final MaterialCardView appointmentAvailableSlotsCardView;
    public final TextView appointmentAvailableSlotsHeadingTextView;
    public final RecyclerView appointmentAvailableSlotsRecyclerView;
    public final EdittextLayoutBinding appointmentDateLayout;
    public final TextView appointmentDateTimeHeadingTextView;
    public final ButtonLayoutBinding appointmentDateTimeNextButtonLayout;
    public final ImageView appointmentDatetimeInfoIconImageView;
    public final TextView appointmentDatetimeInfoTextView;
    public final StepActionLayoutBinding appointmentDetailHeadingLayout;
    public final RecyclerView appointmentDetailStepRecyclerView;
    public final UpdatedHeaderLayoutBackTitleBinding appointmentHeaderLayout;
    public final ImageView frcListTryAgainImageView;
    public final TextView frcListTryAgainTextView;
    private final ConstraintLayout rootView;
    public final AutocompletetextviewLayoutBinding shiftTimeLayout;
    public final LinearLayout slotListTryAgainLayout;

    private FragmentAppointmentDateTimeBinding(ConstraintLayout constraintLayout, NestedScrollView nestedScrollView, MaterialCardView materialCardView, TextView textView, RecyclerView recyclerView, EdittextLayoutBinding edittextLayoutBinding, TextView textView2, ButtonLayoutBinding buttonLayoutBinding, ImageView imageView, TextView textView3, StepActionLayoutBinding stepActionLayoutBinding, RecyclerView recyclerView2, UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBinding, ImageView imageView2, TextView textView4, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding, LinearLayout linearLayout) {
        this.rootView = constraintLayout;
        this.appointmentApplicationScrollView = nestedScrollView;
        this.appointmentAvailableSlotsCardView = materialCardView;
        this.appointmentAvailableSlotsHeadingTextView = textView;
        this.appointmentAvailableSlotsRecyclerView = recyclerView;
        this.appointmentDateLayout = edittextLayoutBinding;
        this.appointmentDateTimeHeadingTextView = textView2;
        this.appointmentDateTimeNextButtonLayout = buttonLayoutBinding;
        this.appointmentDatetimeInfoIconImageView = imageView;
        this.appointmentDatetimeInfoTextView = textView3;
        this.appointmentDetailHeadingLayout = stepActionLayoutBinding;
        this.appointmentDetailStepRecyclerView = recyclerView2;
        this.appointmentHeaderLayout = updatedHeaderLayoutBackTitleBinding;
        this.frcListTryAgainImageView = imageView2;
        this.frcListTryAgainTextView = textView4;
        this.shiftTimeLayout = autocompletetextviewLayoutBinding;
        this.slotListTryAgainLayout = linearLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static FragmentAppointmentDateTimeBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentAppointmentDateTimeBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_appointment_date_time, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentAppointmentDateTimeBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        View viewFindChildViewById4;
        View viewFindChildViewById5;
        int i = R.id.appointment_application_scrollView;
        NestedScrollView nestedScrollView = (NestedScrollView) ViewBindings.findChildViewById(view, i);
        if (nestedScrollView != null) {
            i = R.id.appointment_available_slots_cardView;
            MaterialCardView materialCardView = (MaterialCardView) ViewBindings.findChildViewById(view, i);
            if (materialCardView != null) {
                i = R.id.appointment_available_slots_heading_textView;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    i = R.id.appointment_available_slots_recyclerView;
                    RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
                    if (recyclerView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.appointment_date_layout))) != null) {
                        EdittextLayoutBinding edittextLayoutBindingBind = EdittextLayoutBinding.bind(viewFindChildViewById);
                        i = R.id.appointment_date_time_heading_textView;
                        TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView2 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.appointment_date_time_next_button_layout))) != null) {
                            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById2);
                            i = R.id.appointment_datetime_info_icon_imageView;
                            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                            if (imageView != null) {
                                i = R.id.appointment_datetime_info_textView;
                                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                                if (textView3 != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(view, (i = R.id.appointment_detail_heading_layout))) != null) {
                                    StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById3);
                                    i = R.id.appointment_detail_step_recyclerView;
                                    RecyclerView recyclerView2 = (RecyclerView) ViewBindings.findChildViewById(view, i);
                                    if (recyclerView2 != null && (viewFindChildViewById4 = ViewBindings.findChildViewById(view, (i = R.id.appointment_header_layout))) != null) {
                                        UpdatedHeaderLayoutBackTitleBinding updatedHeaderLayoutBackTitleBindingBind = UpdatedHeaderLayoutBackTitleBinding.bind(viewFindChildViewById4);
                                        i = R.id.frc_list_try_again_imageView;
                                        ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                                        if (imageView2 != null) {
                                            i = R.id.frc_list_try_again_textView;
                                            TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                                            if (textView4 != null && (viewFindChildViewById5 = ViewBindings.findChildViewById(view, (i = R.id.shift_time_layout))) != null) {
                                                AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById5);
                                                i = R.id.slot_list_try_again_layout;
                                                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                                                if (linearLayout != null) {
                                                    return new FragmentAppointmentDateTimeBinding((ConstraintLayout) view, nestedScrollView, materialCardView, textView, recyclerView, edittextLayoutBindingBind, textView2, buttonLayoutBindingBind, imageView, textView3, stepActionLayoutBindingBind, recyclerView2, updatedHeaderLayoutBackTitleBindingBind, imageView2, textView4, autocompletetextviewLayoutBindingBind, linearLayout);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}