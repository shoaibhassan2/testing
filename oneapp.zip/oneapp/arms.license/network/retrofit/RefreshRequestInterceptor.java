package pk.gov.nadra.oneapp.arms.license.network.retrofit;

import com.google.common.net.HttpHeaders;
import java.io.IOException;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;

/* compiled from: RefreshRequestInterceptor.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0016J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0002J\u0010\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0007H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/network/retrofit/RefreshRequestInterceptor;", "Lokhttp3/Interceptor;", "appVersion", "", "<init>", "(Ljava/lang/String;)V", "intercept", "Lokhttp3/Response;", "chain", "Lokhttp3/Interceptor$Chain;", "logRequest", "", "request", "Lokhttp3/Request;", "logResponse", "response", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class RefreshRequestInterceptor implements Interceptor {
    private String appVersion;

    public RefreshRequestInterceptor(String appVersion) {
        Intrinsics.checkNotNullParameter(appVersion, "appVersion");
        this.appVersion = appVersion;
    }

    @Override // okhttp3.Interceptor
    public Response intercept(Interceptor.Chain chain) {
        Intrinsics.checkNotNullParameter(chain, "chain");
        Request request = chain.request();
        return chain.proceed(request.newBuilder().header(HttpHeaders.CONTENT_TYPE, "application/json").header(HttpHeaders.ACCEPT, "*/*").header(HttpHeaders.ACCEPT_ENCODING, "gzip, deflate, br").header("X-App-Version", this.appVersion).method(request.method(), request.body()).build());
    }

    private final void logRequest(Request request) throws IOException {
        System.out.println((Object) ("Request URL: " + request.url()));
        System.out.println((Object) ("Request Method: " + request.method()));
        System.out.println((Object) "Request Headers:");
        for (Pair<? extends String, ? extends String> pair : request.headers()) {
            System.out.println((Object) (pair.getFirst() + ": " + pair.getSecond()));
        }
        RequestBody requestBodyBody = request.body();
        if (requestBodyBody != null) {
            Buffer buffer = new Buffer();
            Intrinsics.checkNotNull(requestBodyBody);
            requestBodyBody.writeTo(buffer);
            System.out.println((Object) ("Request Body: " + buffer.readUtf8()));
        }
    }

    private final void logResponse(Response response) {
        System.out.println((Object) ("Response Code: " + response.code()));
        System.out.println((Object) ("Response Message: " + response.message()));
        System.out.println((Object) "Response Headers:");
        for (Pair<? extends String, ? extends String> pair : response.headers()) {
            System.out.println((Object) (pair.getFirst() + ": " + pair.getSecond()));
        }
        ResponseBody responseBodyBody = response.body();
        String strString = responseBodyBody != null ? responseBodyBody.string() : null;
        if (strString != null) {
            System.out.println((Object) ("Response Body: " + strString));
        }
    }
}