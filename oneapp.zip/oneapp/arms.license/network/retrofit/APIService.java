package pk.gov.nadra.oneapp.arms.license.network.retrofit;

import com.nimbusds.jose.HeaderParameterNames;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: APIService.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\f\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t¨\u0006\r"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/network/retrofit/APIService;", "", "<init>", "()V", "getAPIService", "Lpk/gov/nadra/oneapp/arms/license/network/retrofit/APIInterface;", "tokenProvider", "Lpk/gov/nadra/oneapp/arms/license/network/retrofit/TokenProvider;", "appVersion", "", HeaderParameterNames.ENCRYPTION_ALGORITHM, "", "getRefreshAPIService", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class APIService {
    public static final APIService INSTANCE = new APIService();

    private APIService() {
    }

    public final APIInterface getAPIService(TokenProvider tokenProvider, String appVersion, boolean enc) throws SecurityException {
        Intrinsics.checkNotNullParameter(tokenProvider, "tokenProvider");
        Intrinsics.checkNotNullParameter(appVersion, "appVersion");
        Object objCreate = RetrofitClient.INSTANCE.getClient(tokenProvider, appVersion, enc).create(APIInterface.class);
        Intrinsics.checkNotNullExpressionValue(objCreate, "create(...)");
        return (APIInterface) objCreate;
    }

    public final APIInterface getRefreshAPIService(TokenProvider tokenProvider, String appVersion) throws SecurityException {
        Intrinsics.checkNotNullParameter(tokenProvider, "tokenProvider");
        Intrinsics.checkNotNullParameter(appVersion, "appVersion");
        Object objCreate = RetrofitClient.INSTANCE.getRefreshClient(tokenProvider, appVersion).create(APIInterface.class);
        Intrinsics.checkNotNullExpressionValue(objCreate, "create(...)");
        return (APIInterface) objCreate;
    }
}