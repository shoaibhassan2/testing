package pk.gov.nadra.oneapp.arms.license.network.retrofit;

import java.io.IOException;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okio.Buffer;
import org.apache.commons.io.IOUtils;
import pk.gov.nadra.oneapp.arms.license.network.utils.EncryptionUtil;

/* compiled from: EncryptionInterceptor.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0016J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000bH\u0002J\u0010\u0010\r\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000bH\u0002J\u0010\u0010\u000e\u001a\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u0010H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/network/retrofit/EncryptionInterceptor;", "Lokhttp3/Interceptor;", "aesKey", "", "<init>", "(Ljava/lang/String;)V", "intercept", "Lokhttp3/Response;", "chain", "Lokhttp3/Interceptor$Chain;", "handleGetRequest", "Lokhttp3/Request;", "request", "handlePostRequest", "originalBodyToString", "body", "Lokhttp3/RequestBody;", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class EncryptionInterceptor implements Interceptor {
    private String aesKey;

    public EncryptionInterceptor(String aesKey) {
        Intrinsics.checkNotNullParameter(aesKey, "aesKey");
        this.aesKey = aesKey;
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x0040  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x011a  */
    @Override // okhttp3.Interceptor
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public okhttp3.Response intercept(okhttp3.Interceptor.Chain r15) throws java.io.IOException {
        /*
            Method dump skipped, instructions count: 394
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: pk.gov.nadra.oneapp.arms.license.network.retrofit.EncryptionInterceptor.intercept(okhttp3.Interceptor$Chain):okhttp3.Response");
    }

    private final Request handleGetRequest(Request request) {
        String url = request.url().getUrl();
        String str = url;
        int iIndexOf$default = StringsKt.indexOf$default((CharSequence) str, "/", StringsKt.indexOf$default((CharSequence) str, "//", 0, false, 6, (Object) null) + 2, false, 4, (Object) null);
        if (iIndexOf$default != -1) {
            String strSubstring = url.substring(0, iIndexOf$default);
            Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
            String strSubstring2 = url.substring(iIndexOf$default + 1);
            Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
            List listSplit$default = StringsKt.split$default((CharSequence) strSubstring2, new String[]{"/"}, false, 0, 6, (Object) null);
            if (listSplit$default.size() > 1) {
                try {
                    return request.newBuilder().url(strSubstring + IOUtils.DIR_SEPARATOR_UNIX + ((String) listSplit$default.get(0)) + IOUtils.DIR_SEPARATOR_UNIX + EncryptionUtil.INSTANCE.encrypt(this.aesKey, CollectionsKt.joinToString$default(listSplit$default.subList(1, listSplit$default.size()), "/", null, null, 0, null, null, 62, null))).build();
                } catch (Exception e) {
                    e.printStackTrace();
                    return request;
                }
            }
        }
        return request;
    }

    private final Request handlePostRequest(Request request) throws IOException {
        RequestBody requestBodyBody = request.body();
        if (requestBodyBody != null) {
            try {
                return request.newBuilder().method(request.method(), RequestBody.INSTANCE.create(EncryptionUtil.INSTANCE.encrypt(this.aesKey, originalBodyToString(requestBodyBody)), MediaType.INSTANCE.parse("application/json"))).build();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return request;
    }

    private final String originalBodyToString(RequestBody body) throws IOException {
        Buffer buffer = new Buffer();
        body.writeTo(buffer);
        return buffer.readUtf8();
    }
}