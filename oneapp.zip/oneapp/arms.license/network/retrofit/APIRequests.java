package pk.gov.nadra.oneapp.arms.license.network.retrofit;

import android.content.Context;
import androidx.core.app.NotificationCompat;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.nimbusds.jose.HeaderParameterNames;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.ResponseBody;
import pk.gov.nadra.oneapp.arms.license.models.ARMSLICENSETokenRequest;
import pk.gov.nadra.oneapp.arms.license.models.DeliveryCentersRequestModel;
import pk.gov.nadra.oneapp.arms.license.models.LicenseFeeRequestModel;
import pk.gov.nadra.oneapp.arms.license.models.LicenseListRequestModel;
import pk.gov.nadra.oneapp.arms.license.models.LicenseValidationRequestModel;
import pk.gov.nadra.oneapp.arms.license.network.common.Constants;
import pk.gov.nadra.oneapp.arms.license.network.common.SharedPreferencesTokenProvider;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/* compiled from: APIRequests.kt */
@Metadata(d1 = {"\u0000|\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0012\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\tH\u0002J.\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fJ.\u0010\u0013\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fJ.\u0010\u0014\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u00162\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fJ.\u0010\u0017\u001a\u00020\u000b2\u0006\u0010\u0018\u001a\u00020\u00192\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fJ.\u0010\u001a\u001a\u00020\u000b2\u0006\u0010\u001b\u001a\u00020\u001c2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fJ.\u0010\u001d\u001a\u00020\u000b2\u0006\u0010\u001e\u001a\u00020\u001f2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fJ6\u0010 \u001a\u00020\u000b2\f\u0010!\u001a\b\u0012\u0004\u0012\u00020\u00100\"2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fH\u0002J6\u0010#\u001a\u00020\u000b2\f\u0010!\u001a\b\u0012\u0004\u0012\u00020\u00010\"2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fH\u0002J6\u0010$\u001a\u00020\u000b2\f\u0010!\u001a\b\u0012\u0004\u0012\u00020%0\"2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fH\u0002J6\u0010&\u001a\u00020\u000b2\f\u0010!\u001a\b\u0012\u0004\u0012\u00020'0\"2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020'\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fH\u0002J6\u0010(\u001a\u00020\u000b2\f\u0010)\u001a\b\u0012\u0004\u0012\u00020\u00100*2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fH\u0002J6\u0010+\u001a\u00020\u000b2\f\u0010)\u001a\b\u0012\u0004\u0012\u00020\u00010*2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fH\u0002J6\u0010,\u001a\u00020\u000b2\f\u0010)\u001a\b\u0012\u0004\u0012\u00020%0*2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fH\u0002J6\u0010-\u001a\u00020\u000b2\f\u0010)\u001a\b\u0012\u0004\u0012\u00020'0*2\u001e\u0010\u000e\u001a\u001a\u0012\u0004\u0012\u00020'\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u000b0\u000fH\u0002J\u0010\u0010.\u001a\u00020\u00102\u0006\u0010/\u001a\u00020\u0011H\u0002J\u0010\u00100\u001a\u00020'2\u0006\u0010/\u001a\u00020\u0011H\u0002J\u000e\u00101\u001a\u00020\u00102\u0006\u0010)\u001a\u00020\u0011R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000¨\u00062"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/network/retrofit/APIRequests;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "getAPIService", "Lpk/gov/nadra/oneapp/arms/license/network/retrofit/APIInterface;", HeaderParameterNames.ENCRYPTION_ALGORITHM, "", "generateArmsLicenseRenewalToken", "", "armsLicenseTokenRequest", "Lpk/gov/nadra/oneapp/arms/license/models/ARMSLICENSETokenRequest;", "callback", "Lkotlin/Function3;", "Lcom/google/gson/JsonObject;", "", "", "generateArmsLicenseReprintToken", "getArmsLicenseProducts", "licenseListRequest", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseListRequestModel;", "getCardDeliveryCenters", "deliveryCentersRequest", "Lpk/gov/nadra/oneapp/arms/license/models/DeliveryCentersRequestModel;", "getCardValidations", "cardValidationRequest", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseValidationRequestModel;", "getLicenseFeeSummary", "licenseFeeSummaryRequest", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeRequestModel;", "makeApiCall", NotificationCompat.CATEGORY_CALL, "Lretrofit2/Call;", "makeAnyApiCall", "makeResponseBodyApiCall", "Lokhttp3/ResponseBody;", "makeApiCallForJsonArray", "Lcom/google/gson/JsonArray;", "handleApiResponse", "response", "Lretrofit2/Response;", "handleApiAnyResponse", "handleApiResponseBody", "handleJsonArrayApiResponse", "createErrorJson", "message", "createErrorJsonArray", "createJsonObjectFromString", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class APIRequests {
    private Context context;

    public APIRequests(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    static /* synthetic */ APIInterface getAPIService$default(APIRequests aPIRequests, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = true;
        }
        return aPIRequests.getAPIService(z);
    }

    private final APIInterface getAPIService(boolean enc) {
        SharedPreferencesTokenProvider sharedPreferencesTokenProvider = new SharedPreferencesTokenProvider(this.context);
        String appVersion = Constants.INSTANCE.getAppVersion(this.context);
        if (sharedPreferencesTokenProvider.isEncryptionEnabled()) {
            return APIService.INSTANCE.getAPIService(sharedPreferencesTokenProvider, appVersion, enc);
        }
        return APIService.INSTANCE.getAPIService(sharedPreferencesTokenProvider, appVersion, false);
    }

    public final void generateArmsLicenseRenewalToken(ARMSLICENSETokenRequest armsLicenseTokenRequest, Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        Intrinsics.checkNotNullParameter(armsLicenseTokenRequest, "armsLicenseTokenRequest");
        Intrinsics.checkNotNullParameter(callback, "callback");
        makeApiCall(getAPIService$default(this, false, 1, null).generateArmsLicenseRenewalToken(armsLicenseTokenRequest), callback);
    }

    public final void generateArmsLicenseReprintToken(ARMSLICENSETokenRequest armsLicenseTokenRequest, Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        Intrinsics.checkNotNullParameter(armsLicenseTokenRequest, "armsLicenseTokenRequest");
        Intrinsics.checkNotNullParameter(callback, "callback");
        makeApiCall(getAPIService$default(this, false, 1, null).generateArmsLicenseReprintToken(armsLicenseTokenRequest), callback);
    }

    public final void getArmsLicenseProducts(LicenseListRequestModel licenseListRequest, Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        Intrinsics.checkNotNullParameter(licenseListRequest, "licenseListRequest");
        Intrinsics.checkNotNullParameter(callback, "callback");
        makeApiCall(getAPIService$default(this, false, 1, null).getArmsLicenseProducts(licenseListRequest), callback);
    }

    public final void getCardDeliveryCenters(DeliveryCentersRequestModel deliveryCentersRequest, Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        Intrinsics.checkNotNullParameter(deliveryCentersRequest, "deliveryCentersRequest");
        Intrinsics.checkNotNullParameter(callback, "callback");
        makeApiCall(getAPIService$default(this, false, 1, null).getCardDeliveryCenters(deliveryCentersRequest), callback);
    }

    public final void getCardValidations(LicenseValidationRequestModel cardValidationRequest, Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        Intrinsics.checkNotNullParameter(cardValidationRequest, "cardValidationRequest");
        Intrinsics.checkNotNullParameter(callback, "callback");
        makeApiCall(getAPIService$default(this, false, 1, null).getCardValidations(cardValidationRequest), callback);
    }

    public final void getLicenseFeeSummary(LicenseFeeRequestModel licenseFeeSummaryRequest, Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        Intrinsics.checkNotNullParameter(licenseFeeSummaryRequest, "licenseFeeSummaryRequest");
        Intrinsics.checkNotNullParameter(callback, "callback");
        makeApiCall(getAPIService$default(this, false, 1, null).getLicenseFeeSummary(licenseFeeSummaryRequest), callback);
    }

    private final void makeApiCall(Call<JsonObject> call, final Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        call.enqueue(new Callback<JsonObject>() { // from class: pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests.makeApiCall.1
            @Override // retrofit2.Callback
            public void onResponse(Call<JsonObject> call2, Response<JsonObject> response) {
                Intrinsics.checkNotNullParameter(call2, "call");
                Intrinsics.checkNotNullParameter(response, "response");
                APIRequests.this.handleApiResponse(response, callback);
            }

            @Override // retrofit2.Callback
            public void onFailure(Call<JsonObject> call2, Throwable t) {
                String message;
                String message2;
                Intrinsics.checkNotNullParameter(call2, "call");
                Intrinsics.checkNotNullParameter(t, "t");
                String message3 = t.getMessage();
                if ((message3 != null && StringsKt.contains((CharSequence) message3, (CharSequence) "timeout", true)) || (((message = t.getMessage()) != null && StringsKt.contains((CharSequence) message, (CharSequence) "connection", true)) || ((message2 = t.getMessage()) != null && StringsKt.contains((CharSequence) message2, (CharSequence) "Unable to resolve host", true)))) {
                    callback.invoke(APIRequests.this.createErrorJson("Network is unstable. Please check your internet connection."), "FAILURE", -1);
                } else {
                    callback.invoke(APIRequests.this.createErrorJson("Unable to process your request. Try again later."), "FAILURE", -1);
                }
            }
        });
    }

    private final void makeAnyApiCall(Call<Object> call, final Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        call.enqueue(new Callback<Object>() { // from class: pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests.makeAnyApiCall.1
            @Override // retrofit2.Callback
            public void onResponse(Call<Object> call2, Response<Object> response) {
                Intrinsics.checkNotNullParameter(call2, "call");
                Intrinsics.checkNotNullParameter(response, "response");
                APIRequests.this.handleApiAnyResponse(response, callback);
            }

            @Override // retrofit2.Callback
            public void onFailure(Call<Object> call2, Throwable t) {
                String message;
                String message2;
                Intrinsics.checkNotNullParameter(call2, "call");
                Intrinsics.checkNotNullParameter(t, "t");
                String message3 = t.getMessage();
                if ((message3 != null && StringsKt.contains((CharSequence) message3, (CharSequence) "timeout", true)) || (((message = t.getMessage()) != null && StringsKt.contains((CharSequence) message, (CharSequence) "connection", true)) || ((message2 = t.getMessage()) != null && StringsKt.contains((CharSequence) message2, (CharSequence) "Unable to resolve host", true)))) {
                    callback.invoke(APIRequests.this.createErrorJson("Network is unstable. Please check your internet connection."), "FAILURE", -1);
                } else {
                    callback.invoke(APIRequests.this.createErrorJson("Unable to process your request. Try again later."), "FAILURE", -1);
                }
            }
        });
    }

    private final void makeResponseBodyApiCall(Call<ResponseBody> call, final Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        call.enqueue(new Callback<ResponseBody>() { // from class: pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests.makeResponseBodyApiCall.1
            @Override // retrofit2.Callback
            public void onResponse(Call<ResponseBody> call2, Response<ResponseBody> response) {
                Intrinsics.checkNotNullParameter(call2, "call");
                Intrinsics.checkNotNullParameter(response, "response");
                APIRequests.this.handleApiResponseBody(response, callback);
            }

            @Override // retrofit2.Callback
            public void onFailure(Call<ResponseBody> call2, Throwable t) {
                String message;
                String message2;
                Intrinsics.checkNotNullParameter(call2, "call");
                Intrinsics.checkNotNullParameter(t, "t");
                String message3 = t.getMessage();
                if ((message3 != null && StringsKt.contains((CharSequence) message3, (CharSequence) "timeout", true)) || (((message = t.getMessage()) != null && StringsKt.contains((CharSequence) message, (CharSequence) "connection", true)) || ((message2 = t.getMessage()) != null && StringsKt.contains((CharSequence) message2, (CharSequence) "Unable to resolve host", true)))) {
                    callback.invoke(APIRequests.this.createErrorJson("Network is unstable. Please check your internet connection."), "FAILURE", -1);
                } else {
                    callback.invoke(APIRequests.this.createErrorJson("Unable to process your request. Try again later."), "FAILURE", -1);
                }
            }
        });
    }

    private final void makeApiCallForJsonArray(Call<JsonArray> call, final Function3<? super JsonArray, ? super String, ? super Integer, Unit> callback) {
        call.enqueue(new Callback<JsonArray>() { // from class: pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests.makeApiCallForJsonArray.1
            @Override // retrofit2.Callback
            public void onResponse(Call<JsonArray> call2, Response<JsonArray> response) {
                Intrinsics.checkNotNullParameter(call2, "call");
                Intrinsics.checkNotNullParameter(response, "response");
                APIRequests.this.handleJsonArrayApiResponse(response, callback);
            }

            @Override // retrofit2.Callback
            public void onFailure(Call<JsonArray> call2, Throwable t) {
                String message;
                String message2;
                Intrinsics.checkNotNullParameter(call2, "call");
                Intrinsics.checkNotNullParameter(t, "t");
                String message3 = t.getMessage();
                if ((message3 != null && StringsKt.contains((CharSequence) message3, (CharSequence) "timeout", true)) || (((message = t.getMessage()) != null && StringsKt.contains((CharSequence) message, (CharSequence) "connection", true)) || ((message2 = t.getMessage()) != null && StringsKt.contains((CharSequence) message2, (CharSequence) "Unable to resolve host", true)))) {
                    callback.invoke(APIRequests.this.createErrorJsonArray("Network is unstable. Please check your internet connection."), "FAILURE", -1);
                } else {
                    callback.invoke(APIRequests.this.createErrorJsonArray("Unable to process your request. Try again later."), "FAILURE", -1);
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleApiResponse(Response<JsonObject> response, Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        if (response.isSuccessful()) {
            JsonObject jsonObjectBody = response.body();
            if (jsonObjectBody != null) {
                callback.invoke(jsonObjectBody, "SUCCESS", Integer.valueOf(response.code()));
                return;
            } else {
                callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
                return;
            }
        }
        if (response.code() == 401) {
            callback.invoke(createErrorJson("Your session has been expired. Please login."), "FAILURE", Integer.valueOf(response.code()));
            return;
        }
        if (response.code() == 400 || response.code() == 500 || response.code() == 503) {
            ResponseBody responseBodyErrorBody = response.errorBody();
            if (responseBodyErrorBody != null) {
                try {
                    JsonObject asJsonObject = JsonParser.parseString(responseBodyErrorBody.string()).getAsJsonObject();
                    Intrinsics.checkNotNull(asJsonObject);
                    callback.invoke(asJsonObject, "FAILURE", Integer.valueOf(response.code()));
                    return;
                } catch (Exception unused) {
                    callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
                    return;
                }
            }
            callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
            return;
        }
        callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleApiAnyResponse(Response<Object> response, Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        if (response.isSuccessful()) {
            Object objBody = response.body();
            if (objBody != null) {
                if (objBody instanceof String) {
                    callback.invoke(createJsonObjectFromString((String) objBody), "SUCCESS", Integer.valueOf(response.code()));
                    return;
                } else if (objBody instanceof JsonObject) {
                    callback.invoke(objBody, "SUCCESS", Integer.valueOf(response.code()));
                    return;
                } else {
                    callback.invoke(createErrorJson("Unexpected response type"), "FAILURE", Integer.valueOf(response.code()));
                    return;
                }
            }
            callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
            return;
        }
        if (response.code() == 401) {
            callback.invoke(createErrorJson("Your session has been expired. Please login."), "FAILURE", Integer.valueOf(response.code()));
            return;
        }
        if (response.code() == 400 || response.code() == 500 || response.code() == 503) {
            ResponseBody responseBodyErrorBody = response.errorBody();
            if (responseBodyErrorBody != null) {
                try {
                    JsonObject asJsonObject = JsonParser.parseString(responseBodyErrorBody.string()).getAsJsonObject();
                    Intrinsics.checkNotNull(asJsonObject);
                    callback.invoke(asJsonObject, "FAILURE", Integer.valueOf(response.code()));
                    return;
                } catch (Exception unused) {
                    callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
                    return;
                }
            }
            callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
            return;
        }
        callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleApiResponseBody(Response<ResponseBody> response, Function3<? super JsonObject, ? super String, ? super Integer, Unit> callback) {
        if (response.isSuccessful()) {
            ResponseBody responseBodyBody = response.body();
            if (responseBodyBody != null) {
                String string = StringsKt.trim((CharSequence) responseBodyBody.string()).toString();
                if (string.length() == 0) {
                    callback.invoke(createJsonObjectFromString("Response is Empty"), "SUCCESS", Integer.valueOf(response.code()));
                    return;
                }
                try {
                    JsonObject asJsonObject = JsonParser.parseString(string).getAsJsonObject();
                    Intrinsics.checkNotNull(asJsonObject);
                    callback.invoke(asJsonObject, "SUCCESS", Integer.valueOf(response.code()));
                    return;
                } catch (JsonSyntaxException unused) {
                    callback.invoke(createErrorJson("Unexpected response type"), "FAILURE", Integer.valueOf(response.code()));
                    return;
                }
            }
            callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
            return;
        }
        if (response.code() == 401) {
            callback.invoke(createErrorJson("Your session has been expired. Please login."), "FAILURE", Integer.valueOf(response.code()));
            return;
        }
        if (response.code() == 400 || response.code() == 500 || response.code() == 503) {
            ResponseBody responseBodyErrorBody = response.errorBody();
            if (responseBodyErrorBody != null) {
                try {
                    JsonObject asJsonObject2 = JsonParser.parseString(responseBodyErrorBody.string()).getAsJsonObject();
                    Intrinsics.checkNotNull(asJsonObject2);
                    callback.invoke(asJsonObject2, "FAILURE", Integer.valueOf(response.code()));
                    return;
                } catch (Exception unused2) {
                    callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
                    return;
                }
            }
            callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
            return;
        }
        callback.invoke(createErrorJson("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleJsonArrayApiResponse(Response<JsonArray> response, Function3<? super JsonArray, ? super String, ? super Integer, Unit> callback) {
        if (response.isSuccessful()) {
            JsonArray jsonArrayBody = response.body();
            if (jsonArrayBody != null) {
                callback.invoke(jsonArrayBody, "SUCCESS", Integer.valueOf(response.code()));
                return;
            } else {
                callback.invoke(createErrorJsonArray("Response body is null"), "FAILURE", Integer.valueOf(response.code()));
                return;
            }
        }
        if (response.code() == 401) {
            callback.invoke(createErrorJsonArray("Your session has been expired. Please login."), "FAILURE", Integer.valueOf(response.code()));
            return;
        }
        if (response.code() == 400 || response.code() == 500 || response.code() == 503) {
            ResponseBody responseBodyErrorBody = response.errorBody();
            if (responseBodyErrorBody != null) {
                try {
                    JsonElement string = JsonParser.parseString(responseBodyErrorBody.string());
                    JsonArray jsonArray = new JsonArray();
                    jsonArray.add(string);
                    callback.invoke(jsonArray, "FAILURE", Integer.valueOf(response.code()));
                    return;
                } catch (Exception unused) {
                    callback.invoke(createErrorJsonArray("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
                    return;
                }
            }
            callback.invoke(createErrorJsonArray("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
            return;
        }
        callback.invoke(createErrorJsonArray("Unable to process your request. Try again later."), "FAILURE", Integer.valueOf(response.code()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final JsonObject createErrorJson(String message) {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("error", (Boolean) true);
        jsonObject.addProperty("message", message);
        return jsonObject;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final JsonArray createErrorJsonArray(String message) {
        JsonArray jsonArray = new JsonArray();
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("error", (Boolean) true);
        jsonObject.addProperty("message", message);
        jsonArray.add(jsonObject);
        return jsonArray;
    }

    public final JsonObject createJsonObjectFromString(String response) {
        Intrinsics.checkNotNullParameter(response, "response");
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("response", response);
        return jsonObject;
    }
}