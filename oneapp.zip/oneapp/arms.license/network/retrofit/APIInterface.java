package pk.gov.nadra.oneapp.arms.license.network.retrofit;

import com.google.gson.JsonObject;
import kotlin.Metadata;
import pk.gov.nadra.oneapp.arms.license.models.ARMSLICENSETokenRequest;
import pk.gov.nadra.oneapp.arms.license.models.DeliveryCentersRequestModel;
import pk.gov.nadra.oneapp.arms.license.models.LicenseFeeRequestModel;
import pk.gov.nadra.oneapp.arms.license.models.LicenseListRequestModel;
import pk.gov.nadra.oneapp.arms.license.models.LicenseValidationRequestModel;
import pk.gov.nadra.oneapp.arms.license.network.models.RefreshTokenResponse;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

/* compiled from: APIInterface.kt */
@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0001\u0010\u0005\u001a\u00020\u0006H'J\u0018\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0001\u0010\u0005\u001a\u00020\u0006H'J\u0018\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0001\u0010\t\u001a\u00020\nH'J\u0018\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\f0\u00032\b\b\u0001\u0010\u000b\u001a\u00020\rH'J\u0018\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0001\u0010\u000f\u001a\u00020\u0010H'J\u0018\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0001\u0010\u0012\u001a\u00020\u0013H'J\u0018\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0001\u0010\u0015\u001a\u00020\u0016H'¨\u0006\u0017"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/network/retrofit/APIInterface;", "", "generateArmsLicenseRenewalToken", "Lretrofit2/Call;", "Lcom/google/gson/JsonObject;", "ARMSLICENSETokenRequest", "Lpk/gov/nadra/oneapp/arms/license/models/ARMSLICENSETokenRequest;", "generateArmsLicenseReprintToken", "getArmsLicenseProducts", "licenseListRequest", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseListRequestModel;", "refreshToken", "Lpk/gov/nadra/oneapp/arms/license/network/models/RefreshTokenResponse;", "", "getCardDeliveryCenters", "deliveryCentersRequest", "Lpk/gov/nadra/oneapp/arms/license/models/DeliveryCentersRequestModel;", "getCardValidations", "cardValidationRequest", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseValidationRequestModel;", "getLicenseFeeSummary", "licenseFeeSummaryRequest", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeRequestModel;", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public interface APIInterface {
    @POST("/app-token-service/pals/renewal")
    Call<JsonObject> generateArmsLicenseRenewalToken(@Body ARMSLICENSETokenRequest ARMSLICENSETokenRequest);

    @POST("/app-token-service/pals/reprint")
    Call<JsonObject> generateArmsLicenseReprintToken(@Body ARMSLICENSETokenRequest ARMSLICENSETokenRequest);

    @POST("app-token-service/pals/licenses")
    Call<JsonObject> getArmsLicenseProducts(@Body LicenseListRequestModel licenseListRequest);

    @POST("armslicense-middleware/centers/")
    Call<JsonObject> getCardDeliveryCenters(@Body DeliveryCentersRequestModel deliveryCentersRequest);

    @POST("armslicense-middleware/licenses/validity")
    Call<JsonObject> getCardValidations(@Body LicenseValidationRequestModel cardValidationRequest);

    @POST("armslicense-middleware/license/fee/")
    Call<JsonObject> getLicenseFeeSummary(@Body LicenseFeeRequestModel licenseFeeSummaryRequest);

    @GET("authentication/api/v1/refresh-token/{refreshToken}")
    Call<RefreshTokenResponse> refreshToken(@Path("refreshToken") String refreshToken);
}