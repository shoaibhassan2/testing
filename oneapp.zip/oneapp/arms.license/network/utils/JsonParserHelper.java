package pk.gov.nadra.oneapp.arms.license.network.utils;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: JsonParserHelper.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J0\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0018\u0010\n\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f\u0012\u0004\u0012\u00020\u00050\u000b¨\u0006\u000e"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/network/utils/JsonParserHelper;", "", "<init>", "()V", "parseJsonData", "", "jsonObject", "Lcom/google/gson/JsonObject;", "dataKey", "", "callback", "Lkotlin/Function1;", "Lkotlin/Result;", "Lcom/google/gson/JsonElement;", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class JsonParserHelper {
    public static final JsonParserHelper INSTANCE = new JsonParserHelper();

    private JsonParserHelper() {
    }

    public final void parseJsonData(JsonObject jsonObject, String dataKey, Function1<? super Result<? extends JsonElement>, Unit> callback) {
        String asString;
        Intrinsics.checkNotNullParameter(jsonObject, "jsonObject");
        Intrinsics.checkNotNullParameter(dataKey, "dataKey");
        Intrinsics.checkNotNullParameter(callback, "callback");
        try {
            if (jsonObject.has(dataKey) && !jsonObject.get(dataKey).isJsonNull()) {
                JsonElement jsonElement = jsonObject.get(dataKey);
                Result.Companion companion = Result.INSTANCE;
                callback.invoke(Result.m7257boximpl(Result.m7258constructorimpl(jsonElement)));
                return;
            }
            JsonElement jsonElement2 = jsonObject.get("message");
            if (jsonElement2 == null || (asString = jsonElement2.getAsString()) == null) {
                asString = "Data not found";
            }
            Result.Companion companion2 = Result.INSTANCE;
            callback.invoke(Result.m7257boximpl(Result.m7258constructorimpl(ResultKt.createFailure(new Exception(asString)))));
        } catch (Exception e) {
            Result.Companion companion3 = Result.INSTANCE;
            callback.invoke(Result.m7257boximpl(Result.m7258constructorimpl(ResultKt.createFailure(new Exception("Failed to parse response data: " + e.getLocalizedMessage())))));
        }
    }
}