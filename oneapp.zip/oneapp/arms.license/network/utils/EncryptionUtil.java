package pk.gov.nadra.oneapp.arms.license.network.utils;

import android.os.Build;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;

/* compiled from: EncryptionUtil.kt */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0007\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0016\u0010\u0007\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\u0005J\u0016\u0010\n\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u00052\u0006\u0010\u000b\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/network/utils/EncryptionUtil;", "", "<init>", "()V", "ALGORITHM", "", "TRANSFORMATION", "encrypt", "secretKey", "data", "decrypt", "cipherText", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class EncryptionUtil {
    private static final String ALGORITHM = "AES";
    public static final EncryptionUtil INSTANCE = new EncryptionUtil();
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";

    private EncryptionUtil() {
    }

    public final String encrypt(String secretKey, String data) throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {
        Intrinsics.checkNotNullParameter(secretKey, "secretKey");
        Intrinsics.checkNotNullParameter(data, "data");
        byte[] bytes = secretKey.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        String strSubstring = secretKey.substring(0, 16);
        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        byte[] bytes2 = strSubstring.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
        SecretKeySpec secretKeySpec = new SecretKeySpec(bytes, "AES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(bytes2);
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(1, secretKeySpec, ivParameterSpec);
        byte[] bytes3 = data.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes3, "getBytes(...)");
        byte[] bArrDoFinal = cipher.doFinal(bytes3);
        if (Build.VERSION.SDK_INT >= 26) {
            byte[] bArrEncode = Base64.getEncoder().encode(Base64.getEncoder().encode(bArrDoFinal));
            Intrinsics.checkNotNullExpressionValue(bArrEncode, "encode(...)");
            return new String(bArrEncode, Charsets.UTF_8);
        }
        String strEncodeToString = android.util.Base64.encodeToString(bArrDoFinal, 2);
        Intrinsics.checkNotNullExpressionValue(strEncodeToString, "encodeToString(...)");
        byte[] bytes4 = strEncodeToString.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes4, "getBytes(...)");
        String strEncodeToString2 = android.util.Base64.encodeToString(bytes4, 2);
        Intrinsics.checkNotNull(strEncodeToString2);
        return strEncodeToString2;
    }

    public final String decrypt(String secretKey, String cipherText) throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {
        byte[] bArrDecode;
        Intrinsics.checkNotNullParameter(secretKey, "secretKey");
        Intrinsics.checkNotNullParameter(cipherText, "cipherText");
        byte[] bytes = secretKey.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        String strSubstring = secretKey.substring(0, 16);
        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        byte[] bytes2 = strSubstring.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
        SecretKeySpec secretKeySpec = new SecretKeySpec(bytes, "AES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(bytes2);
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(2, secretKeySpec, ivParameterSpec);
        if (Build.VERSION.SDK_INT >= 26) {
            bArrDecode = Base64.getDecoder().decode(Base64.getDecoder().decode(cipherText));
        } else {
            bArrDecode = android.util.Base64.decode(android.util.Base64.decode(cipherText, 2), 2);
        }
        byte[] bArrDoFinal = cipher.doFinal(bArrDecode);
        Intrinsics.checkNotNull(bArrDoFinal);
        return new String(bArrDoFinal, Charsets.UTF_8);
    }
}