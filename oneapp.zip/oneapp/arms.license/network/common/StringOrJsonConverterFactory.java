package pk.gov.nadra.oneapp.arms.license.network.common;

import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.ResponseBody;
import retrofit2.Converter;
import retrofit2.Retrofit;

/* compiled from: StringOrJsonConverterFactory.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u001b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J7\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0002\b\u0003\u0018\u00010\u00072\u0006\u0010\t\u001a\u00020\n2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\f2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016¢\u0006\u0002\u0010\u0010R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/network/common/StringOrJsonConverterFactory;", "Lretrofit2/Converter$Factory;", "gson", "Lcom/google/gson/Gson;", "<init>", "(Lcom/google/gson/Gson;)V", "responseBodyConverter", "Lretrofit2/Converter;", "Lokhttp3/ResponseBody;", "type", "Ljava/lang/reflect/Type;", "annotations", "", "", "retrofit", "Lretrofit2/Retrofit;", "(Ljava/lang/reflect/Type;[Ljava/lang/annotation/Annotation;Lretrofit2/Retrofit;)Lretrofit2/Converter;", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class StringOrJsonConverterFactory extends Converter.Factory {
    private final Gson gson;

    public StringOrJsonConverterFactory(Gson gson) {
        Intrinsics.checkNotNullParameter(gson, "gson");
        this.gson = gson;
    }

    @Override // retrofit2.Converter.Factory
    public Converter<ResponseBody, ?> responseBodyConverter(Type type, Annotation[] annotations, Retrofit retrofit) {
        Intrinsics.checkNotNullParameter(type, "type");
        Intrinsics.checkNotNullParameter(annotations, "annotations");
        Intrinsics.checkNotNullParameter(retrofit, "retrofit");
        final Converter converterNextResponseBodyConverter = retrofit.nextResponseBodyConverter(this, type, annotations);
        return new Converter() { // from class: pk.gov.nadra.oneapp.arms.license.network.common.StringOrJsonConverterFactory$$ExternalSyntheticLambda0
            @Override // retrofit2.Converter
            public final Object convert(Object obj) {
                return StringOrJsonConverterFactory.responseBodyConverter$lambda$0(converterNextResponseBodyConverter, (ResponseBody) obj);
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Object responseBodyConverter$lambda$0(Converter converter, ResponseBody responseBody) {
        responseBody.contentLength();
        String string = StringsKt.trim((CharSequence) responseBody.string()).toString();
        if (string.length() == 0) {
            return "Response is Empty";
        }
        try {
            JsonParser.parseString(string);
            return converter.convert(ResponseBody.INSTANCE.create(responseBody.contentType(), string));
        } catch (JsonSyntaxException e) {
            e.printStackTrace();
            return string;
        }
    }
}