package pk.gov.nadra.oneapp.arms.license.network.common;

import okhttp3.ResponseBody;
import retrofit2.Converter;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class StringOrJsonConverterFactory$$ExternalSyntheticLambda0 implements Converter {
    public /* synthetic */ StringOrJsonConverterFactory$$ExternalSyntheticLambda0() {
    }

    @Override // retrofit2.Converter
    public final Object convert(Object obj) {
        return StringOrJsonConverterFactory.responseBodyConverter$lambda$0(converterNextResponseBodyConverter, (ResponseBody) obj);
    }
}