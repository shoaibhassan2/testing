package pk.gov.nadra.oneapp.arms.license.network.common;

import android.content.Context;
import android.content.SharedPreferences;
import com.veridiumid.sdk.analytics.Analytics;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider;

/* compiled from: SharedPreferencesTokenProvider.kt */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0012\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016J\b\u0010\u000f\u001a\u00020\u000eH\u0016J\u0012\u0010\u0010\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016J\b\u0010\u0011\u001a\u00020\u000eH\u0016J\u0012\u0010\u0012\u001a\u00020\f2\b\u0010\u0013\u001a\u0004\u0018\u00010\u000eH\u0016J\b\u0010\u0014\u001a\u00020\u000eH\u0016J\u0012\u0010\u0015\u001a\u00020\f2\b\u0010\u0016\u001a\u0004\u0018\u00010\u000eH\u0016J\b\u0010\u0017\u001a\u00020\u000eH\u0016J\u0010\u0010\u0018\u001a\u00020\f2\u0006\u0010\u0019\u001a\u00020\u001aH\u0016J\b\u0010\u001b\u001a\u00020\u001aH\u0016J\u0012\u0010\u001c\u001a\u00020\f2\b\u0010\u001d\u001a\u0004\u0018\u00010\u000eH\u0016J\b\u0010\u001e\u001a\u00020\u000eH\u0016R\u0018\u0010\u0006\u001a\n \b*\u0004\u0018\u00010\u00070\u0007X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\tR\u000e\u0010\n\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001f"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/network/common/SharedPreferencesTokenProvider;", "Lpk/gov/nadra/oneapp/arms/license/network/retrofit/TokenProvider;", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "preferences", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "Landroid/content/SharedPreferences;", "securePrefContext", "saveToken", "", "token", "", "getToken", "saveRefreshToken", "getRefreshToken", "saveAesKey", "aesKey", "getAesKey", "saveDeviceId", "deviceId", "getDeviceId", "saveEncryptionEnabled", "isEnabled", "", "isEncryptionEnabled", "saveUsername", "userName", "getUsername", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class SharedPreferencesTokenProvider implements TokenProvider {
    private final SharedPreferences preferences;
    private final Context securePrefContext;

    public SharedPreferencesTokenProvider(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.preferences = context.getSharedPreferences(Analytics.Cat.AUTH, 0);
        this.securePrefContext = context;
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public void saveToken(String token) {
        try {
            this.preferences.edit().putString("access_token", "").apply();
            ArmsLicenseSecureStorageHelper companion = ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext);
            Intrinsics.checkNotNull(token);
            companion.saveString("access_token", token);
        } catch (Exception unused) {
        }
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public String getToken() {
        try {
            String string = ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext).getString("access_token");
            Intrinsics.checkNotNull(string);
            return string;
        } catch (Exception unused) {
            return "";
        }
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public void saveRefreshToken(String token) {
        try {
            this.preferences.edit().putString("refresh_token", "").apply();
            ArmsLicenseSecureStorageHelper companion = ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext);
            Intrinsics.checkNotNull(token);
            companion.saveString("refresh_token", token);
        } catch (Exception unused) {
        }
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public String getRefreshToken() {
        try {
            String string = ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext).getString("refresh_token");
            Intrinsics.checkNotNull(string);
            return string;
        } catch (Exception unused) {
            return "";
        }
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public void saveAesKey(String aesKey) {
        try {
            this.preferences.edit().putString("aes_key", "").apply();
            ArmsLicenseSecureStorageHelper companion = ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext);
            Intrinsics.checkNotNull(aesKey);
            companion.saveString("aes_key", aesKey);
        } catch (Exception unused) {
        }
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public String getAesKey() {
        try {
            String string = ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext).getString("aes_key");
            Intrinsics.checkNotNull(string);
            return string;
        } catch (Exception unused) {
            return "";
        }
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public void saveDeviceId(String deviceId) {
        try {
            this.preferences.edit().putString("device_id", "").apply();
            ArmsLicenseSecureStorageHelper companion = ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext);
            Intrinsics.checkNotNull(deviceId);
            companion.saveString("device_id", deviceId);
        } catch (Exception unused) {
        }
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public String getDeviceId() {
        try {
            String string = ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext).getString("device_id");
            Intrinsics.checkNotNull(string);
            return string;
        } catch (Exception unused) {
            return "";
        }
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public void saveEncryptionEnabled(boolean isEnabled) {
        this.preferences.edit().putBoolean("is_encryption_enabled", false).apply();
        ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext).saveBoolean("is_encryption_enabled", isEnabled);
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public boolean isEncryptionEnabled() {
        return ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext).getBoolean("is_encryption_enabled", false);
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public void saveUsername(String userName) {
        try {
            this.preferences.edit().putString("user_name", "").apply();
            ArmsLicenseSecureStorageHelper companion = ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext);
            Intrinsics.checkNotNull(userName);
            companion.saveString("user_name", userName);
        } catch (Exception unused) {
        }
    }

    @Override // pk.gov.nadra.oneapp.arms.license.network.retrofit.TokenProvider
    public String getUsername() {
        try {
            String string = ArmsLicenseSecureStorageHelper.INSTANCE.getInstance(this.securePrefContext).getString("user_name");
            Intrinsics.checkNotNull(string);
            return string;
        } catch (Exception unused) {
            return "";
        }
    }
}