package pk.gov.nadra.oneapp.arms.license.network.common;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKeys;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import java.io.IOException;
import java.security.GeneralSecurityException;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ArmsLicenseSecureStorageHelper.kt */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0006\u0018\u0000 \u00182\u00020\u0001:\u0001\u0018B\u0011\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000fJ\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u000f2\u0006\u0010\u000e\u001a\u00020\u000fJ\u0016\u0010\u0012\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0013J\u0018\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u000e\u001a\u00020\u000f2\b\b\u0002\u0010\u0015\u001a\u00020\u0013J\u000e\u0010\u0016\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fJ\u0006\u0010\u0017\u001a\u00020\rR\u001b\u0010\u0006\u001a\u00020\u00078BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\n\u0010\u000b\u001a\u0004\b\b\u0010\t¨\u0006\u0019"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/network/common/ArmsLicenseSecureStorageHelper;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "sharedPreferences", "Landroid/content/SharedPreferences;", "getSharedPreferences", "()Landroid/content/SharedPreferences;", "sharedPreferences$delegate", "Lkotlin/Lazy;", "saveString", "", "key", "", "value", "getString", "saveBoolean", "", "getBoolean", "defaultValue", ProductAction.ACTION_REMOVE, "clearAll", "Companion", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ArmsLicenseSecureStorageHelper {

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private static final String PREF_NAME = "secure_prefs";
    private static volatile ArmsLicenseSecureStorageHelper instance;

    /* renamed from: sharedPreferences$delegate, reason: from kotlin metadata */
    private final Lazy sharedPreferences;

    public /* synthetic */ ArmsLicenseSecureStorageHelper(Context context, DefaultConstructorMarker defaultConstructorMarker) {
        this(context);
    }

    private ArmsLicenseSecureStorageHelper(final Context context) {
        this.sharedPreferences = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.network.common.ArmsLicenseSecureStorageHelper$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ArmsLicenseSecureStorageHelper.sharedPreferences_delegate$lambda$0(context);
            }
        });
    }

    private final SharedPreferences getSharedPreferences() {
        Object value = this.sharedPreferences.getValue();
        Intrinsics.checkNotNullExpressionValue(value, "getValue(...)");
        return (SharedPreferences) value;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final SharedPreferences sharedPreferences_delegate$lambda$0(Context context) throws GeneralSecurityException, IOException {
        Intrinsics.checkNotNullParameter(context, "$context");
        Context applicationContext = context.getApplicationContext();
        String orCreate = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC);
        Intrinsics.checkNotNullExpressionValue(orCreate, "getOrCreate(...)");
        return EncryptedSharedPreferences.create(PREF_NAME, orCreate, applicationContext, EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
    }

    public final void saveString(String key, String value) {
        Intrinsics.checkNotNullParameter(key, "key");
        Intrinsics.checkNotNullParameter(value, "value");
        getSharedPreferences().edit().putString(key, value).apply();
    }

    public final String getString(String key) {
        Intrinsics.checkNotNullParameter(key, "key");
        return getSharedPreferences().getString(key, null);
    }

    public final void saveBoolean(String key, boolean value) {
        Intrinsics.checkNotNullParameter(key, "key");
        getSharedPreferences().edit().putBoolean(key, value).apply();
    }

    public static /* synthetic */ boolean getBoolean$default(ArmsLicenseSecureStorageHelper armsLicenseSecureStorageHelper, String str, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        return armsLicenseSecureStorageHelper.getBoolean(str, z);
    }

    public final boolean getBoolean(String key, boolean defaultValue) {
        Intrinsics.checkNotNullParameter(key, "key");
        return getSharedPreferences().getBoolean(key, defaultValue);
    }

    public final void remove(String key) {
        Intrinsics.checkNotNullParameter(key, "key");
        getSharedPreferences().edit().remove(key).apply();
    }

    public final void clearAll() {
        getSharedPreferences().edit().clear().apply();
    }

    /* compiled from: ArmsLicenseSecureStorageHelper.kt */
    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\nR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/network/common/ArmsLicenseSecureStorageHelper$Companion;", "", "<init>", "()V", "PREF_NAME", "", "instance", "Lpk/gov/nadra/oneapp/arms/license/network/common/ArmsLicenseSecureStorageHelper;", "getInstance", "context", "Landroid/content/Context;", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final ArmsLicenseSecureStorageHelper getInstance(Context context) {
            ArmsLicenseSecureStorageHelper armsLicenseSecureStorageHelper;
            Intrinsics.checkNotNullParameter(context, "context");
            ArmsLicenseSecureStorageHelper armsLicenseSecureStorageHelper2 = ArmsLicenseSecureStorageHelper.instance;
            if (armsLicenseSecureStorageHelper2 != null) {
                return armsLicenseSecureStorageHelper2;
            }
            synchronized (this) {
                armsLicenseSecureStorageHelper = ArmsLicenseSecureStorageHelper.instance;
                if (armsLicenseSecureStorageHelper == null) {
                    armsLicenseSecureStorageHelper = new ArmsLicenseSecureStorageHelper(context, null);
                    Companion companion = ArmsLicenseSecureStorageHelper.INSTANCE;
                    ArmsLicenseSecureStorageHelper.instance = armsLicenseSecureStorageHelper;
                }
            }
            return armsLicenseSecureStorageHelper;
        }
    }
}