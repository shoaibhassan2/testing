package pk.gov.nadra.oneapp.arms.license.network.common;

import android.content.Context;
import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ArmsLicenseSecureStorageHelper$$ExternalSyntheticLambda0 implements Function0 {
    public final /* synthetic */ Context f$0;

    public /* synthetic */ ArmsLicenseSecureStorageHelper$$ExternalSyntheticLambda0(Context context) {
        context = context;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return ArmsLicenseSecureStorageHelper.sharedPreferences_delegate$lambda$0(context);
    }
}