package pk.gov.nadra.oneapp.arms.license.models;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ARMSLICENSETokenResponse.kt */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0019\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B9\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0003¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003J;\u0010\u001b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u001c\u001a\u00020\u001d2\b\u0010\u001e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001f\u001a\u00020 HÖ\u0001J\t\u0010!\u001a\u00020\u0003HÖ\u0001R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u001a\u0010\u0004\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000b\"\u0004\b\u000f\u0010\rR\u001a\u0010\u0005\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u000b\"\u0004\b\u0011\u0010\rR\u001a\u0010\u0006\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u000b\"\u0004\b\u0013\u0010\rR\u001a\u0010\u0007\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u000b\"\u0004\b\u0015\u0010\r¨\u0006\""}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/models/ARMSLICENSETokenResponse;", "", "appDataStatus", "", "appTypeCode", "documentCode", "trackingId", "applicationPin", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getAppDataStatus", "()Ljava/lang/String;", "setAppDataStatus", "(Ljava/lang/String;)V", "getAppTypeCode", "setAppTypeCode", "getDocumentCode", "setDocumentCode", "getTrackingId", "setTrackingId", "getApplicationPin", "setApplicationPin", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "", "toString", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final /* data */ class ARMSLICENSETokenResponse {
    private String appDataStatus;
    private String appTypeCode;
    private String applicationPin;
    private String documentCode;
    private String trackingId;

    public ARMSLICENSETokenResponse() {
        this(null, null, null, null, null, 31, null);
    }

    public static /* synthetic */ ARMSLICENSETokenResponse copy$default(ARMSLICENSETokenResponse aRMSLICENSETokenResponse, String str, String str2, String str3, String str4, String str5, int i, Object obj) {
        if ((i & 1) != 0) {
            str = aRMSLICENSETokenResponse.appDataStatus;
        }
        if ((i & 2) != 0) {
            str2 = aRMSLICENSETokenResponse.appTypeCode;
        }
        if ((i & 4) != 0) {
            str3 = aRMSLICENSETokenResponse.documentCode;
        }
        if ((i & 8) != 0) {
            str4 = aRMSLICENSETokenResponse.trackingId;
        }
        if ((i & 16) != 0) {
            str5 = aRMSLICENSETokenResponse.applicationPin;
        }
        String str6 = str5;
        String str7 = str3;
        return aRMSLICENSETokenResponse.copy(str, str2, str7, str4, str6);
    }

    /* renamed from: component1, reason: from getter */
    public final String getAppDataStatus() {
        return this.appDataStatus;
    }

    /* renamed from: component2, reason: from getter */
    public final String getAppTypeCode() {
        return this.appTypeCode;
    }

    /* renamed from: component3, reason: from getter */
    public final String getDocumentCode() {
        return this.documentCode;
    }

    /* renamed from: component4, reason: from getter */
    public final String getTrackingId() {
        return this.trackingId;
    }

    /* renamed from: component5, reason: from getter */
    public final String getApplicationPin() {
        return this.applicationPin;
    }

    public final ARMSLICENSETokenResponse copy(String appDataStatus, String appTypeCode, String documentCode, String trackingId, String applicationPin) {
        Intrinsics.checkNotNullParameter(appDataStatus, "appDataStatus");
        Intrinsics.checkNotNullParameter(appTypeCode, "appTypeCode");
        Intrinsics.checkNotNullParameter(documentCode, "documentCode");
        Intrinsics.checkNotNullParameter(trackingId, "trackingId");
        Intrinsics.checkNotNullParameter(applicationPin, "applicationPin");
        return new ARMSLICENSETokenResponse(appDataStatus, appTypeCode, documentCode, trackingId, applicationPin);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ARMSLICENSETokenResponse)) {
            return false;
        }
        ARMSLICENSETokenResponse aRMSLICENSETokenResponse = (ARMSLICENSETokenResponse) other;
        return Intrinsics.areEqual(this.appDataStatus, aRMSLICENSETokenResponse.appDataStatus) && Intrinsics.areEqual(this.appTypeCode, aRMSLICENSETokenResponse.appTypeCode) && Intrinsics.areEqual(this.documentCode, aRMSLICENSETokenResponse.documentCode) && Intrinsics.areEqual(this.trackingId, aRMSLICENSETokenResponse.trackingId) && Intrinsics.areEqual(this.applicationPin, aRMSLICENSETokenResponse.applicationPin);
    }

    public int hashCode() {
        return (((((((this.appDataStatus.hashCode() * 31) + this.appTypeCode.hashCode()) * 31) + this.documentCode.hashCode()) * 31) + this.trackingId.hashCode()) * 31) + this.applicationPin.hashCode();
    }

    public String toString() {
        return "ARMSLICENSETokenResponse(appDataStatus=" + this.appDataStatus + ", appTypeCode=" + this.appTypeCode + ", documentCode=" + this.documentCode + ", trackingId=" + this.trackingId + ", applicationPin=" + this.applicationPin + ')';
    }

    public ARMSLICENSETokenResponse(String appDataStatus, String appTypeCode, String documentCode, String trackingId, String applicationPin) {
        Intrinsics.checkNotNullParameter(appDataStatus, "appDataStatus");
        Intrinsics.checkNotNullParameter(appTypeCode, "appTypeCode");
        Intrinsics.checkNotNullParameter(documentCode, "documentCode");
        Intrinsics.checkNotNullParameter(trackingId, "trackingId");
        Intrinsics.checkNotNullParameter(applicationPin, "applicationPin");
        this.appDataStatus = appDataStatus;
        this.appTypeCode = appTypeCode;
        this.documentCode = documentCode;
        this.trackingId = trackingId;
        this.applicationPin = applicationPin;
    }

    public /* synthetic */ ARMSLICENSETokenResponse(String str, String str2, String str3, String str4, String str5, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? "" : str, (i & 2) != 0 ? "" : str2, (i & 4) != 0 ? "" : str3, (i & 8) != 0 ? "" : str4, (i & 16) != 0 ? "" : str5);
    }

    public final String getAppDataStatus() {
        return this.appDataStatus;
    }

    public final void setAppDataStatus(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.appDataStatus = str;
    }

    public final String getAppTypeCode() {
        return this.appTypeCode;
    }

    public final void setAppTypeCode(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.appTypeCode = str;
    }

    public final String getDocumentCode() {
        return this.documentCode;
    }

    public final void setDocumentCode(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.documentCode = str;
    }

    public final String getTrackingId() {
        return this.trackingId;
    }

    public final void setTrackingId(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.trackingId = str;
    }

    public final String getApplicationPin() {
        return this.applicationPin;
    }

    public final void setApplicationPin(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.applicationPin = str;
    }
}