package pk.gov.nadra.oneapp.arms.license.models;

import com.google.gson.annotations.SerializedName;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: LicenseValidationRequestModel.kt */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J1\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0016\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0016\u0010\u0005\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0016\u0010\u0006\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\n¨\u0006\u0019"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/models/LicenseValidationRequestModel;", "", "productCode", "", "licenseNumber", "citizenNumber", "applicationType", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getProductCode", "()Ljava/lang/String;", "getLicenseNumber", "getCitizenNumber", "getApplicationType", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final /* data */ class LicenseValidationRequestModel {

    @SerializedName("ApplicationType")
    private final String applicationType;

    @SerializedName("CitizenNumber")
    private final String citizenNumber;

    @SerializedName("LicenseNumber")
    private final String licenseNumber;

    @SerializedName("ProductCode")
    private final String productCode;

    public static /* synthetic */ LicenseValidationRequestModel copy$default(LicenseValidationRequestModel licenseValidationRequestModel, String str, String str2, String str3, String str4, int i, Object obj) {
        if ((i & 1) != 0) {
            str = licenseValidationRequestModel.productCode;
        }
        if ((i & 2) != 0) {
            str2 = licenseValidationRequestModel.licenseNumber;
        }
        if ((i & 4) != 0) {
            str3 = licenseValidationRequestModel.citizenNumber;
        }
        if ((i & 8) != 0) {
            str4 = licenseValidationRequestModel.applicationType;
        }
        return licenseValidationRequestModel.copy(str, str2, str3, str4);
    }

    /* renamed from: component1, reason: from getter */
    public final String getProductCode() {
        return this.productCode;
    }

    /* renamed from: component2, reason: from getter */
    public final String getLicenseNumber() {
        return this.licenseNumber;
    }

    /* renamed from: component3, reason: from getter */
    public final String getCitizenNumber() {
        return this.citizenNumber;
    }

    /* renamed from: component4, reason: from getter */
    public final String getApplicationType() {
        return this.applicationType;
    }

    public final LicenseValidationRequestModel copy(String productCode, String licenseNumber, String citizenNumber, String applicationType) {
        Intrinsics.checkNotNullParameter(productCode, "productCode");
        Intrinsics.checkNotNullParameter(licenseNumber, "licenseNumber");
        Intrinsics.checkNotNullParameter(citizenNumber, "citizenNumber");
        Intrinsics.checkNotNullParameter(applicationType, "applicationType");
        return new LicenseValidationRequestModel(productCode, licenseNumber, citizenNumber, applicationType);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof LicenseValidationRequestModel)) {
            return false;
        }
        LicenseValidationRequestModel licenseValidationRequestModel = (LicenseValidationRequestModel) other;
        return Intrinsics.areEqual(this.productCode, licenseValidationRequestModel.productCode) && Intrinsics.areEqual(this.licenseNumber, licenseValidationRequestModel.licenseNumber) && Intrinsics.areEqual(this.citizenNumber, licenseValidationRequestModel.citizenNumber) && Intrinsics.areEqual(this.applicationType, licenseValidationRequestModel.applicationType);
    }

    public int hashCode() {
        return (((((this.productCode.hashCode() * 31) + this.licenseNumber.hashCode()) * 31) + this.citizenNumber.hashCode()) * 31) + this.applicationType.hashCode();
    }

    public String toString() {
        return "LicenseValidationRequestModel(productCode=" + this.productCode + ", licenseNumber=" + this.licenseNumber + ", citizenNumber=" + this.citizenNumber + ", applicationType=" + this.applicationType + ')';
    }

    public LicenseValidationRequestModel(String productCode, String licenseNumber, String citizenNumber, String applicationType) {
        Intrinsics.checkNotNullParameter(productCode, "productCode");
        Intrinsics.checkNotNullParameter(licenseNumber, "licenseNumber");
        Intrinsics.checkNotNullParameter(citizenNumber, "citizenNumber");
        Intrinsics.checkNotNullParameter(applicationType, "applicationType");
        this.productCode = productCode;
        this.licenseNumber = licenseNumber;
        this.citizenNumber = citizenNumber;
        this.applicationType = applicationType;
    }

    public final String getProductCode() {
        return this.productCode;
    }

    public final String getLicenseNumber() {
        return this.licenseNumber;
    }

    public final String getCitizenNumber() {
        return this.citizenNumber;
    }

    public final String getApplicationType() {
        return this.applicationType;
    }
}