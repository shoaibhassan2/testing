package pk.gov.nadra.oneapp.arms.license.models;

import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.apache.commons.lang3.StringUtils;

/* compiled from: LicenseProductResponse.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001:\u0001\u0012B\u0019\u0012\u0010\b\u0002\u0010\u0002\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\u0011\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003HÆ\u0003J\u001b\u0010\n\u001a\u00020\u00002\u0010\b\u0002\u0010\u0002\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003HÆ\u0001J\u0013\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001R\u0019\u0010\u0002\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\u0013"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/models/LicenseProductResponse;", "", "data", "", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseProductResponse$LicenseProduct;", "<init>", "(Ljava/util/List;)V", "getData", "()Ljava/util/List;", "component1", "copy", "equals", "", "other", "hashCode", "", "toString", "", "LicenseProduct", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final /* data */ class LicenseProductResponse {
    private final List<LicenseProduct> data;

    public LicenseProductResponse() {
        this(null, 1, 0 == true ? 1 : 0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ LicenseProductResponse copy$default(LicenseProductResponse licenseProductResponse, List list, int i, Object obj) {
        if ((i & 1) != 0) {
            list = licenseProductResponse.data;
        }
        return licenseProductResponse.copy(list);
    }

    public final List<LicenseProduct> component1() {
        return this.data;
    }

    public final LicenseProductResponse copy(List<LicenseProduct> data) {
        return new LicenseProductResponse(data);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        return (other instanceof LicenseProductResponse) && Intrinsics.areEqual(this.data, ((LicenseProductResponse) other).data);
    }

    public int hashCode() {
        List<LicenseProduct> list = this.data;
        if (list == null) {
            return 0;
        }
        return list.hashCode();
    }

    public String toString() {
        return "LicenseProductResponse(data=" + this.data + ')';
    }

    public LicenseProductResponse(List<LicenseProduct> list) {
        this.data = list;
    }

    public /* synthetic */ LicenseProductResponse(List list, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? null : list);
    }

    public final List<LicenseProduct> getData() {
        return this.data;
    }

    /* compiled from: LicenseProductResponse.kt */
    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b@\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001BË\u0001\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\t\u001a\u00020\u0005\u0012\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0003\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\r\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0014\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0016\u0010\u0017J\t\u00100\u001a\u00020\u0003HÆ\u0003J\u000b\u00101\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\t\u00102\u001a\u00020\u0005HÆ\u0003J\u000b\u00103\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\t\u00104\u001a\u00020\u0003HÆ\u0003J\t\u00105\u001a\u00020\u0005HÆ\u0003J\u000b\u00106\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\t\u00107\u001a\u00020\u0003HÆ\u0003J\u000b\u00108\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\t\u00109\u001a\u00020\u0005HÆ\u0003J\t\u0010:\u001a\u00020\u0005HÆ\u0003J\t\u0010;\u001a\u00020\u0003HÆ\u0003J\t\u0010<\u001a\u00020\u0003HÆ\u0003J\t\u0010=\u001a\u00020\u0003HÆ\u0003J\u000b\u0010>\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010?\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010@\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010A\u001a\u0004\u0018\u00010\u0005HÆ\u0003JÍ\u0001\u0010B\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00052\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u000b\u001a\u00020\u00032\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\r\u001a\u00020\u00052\b\b\u0002\u0010\u000e\u001a\u00020\u00052\b\b\u0002\u0010\u000f\u001a\u00020\u00032\b\b\u0002\u0010\u0010\u001a\u00020\u00032\b\b\u0002\u0010\u0011\u001a\u00020\u00032\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0014\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u0005HÆ\u0001J\u0013\u0010C\u001a\u00020\u00032\b\u0010D\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010E\u001a\u00020FHÖ\u0001J\t\u0010G\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001bR\u0013\u0010\u0007\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001bR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0019R\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u001bR\u0013\u0010\n\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u001bR\u0011\u0010\u000b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0019R\u0013\u0010\f\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u001bR\u0011\u0010\r\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b#\u0010\u001bR\u0011\u0010\u000e\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\u001bR\u0011\u0010\u000f\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b%\u0010\u0019R\u0011\u0010\u0010\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b&\u0010\u0019R\u0011\u0010\u0011\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b'\u0010\u0019R\u0013\u0010\u0012\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b(\u0010\u001bR\u0013\u0010\u0013\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b)\u0010\u001bR\u0013\u0010\u0014\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b*\u0010\u001bR\u0013\u0010\u0015\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b+\u0010\u001bR\u0011\u0010,\u001a\u00020\u00058F¢\u0006\u0006\u001a\u0004\b-\u0010\u001bR\u0011\u0010.\u001a\u00020\u00058F¢\u0006\u0006\u001a\u0004\b/\u0010\u001b¨\u0006H"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/models/LicenseProductResponse$LicenseProduct;", "", "cancellationP", "", "citizenNumber", "", "expiryDate", "fatherName", "inheritanceP", "issueDate", "licenseNumber", "modificationP", "name", "productCode", "productName", "renewalP", "reprintP", "transferP", "weaponCalibreBore", "weaponCategoryCode", "weaponNumber", "weaponType", "<init>", "(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getCancellationP", "()Z", "getCitizenNumber", "()Ljava/lang/String;", "getExpiryDate", "getFatherName", "getInheritanceP", "getIssueDate", "getLicenseNumber", "getModificationP", "getName", "getProductCode", "getProductName", "getRenewalP", "getReprintP", "getTransferP", "getWeaponCalibreBore", "getWeaponCategoryCode", "getWeaponNumber", "getWeaponType", "formattedIssueDate", "getFormattedIssueDate", "formattedExpiryDate", "getFormattedExpiryDate", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component17", "component18", "copy", "equals", "other", "hashCode", "", "toString", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final /* data */ class LicenseProduct {
        private final boolean cancellationP;
        private final String citizenNumber;
        private final String expiryDate;
        private final String fatherName;
        private final boolean inheritanceP;
        private final String issueDate;
        private final String licenseNumber;
        private final boolean modificationP;
        private final String name;
        private final String productCode;
        private final String productName;
        private final boolean renewalP;
        private final boolean reprintP;
        private final boolean transferP;
        private final String weaponCalibreBore;
        private final String weaponCategoryCode;
        private final String weaponNumber;
        private final String weaponType;

        public LicenseProduct() {
            this(false, null, null, null, false, null, null, false, null, null, null, false, false, false, null, null, null, null, 262143, null);
        }

        public static /* synthetic */ LicenseProduct copy$default(LicenseProduct licenseProduct, boolean z, String str, String str2, String str3, boolean z2, String str4, String str5, boolean z3, String str6, String str7, String str8, boolean z4, boolean z5, boolean z6, String str9, String str10, String str11, String str12, int i, Object obj) {
            String str13;
            String str14;
            boolean z7 = (i & 1) != 0 ? licenseProduct.cancellationP : z;
            String str15 = (i & 2) != 0 ? licenseProduct.citizenNumber : str;
            String str16 = (i & 4) != 0 ? licenseProduct.expiryDate : str2;
            String str17 = (i & 8) != 0 ? licenseProduct.fatherName : str3;
            boolean z8 = (i & 16) != 0 ? licenseProduct.inheritanceP : z2;
            String str18 = (i & 32) != 0 ? licenseProduct.issueDate : str4;
            String str19 = (i & 64) != 0 ? licenseProduct.licenseNumber : str5;
            boolean z9 = (i & 128) != 0 ? licenseProduct.modificationP : z3;
            String str20 = (i & 256) != 0 ? licenseProduct.name : str6;
            String str21 = (i & 512) != 0 ? licenseProduct.productCode : str7;
            String str22 = (i & 1024) != 0 ? licenseProduct.productName : str8;
            boolean z10 = (i & 2048) != 0 ? licenseProduct.renewalP : z4;
            boolean z11 = (i & 4096) != 0 ? licenseProduct.reprintP : z5;
            boolean z12 = (i & 8192) != 0 ? licenseProduct.transferP : z6;
            boolean z13 = z7;
            String str23 = (i & 16384) != 0 ? licenseProduct.weaponCalibreBore : str9;
            String str24 = (i & 32768) != 0 ? licenseProduct.weaponCategoryCode : str10;
            String str25 = (i & 65536) != 0 ? licenseProduct.weaponNumber : str11;
            if ((i & 131072) != 0) {
                str14 = str25;
                str13 = licenseProduct.weaponType;
            } else {
                str13 = str12;
                str14 = str25;
            }
            return licenseProduct.copy(z13, str15, str16, str17, z8, str18, str19, z9, str20, str21, str22, z10, z11, z12, str23, str24, str14, str13);
        }

        /* renamed from: component1, reason: from getter */
        public final boolean getCancellationP() {
            return this.cancellationP;
        }

        /* renamed from: component10, reason: from getter */
        public final String getProductCode() {
            return this.productCode;
        }

        /* renamed from: component11, reason: from getter */
        public final String getProductName() {
            return this.productName;
        }

        /* renamed from: component12, reason: from getter */
        public final boolean getRenewalP() {
            return this.renewalP;
        }

        /* renamed from: component13, reason: from getter */
        public final boolean getReprintP() {
            return this.reprintP;
        }

        /* renamed from: component14, reason: from getter */
        public final boolean getTransferP() {
            return this.transferP;
        }

        /* renamed from: component15, reason: from getter */
        public final String getWeaponCalibreBore() {
            return this.weaponCalibreBore;
        }

        /* renamed from: component16, reason: from getter */
        public final String getWeaponCategoryCode() {
            return this.weaponCategoryCode;
        }

        /* renamed from: component17, reason: from getter */
        public final String getWeaponNumber() {
            return this.weaponNumber;
        }

        /* renamed from: component18, reason: from getter */
        public final String getWeaponType() {
            return this.weaponType;
        }

        /* renamed from: component2, reason: from getter */
        public final String getCitizenNumber() {
            return this.citizenNumber;
        }

        /* renamed from: component3, reason: from getter */
        public final String getExpiryDate() {
            return this.expiryDate;
        }

        /* renamed from: component4, reason: from getter */
        public final String getFatherName() {
            return this.fatherName;
        }

        /* renamed from: component5, reason: from getter */
        public final boolean getInheritanceP() {
            return this.inheritanceP;
        }

        /* renamed from: component6, reason: from getter */
        public final String getIssueDate() {
            return this.issueDate;
        }

        /* renamed from: component7, reason: from getter */
        public final String getLicenseNumber() {
            return this.licenseNumber;
        }

        /* renamed from: component8, reason: from getter */
        public final boolean getModificationP() {
            return this.modificationP;
        }

        /* renamed from: component9, reason: from getter */
        public final String getName() {
            return this.name;
        }

        public final LicenseProduct copy(boolean cancellationP, String citizenNumber, String expiryDate, String fatherName, boolean inheritanceP, String issueDate, String licenseNumber, boolean modificationP, String name, String productCode, String productName, boolean renewalP, boolean reprintP, boolean transferP, String weaponCalibreBore, String weaponCategoryCode, String weaponNumber, String weaponType) {
            Intrinsics.checkNotNullParameter(expiryDate, "expiryDate");
            Intrinsics.checkNotNullParameter(issueDate, "issueDate");
            Intrinsics.checkNotNullParameter(productCode, "productCode");
            Intrinsics.checkNotNullParameter(productName, "productName");
            return new LicenseProduct(cancellationP, citizenNumber, expiryDate, fatherName, inheritanceP, issueDate, licenseNumber, modificationP, name, productCode, productName, renewalP, reprintP, transferP, weaponCalibreBore, weaponCategoryCode, weaponNumber, weaponType);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof LicenseProduct)) {
                return false;
            }
            LicenseProduct licenseProduct = (LicenseProduct) other;
            return this.cancellationP == licenseProduct.cancellationP && Intrinsics.areEqual(this.citizenNumber, licenseProduct.citizenNumber) && Intrinsics.areEqual(this.expiryDate, licenseProduct.expiryDate) && Intrinsics.areEqual(this.fatherName, licenseProduct.fatherName) && this.inheritanceP == licenseProduct.inheritanceP && Intrinsics.areEqual(this.issueDate, licenseProduct.issueDate) && Intrinsics.areEqual(this.licenseNumber, licenseProduct.licenseNumber) && this.modificationP == licenseProduct.modificationP && Intrinsics.areEqual(this.name, licenseProduct.name) && Intrinsics.areEqual(this.productCode, licenseProduct.productCode) && Intrinsics.areEqual(this.productName, licenseProduct.productName) && this.renewalP == licenseProduct.renewalP && this.reprintP == licenseProduct.reprintP && this.transferP == licenseProduct.transferP && Intrinsics.areEqual(this.weaponCalibreBore, licenseProduct.weaponCalibreBore) && Intrinsics.areEqual(this.weaponCategoryCode, licenseProduct.weaponCategoryCode) && Intrinsics.areEqual(this.weaponNumber, licenseProduct.weaponNumber) && Intrinsics.areEqual(this.weaponType, licenseProduct.weaponType);
        }

        public int hashCode() {
            int iHashCode = Boolean.hashCode(this.cancellationP) * 31;
            String str = this.citizenNumber;
            int iHashCode2 = (((iHashCode + (str == null ? 0 : str.hashCode())) * 31) + this.expiryDate.hashCode()) * 31;
            String str2 = this.fatherName;
            int iHashCode3 = (((((iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31) + Boolean.hashCode(this.inheritanceP)) * 31) + this.issueDate.hashCode()) * 31;
            String str3 = this.licenseNumber;
            int iHashCode4 = (((iHashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31) + Boolean.hashCode(this.modificationP)) * 31;
            String str4 = this.name;
            int iHashCode5 = (((((((((((iHashCode4 + (str4 == null ? 0 : str4.hashCode())) * 31) + this.productCode.hashCode()) * 31) + this.productName.hashCode()) * 31) + Boolean.hashCode(this.renewalP)) * 31) + Boolean.hashCode(this.reprintP)) * 31) + Boolean.hashCode(this.transferP)) * 31;
            String str5 = this.weaponCalibreBore;
            int iHashCode6 = (iHashCode5 + (str5 == null ? 0 : str5.hashCode())) * 31;
            String str6 = this.weaponCategoryCode;
            int iHashCode7 = (iHashCode6 + (str6 == null ? 0 : str6.hashCode())) * 31;
            String str7 = this.weaponNumber;
            int iHashCode8 = (iHashCode7 + (str7 == null ? 0 : str7.hashCode())) * 31;
            String str8 = this.weaponType;
            return iHashCode8 + (str8 != null ? str8.hashCode() : 0);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder("LicenseProduct(cancellationP=");
            sb.append(this.cancellationP).append(", citizenNumber=").append(this.citizenNumber).append(", expiryDate=").append(this.expiryDate).append(", fatherName=").append(this.fatherName).append(", inheritanceP=").append(this.inheritanceP).append(", issueDate=").append(this.issueDate).append(", licenseNumber=").append(this.licenseNumber).append(", modificationP=").append(this.modificationP).append(", name=").append(this.name).append(", productCode=").append(this.productCode).append(", productName=").append(this.productName).append(", renewalP=");
            sb.append(this.renewalP).append(", reprintP=").append(this.reprintP).append(", transferP=").append(this.transferP).append(", weaponCalibreBore=").append(this.weaponCalibreBore).append(", weaponCategoryCode=").append(this.weaponCategoryCode).append(", weaponNumber=").append(this.weaponNumber).append(", weaponType=").append(this.weaponType).append(')');
            return sb.toString();
        }

        public LicenseProduct(boolean z, String str, String expiryDate, String str2, boolean z2, String issueDate, String str3, boolean z3, String str4, String productCode, String productName, boolean z4, boolean z5, boolean z6, String str5, String str6, String str7, String str8) {
            Intrinsics.checkNotNullParameter(expiryDate, "expiryDate");
            Intrinsics.checkNotNullParameter(issueDate, "issueDate");
            Intrinsics.checkNotNullParameter(productCode, "productCode");
            Intrinsics.checkNotNullParameter(productName, "productName");
            this.cancellationP = z;
            this.citizenNumber = str;
            this.expiryDate = expiryDate;
            this.fatherName = str2;
            this.inheritanceP = z2;
            this.issueDate = issueDate;
            this.licenseNumber = str3;
            this.modificationP = z3;
            this.name = str4;
            this.productCode = productCode;
            this.productName = productName;
            this.renewalP = z4;
            this.reprintP = z5;
            this.transferP = z6;
            this.weaponCalibreBore = str5;
            this.weaponCategoryCode = str6;
            this.weaponNumber = str7;
            this.weaponType = str8;
        }

        /* JADX WARN: Illegal instructions before constructor call */
        public /* synthetic */ LicenseProduct(boolean z, String str, String str2, String str3, boolean z2, String str4, String str5, boolean z3, String str6, String str7, String str8, boolean z4, boolean z5, boolean z6, String str9, String str10, String str11, String str12, int i, DefaultConstructorMarker defaultConstructorMarker) {
            boolean z7 = (i & 1) != 0 ? false : z;
            String str13 = (i & 2) != 0 ? "" : str;
            String str14 = (i & 4) != 0 ? "" : str2;
            String str15 = (i & 8) != 0 ? "" : str3;
            boolean z8 = (i & 16) != 0 ? false : z2;
            String str16 = (i & 32) != 0 ? "" : str4;
            String str17 = (i & 64) != 0 ? "" : str5;
            boolean z9 = (i & 128) != 0 ? false : z3;
            String str18 = (i & 256) != 0 ? "" : str6;
            String str19 = (i & 512) != 0 ? "" : str7;
            String str20 = (i & 1024) != 0 ? "" : str8;
            boolean z10 = (i & 2048) != 0 ? false : z4;
            boolean z11 = (i & 4096) != 0 ? false : z5;
            boolean z12 = (i & 8192) != 0 ? false : z6;
            this(z7, str13, str14, str15, z8, str16, str17, z9, str18, str19, str20, z10, z11, z12, (i & 16384) != 0 ? "" : str9, (i & 32768) != 0 ? "" : str10, (i & 65536) != 0 ? "" : str11, (i & 131072) != 0 ? "" : str12);
        }

        public final boolean getCancellationP() {
            return this.cancellationP;
        }

        public final String getCitizenNumber() {
            return this.citizenNumber;
        }

        public final String getExpiryDate() {
            return this.expiryDate;
        }

        public final String getFatherName() {
            return this.fatherName;
        }

        public final boolean getInheritanceP() {
            return this.inheritanceP;
        }

        public final String getIssueDate() {
            return this.issueDate;
        }

        public final String getLicenseNumber() {
            return this.licenseNumber;
        }

        public final boolean getModificationP() {
            return this.modificationP;
        }

        public final String getName() {
            return this.name;
        }

        public final String getProductCode() {
            return this.productCode;
        }

        public final String getProductName() {
            return this.productName;
        }

        public final boolean getRenewalP() {
            return this.renewalP;
        }

        public final boolean getReprintP() {
            return this.reprintP;
        }

        public final boolean getTransferP() {
            return this.transferP;
        }

        public final String getWeaponCalibreBore() {
            return this.weaponCalibreBore;
        }

        public final String getWeaponCategoryCode() {
            return this.weaponCategoryCode;
        }

        public final String getWeaponNumber() {
            return this.weaponNumber;
        }

        public final String getWeaponType() {
            return this.weaponType;
        }

        public final String getFormattedIssueDate() {
            List listSplit$default;
            String str;
            String str2 = this.issueDate;
            return (str2 == null || (listSplit$default = StringsKt.split$default((CharSequence) str2, new String[]{StringUtils.SPACE}, false, 0, 6, (Object) null)) == null || (str = (String) listSplit$default.get(0)) == null) ? "" : str;
        }

        public final String getFormattedExpiryDate() {
            List listSplit$default;
            String str;
            String str2 = this.expiryDate;
            return (str2 == null || (listSplit$default = StringsKt.split$default((CharSequence) str2, new String[]{StringUtils.SPACE}, false, 0, 6, (Object) null)) == null || (str = (String) listSplit$default.get(0)) == null) ? "" : str;
        }
    }
}