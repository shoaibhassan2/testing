package pk.gov.nadra.oneapp.arms.license.models;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: LicenseFeeRequestModel.kt */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0013\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J;\u0010\u0015\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0016\u001a\u00020\u00172\b\u0010\u0018\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0019\u001a\u00020\u001aHÖ\u0001J\t\u0010\u001b\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000bR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000b¨\u0006\u001c"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeRequestModel;", "", "productCode", "", "citizenNumber", "licenseNumber", "validityPeriod", "applicationType", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getProductCode", "()Ljava/lang/String;", "getCitizenNumber", "getLicenseNumber", "getValidityPeriod", "getApplicationType", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "", "toString", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final /* data */ class LicenseFeeRequestModel {
    private final String applicationType;
    private final String citizenNumber;
    private final String licenseNumber;
    private final String productCode;
    private final String validityPeriod;

    public static /* synthetic */ LicenseFeeRequestModel copy$default(LicenseFeeRequestModel licenseFeeRequestModel, String str, String str2, String str3, String str4, String str5, int i, Object obj) {
        if ((i & 1) != 0) {
            str = licenseFeeRequestModel.productCode;
        }
        if ((i & 2) != 0) {
            str2 = licenseFeeRequestModel.citizenNumber;
        }
        if ((i & 4) != 0) {
            str3 = licenseFeeRequestModel.licenseNumber;
        }
        if ((i & 8) != 0) {
            str4 = licenseFeeRequestModel.validityPeriod;
        }
        if ((i & 16) != 0) {
            str5 = licenseFeeRequestModel.applicationType;
        }
        String str6 = str5;
        String str7 = str3;
        return licenseFeeRequestModel.copy(str, str2, str7, str4, str6);
    }

    /* renamed from: component1, reason: from getter */
    public final String getProductCode() {
        return this.productCode;
    }

    /* renamed from: component2, reason: from getter */
    public final String getCitizenNumber() {
        return this.citizenNumber;
    }

    /* renamed from: component3, reason: from getter */
    public final String getLicenseNumber() {
        return this.licenseNumber;
    }

    /* renamed from: component4, reason: from getter */
    public final String getValidityPeriod() {
        return this.validityPeriod;
    }

    /* renamed from: component5, reason: from getter */
    public final String getApplicationType() {
        return this.applicationType;
    }

    public final LicenseFeeRequestModel copy(String productCode, String citizenNumber, String licenseNumber, String validityPeriod, String applicationType) {
        Intrinsics.checkNotNullParameter(productCode, "productCode");
        Intrinsics.checkNotNullParameter(citizenNumber, "citizenNumber");
        Intrinsics.checkNotNullParameter(licenseNumber, "licenseNumber");
        Intrinsics.checkNotNullParameter(validityPeriod, "validityPeriod");
        Intrinsics.checkNotNullParameter(applicationType, "applicationType");
        return new LicenseFeeRequestModel(productCode, citizenNumber, licenseNumber, validityPeriod, applicationType);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof LicenseFeeRequestModel)) {
            return false;
        }
        LicenseFeeRequestModel licenseFeeRequestModel = (LicenseFeeRequestModel) other;
        return Intrinsics.areEqual(this.productCode, licenseFeeRequestModel.productCode) && Intrinsics.areEqual(this.citizenNumber, licenseFeeRequestModel.citizenNumber) && Intrinsics.areEqual(this.licenseNumber, licenseFeeRequestModel.licenseNumber) && Intrinsics.areEqual(this.validityPeriod, licenseFeeRequestModel.validityPeriod) && Intrinsics.areEqual(this.applicationType, licenseFeeRequestModel.applicationType);
    }

    public int hashCode() {
        return (((((((this.productCode.hashCode() * 31) + this.citizenNumber.hashCode()) * 31) + this.licenseNumber.hashCode()) * 31) + this.validityPeriod.hashCode()) * 31) + this.applicationType.hashCode();
    }

    public String toString() {
        return "LicenseFeeRequestModel(productCode=" + this.productCode + ", citizenNumber=" + this.citizenNumber + ", licenseNumber=" + this.licenseNumber + ", validityPeriod=" + this.validityPeriod + ", applicationType=" + this.applicationType + ')';
    }

    public LicenseFeeRequestModel(String productCode, String citizenNumber, String licenseNumber, String validityPeriod, String applicationType) {
        Intrinsics.checkNotNullParameter(productCode, "productCode");
        Intrinsics.checkNotNullParameter(citizenNumber, "citizenNumber");
        Intrinsics.checkNotNullParameter(licenseNumber, "licenseNumber");
        Intrinsics.checkNotNullParameter(validityPeriod, "validityPeriod");
        Intrinsics.checkNotNullParameter(applicationType, "applicationType");
        this.productCode = productCode;
        this.citizenNumber = citizenNumber;
        this.licenseNumber = licenseNumber;
        this.validityPeriod = validityPeriod;
        this.applicationType = applicationType;
    }

    public final String getProductCode() {
        return this.productCode;
    }

    public final String getCitizenNumber() {
        return this.citizenNumber;
    }

    public final String getLicenseNumber() {
        return this.licenseNumber;
    }

    public final String getValidityPeriod() {
        return this.validityPeriod;
    }

    public final String getApplicationType() {
        return this.applicationType;
    }
}