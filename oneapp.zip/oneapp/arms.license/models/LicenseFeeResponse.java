package pk.gov.nadra.oneapp.arms.license.models;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: LicenseFeeResponse.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001:\u0001\u0011B\u0013\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000b\u0010\b\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0015\u0010\t\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\r\u001a\u00020\u000eHÖ\u0001J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0012"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeResponse;", "", "data", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeResponse$FeeDetails;", "<init>", "(Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeResponse$FeeDetails;)V", "getData", "()Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeResponse$FeeDetails;", "component1", "copy", "equals", "", "other", "hashCode", "", "toString", "", "FeeDetails", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final /* data */ class LicenseFeeResponse {
    private final FeeDetails data;

    public LicenseFeeResponse() {
        this(null, 1, 0 == true ? 1 : 0);
    }

    public static /* synthetic */ LicenseFeeResponse copy$default(LicenseFeeResponse licenseFeeResponse, FeeDetails feeDetails, int i, Object obj) {
        if ((i & 1) != 0) {
            feeDetails = licenseFeeResponse.data;
        }
        return licenseFeeResponse.copy(feeDetails);
    }

    /* renamed from: component1, reason: from getter */
    public final FeeDetails getData() {
        return this.data;
    }

    public final LicenseFeeResponse copy(FeeDetails data) {
        return new LicenseFeeResponse(data);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        return (other instanceof LicenseFeeResponse) && Intrinsics.areEqual(this.data, ((LicenseFeeResponse) other).data);
    }

    public int hashCode() {
        FeeDetails feeDetails = this.data;
        if (feeDetails == null) {
            return 0;
        }
        return feeDetails.hashCode();
    }

    public String toString() {
        return "LicenseFeeResponse(data=" + this.data + ')';
    }

    public LicenseFeeResponse(FeeDetails feeDetails) {
        this.data = feeDetails;
    }

    public /* synthetic */ LicenseFeeResponse(FeeDetails feeDetails, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? null : feeDetails);
    }

    public final FeeDetails getData() {
        return this.data;
    }

    /* compiled from: LicenseFeeResponse.kt */
    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B/\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J1\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\n¨\u0006\u0019"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeResponse$FeeDetails;", "", "totalFee", "", "processingFee", "licenseFee", "penaltyFee", "<init>", "(IIII)V", "getTotalFee", "()I", "getProcessingFee", "getLicenseFee", "getPenaltyFee", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final /* data */ class FeeDetails {
        private final int licenseFee;
        private final int penaltyFee;
        private final int processingFee;
        private final int totalFee;

        public FeeDetails() {
            this(0, 0, 0, 0, 15, null);
        }

        public static /* synthetic */ FeeDetails copy$default(FeeDetails feeDetails, int i, int i2, int i3, int i4, int i5, Object obj) {
            if ((i5 & 1) != 0) {
                i = feeDetails.totalFee;
            }
            if ((i5 & 2) != 0) {
                i2 = feeDetails.processingFee;
            }
            if ((i5 & 4) != 0) {
                i3 = feeDetails.licenseFee;
            }
            if ((i5 & 8) != 0) {
                i4 = feeDetails.penaltyFee;
            }
            return feeDetails.copy(i, i2, i3, i4);
        }

        /* renamed from: component1, reason: from getter */
        public final int getTotalFee() {
            return this.totalFee;
        }

        /* renamed from: component2, reason: from getter */
        public final int getProcessingFee() {
            return this.processingFee;
        }

        /* renamed from: component3, reason: from getter */
        public final int getLicenseFee() {
            return this.licenseFee;
        }

        /* renamed from: component4, reason: from getter */
        public final int getPenaltyFee() {
            return this.penaltyFee;
        }

        public final FeeDetails copy(int totalFee, int processingFee, int licenseFee, int penaltyFee) {
            return new FeeDetails(totalFee, processingFee, licenseFee, penaltyFee);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof FeeDetails)) {
                return false;
            }
            FeeDetails feeDetails = (FeeDetails) other;
            return this.totalFee == feeDetails.totalFee && this.processingFee == feeDetails.processingFee && this.licenseFee == feeDetails.licenseFee && this.penaltyFee == feeDetails.penaltyFee;
        }

        public int hashCode() {
            return (((((Integer.hashCode(this.totalFee) * 31) + Integer.hashCode(this.processingFee)) * 31) + Integer.hashCode(this.licenseFee)) * 31) + Integer.hashCode(this.penaltyFee);
        }

        public String toString() {
            return "FeeDetails(totalFee=" + this.totalFee + ", processingFee=" + this.processingFee + ", licenseFee=" + this.licenseFee + ", penaltyFee=" + this.penaltyFee + ')';
        }

        public FeeDetails(int i, int i2, int i3, int i4) {
            this.totalFee = i;
            this.processingFee = i2;
            this.licenseFee = i3;
            this.penaltyFee = i4;
        }

        public /* synthetic */ FeeDetails(int i, int i2, int i3, int i4, int i5, DefaultConstructorMarker defaultConstructorMarker) {
            this((i5 & 1) != 0 ? 0 : i, (i5 & 2) != 0 ? 0 : i2, (i5 & 4) != 0 ? 0 : i3, (i5 & 8) != 0 ? 0 : i4);
        }

        public final int getTotalFee() {
            return this.totalFee;
        }

        public final int getProcessingFee() {
            return this.processingFee;
        }

        public final int getLicenseFee() {
            return this.licenseFee;
        }

        public final int getPenaltyFee() {
            return this.penaltyFee;
        }
    }
}