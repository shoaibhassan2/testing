package pk.gov.nadra.oneapp.arms.license.models;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: LicenseListDataModel.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\r¨\u0006\u001a"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/models/LicenseListDataModel;", "", "imageResId", "", "number", "", "issuanceDate", "expiryDate", "<init>", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getImageResId", "()I", "getNumber", "()Ljava/lang/String;", "getIssuanceDate", "getExpiryDate", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final /* data */ class LicenseListDataModel {
    private final String expiryDate;
    private final int imageResId;
    private final String issuanceDate;
    private final String number;

    public static /* synthetic */ LicenseListDataModel copy$default(LicenseListDataModel licenseListDataModel, int i, String str, String str2, String str3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = licenseListDataModel.imageResId;
        }
        if ((i2 & 2) != 0) {
            str = licenseListDataModel.number;
        }
        if ((i2 & 4) != 0) {
            str2 = licenseListDataModel.issuanceDate;
        }
        if ((i2 & 8) != 0) {
            str3 = licenseListDataModel.expiryDate;
        }
        return licenseListDataModel.copy(i, str, str2, str3);
    }

    /* renamed from: component1, reason: from getter */
    public final int getImageResId() {
        return this.imageResId;
    }

    /* renamed from: component2, reason: from getter */
    public final String getNumber() {
        return this.number;
    }

    /* renamed from: component3, reason: from getter */
    public final String getIssuanceDate() {
        return this.issuanceDate;
    }

    /* renamed from: component4, reason: from getter */
    public final String getExpiryDate() {
        return this.expiryDate;
    }

    public final LicenseListDataModel copy(int imageResId, String number, String issuanceDate, String expiryDate) {
        Intrinsics.checkNotNullParameter(number, "number");
        Intrinsics.checkNotNullParameter(issuanceDate, "issuanceDate");
        Intrinsics.checkNotNullParameter(expiryDate, "expiryDate");
        return new LicenseListDataModel(imageResId, number, issuanceDate, expiryDate);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof LicenseListDataModel)) {
            return false;
        }
        LicenseListDataModel licenseListDataModel = (LicenseListDataModel) other;
        return this.imageResId == licenseListDataModel.imageResId && Intrinsics.areEqual(this.number, licenseListDataModel.number) && Intrinsics.areEqual(this.issuanceDate, licenseListDataModel.issuanceDate) && Intrinsics.areEqual(this.expiryDate, licenseListDataModel.expiryDate);
    }

    public int hashCode() {
        return (((((Integer.hashCode(this.imageResId) * 31) + this.number.hashCode()) * 31) + this.issuanceDate.hashCode()) * 31) + this.expiryDate.hashCode();
    }

    public String toString() {
        return "LicenseListDataModel(imageResId=" + this.imageResId + ", number=" + this.number + ", issuanceDate=" + this.issuanceDate + ", expiryDate=" + this.expiryDate + ')';
    }

    public LicenseListDataModel(int i, String number, String issuanceDate, String expiryDate) {
        Intrinsics.checkNotNullParameter(number, "number");
        Intrinsics.checkNotNullParameter(issuanceDate, "issuanceDate");
        Intrinsics.checkNotNullParameter(expiryDate, "expiryDate");
        this.imageResId = i;
        this.number = number;
        this.issuanceDate = issuanceDate;
        this.expiryDate = expiryDate;
    }

    public final int getImageResId() {
        return this.imageResId;
    }

    public final String getNumber() {
        return this.number;
    }

    public final String getIssuanceDate() {
        return this.issuanceDate;
    }

    public final String getExpiryDate() {
        return this.expiryDate;
    }
}