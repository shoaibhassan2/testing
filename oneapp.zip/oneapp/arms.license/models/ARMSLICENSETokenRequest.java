package pk.gov.nadra.oneapp.arms.license.models;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ARMSLICENSETokenRequest.kt */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b=\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u0093\u0001\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0003\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\t\u001a\u00020\u0003\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\r\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u0003¢\u0006\u0004\b\u0011\u0010\u0012J\t\u00101\u001a\u00020\u0003HÆ\u0003J\t\u00102\u001a\u00020\u0003HÆ\u0003J\t\u00103\u001a\u00020\u0003HÆ\u0003J\t\u00104\u001a\u00020\u0003HÆ\u0003J\t\u00105\u001a\u00020\u0003HÆ\u0003J\t\u00106\u001a\u00020\u0003HÆ\u0003J\t\u00107\u001a\u00020\u0003HÆ\u0003J\t\u00108\u001a\u00020\u0003HÆ\u0003J\t\u00109\u001a\u00020\u0003HÆ\u0003J\t\u0010:\u001a\u00020\u0003HÆ\u0003J\t\u0010;\u001a\u00020\u0003HÆ\u0003J\t\u0010<\u001a\u00020\u0003HÆ\u0003J\t\u0010=\u001a\u00020\u0003HÆ\u0003J\t\u0010>\u001a\u00020\u0003HÆ\u0003J\u0095\u0001\u0010?\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\u00032\b\b\u0002\u0010\f\u001a\u00020\u00032\b\b\u0002\u0010\r\u001a\u00020\u00032\b\b\u0002\u0010\u000e\u001a\u00020\u00032\b\b\u0002\u0010\u000f\u001a\u00020\u00032\b\b\u0002\u0010\u0010\u001a\u00020\u0003HÆ\u0001J\u0013\u0010@\u001a\u00020A2\b\u0010B\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010C\u001a\u00020DHÖ\u0001J\t\u0010E\u001a\u00020\u0003HÖ\u0001R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u0014\"\u0004\b\u0015\u0010\u0016R\u001a\u0010\u0004\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0014\"\u0004\b\u0018\u0010\u0016R\u001a\u0010\u0005\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u0014\"\u0004\b\u001a\u0010\u0016R\u001a\u0010\u0006\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u0014\"\u0004\b\u001c\u0010\u0016R\u001a\u0010\u0007\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u0014\"\u0004\b\u001e\u0010\u0016R\u001a\u0010\b\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010\u0014\"\u0004\b \u0010\u0016R\u001a\u0010\t\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\u0014\"\u0004\b\"\u0010\u0016R\u001a\u0010\n\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b#\u0010\u0014\"\u0004\b$\u0010\u0016R\u001a\u0010\u000b\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b%\u0010\u0014\"\u0004\b&\u0010\u0016R\u001a\u0010\f\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b'\u0010\u0014\"\u0004\b(\u0010\u0016R\u001a\u0010\r\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b)\u0010\u0014\"\u0004\b*\u0010\u0016R\u001a\u0010\u000e\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b+\u0010\u0014\"\u0004\b,\u0010\u0016R\u001a\u0010\u000f\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b-\u0010\u0014\"\u0004\b.\u0010\u0016R\u001a\u0010\u0010\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b/\u0010\u0014\"\u0004\b0\u0010\u0016¨\u0006F"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/models/ARMSLICENSETokenRequest;", "", "trackingId", "", "citizenNumber", "weaponNumber", "weaponType", "weaponCaliberBore", "licenseNumber", "cardValidation", "cardDeliveryUnitId", "processingFee", "licenseFee", "penalityFee", "totalFee", "productCode", "tokenCategory", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getTrackingId", "()Ljava/lang/String;", "setTrackingId", "(Ljava/lang/String;)V", "getCitizenNumber", "setCitizenNumber", "getWeaponNumber", "setWeaponNumber", "getWeaponType", "setWeaponType", "getWeaponCaliberBore", "setWeaponCaliberBore", "getLicenseNumber", "setLicenseNumber", "getCardValidation", "setCardValidation", "getCardDeliveryUnitId", "setCardDeliveryUnitId", "getProcessingFee", "setProcessingFee", "getLicenseFee", "setLicenseFee", "getPenalityFee", "setPenalityFee", "getTotalFee", "setTotalFee", "getProductCode", "setProductCode", "getTokenCategory", "setTokenCategory", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "component12", "component13", "component14", "copy", "equals", "", "other", "hashCode", "", "toString", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final /* data */ class ARMSLICENSETokenRequest {
    private String cardDeliveryUnitId;
    private String cardValidation;
    private String citizenNumber;
    private String licenseFee;
    private String licenseNumber;
    private String penalityFee;
    private String processingFee;
    private String productCode;
    private String tokenCategory;
    private String totalFee;
    private String trackingId;
    private String weaponCaliberBore;
    private String weaponNumber;
    private String weaponType;

    public ARMSLICENSETokenRequest() {
        this(null, null, null, null, null, null, null, null, null, null, null, null, null, null, 16383, null);
    }

    /* renamed from: component1, reason: from getter */
    public final String getTrackingId() {
        return this.trackingId;
    }

    /* renamed from: component10, reason: from getter */
    public final String getLicenseFee() {
        return this.licenseFee;
    }

    /* renamed from: component11, reason: from getter */
    public final String getPenalityFee() {
        return this.penalityFee;
    }

    /* renamed from: component12, reason: from getter */
    public final String getTotalFee() {
        return this.totalFee;
    }

    /* renamed from: component13, reason: from getter */
    public final String getProductCode() {
        return this.productCode;
    }

    /* renamed from: component14, reason: from getter */
    public final String getTokenCategory() {
        return this.tokenCategory;
    }

    /* renamed from: component2, reason: from getter */
    public final String getCitizenNumber() {
        return this.citizenNumber;
    }

    /* renamed from: component3, reason: from getter */
    public final String getWeaponNumber() {
        return this.weaponNumber;
    }

    /* renamed from: component4, reason: from getter */
    public final String getWeaponType() {
        return this.weaponType;
    }

    /* renamed from: component5, reason: from getter */
    public final String getWeaponCaliberBore() {
        return this.weaponCaliberBore;
    }

    /* renamed from: component6, reason: from getter */
    public final String getLicenseNumber() {
        return this.licenseNumber;
    }

    /* renamed from: component7, reason: from getter */
    public final String getCardValidation() {
        return this.cardValidation;
    }

    /* renamed from: component8, reason: from getter */
    public final String getCardDeliveryUnitId() {
        return this.cardDeliveryUnitId;
    }

    /* renamed from: component9, reason: from getter */
    public final String getProcessingFee() {
        return this.processingFee;
    }

    public final ARMSLICENSETokenRequest copy(String trackingId, String citizenNumber, String weaponNumber, String weaponType, String weaponCaliberBore, String licenseNumber, String cardValidation, String cardDeliveryUnitId, String processingFee, String licenseFee, String penalityFee, String totalFee, String productCode, String tokenCategory) {
        Intrinsics.checkNotNullParameter(trackingId, "trackingId");
        Intrinsics.checkNotNullParameter(citizenNumber, "citizenNumber");
        Intrinsics.checkNotNullParameter(weaponNumber, "weaponNumber");
        Intrinsics.checkNotNullParameter(weaponType, "weaponType");
        Intrinsics.checkNotNullParameter(weaponCaliberBore, "weaponCaliberBore");
        Intrinsics.checkNotNullParameter(licenseNumber, "licenseNumber");
        Intrinsics.checkNotNullParameter(cardValidation, "cardValidation");
        Intrinsics.checkNotNullParameter(cardDeliveryUnitId, "cardDeliveryUnitId");
        Intrinsics.checkNotNullParameter(processingFee, "processingFee");
        Intrinsics.checkNotNullParameter(licenseFee, "licenseFee");
        Intrinsics.checkNotNullParameter(penalityFee, "penalityFee");
        Intrinsics.checkNotNullParameter(totalFee, "totalFee");
        Intrinsics.checkNotNullParameter(productCode, "productCode");
        Intrinsics.checkNotNullParameter(tokenCategory, "tokenCategory");
        return new ARMSLICENSETokenRequest(trackingId, citizenNumber, weaponNumber, weaponType, weaponCaliberBore, licenseNumber, cardValidation, cardDeliveryUnitId, processingFee, licenseFee, penalityFee, totalFee, productCode, tokenCategory);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ARMSLICENSETokenRequest)) {
            return false;
        }
        ARMSLICENSETokenRequest aRMSLICENSETokenRequest = (ARMSLICENSETokenRequest) other;
        return Intrinsics.areEqual(this.trackingId, aRMSLICENSETokenRequest.trackingId) && Intrinsics.areEqual(this.citizenNumber, aRMSLICENSETokenRequest.citizenNumber) && Intrinsics.areEqual(this.weaponNumber, aRMSLICENSETokenRequest.weaponNumber) && Intrinsics.areEqual(this.weaponType, aRMSLICENSETokenRequest.weaponType) && Intrinsics.areEqual(this.weaponCaliberBore, aRMSLICENSETokenRequest.weaponCaliberBore) && Intrinsics.areEqual(this.licenseNumber, aRMSLICENSETokenRequest.licenseNumber) && Intrinsics.areEqual(this.cardValidation, aRMSLICENSETokenRequest.cardValidation) && Intrinsics.areEqual(this.cardDeliveryUnitId, aRMSLICENSETokenRequest.cardDeliveryUnitId) && Intrinsics.areEqual(this.processingFee, aRMSLICENSETokenRequest.processingFee) && Intrinsics.areEqual(this.licenseFee, aRMSLICENSETokenRequest.licenseFee) && Intrinsics.areEqual(this.penalityFee, aRMSLICENSETokenRequest.penalityFee) && Intrinsics.areEqual(this.totalFee, aRMSLICENSETokenRequest.totalFee) && Intrinsics.areEqual(this.productCode, aRMSLICENSETokenRequest.productCode) && Intrinsics.areEqual(this.tokenCategory, aRMSLICENSETokenRequest.tokenCategory);
    }

    public int hashCode() {
        return (((((((((((((((((((((((((this.trackingId.hashCode() * 31) + this.citizenNumber.hashCode()) * 31) + this.weaponNumber.hashCode()) * 31) + this.weaponType.hashCode()) * 31) + this.weaponCaliberBore.hashCode()) * 31) + this.licenseNumber.hashCode()) * 31) + this.cardValidation.hashCode()) * 31) + this.cardDeliveryUnitId.hashCode()) * 31) + this.processingFee.hashCode()) * 31) + this.licenseFee.hashCode()) * 31) + this.penalityFee.hashCode()) * 31) + this.totalFee.hashCode()) * 31) + this.productCode.hashCode()) * 31) + this.tokenCategory.hashCode();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("ARMSLICENSETokenRequest(trackingId=");
        sb.append(this.trackingId).append(", citizenNumber=").append(this.citizenNumber).append(", weaponNumber=").append(this.weaponNumber).append(", weaponType=").append(this.weaponType).append(", weaponCaliberBore=").append(this.weaponCaliberBore).append(", licenseNumber=").append(this.licenseNumber).append(", cardValidation=").append(this.cardValidation).append(", cardDeliveryUnitId=").append(this.cardDeliveryUnitId).append(", processingFee=").append(this.processingFee).append(", licenseFee=").append(this.licenseFee).append(", penalityFee=").append(this.penalityFee).append(", totalFee=");
        sb.append(this.totalFee).append(", productCode=").append(this.productCode).append(", tokenCategory=").append(this.tokenCategory).append(')');
        return sb.toString();
    }

    public ARMSLICENSETokenRequest(String trackingId, String citizenNumber, String weaponNumber, String weaponType, String weaponCaliberBore, String licenseNumber, String cardValidation, String cardDeliveryUnitId, String processingFee, String licenseFee, String penalityFee, String totalFee, String productCode, String tokenCategory) {
        Intrinsics.checkNotNullParameter(trackingId, "trackingId");
        Intrinsics.checkNotNullParameter(citizenNumber, "citizenNumber");
        Intrinsics.checkNotNullParameter(weaponNumber, "weaponNumber");
        Intrinsics.checkNotNullParameter(weaponType, "weaponType");
        Intrinsics.checkNotNullParameter(weaponCaliberBore, "weaponCaliberBore");
        Intrinsics.checkNotNullParameter(licenseNumber, "licenseNumber");
        Intrinsics.checkNotNullParameter(cardValidation, "cardValidation");
        Intrinsics.checkNotNullParameter(cardDeliveryUnitId, "cardDeliveryUnitId");
        Intrinsics.checkNotNullParameter(processingFee, "processingFee");
        Intrinsics.checkNotNullParameter(licenseFee, "licenseFee");
        Intrinsics.checkNotNullParameter(penalityFee, "penalityFee");
        Intrinsics.checkNotNullParameter(totalFee, "totalFee");
        Intrinsics.checkNotNullParameter(productCode, "productCode");
        Intrinsics.checkNotNullParameter(tokenCategory, "tokenCategory");
        this.trackingId = trackingId;
        this.citizenNumber = citizenNumber;
        this.weaponNumber = weaponNumber;
        this.weaponType = weaponType;
        this.weaponCaliberBore = weaponCaliberBore;
        this.licenseNumber = licenseNumber;
        this.cardValidation = cardValidation;
        this.cardDeliveryUnitId = cardDeliveryUnitId;
        this.processingFee = processingFee;
        this.licenseFee = licenseFee;
        this.penalityFee = penalityFee;
        this.totalFee = totalFee;
        this.productCode = productCode;
        this.tokenCategory = tokenCategory;
    }

    public /* synthetic */ ARMSLICENSETokenRequest(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13, String str14, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? "" : str, (i & 2) != 0 ? "" : str2, (i & 4) != 0 ? "" : str3, (i & 8) != 0 ? "" : str4, (i & 16) != 0 ? "" : str5, (i & 32) != 0 ? "" : str6, (i & 64) != 0 ? "" : str7, (i & 128) != 0 ? "" : str8, (i & 256) != 0 ? "" : str9, (i & 512) != 0 ? "" : str10, (i & 1024) != 0 ? "" : str11, (i & 2048) != 0 ? "" : str12, (i & 4096) != 0 ? "" : str13, (i & 8192) != 0 ? "" : str14);
    }

    public final String getTrackingId() {
        return this.trackingId;
    }

    public final void setTrackingId(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.trackingId = str;
    }

    public final String getCitizenNumber() {
        return this.citizenNumber;
    }

    public final void setCitizenNumber(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.citizenNumber = str;
    }

    public final String getWeaponNumber() {
        return this.weaponNumber;
    }

    public final void setWeaponNumber(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.weaponNumber = str;
    }

    public final String getWeaponType() {
        return this.weaponType;
    }

    public final void setWeaponType(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.weaponType = str;
    }

    public final String getWeaponCaliberBore() {
        return this.weaponCaliberBore;
    }

    public final void setWeaponCaliberBore(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.weaponCaliberBore = str;
    }

    public final String getLicenseNumber() {
        return this.licenseNumber;
    }

    public final void setLicenseNumber(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.licenseNumber = str;
    }

    public final String getCardValidation() {
        return this.cardValidation;
    }

    public final void setCardValidation(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.cardValidation = str;
    }

    public final String getCardDeliveryUnitId() {
        return this.cardDeliveryUnitId;
    }

    public final void setCardDeliveryUnitId(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.cardDeliveryUnitId = str;
    }

    public final String getProcessingFee() {
        return this.processingFee;
    }

    public final void setProcessingFee(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.processingFee = str;
    }

    public final String getLicenseFee() {
        return this.licenseFee;
    }

    public final void setLicenseFee(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.licenseFee = str;
    }

    public final String getPenalityFee() {
        return this.penalityFee;
    }

    public final void setPenalityFee(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.penalityFee = str;
    }

    public final String getTotalFee() {
        return this.totalFee;
    }

    public final void setTotalFee(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.totalFee = str;
    }

    public final String getProductCode() {
        return this.productCode;
    }

    public final void setProductCode(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.productCode = str;
    }

    public final String getTokenCategory() {
        return this.tokenCategory;
    }

    public final void setTokenCategory(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.tokenCategory = str;
    }
}