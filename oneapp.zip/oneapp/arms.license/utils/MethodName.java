package pk.gov.nadra.oneapp.arms.license.utils;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: MethodName.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/utils/MethodName;", "", "<init>", "(Ljava/lang/String;I)V", "CENTER", "VALIDATION", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class MethodName {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ MethodName[] $VALUES;
    public static final MethodName CENTER = new MethodName("CENTER", 0);
    public static final MethodName VALIDATION = new MethodName("VALIDATION", 1);

    private static final /* synthetic */ MethodName[] $values() {
        return new MethodName[]{CENTER, VALIDATION};
    }

    public static EnumEntries<MethodName> getEntries() {
        return $ENTRIES;
    }

    private MethodName(String str, int i) {
    }

    static {
        MethodName[] methodNameArr$values = $values();
        $VALUES = methodNameArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(methodNameArr$values);
    }

    public static MethodName valueOf(String str) {
        return (MethodName) Enum.valueOf(MethodName.class, str);
    }

    public static MethodName[] values() {
        return (MethodName[]) $VALUES.clone();
    }
}