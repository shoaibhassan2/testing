package pk.gov.nadra.oneapp.arms.license.viewmodel;

import androidx.lifecycle.ViewModel;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.arms.license.models.LicenseFeeResponse;
import pk.gov.nadra.oneapp.arms.license.models.LicenseProductResponse;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;

/* compiled from: ArmsLicenseSharedViewModel.kt */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000e\n\u0002\b\u0017\n\u0002\u0010\u000b\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0016\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR \u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010R\u001a\u0010\u0011\u001a\u00020\fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u001a\u0010\u0016\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001bR\u001a\u0010\u001c\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u0019\"\u0004\b\u001e\u0010\u001bR\u001a\u0010\u001f\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b \u0010\u0019\"\u0004\b!\u0010\u001bR\u001a\u0010\"\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b#\u0010\u0019\"\u0004\b$\u0010\u001bR\u001a\u0010%\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b&\u0010\u0019\"\u0004\b'\u0010\u001bR\u001a\u0010(\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b)\u0010\u0019\"\u0004\b*\u0010\u001bR\u001a\u0010+\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b,\u0010\u0019\"\u0004\b-\u0010\u001bR\u001a\u0010.\u001a\u00020/X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b0\u00101\"\u0004\b2\u00103R\u001a\u00104\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b5\u0010\u0019\"\u0004\b6\u0010\u001bR\u001a\u00107\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b8\u0010\u0019\"\u0004\b9\u0010\u001bR\u001a\u0010:\u001a\u00020;X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b<\u0010=\"\u0004\b>\u0010?¨\u0006@"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/viewmodel/ArmsLicenseSharedViewModel;", "Landroidx/lifecycle/ViewModel;", "<init>", "()V", "reactNativeData", "Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "getReactNativeData", "()Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;", "setReactNativeData", "(Lpk/gov/nadra/oneapp/models/crc/ReactNativeData;)V", "licenseProductsResponse", "", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseProductResponse$LicenseProduct;", "getLicenseProductsResponse", "()Ljava/util/List;", "setLicenseProductsResponse", "(Ljava/util/List;)V", "selectedLicenseProduct", "getSelectedLicenseProduct", "()Lpk/gov/nadra/oneapp/arms/license/models/LicenseProductResponse$LicenseProduct;", "setSelectedLicenseProduct", "(Lpk/gov/nadra/oneapp/arms/license/models/LicenseProductResponse$LicenseProduct;)V", "selectedLicenseAction", "", "getSelectedLicenseAction", "()Ljava/lang/String;", "setSelectedLicenseAction", "(Ljava/lang/String;)V", "appType", "getAppType", "setAppType", "trackingId", "getTrackingId", "setTrackingId", "amount", "getAmount", "setAmount", "applicantPhotoPath", "getApplicantPhotoPath", "setApplicantPhotoPath", "applicationType", "getApplicationType", "setApplicationType", "documentType", "getDocumentType", "setDocumentType", "uploadDocumentP", "", "getUploadDocumentP", "()Z", "setUploadDocumentP", "(Z)V", "documentTypeValue", "getDocumentTypeValue", "setDocumentTypeValue", "applicationTypeValue", "getApplicationTypeValue", "setApplicationTypeValue", "licenseFeeResponse", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeResponse$FeeDetails;", "getLicenseFeeResponse", "()Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeResponse$FeeDetails;", "setLicenseFeeResponse", "(Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeResponse$FeeDetails;)V", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public class ArmsLicenseSharedViewModel extends ViewModel {
    private ReactNativeData reactNativeData = new ReactNativeData(null, null, null, null, null, null, null, false, false, false, null, null, false, null, null, null, false, null, false, false, false, false, null, null, false, false, false, null, false, false, null, null, null, false, null, null, null, false, false, null, null, null, null, false, null, null, null, null, null, null, -1, 262143, null);
    private List<LicenseProductResponse.LicenseProduct> licenseProductsResponse = new ArrayList();
    private LicenseProductResponse.LicenseProduct selectedLicenseProduct = new LicenseProductResponse.LicenseProduct(false, null, null, null, false, null, null, false, null, null, null, false, false, false, null, null, null, null, 262143, null);
    private String selectedLicenseAction = "";
    private String appType = "";
    private String trackingId = "";
    private String amount = "0";
    private String applicantPhotoPath = "";
    private String applicationType = "";
    private String documentType = "";
    private boolean uploadDocumentP = true;
    private String documentTypeValue = "";
    private String applicationTypeValue = "";
    private LicenseFeeResponse.FeeDetails licenseFeeResponse = new LicenseFeeResponse.FeeDetails(0, 0, 0, 0, 15, null);

    public final ReactNativeData getReactNativeData() {
        return this.reactNativeData;
    }

    public final void setReactNativeData(ReactNativeData reactNativeData) {
        Intrinsics.checkNotNullParameter(reactNativeData, "<set-?>");
        this.reactNativeData = reactNativeData;
    }

    public final List<LicenseProductResponse.LicenseProduct> getLicenseProductsResponse() {
        return this.licenseProductsResponse;
    }

    public final void setLicenseProductsResponse(List<LicenseProductResponse.LicenseProduct> list) {
        Intrinsics.checkNotNullParameter(list, "<set-?>");
        this.licenseProductsResponse = list;
    }

    public final LicenseProductResponse.LicenseProduct getSelectedLicenseProduct() {
        return this.selectedLicenseProduct;
    }

    public final void setSelectedLicenseProduct(LicenseProductResponse.LicenseProduct licenseProduct) {
        Intrinsics.checkNotNullParameter(licenseProduct, "<set-?>");
        this.selectedLicenseProduct = licenseProduct;
    }

    public final String getSelectedLicenseAction() {
        return this.selectedLicenseAction;
    }

    public final void setSelectedLicenseAction(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.selectedLicenseAction = str;
    }

    public final String getAppType() {
        return this.appType;
    }

    public final void setAppType(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.appType = str;
    }

    public final String getTrackingId() {
        return this.trackingId;
    }

    public final void setTrackingId(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.trackingId = str;
    }

    public final String getAmount() {
        return this.amount;
    }

    public final void setAmount(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.amount = str;
    }

    public final String getApplicantPhotoPath() {
        return this.applicantPhotoPath;
    }

    public final void setApplicantPhotoPath(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.applicantPhotoPath = str;
    }

    public final String getApplicationType() {
        return this.applicationType;
    }

    public final void setApplicationType(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.applicationType = str;
    }

    public final String getDocumentType() {
        return this.documentType;
    }

    public final void setDocumentType(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.documentType = str;
    }

    public final boolean getUploadDocumentP() {
        return this.uploadDocumentP;
    }

    public final void setUploadDocumentP(boolean z) {
        this.uploadDocumentP = z;
    }

    public final String getDocumentTypeValue() {
        return this.documentTypeValue;
    }

    public final void setDocumentTypeValue(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.documentTypeValue = str;
    }

    public final String getApplicationTypeValue() {
        return this.applicationTypeValue;
    }

    public final void setApplicationTypeValue(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.applicationTypeValue = str;
    }

    public final LicenseFeeResponse.FeeDetails getLicenseFeeResponse() {
        return this.licenseFeeResponse;
    }

    public final void setLicenseFeeResponse(LicenseFeeResponse.FeeDetails feeDetails) {
        Intrinsics.checkNotNullParameter(feeDetails, "<set-?>");
        this.licenseFeeResponse = feeDetails;
    }
}