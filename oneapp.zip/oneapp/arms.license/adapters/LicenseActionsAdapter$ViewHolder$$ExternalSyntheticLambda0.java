package pk.gov.nadra.oneapp.arms.license.adapters;

import android.view.View;
import pk.gov.nadra.oneapp.arms.license.adapters.LicenseActionsAdapter;
import pk.gov.nadra.oneapp.arms.license.models.LicenseActionModel;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class LicenseActionsAdapter$ViewHolder$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ LicenseActionModel f$1;

    public /* synthetic */ LicenseActionsAdapter$ViewHolder$$ExternalSyntheticLambda0(LicenseActionModel licenseActionModel) {
        item = licenseActionModel;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        LicenseActionsAdapter.ViewHolder.bind$lambda$0(licenseActionsAdapter, item, view);
    }
}