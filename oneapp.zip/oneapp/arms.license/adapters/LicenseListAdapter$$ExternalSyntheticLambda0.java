package pk.gov.nadra.oneapp.arms.license.adapters;

import android.view.View;
import pk.gov.nadra.oneapp.arms.license.models.LicenseProductResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class LicenseListAdapter$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ LicenseProductResponse.LicenseProduct f$1;

    public /* synthetic */ LicenseListAdapter$$ExternalSyntheticLambda0(LicenseProductResponse.LicenseProduct licenseProduct) {
        licenseProduct = licenseProduct;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        LicenseListAdapter.onBindViewHolder$lambda$0(this.f$0, licenseProduct, view);
    }
}