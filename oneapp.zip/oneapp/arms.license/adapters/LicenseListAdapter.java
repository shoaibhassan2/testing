package pk.gov.nadra.oneapp.arms.license.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.arms.license.R;
import pk.gov.nadra.oneapp.arms.license.models.LicenseProductResponse;

/* compiled from: LicenseListAdapter.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0016B)\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\u0004\b\t\u0010\nJ\u0014\u0010\u000b\u001a\u00020\b2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004J\u0018\u0010\r\u001a\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0016J\u0018\u0010\u0012\u001a\u00020\b2\u0006\u0010\u0013\u001a\u00020\u00022\u0006\u0010\u0014\u001a\u00020\u0011H\u0016J\b\u0010\u0015\u001a\u00020\u0011H\u0016R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0017"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/adapters/LicenseListAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lpk/gov/nadra/oneapp/arms/license/adapters/LicenseListAdapter$ViewHolder;", FirebaseAnalytics.Param.ITEMS, "", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseProductResponse$LicenseProduct;", "onItemClick", "Lkotlin/Function1;", "", "<init>", "(Ljava/util/List;Lkotlin/jvm/functions/Function1;)V", "updateList", "list", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "onBindViewHolder", "holder", "position", "getItemCount", "ViewHolder", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class LicenseListAdapter extends RecyclerView.Adapter<ViewHolder> {
    private List<LicenseProductResponse.LicenseProduct> items;
    private final Function1<LicenseProductResponse.LicenseProduct, Unit> onItemClick;

    /* JADX WARN: Multi-variable type inference failed */
    public LicenseListAdapter(List<LicenseProductResponse.LicenseProduct> items, Function1<? super LicenseProductResponse.LicenseProduct, Unit> onItemClick) {
        Intrinsics.checkNotNullParameter(items, "items");
        Intrinsics.checkNotNullParameter(onItemClick, "onItemClick");
        this.items = items;
        this.onItemClick = onItemClick;
    }

    /* compiled from: LicenseListAdapter.kt */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u000e\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\rR\u0011\u0010\u0010\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\rR\u0011\u0010\u0012\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\r¨\u0006\u0014"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/adapters/LicenseListAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", Promotion.ACTION_VIEW, "Landroid/view/View;", "<init>", "(Landroid/view/View;)V", "icon", "Landroid/widget/ImageView;", "getIcon", "()Landroid/widget/ImageView;", "licenseNumber", "Landroid/widget/TextView;", "getLicenseNumber", "()Landroid/widget/TextView;", "issueDate", "getIssueDate", "expiryDate", "getExpiryDate", "licenseTypeLabel", "getLicenseTypeLabel", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView expiryDate;
        private final ImageView icon;
        private final TextView issueDate;
        private final TextView licenseNumber;
        private final TextView licenseTypeLabel;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ViewHolder(View view) {
            super(view);
            Intrinsics.checkNotNullParameter(view, "view");
            View viewFindViewById = view.findViewById(R.id.itemImage);
            Intrinsics.checkNotNullExpressionValue(viewFindViewById, "findViewById(...)");
            this.icon = (ImageView) viewFindViewById;
            View viewFindViewById2 = view.findViewById(R.id.itemNumber);
            Intrinsics.checkNotNullExpressionValue(viewFindViewById2, "findViewById(...)");
            this.licenseNumber = (TextView) viewFindViewById2;
            View viewFindViewById3 = view.findViewById(R.id.issuanceDate);
            Intrinsics.checkNotNullExpressionValue(viewFindViewById3, "findViewById(...)");
            this.issueDate = (TextView) viewFindViewById3;
            View viewFindViewById4 = view.findViewById(R.id.expiryDate);
            Intrinsics.checkNotNullExpressionValue(viewFindViewById4, "findViewById(...)");
            this.expiryDate = (TextView) viewFindViewById4;
            View viewFindViewById5 = view.findViewById(R.id.licenseTypeLabel);
            Intrinsics.checkNotNullExpressionValue(viewFindViewById5, "findViewById(...)");
            this.licenseTypeLabel = (TextView) viewFindViewById5;
        }

        public final ImageView getIcon() {
            return this.icon;
        }

        public final TextView getLicenseNumber() {
            return this.licenseNumber;
        }

        public final TextView getIssueDate() {
            return this.issueDate;
        }

        public final TextView getExpiryDate() {
            return this.expiryDate;
        }

        public final TextView getLicenseTypeLabel() {
            return this.licenseTypeLabel;
        }
    }

    public final void updateList(List<LicenseProductResponse.LicenseProduct> list) {
        Intrinsics.checkNotNullParameter(list, "list");
        this.items = list;
        notifyDataSetChanged();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        View viewInflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_license_list, parent, false);
        Intrinsics.checkNotNull(viewInflate);
        return new ViewHolder(viewInflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder holder, int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        final LicenseProductResponse.LicenseProduct licenseProduct = this.items.get(position);
        holder.getLicenseNumber().setText(licenseProduct.getLicenseNumber());
        holder.getLicenseTypeLabel().setText(licenseProduct.getProductName());
        holder.getIssueDate().setText(licenseProduct.getFormattedIssueDate());
        holder.getExpiryDate().setText(licenseProduct.getFormattedExpiryDate());
        holder.itemView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.arms.license.adapters.LicenseListAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                LicenseListAdapter.onBindViewHolder$lambda$0(this.f$0, licenseProduct, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$0(LicenseListAdapter this$0, LicenseProductResponse.LicenseProduct item, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(item, "$item");
        this$0.onItemClick.invoke(item);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.items.size();
    }
}