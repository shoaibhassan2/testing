package pk.gov.nadra.oneapp.arms.license.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import pk.gov.nadra.oneapp.arms.license.R;
import pk.gov.nadra.oneapp.arms.license.adapters.LicenseActionsAdapter;
import pk.gov.nadra.oneapp.arms.license.models.LicenseActionModel;

/* compiled from: LicenseActionsAdapter.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001\u0014B)\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\u0004\b\t\u0010\nJ\u001c\u0010\u000b\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016J\u001c\u0010\u0010\u001a\u00020\b2\n\u0010\u0011\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0012\u001a\u00020\u000fH\u0016J\b\u0010\u0013\u001a\u00020\u000fH\u0016R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0015"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/adapters/LicenseActionsAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lpk/gov/nadra/oneapp/arms/license/adapters/LicenseActionsAdapter$ViewHolder;", FirebaseAnalytics.Param.ITEMS, "", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseActionModel;", "onItemClick", "Lkotlin/Function1;", "", "<init>", "(Ljava/util/List;Lkotlin/jvm/functions/Function1;)V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "onBindViewHolder", "holder", "position", "getItemCount", "ViewHolder", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class LicenseActionsAdapter extends RecyclerView.Adapter<ViewHolder> {
    private final List<LicenseActionModel> items;
    private final Function1<LicenseActionModel, Unit> onItemClick;

    /* JADX WARN: Multi-variable type inference failed */
    public LicenseActionsAdapter(List<LicenseActionModel> items, Function1<? super LicenseActionModel, Unit> onItemClick) {
        Intrinsics.checkNotNullParameter(items, "items");
        Intrinsics.checkNotNullParameter(onItemClick, "onItemClick");
        this.items = items;
        this.onItemClick = onItemClick;
    }

    /* compiled from: LicenseActionsAdapter.kt */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eR\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/adapters/LicenseActionsAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", Promotion.ACTION_VIEW, "Landroid/view/View;", "<init>", "(Lpk/gov/nadra/oneapp/arms/license/adapters/LicenseActionsAdapter;Landroid/view/View;)V", "backgroundImage", "Landroid/widget/ImageView;", "title", "Landroid/widget/TextView;", "description", "bind", "", "item", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseActionModel;", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public final class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView backgroundImage;
        private final TextView description;
        final /* synthetic */ LicenseActionsAdapter this$0;
        private final TextView title;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ViewHolder(LicenseActionsAdapter licenseActionsAdapter, View view) {
            super(view);
            Intrinsics.checkNotNullParameter(view, "view");
            this.this$0 = licenseActionsAdapter;
            View viewFindViewById = view.findViewById(R.id.ivBackground);
            Intrinsics.checkNotNullExpressionValue(viewFindViewById, "findViewById(...)");
            this.backgroundImage = (ImageView) viewFindViewById;
            View viewFindViewById2 = view.findViewById(R.id.tvTitle);
            Intrinsics.checkNotNullExpressionValue(viewFindViewById2, "findViewById(...)");
            this.title = (TextView) viewFindViewById2;
            View viewFindViewById3 = view.findViewById(R.id.tvDescription);
            Intrinsics.checkNotNullExpressionValue(viewFindViewById3, "findViewById(...)");
            this.description = (TextView) viewFindViewById3;
        }

        public final void bind(final LicenseActionModel item) {
            Intrinsics.checkNotNullParameter(item, "item");
            this.backgroundImage.setImageResource(item.getImage());
            this.title.setText(item.getTitle());
            this.description.setText(item.getDescription());
            View view = this.itemView;
            final LicenseActionsAdapter licenseActionsAdapter = this.this$0;
            view.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.arms.license.adapters.LicenseActionsAdapter$ViewHolder$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    LicenseActionsAdapter.ViewHolder.bind$lambda$0(licenseActionsAdapter, item, view2);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void bind$lambda$0(LicenseActionsAdapter this$0, LicenseActionModel item, View view) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(item, "$item");
            this$0.onItemClick.invoke(item);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        View viewInflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_license_action, parent, false);
        Intrinsics.checkNotNull(viewInflate);
        return new ViewHolder(this, viewInflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder holder, int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        holder.bind(this.items.get(position));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.items.size();
    }
}