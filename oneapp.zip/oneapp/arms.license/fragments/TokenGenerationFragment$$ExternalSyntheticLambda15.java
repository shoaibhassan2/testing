package pk.gov.nadra.oneapp.arms.license.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class TokenGenerationFragment$$ExternalSyntheticLambda15 implements ActivityResultCallback {
    public /* synthetic */ TokenGenerationFragment$$ExternalSyntheticLambda15() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        TokenGenerationFragment.startForResult$lambda$31(this.f$0, (ActivityResult) obj);
    }
}