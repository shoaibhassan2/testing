package pk.gov.nadra.oneapp.arms.license.fragments;

import kotlin.jvm.functions.Function0;
import pk.gov.nadra.oneapp.models.supportingDocument.SupportingDocuments;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda0 implements Function0 {
    public final /* synthetic */ SupportingDocuments.GroupDocument.GroupDocuments f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda0(SupportingDocuments.GroupDocument.GroupDocuments groupDocuments, int i) {
        document = groupDocuments;
        i = i;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$4$lambda$3(this.f$0, document, i);
    }
}