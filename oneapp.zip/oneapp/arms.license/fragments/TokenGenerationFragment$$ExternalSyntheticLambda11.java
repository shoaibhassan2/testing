package pk.gov.nadra.oneapp.arms.license.fragments;

import kotlin.Result;
import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class TokenGenerationFragment$$ExternalSyntheticLambda11 implements Function1 {
    public final /* synthetic */ Integer f$1;

    public /* synthetic */ TokenGenerationFragment$$ExternalSyntheticLambda11(Integer num) {
        responseCode = num;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return TokenGenerationFragment.processDeliveryCentersResponse$lambda$28(this.f$0, responseCode, (Result) obj);
    }
}