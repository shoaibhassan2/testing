package pk.gov.nadra.oneapp.arms.license.fragments;

import kotlin.jvm.functions.Function1;
import pk.gov.nadra.oneapp.arms.license.models.LicenseActionModel;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class LicenseActionsFragment$$ExternalSyntheticLambda0 implements Function1 {
    public /* synthetic */ LicenseActionsFragment$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return LicenseActionsFragment.onViewCreated$lambda$1(this.f$0, (LicenseActionModel) obj);
    }
}