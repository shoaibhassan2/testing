package pk.gov.nadra.oneapp.arms.license.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class TokenGenerationFragment$$ExternalSyntheticLambda10 implements View.OnClickListener {
    public /* synthetic */ TokenGenerationFragment$$ExternalSyntheticLambda10() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        TokenGenerationFragment.setupClickListeners$lambda$7(this.f$0, view);
    }
}