package pk.gov.nadra.oneapp.arms.license.fragments;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import pk.gov.nadra.oneapp.arms.license.databinding.FragmentLicenseSupportingDocumentsBinding;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda12 implements SwipeRefreshLayout.OnRefreshListener {
    public final /* synthetic */ FragmentLicenseSupportingDocumentsBinding f$1;

    public /* synthetic */ LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda12(FragmentLicenseSupportingDocumentsBinding fragmentLicenseSupportingDocumentsBinding) {
        binding = fragmentLicenseSupportingDocumentsBinding;
    }

    @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
    public final void onRefresh() {
        LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$7(this.f$0, binding);
    }
}