package pk.gov.nadra.oneapp.arms.license.fragments;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class LicenseListFragment$$ExternalSyntheticLambda1 implements SwipeRefreshLayout.OnRefreshListener {
    public /* synthetic */ LicenseListFragment$$ExternalSyntheticLambda1() {
    }

    @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
    public final void onRefresh() {
        LicenseListFragment.onViewCreated$lambda$1(this.f$0);
    }
}