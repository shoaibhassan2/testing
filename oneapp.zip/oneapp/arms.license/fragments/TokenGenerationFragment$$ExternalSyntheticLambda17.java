package pk.gov.nadra.oneapp.arms.license.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class TokenGenerationFragment$$ExternalSyntheticLambda17 implements Function0 {
    public /* synthetic */ TokenGenerationFragment$$ExternalSyntheticLambda17() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return TokenGenerationFragment.processLicenseFeeSummaryResponse$lambda$45$lambda$44$lambda$43(this.f$0);
    }
}