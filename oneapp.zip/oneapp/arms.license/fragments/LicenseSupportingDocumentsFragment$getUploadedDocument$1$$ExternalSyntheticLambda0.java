package pk.gov.nadra.oneapp.arms.license.fragments;

import com.google.gson.JsonObject;
import kotlin.jvm.functions.Function3;
import pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class LicenseSupportingDocumentsFragment$getUploadedDocument$1$$ExternalSyntheticLambda0 implements Function3 {
    public /* synthetic */ LicenseSupportingDocumentsFragment$getUploadedDocument$1$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return LicenseSupportingDocumentsFragment.C11061.invokeSuspend$lambda$0(licenseSupportingDocumentsFragment, (JsonObject) obj, (String) obj2, ((Integer) obj3).intValue());
    }
}