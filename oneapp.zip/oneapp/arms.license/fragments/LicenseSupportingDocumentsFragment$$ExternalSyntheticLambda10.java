package pk.gov.nadra.oneapp.arms.license.fragments;

import kotlin.jvm.functions.Function2;
import pk.gov.nadra.oneapp.models.supportingDocument.SupportingDocuments;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda10 implements Function2 {
    public /* synthetic */ LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda10() {
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$5(this.f$0, (SupportingDocuments.GroupDocument.GroupDocuments) obj, ((Integer) obj2).intValue());
    }
}