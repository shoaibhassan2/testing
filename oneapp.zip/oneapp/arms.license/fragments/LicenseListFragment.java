package pk.gov.nadra.oneapp.arms.license.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.compose.material3.MenuKt;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import pk.gov.nadra.oneapp.arms.license.R;
import pk.gov.nadra.oneapp.arms.license.adapters.LicenseListAdapter;
import pk.gov.nadra.oneapp.arms.license.databinding.FragmentLicenseListBinding;
import pk.gov.nadra.oneapp.arms.license.fragments.LicenseListFragment;
import pk.gov.nadra.oneapp.arms.license.models.LicenseListRequestModel;
import pk.gov.nadra.oneapp.arms.license.models.LicenseProductResponse;
import pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests;
import pk.gov.nadra.oneapp.arms.license.network.utils.JsonParserHelper;
import pk.gov.nadra.oneapp.arms.license.viewmodel.ArmsLicenseSharedViewModel;
import pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.network.common.Constants;

/* compiled from: LicenseListFragment.kt */
@Metadata(d1 = {"\u0000z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!H\u0016J$\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020%2\b\u0010&\u001a\u0004\u0018\u00010'2\b\u0010(\u001a\u0004\u0018\u00010)H\u0016J\u001a\u0010*\u001a\u00020\u001f2\u0006\u0010+\u001a\u00020#2\b\u0010(\u001a\u0004\u0018\u00010)H\u0016J\u0010\u0010,\u001a\u00020\u001f2\u0006\u0010-\u001a\u00020\u001dH\u0002J\b\u0010.\u001a\u00020/H\u0002J\b\u00100\u001a\u00020\u001fH\u0002J\u0010\u00101\u001a\u00020\u001f2\u0006\u00102\u001a\u000203H\u0002J#\u00104\u001a\u00020\u001f2\b\u00105\u001a\u0004\u0018\u0001062\n\b\u0002\u00107\u001a\u0004\u0018\u000108H\u0002¢\u0006\u0002\u00109J\b\u0010:\u001a\u00020\u001fH\u0016R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u001a\u0010\n\u001a\u00020\u000bX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0010\u001a\u00020\u0011X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0018\u001a\u00020\u00178BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u001aR\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001cX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006;"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/fragments/LicenseListFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "armsLicenseSharedViewModel", "Lpk/gov/nadra/oneapp/arms/license/viewmodel/ArmsLicenseSharedViewModel;", "getArmsLicenseSharedViewModel", "()Lpk/gov/nadra/oneapp/arms/license/viewmodel/ArmsLicenseSharedViewModel;", "armsLicenseSharedViewModel$delegate", "Lkotlin/Lazy;", "activity", "Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;)V", "adapter", "Lpk/gov/nadra/oneapp/arms/license/adapters/LicenseListAdapter;", "getAdapter", "()Lpk/gov/nadra/oneapp/arms/license/adapters/LicenseListAdapter;", "setAdapter", "(Lpk/gov/nadra/oneapp/arms/license/adapters/LicenseListAdapter;)V", "_binding", "Lpk/gov/nadra/oneapp/arms/license/databinding/FragmentLicenseListBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/arms/license/databinding/FragmentLicenseListBinding;", "licenseProductList", "", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseProductResponse$LicenseProduct;", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "onLicenseSelected", "selectedLicense", "getLicenseListRequest", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseListRequestModel;", "getArmsLicenseList", "processArmsLicenseProductResponse", "jsonObject", "Lcom/google/gson/JsonObject;", "handleFailureCase", "error", "", "responseCode", "", "(Ljava/lang/Object;Ljava/lang/Integer;)V", "onDestroyView", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class LicenseListFragment extends Fragment {
    private FragmentLicenseListBinding _binding;
    public ArmsLicenseActivity activity;
    public LicenseListAdapter adapter;

    /* renamed from: armsLicenseSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy armsLicenseSharedViewModel;
    private List<LicenseProductResponse.LicenseProduct> licenseProductList = new ArrayList();

    public LicenseListFragment() {
        final LicenseListFragment licenseListFragment = this;
        final Function0 function0 = null;
        this.armsLicenseSharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(licenseListFragment, Reflection.getOrCreateKotlinClass(ArmsLicenseSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseListFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = licenseListFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseListFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = licenseListFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseListFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = licenseListFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    private final ArmsLicenseSharedViewModel getArmsLicenseSharedViewModel() {
        return (ArmsLicenseSharedViewModel) this.armsLicenseSharedViewModel.getValue();
    }

    @Override // androidx.fragment.app.Fragment
    public final ArmsLicenseActivity getActivity() {
        ArmsLicenseActivity armsLicenseActivity = this.activity;
        if (armsLicenseActivity != null) {
            return armsLicenseActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(ArmsLicenseActivity armsLicenseActivity) {
        Intrinsics.checkNotNullParameter(armsLicenseActivity, "<set-?>");
        this.activity = armsLicenseActivity;
    }

    public final LicenseListAdapter getAdapter() {
        LicenseListAdapter licenseListAdapter = this.adapter;
        if (licenseListAdapter != null) {
            return licenseListAdapter;
        }
        Intrinsics.throwUninitializedPropertyAccessException("adapter");
        return null;
    }

    public final void setAdapter(LicenseListAdapter licenseListAdapter) {
        Intrinsics.checkNotNullParameter(licenseListAdapter, "<set-?>");
        this.adapter = licenseListAdapter;
    }

    private final FragmentLicenseListBinding getBinding() {
        FragmentLicenseListBinding fragmentLicenseListBinding = this._binding;
        Intrinsics.checkNotNull(fragmentLicenseListBinding);
        return fragmentLicenseListBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity");
        setActivity((ArmsLicenseActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentLicenseListBinding.inflate(inflater, container, false);
        SwipeRefreshLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getBinding().rvLicenseList.setLayoutManager(new LinearLayoutManager(requireContext()));
        setAdapter(new LicenseListAdapter(this.licenseProductList, new Function1() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseListFragment$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LicenseListFragment.onViewCreated$lambda$0(this.f$0, (LicenseProductResponse.LicenseProduct) obj);
            }
        }));
        getBinding().mainSwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseListFragment$$ExternalSyntheticLambda1
            @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
            public final void onRefresh() {
                LicenseListFragment.onViewCreated$lambda$1(this.f$0);
            }
        });
        getBinding().rvLicenseList.setAdapter(getAdapter());
        if (getArmsLicenseSharedViewModel().getLicenseProductsResponse().isEmpty()) {
            getArmsLicenseList();
            return;
        }
        getAdapter().updateList(getArmsLicenseSharedViewModel().getLicenseProductsResponse());
        getBinding().tryAgainSection.inboxTryAgainLayout.setVisibility(8);
        getBinding().rvLicenseList.setVisibility(0);
        getBinding().tvLicenseTitle.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Arms License(s) (" + getAdapter().getItemCount() + ") ", "(اسلحہ لائسنس)", 0, false, 12, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$0(LicenseListFragment this$0, LicenseProductResponse.LicenseProduct licenseProduct) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(licenseProduct, "licenseProduct");
        this$0.onLicenseSelected(licenseProduct);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$1(LicenseListFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getArmsLicenseList();
        this$0.getBinding().mainSwipeRefresh.setRefreshing(false);
    }

    private final void onLicenseSelected(LicenseProductResponse.LicenseProduct selectedLicense) {
        if (selectedLicense.getRenewalP() || selectedLicense.getReprintP()) {
            getArmsLicenseSharedViewModel().setSelectedLicenseProduct(selectedLicense);
            getActivity().navigateToFragment(R.id.licenseActionsFragment);
            return;
        }
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        ArmsLicenseActivity activity = getActivity();
        String string = getString(pk.gov.nadra.oneapp.commonui.R.string.only_renewal_reprint);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = getString(pk.gov.nadra.oneapp.commonui.R.string.only_renewal_reprint_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Action Restricted", string, false, true, string2, (Function1) null, 72, (Object) null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final LicenseListRequestModel getLicenseListRequest() {
        return new LicenseListRequestModel(StringsKt.replace$default(getArmsLicenseSharedViewModel().getReactNativeData().getCitizenNumber(), "-", "", false, 4, (Object) null));
    }

    private final void getArmsLicenseList() {
        getBinding().tvLicenseTitle.setVisibility(8);
        getBinding().rvLicenseList.setVisibility(8);
        getBinding().tryAgainSection.inboxTryAgainLayout.setVisibility(8);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(null), 3, null);
    }

    /* compiled from: LicenseListFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.LicenseListFragment$getArmsLicenseList$1", f = "LicenseListFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.LicenseListFragment$getArmsLicenseList$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return LicenseListFragment.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(LicenseListFragment.this.getActivity());
            APIRequests aPIRequests = new APIRequests(LicenseListFragment.this.getActivity());
            LicenseListRequestModel licenseListRequest = LicenseListFragment.this.getLicenseListRequest();
            final LicenseListFragment licenseListFragment = LicenseListFragment.this;
            aPIRequests.getArmsLicenseProducts(licenseListRequest, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseListFragment$getArmsLicenseList$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return LicenseListFragment.AnonymousClass1.invokeSuspend$lambda$0(licenseListFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(LicenseListFragment licenseListFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(licenseListFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                licenseListFragment.processArmsLicenseProductResponse(jsonObject);
            } else {
                licenseListFragment.handleFailureCase(jsonObject, Integer.valueOf(i));
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processArmsLicenseProductResponse(JsonObject jsonObject) {
        JsonParserHelper.INSTANCE.parseJsonData(jsonObject, "licenseDataList", new Function1() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseListFragment$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LicenseListFragment.processArmsLicenseProductResponse$lambda$5(this.f$0, (Result) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processArmsLicenseProductResponse$lambda$5(LicenseListFragment this$0, Result result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Object value = result.getValue();
        Throwable thM7261exceptionOrNullimpl = Result.m7261exceptionOrNullimpl(value);
        if (thM7261exceptionOrNullimpl == null) {
            try {
                Object objFromJson = new Gson().fromJson((JsonElement) value, (Class<Object>) LicenseProductResponse.LicenseProduct[].class);
                Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
                List<LicenseProductResponse.LicenseProduct> list = ArraysKt.toList((Object[]) objFromJson);
                this$0.getAdapter().updateList(list);
                if (!list.isEmpty()) {
                    this$0.getArmsLicenseSharedViewModel().setLicenseProductsResponse(list);
                    this$0.getBinding().rvLicenseList.setVisibility(0);
                    TextView textView = this$0.getBinding().tvLicenseTitle;
                    Util util = Util.INSTANCE;
                    ArmsLicenseActivity activity = this$0.getActivity();
                    String string = this$0.getString(R.string.arms_license_title, Integer.valueOf(this$0.getAdapter().getItemCount()));
                    Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                    textView.setText(Util.setEnglishTextSpan$default(util, activity, string, "(اسلحہ لائسنس)", 0, false, 12, null));
                    this$0.getBinding().tvLicenseTitle.setVisibility(0);
                    if (Constant.INSTANCE.getDEBUG()) {
                        System.out.println((Object) ("Arms License List Response: " + list));
                    }
                } else {
                    handleFailureCase$default(this$0, this$0.getString(R.string.no_licenses), null, 2, null);
                }
            } catch (Exception e) {
                handleFailureCase$default(this$0, e, null, 2, null);
            }
        } else {
            handleFailureCase$default(this$0, thM7261exceptionOrNullimpl, null, 2, null);
        }
        return Unit.INSTANCE;
    }

    static /* synthetic */ void handleFailureCase$default(LicenseListFragment licenseListFragment, Object obj, Integer num, int i, Object obj2) {
        if ((i & 2) != 0) {
            num = null;
        }
        licenseListFragment.handleFailureCase(obj, num);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(Object error, Integer responseCode) {
        String string;
        if (error instanceof Throwable) {
            string = ((Throwable) error).getMessage();
            if (string == null) {
                string = getString(pk.gov.nadra.oneapp.commonui.R.string.arms_license_generic_error_message);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            }
        } else if (error instanceof String) {
            string = (String) error;
        } else if (error instanceof JsonObject) {
            string = ((ErrorResponse) new Gson().fromJson((JsonElement) ((JsonObject) error).getAsJsonObject(), ErrorResponse.class)).getMessage();
            if (string == null) {
                string = getString(pk.gov.nadra.oneapp.commonui.R.string.arms_license_generic_error_message);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            }
        } else {
            string = getString(pk.gov.nadra.oneapp.commonui.R.string.arms_license_generic_error_message);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        }
        String str = string;
        if (getBinding() != null) {
            FragmentLicenseListBinding binding = getBinding();
            binding.rvLicenseList.setVisibility(8);
            binding.tryAgainSection.inboxTryAgainLayout.setVisibility(0);
            binding.tryAgainSection.inboxTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), getString(R.string.no_licenses) + '\n', "ابھی تک کوئی لائسنس نہیں", 0, false, 12, null));
            TextView textView = binding.tvLicenseTitle;
            Util util = Util.INSTANCE;
            ArmsLicenseActivity activity = getActivity();
            String string2 = getString(R.string.arms_license_title, Integer.valueOf(getAdapter().getItemCount()));
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            textView.setText(Util.setEnglishTextSpan$default(util, activity, string2, "(اسلحہ لائسنس)", 0, false, 12, null));
        }
        if (Constants.INSTANCE.getDEBUG()) {
            System.out.println((Object) ("Failure - Code: " + (responseCode == null ? "N/A" : responseCode) + ", Message: " + str));
        }
        BottomSheetUtils.showMessageBottomSheet$default(BottomSheetUtils.INSTANCE, (FragmentActivity) getActivity(), "Info", str, false, false, (String) null, (Function1) null, MenuKt.InTransitionDuration, (Object) null);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}