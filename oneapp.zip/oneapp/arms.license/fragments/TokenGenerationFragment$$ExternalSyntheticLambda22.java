package pk.gov.nadra.oneapp.arms.license.fragments;

import kotlin.Result;
import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class TokenGenerationFragment$$ExternalSyntheticLambda22 implements Function1 {
    public final /* synthetic */ int f$1;

    public /* synthetic */ TokenGenerationFragment$$ExternalSyntheticLambda22(int i) {
        responseCode = i;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return TokenGenerationFragment.processLicenseFeeSummaryResponse$lambda$45(this.f$0, responseCode, (Result) obj);
    }
}