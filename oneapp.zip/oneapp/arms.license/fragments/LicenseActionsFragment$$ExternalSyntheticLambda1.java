package pk.gov.nadra.oneapp.arms.license.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class LicenseActionsFragment$$ExternalSyntheticLambda1 implements Function0 {
    public /* synthetic */ LicenseActionsFragment$$ExternalSyntheticLambda1() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return LicenseActionsFragment.originalItems_delegate$lambda$0(this.f$0);
    }
}