package pk.gov.nadra.oneapp.arms.license.fragments;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import com.google.gson.JsonSyntaxException;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class TokenGenerationFragment$$ExternalSyntheticLambda14 implements ActivityResultCallback {
    public /* synthetic */ TokenGenerationFragment$$ExternalSyntheticLambda14() {
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) throws JsonSyntaxException {
        TokenGenerationFragment.fingerprintLauncher$lambda$9(this.f$0, (ActivityResult) obj);
    }
}