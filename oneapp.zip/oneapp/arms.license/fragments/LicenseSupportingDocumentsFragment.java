package pk.gov.nadra.oneapp.arms.license.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import pk.gov.nadra.oneapp.arms.license.R;
import pk.gov.nadra.oneapp.arms.license.databinding.FragmentLicenseSupportingDocumentsBinding;
import pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment;
import pk.gov.nadra.oneapp.arms.license.viewmodel.ArmsLicenseSharedViewModel;
import pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonutils.adapter.SupportingDocumentsAdapter;
import pk.gov.nadra.oneapp.commonutils.adapter.SupportingUploadedDocumentsAdapter;
import pk.gov.nadra.oneapp.commonutils.document.DocumentActivity;
import pk.gov.nadra.oneapp.commonutils.document.ViewDocumentActivity;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.NonScrollExpandableListView;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.TabUpdateRequest;
import pk.gov.nadra.oneapp.models.supportingDocument.DownloadDocumentResponse;
import pk.gov.nadra.oneapp.models.supportingDocument.SupportingDocuments;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: LicenseSupportingDocumentsFragment.kt */
@Metadata(d1 = {"\u0000\u008e\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001cH\u0016J$\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 2\b\u0010!\u001a\u0004\u0018\u00010\"2\b\u0010#\u001a\u0004\u0018\u00010$H\u0016J\u001a\u0010%\u001a\u00020\u001a2\u0006\u0010&\u001a\u00020\u001e2\b\u0010#\u001a\u0004\u0018\u00010$H\u0016J\b\u0010'\u001a\u00020\u001aH\u0002J\u0018\u0010,\u001a\u00020\u001a2\u0006\u0010-\u001a\u00020.2\u0006\u0010/\u001a\u000200H\u0002J\u0018\u00101\u001a\u00020\u001a2\u0006\u00102\u001a\u0002032\u0006\u00104\u001a\u000200H\u0002J \u00105\u001a\u00020\u001a2\u0006\u00106\u001a\u0002072\u0006\u00108\u001a\u0002092\u0006\u0010/\u001a\u000209H\u0002J\u0010\u0010:\u001a\u00020\u001a2\u0006\u0010;\u001a\u000203H\u0002J\b\u0010<\u001a\u00020\u001aH\u0002J\u0010\u0010=\u001a\u00020\u001a2\u0006\u0010;\u001a\u000203H\u0002J\u0018\u0010>\u001a\u00020\u001a2\u0006\u0010?\u001a\u0002002\u0006\u0010@\u001a\u000200H\u0002J\u0010\u0010A\u001a\u00020\u001a2\u0006\u0010;\u001a\u000203H\u0002J\u0018\u0010B\u001a\u00020\u001a2\u0006\u0010?\u001a\u0002002\u0006\u0010@\u001a\u000200H\u0002J\u0010\u0010C\u001a\u00020\u001a2\u0006\u0010;\u001a\u000203H\u0002J\u0010\u0010D\u001a\u00020\u001a2\u0006\u0010E\u001a\u00020.H\u0002J\b\u0010H\u001a\u00020\u001aH\u0002J\u0010\u0010I\u001a\u00020\u001a2\u0006\u0010;\u001a\u000203H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082.¢\u0006\u0002\n\u0000R\u001c\u0010(\u001a\u0010\u0012\f\u0012\n +*\u0004\u0018\u00010*0*0)X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010F\u001a\u00020GX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006J"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/fragments/LicenseSupportingDocumentsFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "sharedViewModel", "Lpk/gov/nadra/oneapp/arms/license/viewmodel/ArmsLicenseSharedViewModel;", "getSharedViewModel", "()Lpk/gov/nadra/oneapp/arms/license/viewmodel/ArmsLicenseSharedViewModel;", "sharedViewModel$delegate", "Lkotlin/Lazy;", "_binding", "Lpk/gov/nadra/oneapp/arms/license/databinding/FragmentLicenseSupportingDocumentsBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/arms/license/databinding/FragmentLicenseSupportingDocumentsBinding;", "activity", "Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;)V", "supportingDocumentsAdapter", "Lpk/gov/nadra/oneapp/commonutils/adapter/SupportingDocumentsAdapter;", "supportingUploadedDocumentsAdapter", "Lpk/gov/nadra/oneapp/commonutils/adapter/SupportingUploadedDocumentsAdapter;", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "handleFragmentNavigationLogic", "galleryLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "handleUploadDocument", "filePath", "", "documentTypeId", "", "handleFailureCase", "jsonResponse", "Lcom/google/gson/JsonObject;", "responseCode", "uploadDocument", "image", "Lokhttp3/MultipartBody$Part;", "trackingId", "Lokhttp3/RequestBody;", "processPhotographSuccessResponse", "jSonObject", "getUploadedDocument", "processGetDocumentSuccessResponse", "deleteUploadedDocument", "documentId", "pageId", "processDeleteDocumentSuccessResponse", "downloadUploadedDocument", "processDownloadDocumentSuccessResponse", "writePhotoBase64Data", "photoBase64", "iwritePhotoBase64DataServiceResult", "Lpk/gov/nadra/oneapp/commonutils/utils/WritePhotoBase64Data$ICompressImageTaskListener;", "saveDocumentUploadStatus", "processDocumentUploadStatusSuccessResponse", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class LicenseSupportingDocumentsFragment extends Fragment {
    private FragmentLicenseSupportingDocumentsBinding _binding;
    public ArmsLicenseActivity activity;
    private final ActivityResultLauncher<Intent> galleryLauncher;
    private WritePhotoBase64Data.ICompressImageTaskListener iwritePhotoBase64DataServiceResult;

    /* renamed from: sharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy sharedViewModel;
    private SupportingDocumentsAdapter supportingDocumentsAdapter;
    private SupportingUploadedDocumentsAdapter supportingUploadedDocumentsAdapter;

    public LicenseSupportingDocumentsFragment() {
        final LicenseSupportingDocumentsFragment licenseSupportingDocumentsFragment = this;
        final Function0 function0 = null;
        this.sharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(licenseSupportingDocumentsFragment, Reflection.getOrCreateKotlinClass(ArmsLicenseSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = licenseSupportingDocumentsFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = licenseSupportingDocumentsFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = licenseSupportingDocumentsFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda1
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                LicenseSupportingDocumentsFragment.galleryLauncher$lambda$10(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.galleryLauncher = activityResultLauncherRegisterForActivityResult;
        this.iwritePhotoBase64DataServiceResult = new WritePhotoBase64Data.ICompressImageTaskListener() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$iwritePhotoBase64DataServiceResult$1
            @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
            public void onComplete(File compressed) {
                Intrinsics.checkNotNullParameter(compressed, "compressed");
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
                Intent intent = new Intent(this.this$0.getActivity(), (Class<?>) ViewDocumentActivity.class);
                intent.putExtra(Constant.TRACKING_ID, this.this$0.getSharedViewModel().getTrackingId());
                intent.putExtra(Constant.DOCUMENT_FILE_PATH, compressed.getAbsolutePath());
                this.this$0.startActivity(intent);
            }

            @Override // pk.gov.nadra.oneapp.commonutils.utils.WritePhotoBase64Data.ICompressImageTaskListener
            public void onError() {
                LoaderManager.INSTANCE.hideLoader(this.this$0.getActivity());
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final ArmsLicenseSharedViewModel getSharedViewModel() {
        return (ArmsLicenseSharedViewModel) this.sharedViewModel.getValue();
    }

    private final FragmentLicenseSupportingDocumentsBinding getBinding() {
        FragmentLicenseSupportingDocumentsBinding fragmentLicenseSupportingDocumentsBinding = this._binding;
        Intrinsics.checkNotNull(fragmentLicenseSupportingDocumentsBinding);
        return fragmentLicenseSupportingDocumentsBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final ArmsLicenseActivity getActivity() {
        ArmsLicenseActivity armsLicenseActivity = this.activity;
        if (armsLicenseActivity != null) {
            return armsLicenseActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(ArmsLicenseActivity armsLicenseActivity) {
        Intrinsics.checkNotNullParameter(armsLicenseActivity, "<set-?>");
        this.activity = armsLicenseActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity");
        setActivity((ArmsLicenseActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentLicenseSupportingDocumentsBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getActivity().showOrHideHeader(false);
        final FragmentLicenseSupportingDocumentsBinding binding = getBinding();
        binding.licenseHeaderLayout.iconHome.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$0(this.f$0, view2);
            }
        });
        binding.licenseHeaderLayout.textTitle.setText(getString(R.string.arms_license_header));
        binding.licenseHeaderLayout.textSubtitle.setText(Util.INSTANCE.capitalizeWords(getSharedViewModel().getAppType()));
        binding.licenseHeaderLayout.textSubtitle.setVisibility(0);
        binding.licenseHeaderLayout.tvHeaderTrackingId.setText(getSharedViewModel().getTrackingId());
        binding.licenseHeaderLayout.tvHeaderFee.setText(getString(R.string.license_fees, getSharedViewModel().getAmount()));
        binding.stepTitleHeadingLayout.tvStepTitleHeading.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), getString(pk.gov.nadra.oneapp.commonui.R.string.supporting_documents) + '\n', " (معاون دستاویزات) ", 0, false, 12, null));
        TextView textView = binding.documentsDetailsHeading.tvStepAction;
        Util util = Util.INSTANCE;
        ArmsLicenseActivity activity = getActivity();
        String string = getString(pk.gov.nadra.oneapp.commonui.R.string.required_document);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util, activity, string, " (ضروری دستاویزات) ", 0, false, 12, null));
        binding.documentsDetailsHeading.linearLayoutInfo.setVisibility(8);
        TextView textView2 = binding.uploadedDocumentsDetailsHeading.tvStepAction;
        Util util2 = Util.INSTANCE;
        ArmsLicenseActivity activity2 = getActivity();
        String string2 = getString(pk.gov.nadra.oneapp.commonui.R.string.uploaded_documents);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        textView2.setText(Util.setEnglishTextSpan$default(util2, activity2, string2, " (اپ لوڈ کی گئی دستاویزات) ", 0, false, 12, null));
        binding.stepTitleHeadingLayout.tvMandatoryField.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Mandatory Field", " (لازمی زمرے)", 0, false, 12, null));
        binding.documentsListTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Try Again", " دوبارہ کوشش کریں", 0, false, 12, null));
        binding.uploadedDocumentsDetailsHeading.linearLayoutInfo.setVisibility(8);
        binding.licenseHeaderLayout.iconBack.setVisibility(0);
        binding.licenseHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$1(this.f$0, view2);
            }
        });
        SupportingUploadedDocumentsAdapter supportingUploadedDocumentsAdapter = null;
        this.supportingDocumentsAdapter = new SupportingDocumentsAdapter(getActivity(), new SupportingDocuments(null, 1, null), new Function2() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$2(this.f$0, (SupportingDocuments.GroupDocument.GroupDocuments) obj, ((Integer) obj2).intValue());
            }
        });
        NonScrollExpandableListView nonScrollExpandableListView = binding.expandableListViewUploadedDocuments;
        SupportingDocumentsAdapter supportingDocumentsAdapter = this.supportingDocumentsAdapter;
        if (supportingDocumentsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("supportingDocumentsAdapter");
            supportingDocumentsAdapter = null;
        }
        nonScrollExpandableListView.setAdapter(supportingDocumentsAdapter);
        this.supportingUploadedDocumentsAdapter = new SupportingUploadedDocumentsAdapter(getActivity(), new ArrayList(), new Function2() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda9
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$4(this.f$0, (SupportingDocuments.GroupDocument.GroupDocuments) obj, ((Integer) obj2).intValue());
            }
        }, new Function2() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda10
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$5(this.f$0, (SupportingDocuments.GroupDocument.GroupDocuments) obj, ((Integer) obj2).intValue());
            }
        });
        NonScrollExpandableListView nonScrollExpandableListView2 = getBinding().supportingUploadedDocumentsRecyclerView;
        SupportingUploadedDocumentsAdapter supportingUploadedDocumentsAdapter2 = this.supportingUploadedDocumentsAdapter;
        if (supportingUploadedDocumentsAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("supportingUploadedDocumentsAdapter");
        } else {
            supportingUploadedDocumentsAdapter = supportingUploadedDocumentsAdapter2;
        }
        nonScrollExpandableListView2.setAdapter(supportingUploadedDocumentsAdapter);
        ConfigurableButton configurableButton = binding.startApplicationButtonLayout.commonButton;
        Util util3 = Util.INSTANCE;
        ArmsLicenseActivity activity3 = getActivity();
        String string3 = getString(pk.gov.nadra.oneapp.commonui.R.string.submit_application);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util3, activity3, string3, " (درخواست جمع کروائیں)", 0, false, 12, null));
        binding.startApplicationButtonLayout.commonButton.setFilled(true);
        binding.startApplicationButtonLayout.commonButton.setInsetTop(0);
        binding.startApplicationButtonLayout.commonButton.setInsetBottom(0);
        binding.startApplicationButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$6(this.f$0, view2);
            }
        });
        binding.documentsSwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda12
            @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
            public final void onRefresh() {
                LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$7(this.f$0, binding);
            }
        });
        getUploadedDocument();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$8$lambda$0(LicenseSupportingDocumentsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().handleHomeIconClick();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$8$lambda$1(LicenseSupportingDocumentsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().popupFromNavHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$8$lambda$2(LicenseSupportingDocumentsFragment this$0, SupportingDocuments.GroupDocument.GroupDocuments document, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(document, "document");
        Intent intent = new Intent(this$0.getActivity(), (Class<?>) DocumentActivity.class);
        intent.putExtra(Constant.TRACKING_ID, this$0.getSharedViewModel().getTrackingId());
        intent.putExtra(Constant.DOCUMENT_TYPE_ID, document.getId());
        intent.putExtra(Constant.DOCUMENT_TYPE_NAME, document.getValue());
        this$0.galleryLauncher.launch(intent);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$8$lambda$4(final LicenseSupportingDocumentsFragment this$0, final SupportingDocuments.GroupDocument.GroupDocuments document, final int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(document, "document");
        Util.INSTANCE.showConfirmationDialog(this$0.getActivity(), "Delete Document", "Are you sure you want to delete this document?", "کیا آپ واقعی یہ دستاویز حذف کرنا چاہتے ہیں؟", new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$4$lambda$3(this.f$0, document, i);
            }
        });
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$8$lambda$4$lambda$3(LicenseSupportingDocumentsFragment this$0, SupportingDocuments.GroupDocument.GroupDocuments document, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(document, "$document");
        this$0.deleteUploadedDocument(document.getId(), document.getSubList().get(i).getId());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$8$lambda$5(LicenseSupportingDocumentsFragment this$0, SupportingDocuments.GroupDocument.GroupDocuments document, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(document, "document");
        this$0.downloadUploadedDocument(document.getId(), document.getSubList().get(i).getId());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$8$lambda$6(LicenseSupportingDocumentsFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.saveDocumentUploadStatus();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onViewCreated$lambda$8$lambda$7(LicenseSupportingDocumentsFragment this$0, FragmentLicenseSupportingDocumentsBinding this_apply) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(this_apply, "$this_apply");
        this$0.getUploadedDocument();
        this_apply.documentsSwipeRefresh.setRefreshing(false);
    }

    private final void handleFragmentNavigationLogic() {
        getActivity().navigateToReactNativeInbox(Constant.GO_TO_INBOX);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void galleryLauncher$lambda$10(LicenseSupportingDocumentsFragment this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() != -1 || result.getData() == null) {
            return;
        }
        Intent data = result.getData();
        Intrinsics.checkNotNull(data);
        String stringExtra = data.getStringExtra(Constant.DOCUMENT_FILE_PATH);
        Intent data2 = result.getData();
        Intrinsics.checkNotNull(data2);
        int intExtra = data2.getIntExtra(Constant.DOCUMENT_TYPE_ID, -1);
        Intent data3 = result.getData();
        Intrinsics.checkNotNull(data3);
        data3.getStringExtra(Constant.DOCUMENT_TYPE_NAME);
        if (stringExtra != null) {
            this$0.handleUploadDocument(stringExtra, intExtra);
        }
    }

    private final void handleUploadDocument(String filePath, int documentTypeId) {
        File file = new File(filePath);
        uploadDocument(MultipartBody.Part.INSTANCE.createFormData("file", file.getName(), RequestBody.INSTANCE.create(file, MediaType.INSTANCE.parse("image/*"))), RequestBody.INSTANCE.create(getSharedViewModel().getTrackingId(), MediaType.INSTANCE.get("text/plain")), RequestBody.INSTANCE.create(String.valueOf(documentTypeId), MediaType.INSTANCE.get("application/octet-stream")));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) {
        ErrorResponse errorResponse = (ErrorResponse) new Gson().fromJson(jsonResponse.toString(), ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                errorResponse.getErrors();
                return;
            }
            NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
            ArmsLicenseActivity activity = getActivity();
            Intrinsics.checkNotNull(errorResponse);
            NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return LicenseSupportingDocumentsFragment.handleFailureCase$lambda$12(this.f$0);
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
        ArmsLicenseActivity activity2 = getActivity();
        Intrinsics.checkNotNull(errorResponse);
        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return LicenseSupportingDocumentsFragment.handleFailureCase$lambda$13(this.f$0);
            }
        }, 8, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$12(LicenseSupportingDocumentsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleFailureCase$lambda$13(LicenseSupportingDocumentsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_LOGIN);
        return Unit.INSTANCE;
    }

    /* compiled from: LicenseSupportingDocumentsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$uploadDocument$1", f = "LicenseSupportingDocumentsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$uploadDocument$1, reason: invalid class name and case insensitive filesystem */
    static final class C11081 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ RequestBody $documentTypeId;
        final /* synthetic */ MultipartBody.Part $image;
        final /* synthetic */ RequestBody $trackingId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C11081(MultipartBody.Part part, RequestBody requestBody, RequestBody requestBody2, Continuation<? super C11081> continuation) {
            super(2, continuation);
            this.$image = part;
            this.$trackingId = requestBody;
            this.$documentTypeId = requestBody2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return LicenseSupportingDocumentsFragment.this.new C11081(this.$image, this.$trackingId, this.$documentTypeId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11081) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(LicenseSupportingDocumentsFragment.this.getActivity());
            MultipartBody.Part part = this.$image;
            RequestBody requestBody = this.$trackingId;
            RequestBody requestBody2 = this.$documentTypeId;
            final LicenseSupportingDocumentsFragment licenseSupportingDocumentsFragment = LicenseSupportingDocumentsFragment.this;
            aPIRequests.uploadDocumentV2(part, requestBody, requestBody2, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$uploadDocument$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return LicenseSupportingDocumentsFragment.C11081.invokeSuspend$lambda$0(licenseSupportingDocumentsFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(LicenseSupportingDocumentsFragment licenseSupportingDocumentsFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(licenseSupportingDocumentsFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                licenseSupportingDocumentsFragment.processPhotographSuccessResponse(jsonObject);
            } else {
                licenseSupportingDocumentsFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void uploadDocument(MultipartBody.Part image, RequestBody trackingId, RequestBody documentTypeId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11081(image, trackingId, documentTypeId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processPhotographSuccessResponse(JsonObject jSonObject) {
        getUploadedDocument();
    }

    private final void getUploadedDocument() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11061(null), 3, null);
    }

    /* compiled from: LicenseSupportingDocumentsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$getUploadedDocument$1", f = "LicenseSupportingDocumentsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$getUploadedDocument$1, reason: invalid class name and case insensitive filesystem */
    static final class C11061 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C11061(Continuation<? super C11061> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return LicenseSupportingDocumentsFragment.this.new C11061(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11061) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(LicenseSupportingDocumentsFragment.this.getActivity());
            String trackingId = LicenseSupportingDocumentsFragment.this.getSharedViewModel().getTrackingId();
            final LicenseSupportingDocumentsFragment licenseSupportingDocumentsFragment = LicenseSupportingDocumentsFragment.this;
            aPIRequests.getSupportingDocumentsList(trackingId, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$getUploadedDocument$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return LicenseSupportingDocumentsFragment.C11061.invokeSuspend$lambda$0(licenseSupportingDocumentsFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(LicenseSupportingDocumentsFragment licenseSupportingDocumentsFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(licenseSupportingDocumentsFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                licenseSupportingDocumentsFragment.processGetDocumentSuccessResponse(jsonObject);
            } else {
                licenseSupportingDocumentsFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processGetDocumentSuccessResponse(JsonObject jSonObject) {
        SupportingDocuments supportingDocuments = (SupportingDocuments) new Gson().fromJson(jSonObject.toString(), SupportingDocuments.class);
        SupportingUploadedDocumentsAdapter supportingUploadedDocumentsAdapter = null;
        if (!supportingDocuments.getGroupDocuments().isEmpty()) {
            SupportingDocumentsAdapter supportingDocumentsAdapter = this.supportingDocumentsAdapter;
            if (supportingDocumentsAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("supportingDocumentsAdapter");
                supportingDocumentsAdapter = null;
            }
            Intrinsics.checkNotNull(supportingDocuments);
            supportingDocumentsAdapter.updateList(supportingDocuments);
            NonScrollExpandableListView nonScrollExpandableListView = getBinding().expandableListViewUploadedDocuments;
            SupportingDocumentsAdapter supportingDocumentsAdapter2 = this.supportingDocumentsAdapter;
            if (supportingDocumentsAdapter2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("supportingDocumentsAdapter");
                supportingDocumentsAdapter2 = null;
            }
            nonScrollExpandableListView.expandAllSupportingDocuments(supportingDocumentsAdapter2);
            List<SupportingDocuments.GroupDocument> groupDocuments = supportingDocuments.getGroupDocuments();
            ArrayList arrayList = new ArrayList();
            for (SupportingDocuments.GroupDocument groupDocument : groupDocuments) {
                List<SupportingDocuments.GroupDocument.GroupDocuments> groupDocumentsList = groupDocument.getGroupDocumentsList();
                ArrayList arrayList2 = new ArrayList();
                for (Object obj : groupDocumentsList) {
                    if (!((SupportingDocuments.GroupDocument.GroupDocuments) obj).getSubList().isEmpty()) {
                        arrayList2.add(obj);
                    }
                }
                ArrayList<SupportingDocuments.GroupDocument.GroupDocuments> arrayList3 = arrayList2;
                ArrayList arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList3, 10));
                for (SupportingDocuments.GroupDocument.GroupDocuments groupDocuments2 : arrayList3) {
                    arrayList4.add(new Pair(groupDocuments2.getValue() + " (" + groupDocument.getDisplayName() + ')', groupDocuments2));
                }
                CollectionsKt.addAll(arrayList, arrayList4);
            }
            ArrayList arrayList5 = arrayList;
            ArrayList arrayList6 = arrayList5;
            ArrayList arrayList7 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList6, 10));
            Iterator it = arrayList6.iterator();
            while (it.hasNext()) {
                arrayList7.add(((SupportingDocuments.GroupDocument.GroupDocuments) ((Pair) it.next()).getSecond()).getSubList());
            }
            if (CollectionsKt.flatten(arrayList7).isEmpty()) {
                getBinding().uploadedDocumentsDetailsHeading.getRoot().setVisibility(8);
                getBinding().supportingUploadedDocumentsRecyclerView.setVisibility(8);
                SupportingUploadedDocumentsAdapter supportingUploadedDocumentsAdapter2 = this.supportingUploadedDocumentsAdapter;
                if (supportingUploadedDocumentsAdapter2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("supportingUploadedDocumentsAdapter");
                } else {
                    supportingUploadedDocumentsAdapter = supportingUploadedDocumentsAdapter2;
                }
                supportingUploadedDocumentsAdapter.updateList(new ArrayList());
                return;
            }
            getBinding().uploadedDocumentsDetailsHeading.getRoot().setVisibility(0);
            getBinding().supportingUploadedDocumentsRecyclerView.setVisibility(0);
            SupportingUploadedDocumentsAdapter supportingUploadedDocumentsAdapter3 = this.supportingUploadedDocumentsAdapter;
            if (supportingUploadedDocumentsAdapter3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("supportingUploadedDocumentsAdapter");
            } else {
                supportingUploadedDocumentsAdapter = supportingUploadedDocumentsAdapter3;
            }
            supportingUploadedDocumentsAdapter.updateList(arrayList5);
            return;
        }
        SupportingDocumentsAdapter supportingDocumentsAdapter3 = this.supportingDocumentsAdapter;
        if (supportingDocumentsAdapter3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("supportingDocumentsAdapter");
            supportingDocumentsAdapter3 = null;
        }
        supportingDocumentsAdapter3.updateList(new SupportingDocuments(null, 1, null));
        getBinding().uploadedDocumentsDetailsHeading.getRoot().setVisibility(8);
        getBinding().supportingUploadedDocumentsRecyclerView.setVisibility(8);
        getBinding().documentsListTryAgainLayout.setVisibility(0);
        getBinding().documentsListTryAgainImageView.setImageResource(pk.gov.nadra.oneapp.commonutils.R.drawable.ic_documents);
        getBinding().documentsListTryAgainTextView.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "There is nothing here...yet!", "\n (یہاں کچھ بھی نہیں ہے... ابھی تک!)", 0, false, 12, null));
    }

    /* compiled from: LicenseSupportingDocumentsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$deleteUploadedDocument$1", f = "LicenseSupportingDocumentsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$deleteUploadedDocument$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ int $documentId;
        final /* synthetic */ int $pageId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(int i, int i2, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$documentId = i;
            this.$pageId = i2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return LicenseSupportingDocumentsFragment.this.new AnonymousClass1(this.$documentId, this.$pageId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(LicenseSupportingDocumentsFragment.this.getActivity());
            String trackingId = LicenseSupportingDocumentsFragment.this.getSharedViewModel().getTrackingId();
            int i = this.$documentId;
            int i2 = this.$pageId;
            final LicenseSupportingDocumentsFragment licenseSupportingDocumentsFragment = LicenseSupportingDocumentsFragment.this;
            aPIRequests.deleteDocumentV2(trackingId, i, i2, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$deleteUploadedDocument$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return LicenseSupportingDocumentsFragment.AnonymousClass1.invokeSuspend$lambda$0(licenseSupportingDocumentsFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(LicenseSupportingDocumentsFragment licenseSupportingDocumentsFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(licenseSupportingDocumentsFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                licenseSupportingDocumentsFragment.processDeleteDocumentSuccessResponse(jsonObject);
            } else {
                licenseSupportingDocumentsFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void deleteUploadedDocument(int documentId, int pageId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(documentId, pageId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processDeleteDocumentSuccessResponse(JsonObject jSonObject) {
        getUploadedDocument();
    }

    /* compiled from: LicenseSupportingDocumentsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$downloadUploadedDocument$1", f = "LicenseSupportingDocumentsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$downloadUploadedDocument$1, reason: invalid class name and case insensitive filesystem */
    static final class C11051 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ int $documentId;
        final /* synthetic */ int $pageId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C11051(int i, int i2, Continuation<? super C11051> continuation) {
            super(2, continuation);
            this.$documentId = i;
            this.$pageId = i2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return LicenseSupportingDocumentsFragment.this.new C11051(this.$documentId, this.$pageId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11051) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(LicenseSupportingDocumentsFragment.this.getActivity());
            String trackingId = LicenseSupportingDocumentsFragment.this.getSharedViewModel().getTrackingId();
            int i = this.$documentId;
            int i2 = this.$pageId;
            final LicenseSupportingDocumentsFragment licenseSupportingDocumentsFragment = LicenseSupportingDocumentsFragment.this;
            aPIRequests.downloadDocumentV2(trackingId, i, i2, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$downloadUploadedDocument$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return LicenseSupportingDocumentsFragment.C11051.invokeSuspend$lambda$0(licenseSupportingDocumentsFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(LicenseSupportingDocumentsFragment licenseSupportingDocumentsFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(licenseSupportingDocumentsFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                licenseSupportingDocumentsFragment.processDownloadDocumentSuccessResponse(jsonObject);
            } else {
                licenseSupportingDocumentsFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void downloadUploadedDocument(int documentId, int pageId) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11051(documentId, pageId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processDownloadDocumentSuccessResponse(JsonObject jSonObject) {
        writePhotoBase64Data(((DownloadDocumentResponse) new Gson().fromJson(jSonObject.toString(), DownloadDocumentResponse.class)).getDocumentBase64());
    }

    private final void writePhotoBase64Data(String photoBase64) {
        File fileCreatePhotoFile;
        try {
            fileCreatePhotoFile = Util.INSTANCE.createPhotoFile(getActivity());
        } catch (Exception e) {
            e.printStackTrace();
            fileCreatePhotoFile = null;
        }
        if (fileCreatePhotoFile == null) {
            return;
        }
        LoaderManager.INSTANCE.showLoader(getActivity());
        new WritePhotoBase64Data(getActivity(), this.iwritePhotoBase64DataServiceResult).execute(new Object[]{photoBase64, fileCreatePhotoFile});
    }

    /* compiled from: LicenseSupportingDocumentsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$saveDocumentUploadStatus$1", f = "LicenseSupportingDocumentsFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$saveDocumentUploadStatus$1, reason: invalid class name and case insensitive filesystem */
    static final class C11071 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Ref.ObjectRef<TabUpdateRequest> $tabUpdateRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C11071(Ref.ObjectRef<TabUpdateRequest> objectRef, Continuation<? super C11071> continuation) {
            super(2, continuation);
            this.$tabUpdateRequest = objectRef;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return LicenseSupportingDocumentsFragment.this.new C11071(this.$tabUpdateRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11071) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            LoaderManager.INSTANCE.showLoader(LicenseSupportingDocumentsFragment.this.getActivity());
            APIRequests aPIRequests = new APIRequests(LicenseSupportingDocumentsFragment.this.getActivity());
            TabUpdateRequest tabUpdateRequest = this.$tabUpdateRequest.element;
            final LicenseSupportingDocumentsFragment licenseSupportingDocumentsFragment = LicenseSupportingDocumentsFragment.this;
            aPIRequests.applicationFormSubmissionV2(tabUpdateRequest, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$saveDocumentUploadStatus$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return LicenseSupportingDocumentsFragment.C11071.invokeSuspend$lambda$0(licenseSupportingDocumentsFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(LicenseSupportingDocumentsFragment licenseSupportingDocumentsFragment, JsonObject jsonObject, String str, int i) {
            LoaderManager.INSTANCE.hideLoader(licenseSupportingDocumentsFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                licenseSupportingDocumentsFragment.processDocumentUploadStatusSuccessResponse(jsonObject);
            } else {
                licenseSupportingDocumentsFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [T, pk.gov.nadra.oneapp.models.crc.TabUpdateRequest] */
    private final void saveDocumentUploadStatus() {
        Ref.ObjectRef objectRef = new Ref.ObjectRef();
        objectRef.element = new TabUpdateRequest(getSharedViewModel().getTrackingId(), null, 2, null);
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11071(objectRef, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processDocumentUploadStatusSuccessResponse(JsonObject jSonObject) {
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        ArmsLicenseActivity activity = getActivity();
        String string = getString(R.string.submission_title);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = getString(R.string.submission_success_message);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        bottomSheetUtils.showMessageBottomSheet((FragmentActivity) activity, string, string2, true, (CharSequence) "Confirm", true, "آپ کی درخواست کامیابی سے جمع ہو گئی ہے۔ درخواست کی منظوری کے بعد آپ کو فیس کی ادائیگی کے لیے مطلع کیا جائے گا۔ درخواست پہ کاروائی کے دوران ضرورت پڑنے پرہمارا نمائندہ آپ سے رابطہ کر سکتا ہے۔", new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return LicenseSupportingDocumentsFragment.processDocumentUploadStatusSuccessResponse$lambda$20(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return LicenseSupportingDocumentsFragment.processDocumentUploadStatusSuccessResponse$lambda$21(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processDocumentUploadStatusSuccessResponse$lambda$20(LicenseSupportingDocumentsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.handleFragmentNavigationLogic();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processDocumentUploadStatusSuccessResponse$lambda$21(LicenseSupportingDocumentsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.handleFragmentNavigationLogic();
        return Unit.INSTANCE;
    }
}