package pk.gov.nadra.oneapp.arms.license.fragments;

import kotlin.jvm.functions.Function1;
import pk.gov.nadra.oneapp.arms.license.models.LicenseProductResponse;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class LicenseListFragment$$ExternalSyntheticLambda0 implements Function1 {
    public /* synthetic */ LicenseListFragment$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return LicenseListFragment.onViewCreated$lambda$0(this.f$0, (LicenseProductResponse.LicenseProduct) obj);
    }
}