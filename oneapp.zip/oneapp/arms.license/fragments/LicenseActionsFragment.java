package pk.gov.nadra.oneapp.arms.license.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import pk.gov.nadra.oneapp.arms.license.R;
import pk.gov.nadra.oneapp.arms.license.adapters.LicenseActionsAdapter;
import pk.gov.nadra.oneapp.arms.license.databinding.FragmentLicenseActionsBinding;
import pk.gov.nadra.oneapp.arms.license.models.LicenseActionModel;
import pk.gov.nadra.oneapp.arms.license.models.LicenseProductResponse;
import pk.gov.nadra.oneapp.arms.license.viewmodel.ArmsLicenseSharedViewModel;
import pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity;

/* compiled from: LicenseActionsFragment.kt */
@Metadata(d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\"H\u0016J$\u0010#\u001a\u00020$2\u0006\u0010%\u001a\u00020&2\b\u0010'\u001a\u0004\u0018\u00010(2\b\u0010)\u001a\u0004\u0018\u00010*H\u0016J\u001a\u0010+\u001a\u00020 2\u0006\u0010,\u001a\u00020$2\b\u0010)\u001a\u0004\u0018\u00010*H\u0016J\b\u0010-\u001a\u00020 H\u0002J\b\u0010.\u001a\u00020 H\u0002J\u0010\u0010/\u001a\u00020 2\u0006\u00100\u001a\u000201H\u0002J\b\u00102\u001a\u00020 H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\nX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u000e\u0010\u000f\u001a\u00020\u0010X\u0082.¢\u0006\u0002\n\u0000R\u001b\u0010\u0011\u001a\u00020\u00128BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u0015\u0010\u0016\u001a\u0004\b\u0013\u0010\u0014R\u0014\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00190\u0018X\u0082\u0004¢\u0006\u0002\n\u0000R!\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00190\u001b8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u001e\u0010\u0016\u001a\u0004\b\u001c\u0010\u001d¨\u00063"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/fragments/LicenseActionsFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lpk/gov/nadra/oneapp/arms/license/databinding/FragmentLicenseActionsBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/arms/license/databinding/FragmentLicenseActionsBinding;", "activity", "Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;)V", "adapter", "Lpk/gov/nadra/oneapp/arms/license/adapters/LicenseActionsAdapter;", "sharedViewModel", "Lpk/gov/nadra/oneapp/arms/license/viewmodel/ArmsLicenseSharedViewModel;", "getSharedViewModel", "()Lpk/gov/nadra/oneapp/arms/license/viewmodel/ArmsLicenseSharedViewModel;", "sharedViewModel$delegate", "Lkotlin/Lazy;", FirebaseAnalytics.Param.ITEMS, "", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseActionModel;", "originalItems", "", "getOriginalItems", "()Ljava/util/List;", "originalItems$delegate", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "filterActionsBasedOnLicense", "openTokenGenerationFragment", "handleClick", "title", "", "onDestroyView", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class LicenseActionsFragment extends Fragment {
    private FragmentLicenseActionsBinding _binding;
    public ArmsLicenseActivity activity;
    private LicenseActionsAdapter adapter;
    private final List<LicenseActionModel> items = new ArrayList();

    /* renamed from: originalItems$delegate, reason: from kotlin metadata */
    private final Lazy originalItems = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseActionsFragment$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return LicenseActionsFragment.originalItems_delegate$lambda$0(this.f$0);
        }
    });

    /* renamed from: sharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy sharedViewModel;

    public LicenseActionsFragment() {
        final LicenseActionsFragment licenseActionsFragment = this;
        final Function0 function0 = null;
        this.sharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(licenseActionsFragment, Reflection.getOrCreateKotlinClass(ArmsLicenseSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseActionsFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = licenseActionsFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseActionsFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = licenseActionsFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseActionsFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = licenseActionsFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
    }

    private final FragmentLicenseActionsBinding getBinding() {
        FragmentLicenseActionsBinding fragmentLicenseActionsBinding = this._binding;
        Intrinsics.checkNotNull(fragmentLicenseActionsBinding);
        return fragmentLicenseActionsBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public final ArmsLicenseActivity getActivity() {
        ArmsLicenseActivity armsLicenseActivity = this.activity;
        if (armsLicenseActivity != null) {
            return armsLicenseActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(ArmsLicenseActivity armsLicenseActivity) {
        Intrinsics.checkNotNullParameter(armsLicenseActivity, "<set-?>");
        this.activity = armsLicenseActivity;
    }

    private final ArmsLicenseSharedViewModel getSharedViewModel() {
        return (ArmsLicenseSharedViewModel) this.sharedViewModel.getValue();
    }

    private final List<LicenseActionModel> getOriginalItems() {
        return (List) this.originalItems.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final List originalItems_delegate$lambda$0(LicenseActionsFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        int i = R.drawable.license_action_renew;
        String string = this$0.getString(R.string.license_action_renew);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = this$0.getString(R.string.license_action_renew_desc);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        int i2 = R.drawable.license_action_modification;
        String string3 = this$0.getString(R.string.license_action_modification);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        String string4 = this$0.getString(R.string.license_action_modification_desc);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        int i3 = R.drawable.license_action_inheritance;
        String string5 = this$0.getString(R.string.license_action_inheritance);
        Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
        String string6 = this$0.getString(R.string.license_action_inheritance_desc);
        Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
        int i4 = R.drawable.license_action_reprint;
        String string7 = this$0.getString(R.string.license_action_reprint);
        Intrinsics.checkNotNullExpressionValue(string7, "getString(...)");
        String string8 = this$0.getString(R.string.license_action_reprint_desc);
        Intrinsics.checkNotNullExpressionValue(string8, "getString(...)");
        int i5 = R.drawable.license_action_transfer;
        String string9 = this$0.getString(R.string.license_action_transfer);
        Intrinsics.checkNotNullExpressionValue(string9, "getString(...)");
        String string10 = this$0.getString(R.string.license_action_transfer_desc);
        Intrinsics.checkNotNullExpressionValue(string10, "getString(...)");
        int i6 = R.drawable.license_action_cancellation;
        String string11 = this$0.getString(R.string.license_action_cancellation);
        Intrinsics.checkNotNullExpressionValue(string11, "getString(...)");
        String string12 = this$0.getString(R.string.license_action_cancellation_desc);
        Intrinsics.checkNotNullExpressionValue(string12, "getString(...)");
        return CollectionsKt.listOf((Object[]) new LicenseActionModel[]{new LicenseActionModel(i, string, string2), new LicenseActionModel(i2, string3, string4), new LicenseActionModel(i3, string5, string6), new LicenseActionModel(i4, string7, string8), new LicenseActionModel(i5, string9, string10), new LicenseActionModel(i6, string11, string12)});
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity");
        setActivity((ArmsLicenseActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentLicenseActionsBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getBinding().rvLicenseActions.setLayoutManager(new GridLayoutManager(requireContext(), 2));
        this.adapter = new LicenseActionsAdapter(this.items, new Function1() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.LicenseActionsFragment$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LicenseActionsFragment.onViewCreated$lambda$1(this.f$0, (LicenseActionModel) obj);
            }
        });
        RecyclerView recyclerView = getBinding().rvLicenseActions;
        LicenseActionsAdapter licenseActionsAdapter = this.adapter;
        if (licenseActionsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
            licenseActionsAdapter = null;
        }
        recyclerView.setAdapter(licenseActionsAdapter);
        this.items.clear();
        filterActionsBasedOnLicense();
        getActivity().hideSubTitle();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onViewCreated$lambda$1(LicenseActionsFragment this$0, LicenseActionModel selectedAction) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(selectedAction, "selectedAction");
        this$0.handleClick(selectedAction.getTitle());
        return Unit.INSTANCE;
    }

    private final void filterActionsBasedOnLicense() {
        LicenseProductResponse.LicenseProduct selectedLicenseProduct = getSharedViewModel().getSelectedLicenseProduct();
        Map mapMapOf = MapsKt.mapOf(TuplesKt.to(getString(R.string.license_action_renew), Boolean.valueOf(selectedLicenseProduct.getRenewalP())), TuplesKt.to(getString(R.string.license_action_modification), Boolean.valueOf(selectedLicenseProduct.getModificationP())), TuplesKt.to(getString(R.string.license_action_inheritance), Boolean.valueOf(selectedLicenseProduct.getInheritanceP())), TuplesKt.to(getString(R.string.license_action_reprint), Boolean.valueOf(selectedLicenseProduct.getReprintP())), TuplesKt.to(getString(R.string.license_action_transfer), Boolean.valueOf(selectedLicenseProduct.getTransferP())), TuplesKt.to(getString(R.string.license_action_cancellation), Boolean.valueOf(selectedLicenseProduct.getCancellationP())));
        this.items.clear();
        List<LicenseActionModel> list = this.items;
        List<LicenseActionModel> originalItems = getOriginalItems();
        ArrayList arrayList = new ArrayList();
        for (Object obj : originalItems) {
            if (Intrinsics.areEqual(mapMapOf.get(((LicenseActionModel) obj).getTitle()), (Object) true)) {
                arrayList.add(obj);
            }
        }
        list.addAll(arrayList);
        LicenseActionsAdapter licenseActionsAdapter = this.adapter;
        if (licenseActionsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
            licenseActionsAdapter = null;
        }
        licenseActionsAdapter.notifyDataSetChanged();
    }

    private final void openTokenGenerationFragment() {
        getActivity().navigateToFragment(R.id.licenseTokenGenerationFragment);
    }

    private final void handleClick(String title) {
        getSharedViewModel().setSelectedLicenseAction(title);
        if (Intrinsics.areEqual(title, getString(R.string.license_action_renew))) {
            getSharedViewModel().setAppType("renewal");
            getSharedViewModel().setSelectedLicenseAction(title);
            openTokenGenerationFragment();
        } else if (Intrinsics.areEqual(title, getString(R.string.license_action_reprint))) {
            getSharedViewModel().setAppType("reprint");
            getSharedViewModel().setSelectedLicenseAction(title);
            openTokenGenerationFragment();
        } else {
            if (Intrinsics.areEqual(title, getString(R.string.license_action_modification)) || Intrinsics.areEqual(title, getString(R.string.license_action_inheritance)) || Intrinsics.areEqual(title, getString(R.string.license_action_transfer))) {
                return;
            }
            Intrinsics.areEqual(title, getString(R.string.license_action_cancellation));
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}