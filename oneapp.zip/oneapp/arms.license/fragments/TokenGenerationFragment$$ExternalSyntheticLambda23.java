package pk.gov.nadra.oneapp.arms.license.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class TokenGenerationFragment$$ExternalSyntheticLambda23 implements View.OnClickListener {
    public /* synthetic */ TokenGenerationFragment$$ExternalSyntheticLambda23() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        TokenGenerationFragment.attachLayoutViews$lambda$2(this.f$0, view);
    }
}