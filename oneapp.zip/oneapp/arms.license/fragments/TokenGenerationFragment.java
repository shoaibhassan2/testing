package pk.gov.nadra.oneapp.arms.license.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.farrakhj.stringpickerlibrary.views.StringPickerActivity;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import org.apache.commons.lang3.StringUtils;
import pk.gov.nadra.oneapp.arms.license.databinding.FragmentTokenGenerationBinding;
import pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment;
import pk.gov.nadra.oneapp.arms.license.models.ARMSLICENSETokenRequest;
import pk.gov.nadra.oneapp.arms.license.models.ARMSLICENSETokenResponse;
import pk.gov.nadra.oneapp.arms.license.models.DeliveryCentersRequestModel;
import pk.gov.nadra.oneapp.arms.license.models.LicenseDeliveryCenterResponse;
import pk.gov.nadra.oneapp.arms.license.models.LicenseFeeRequestModel;
import pk.gov.nadra.oneapp.arms.license.models.LicenseFeeResponse;
import pk.gov.nadra.oneapp.arms.license.models.LicenseValidationRequestModel;
import pk.gov.nadra.oneapp.arms.license.network.utils.JsonParserHelper;
import pk.gov.nadra.oneapp.arms.license.utils.MethodName;
import pk.gov.nadra.oneapp.arms.license.viewmodel.ArmsLicenseSharedViewModel;
import pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity;
import pk.gov.nadra.oneapp.commonui.CnicMaskWatcher;
import pk.gov.nadra.oneapp.commonui.ConfigurableButton;
import pk.gov.nadra.oneapp.commonui.R;
import pk.gov.nadra.oneapp.commonutils.fingerprint.FingerprintScanSelectionActivityUnikrew;
import pk.gov.nadra.oneapp.commonutils.preferences.AppPreferences;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.FingerIndexEnum;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.NetworkErrorHandler;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.models.crc.ErrorResponse;
import pk.gov.nadra.oneapp.models.crc.fingerprint.FingerPreference;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintRequest;
import pk.gov.nadra.oneapp.models.crc.fingerprint.VerifyFingerprintResponse;
import pk.gov.nadra.oneapp.network.retrofit.APIRequests;

/* compiled from: TokenGenerationFragment.kt */
@Metadata(d1 = {"\u0000Æ\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010*\u001a\u00020+2\u0006\u0010,\u001a\u00020-H\u0016J$\u0010.\u001a\u00020/2\u0006\u00100\u001a\u0002012\b\u00102\u001a\u0004\u0018\u0001032\b\u00104\u001a\u0004\u0018\u000105H\u0016J\u001a\u00106\u001a\u00020+2\u0006\u00107\u001a\u00020/2\b\u00104\u001a\u0004\u0018\u000105H\u0016J\b\u00108\u001a\u00020+H\u0002J\b\u00109\u001a\u00020+H\u0002J\b\u0010:\u001a\u00020+H\u0002J\u0006\u0010;\u001a\u00020+J\b\u0010<\u001a\u00020+H\u0002J\b\u0010=\u001a\u00020+H\u0002J\b\u0010B\u001a\u00020+H\u0002J\u0010\u0010C\u001a\u00020+2\u0006\u0010D\u001a\u00020EH\u0002J\u0010\u0010F\u001a\u00020+2\u0006\u0010G\u001a\u00020HH\u0002J\u0018\u0010I\u001a\u00020+2\u0006\u0010J\u001a\u00020H2\u0006\u0010K\u001a\u00020\u001eH\u0002J\b\u0010L\u001a\u00020+H\u0002J\b\u0010M\u001a\u00020+H\u0002J\b\u0010N\u001a\u00020+H\u0002J\u0010\u0010O\u001a\u00020+2\u0006\u0010G\u001a\u00020HH\u0002J\u0010\u0010P\u001a\u00020+2\u0006\u0010Q\u001a\u00020%H\u0002J\u0010\u0010R\u001a\u00020+2\u0006\u0010Q\u001a\u00020%H\u0002J\b\u0010S\u001a\u00020TH\u0002J\b\u0010U\u001a\u00020VH\u0002J\b\u0010W\u001a\u00020+H\u0002J\u001f\u0010X\u001a\u00020+2\u0006\u0010Y\u001a\u00020H2\b\u0010K\u001a\u0004\u0018\u00010\u001eH\u0002¢\u0006\u0002\u0010ZJ%\u0010[\u001a\u00020+2\u0016\u0010\\\u001a\u0012\u0012\u0004\u0012\u00020%0\u001aj\b\u0012\u0004\u0012\u00020%`\u0018H\u0002¢\u0006\u0002\u0010]J\b\u0010_\u001a\u00020`H\u0002J\b\u0010a\u001a\u00020+H\u0002J\u0018\u0010b\u001a\u00020+2\u0006\u0010Y\u001a\u00020H2\u0006\u0010K\u001a\u00020\u001eH\u0002J\b\u0010c\u001a\u00020+H\u0002J\b\u0010d\u001a\u00020eH\u0002J\b\u0010f\u001a\u00020+H\u0002J\u0018\u0010g\u001a\u00020+2\u0006\u0010Y\u001a\u00020H2\u0006\u0010K\u001a\u00020\u001eH\u0002J3\u0010h\u001a\u00020+2\b\u0010i\u001a\u0004\u0018\u00010j2\b\u0010K\u001a\u0004\u0018\u00010\u001e2\u0010\b\u0002\u0010k\u001a\n\u0012\u0004\u0012\u00020+\u0018\u00010lH\u0002¢\u0006\u0002\u0010mJ\b\u0010n\u001a\u00020+H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u001b\u0010\t\u001a\u00020\n8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\r\u0010\u000e\u001a\u0004\b\u000b\u0010\fR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\u0017\u001a\u0012\u0012\u0004\u0012\u00020\u00190\u001aj\b\u0012\u0004\u0012\u00020\u0019`\u0018X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u001bR\u0010\u0010\u001c\u001a\u0004\u0018\u00010\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\u001d\u001a\u0012\u0012\u0004\u0012\u00020\u001e0\u001aj\b\u0012\u0004\u0012\u00020\u001e`\u0018X\u0082.¢\u0006\u0004\n\u0002\u0010\u001bR\u0012\u0010\u001f\u001a\u0004\u0018\u00010\u001eX\u0082\u000e¢\u0006\u0004\n\u0002\u0010 R\u000e\u0010!\u001a\u00020\"X\u0082\u000e¢\u0006\u0002\n\u0000R'\u0010#\u001a\u000e\u0012\u0004\u0012\u00020%\u0012\u0004\u0012\u00020&0$8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b)\u0010\u000e\u001a\u0004\b'\u0010(R\u001c\u0010>\u001a\u0010\u0012\f\u0012\n A*\u0004\u0018\u00010@0@0?X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010^\u001a\u0010\u0012\f\u0012\n A*\u0004\u0018\u00010@0@0?X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006o"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/fragments/TokenGenerationFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lpk/gov/nadra/oneapp/arms/license/databinding/FragmentTokenGenerationBinding;", "binding", "getBinding", "()Lpk/gov/nadra/oneapp/arms/license/databinding/FragmentTokenGenerationBinding;", "sharedViewModel", "Lpk/gov/nadra/oneapp/arms/license/viewmodel/ArmsLicenseSharedViewModel;", "getSharedViewModel", "()Lpk/gov/nadra/oneapp/arms/license/viewmodel/ArmsLicenseSharedViewModel;", "sharedViewModel$delegate", "Lkotlin/Lazy;", "activity", "Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;", "getActivity", "()Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;", "setActivity", "(Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;)V", "dropdownCalling", "Lpk/gov/nadra/oneapp/arms/license/utils/MethodName;", "deliveryCentersList", "Lkotlin/collections/ArrayList;", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseDeliveryCenterResponse;", "Ljava/util/ArrayList;", "Ljava/util/ArrayList;", "selectedDeliveryCenter", "validationYearsList", "", "selectedValidationYear", "Ljava/lang/Integer;", "verifyFingerprintResponse", "Lpk/gov/nadra/oneapp/models/crc/fingerprint/VerifyFingerprintResponse;", "fieldToViewMap", "", "", "Lcom/google/android/material/textfield/TextInputLayout;", "getFieldToViewMap", "()Ljava/util/Map;", "fieldToViewMap$delegate", "onAttach", "", "context", "Landroid/content/Context;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", Promotion.ACTION_VIEW, "attachLayoutViews", "initViews", "showRemainingViews", "initWeaponData", "setupClickListeners", "launchFingerprintActivity", "fingerprintLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "handleCaptureSuccess", "verifyApplicantFingerprint", "verifyFingerprintRequest", "Lpk/gov/nadra/oneapp/models/crc/fingerprint/VerifyFingerprintRequest;", "processVerifyApplicantSuccessResponse", "jSonObject", "Lcom/google/gson/JsonObject;", "handleFailureCase", "jsonResponse", "responseCode", "processStartApplicationButtonClickAction", "generateArmsLicenseRenewalToken", "generateArmsLicenseReprintToken", "processTIDDataUpdationSuccessResponse", "handleReprintFlow", "trackingId", "handleRenewalFlow", "getTIDDataUpdationRequest", "Lpk/gov/nadra/oneapp/arms/license/models/ARMSLICENSETokenRequest;", "getDeliveryCentersRequest", "Lpk/gov/nadra/oneapp/arms/license/models/DeliveryCentersRequestModel;", "getLicenseDeliveryCenters", "processDeliveryCentersResponse", "jsonObject", "(Lcom/google/gson/JsonObject;Ljava/lang/Integer;)V", "launchStringPicker", FirebaseAnalytics.Param.ITEMS, "(Ljava/util/ArrayList;)V", "startForResult", "getLicenseValidationRequest", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseValidationRequestModel;", "getCardValidationYears", "processValidationYearsResponse", "checkAndCallProcessingFeeAPI", "getLicenseFeeRequest", "Lpk/gov/nadra/oneapp/arms/license/models/LicenseFeeRequestModel;", "callProcessingFeeAPI", "processLicenseFeeSummaryResponse", "handleArmsLicenseFailureCase", "error", "", "retryAction", "Lkotlin/Function0;", "(Ljava/lang/Object;Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)V", "onDestroyView", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class TokenGenerationFragment extends Fragment {
    private FragmentTokenGenerationBinding _binding;
    public ArmsLicenseActivity activity;
    private final ActivityResultLauncher<Intent> fingerprintLauncher;
    private LicenseDeliveryCenterResponse selectedDeliveryCenter;

    /* renamed from: sharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy sharedViewModel;
    private final ActivityResultLauncher<Intent> startForResult;
    private ArrayList<Integer> validationYearsList;
    private MethodName dropdownCalling = MethodName.CENTER;
    private ArrayList<LicenseDeliveryCenterResponse> deliveryCentersList = new ArrayList<>();
    private Integer selectedValidationYear = 0;
    private VerifyFingerprintResponse verifyFingerprintResponse = new VerifyFingerprintResponse(null, false, false, null, null, false, null, null, null, null, null, null, null, false, null, null, 65535, null);

    /* renamed from: fieldToViewMap$delegate, reason: from kotlin metadata */
    private final Lazy fieldToViewMap = LazyKt.lazy(new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda13
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return TokenGenerationFragment.fieldToViewMap_delegate$lambda$0(this.f$0);
        }
    });

    /* compiled from: TokenGenerationFragment.kt */
    @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[MethodName.values().length];
            try {
                iArr[MethodName.CENTER.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[MethodName.VALIDATION.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public TokenGenerationFragment() {
        final TokenGenerationFragment tokenGenerationFragment = this;
        final Function0 function0 = null;
        this.sharedViewModel = FragmentViewModelLazyKt.createViewModelLazy(tokenGenerationFragment, Reflection.getOrCreateKotlinClass(ArmsLicenseSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$special$$inlined$activityViewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = tokenGenerationFragment.requireActivity().getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$special$$inlined$activityViewModels$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                if (function02 != null && (creationExtras = (CreationExtras) function02.invoke()) != null) {
                    return creationExtras;
                }
                CreationExtras defaultViewModelCreationExtras = tokenGenerationFragment.requireActivity().getDefaultViewModelCreationExtras();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelCreationExtras, "requireActivity().defaultViewModelCreationExtras");
                return defaultViewModelCreationExtras;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$special$$inlined$activityViewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory = tokenGenerationFragment.requireActivity().getDefaultViewModelProviderFactory();
                Intrinsics.checkNotNullExpressionValue(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
            }
        });
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda14
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) throws JsonSyntaxException {
                TokenGenerationFragment.fingerprintLauncher$lambda$9(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.fingerprintLauncher = activityResultLauncherRegisterForActivityResult;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult2 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda15
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                TokenGenerationFragment.startForResult$lambda$31(this.f$0, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult2, "registerForActivityResult(...)");
        this.startForResult = activityResultLauncherRegisterForActivityResult2;
    }

    private final FragmentTokenGenerationBinding getBinding() {
        FragmentTokenGenerationBinding fragmentTokenGenerationBinding = this._binding;
        Intrinsics.checkNotNull(fragmentTokenGenerationBinding);
        return fragmentTokenGenerationBinding;
    }

    private final ArmsLicenseSharedViewModel getSharedViewModel() {
        return (ArmsLicenseSharedViewModel) this.sharedViewModel.getValue();
    }

    @Override // androidx.fragment.app.Fragment
    public final ArmsLicenseActivity getActivity() {
        ArmsLicenseActivity armsLicenseActivity = this.activity;
        if (armsLicenseActivity != null) {
            return armsLicenseActivity;
        }
        Intrinsics.throwUninitializedPropertyAccessException("activity");
        return null;
    }

    public final void setActivity(ArmsLicenseActivity armsLicenseActivity) {
        Intrinsics.checkNotNullParameter(armsLicenseActivity, "<set-?>");
        this.activity = armsLicenseActivity;
    }

    private final Map<String, TextInputLayout> getFieldToViewMap() {
        return (Map) this.fieldToViewMap.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Map fieldToViewMap_delegate$lambda$0(TokenGenerationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        return MapsKt.mapOf(TuplesKt.to("citizenNumber", this$0.getBinding().applicantCnicLayout.maskedCnicTextInputLayout));
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        super.onAttach(context);
        FragmentActivity fragmentActivityRequireActivity = requireActivity();
        Intrinsics.checkNotNull(fragmentActivityRequireActivity, "null cannot be cast to non-null type pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity");
        setActivity((ArmsLicenseActivity) fragmentActivityRequireActivity);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentTokenGenerationBinding.inflate(inflater, container, false);
        ScrollView root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        attachLayoutViews();
    }

    private final void attachLayoutViews() {
        getActivity().showSubTitle();
        TextView textView = getBinding().applicationDetailHeadingLayout.tvStepAction;
        Util util = Util.INSTANCE;
        ArmsLicenseActivity activity = getActivity();
        String string = getString(R.string.application_details);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        textView.setText(Util.setEnglishTextSpan$default(util, activity, string, " (درخواست کی تفصیلات)", 0, false, 12, null));
        getBinding().applicationDetailHeadingLayout.linearLayoutInfo.setVisibility(4);
        TextInputEditText textInputEditText = getBinding().applicantCnicLayout.maskedCnicEditText;
        textInputEditText.addTextChangedListener(new CnicMaskWatcher("#####-#######-#"));
        textInputEditText.setText(getSharedViewModel().getReactNativeData().getCitizenNumber());
        textInputEditText.setFocusable(false);
        textInputEditText.setClickable(false);
        textInputEditText.setFocusableInTouchMode(false);
        textInputEditText.setEnabled(false);
        textInputEditText.setBackgroundTintList(ColorStateList.valueOf(getActivity().getResources().getColor(R.color.card_background_color)));
        ConfigurableButton configurableButton = getBinding().verifyApplicantFingerprintButtonLayout.commonButton;
        Util util2 = Util.INSTANCE;
        ArmsLicenseActivity activity2 = getActivity();
        String string2 = getString(pk.gov.nadra.oneapp.arms.license.R.string.verify_fingerprints_button);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        configurableButton.setText(Util.setEnglishTextSpan$default(util2, activity2, string2, " (انگلیوں کے نشانات کی تصدیق)", 0, false, 12, null));
        if (Intrinsics.areEqual(getSharedViewModel().getAppType(), "reprint")) {
            ConfigurableButton configurableButton2 = getBinding().startApplicationLicense.commonButton;
            Util util3 = Util.INSTANCE;
            ArmsLicenseActivity activity3 = getActivity();
            String string3 = getString(R.string.start_application);
            Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
            configurableButton2.setText(Util.setEnglishTextSpan$default(util3, activity3, string3, " (درخواست شروع کریں)", 0, false, 12, null));
        } else {
            ConfigurableButton configurableButton3 = getBinding().startApplicationLicense.commonButton;
            Util util4 = Util.INSTANCE;
            ArmsLicenseActivity activity4 = getActivity();
            String string4 = getString(R.string.submit_application);
            Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
            configurableButton3.setText(Util.setEnglishTextSpan$default(util4, activity4, string4, " (درخواست جمع کروائیں)", 0, false, 12, null));
        }
        getBinding().startApplicationLicense.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda23
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TokenGenerationFragment.attachLayoutViews$lambda$2(this.f$0, view);
            }
        });
        initViews();
        initWeaponData();
        setupClickListeners();
        this.verifyFingerprintResponse.setVerificationMode("FINGER");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void attachLayoutViews$lambda$2(TokenGenerationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.processStartApplicationButtonClickAction();
    }

    private final void initViews() {
        FragmentTokenGenerationBinding binding = getBinding();
        binding.applicantCnicLayout.maskedCnicEditText.setVisibility(0);
        binding.verifyApplicantFingerprintButtonLayout.commonButton.setVisibility(0);
        binding.tvWeaponDetails.setVisibility(8);
        binding.cardWeaponDetails.setVisibility(8);
        binding.tvSelectNadraCenter.setVisibility(8);
        binding.tvSelectCardValidation.setVisibility(8);
        binding.spinnerNadraCenter.textInputLayout.setVisibility(8);
        binding.spinnerCardValidation.textInputLayout.setVisibility(8);
        binding.feeSummaryTitle.setVisibility(8);
        binding.cardFeeSummary.setVisibility(8);
        binding.startApplicationLicense.commonButton.setVisibility(8);
        binding.applicantCnicLayout.maskedCnicTextInputLayout.setHint(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Citizen Number", " (شناختی کارڈ نمبر)", 0, false, 12, null));
        binding.tvWeaponDetails.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Current Weapon Details", " (اسلحہ کی تفصیلات)", 0, false, 12, null));
        binding.weaponDetailTitle.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "License Number", " (لائسنس نمبر)", 0, false, 12, null));
        binding.weaponNumber.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Weapon Number", " (اسلحہ نمبر)", 0, false, 12, null));
        binding.weaponType.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Weapon Type", " (اسلحہ کی نوعیت)", 0, false, 12, null));
        binding.WeaponBore.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Weapon Caliber/Bore", " (اسلحہ کا بور)", 0, false, 12, null));
        binding.WeaponCategory.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Weapon Category", " (اسلحہ کی کیٹیگری)", 0, false, 12, null));
        binding.tvSelectNadraCenter.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Select NADRA Center for Card Delivery", " (کارڈ کی ترسیل کے لیے نادرا مرکز منتخب کریں)", 0, false, 12, null));
        binding.tvSelectCardValidation.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Select Card Validity", " (کارڈ کی مدتِ معیاد منتخب کریں)", 0, false, 12, null));
        binding.feeSummaryTitle.setText(Util.setEnglishTextSpan$default(Util.INSTANCE, getActivity(), "Fee Summary", " (فیس کی تفصیل)", 0, false, 12, null));
    }

    private final void showRemainingViews() {
        FragmentTokenGenerationBinding binding = getBinding();
        binding.verifyApplicantFingerprintButtonLayout.commonButton.setVisibility(8);
        binding.tvWeaponDetails.setVisibility(0);
        binding.cardWeaponDetails.setVisibility(0);
        binding.tvSelectNadraCenter.setVisibility(0);
        binding.spinnerNadraCenter.getRoot().setVisibility(0);
        MaterialAutoCompleteTextView materialAutoCompleteTextView = binding.spinnerNadraCenter.autoCompleteTextView;
        Util util = Util.INSTANCE;
        ArmsLicenseActivity activity = getActivity();
        String string = getString(pk.gov.nadra.oneapp.arms.license.R.string.select_center);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        materialAutoCompleteTextView.setText(Util.setEnglishTextSpan$default(util, activity, string, " (مرکز منتخب کریں)", 0, false, 12, null));
    }

    public final void initWeaponData() {
        FragmentTokenGenerationBinding binding = getBinding();
        TextView textView = binding.licenseNumberTextView;
        String licenseNumber = getSharedViewModel().getSelectedLicenseProduct().getLicenseNumber();
        textView.setText(licenseNumber != null ? licenseNumber : "");
        TextView textView2 = binding.weaponNumberTextView;
        String weaponNumber = getSharedViewModel().getSelectedLicenseProduct().getWeaponNumber();
        textView2.setText(weaponNumber != null ? weaponNumber : "");
        TextView textView3 = binding.weaponTypeTextView;
        String weaponType = getSharedViewModel().getSelectedLicenseProduct().getWeaponType();
        textView3.setText(weaponType != null ? weaponType : "");
        TextView textView4 = binding.weaponCaliberTextView;
        String weaponCalibreBore = getSharedViewModel().getSelectedLicenseProduct().getWeaponCalibreBore();
        textView4.setText(weaponCalibreBore != null ? weaponCalibreBore : "");
        TextView textView5 = binding.weaponCategoryTextView;
        String weaponCategoryCode = getSharedViewModel().getSelectedLicenseProduct().getWeaponCategoryCode();
        textView5.setText(weaponCategoryCode != null ? weaponCategoryCode : "");
    }

    private final void setupClickListeners() {
        getBinding().verifyApplicantFingerprintButtonLayout.commonButton.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TokenGenerationFragment.setupClickListeners$lambda$6(this.f$0, view);
            }
        });
        getBinding().spinnerNadraCenter.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TokenGenerationFragment.setupClickListeners$lambda$7(this.f$0, view);
            }
        });
        getBinding().spinnerCardValidation.autoCompleteTextView.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TokenGenerationFragment.setupClickListeners$lambda$8(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setupClickListeners$lambda$6(TokenGenerationFragment this$0, View view) {
        String str;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        String verificationMode = this$0.verifyFingerprintResponse.getVerificationMode();
        if (verificationMode == null) {
            verificationMode = "FINGER";
        }
        int iHashCode = verificationMode.hashCode();
        if (iHashCode == 2402104) {
            str = "NONE";
        } else {
            if (iHashCode != 2066137676) {
                if (iHashCode == 2073851753 && verificationMode.equals("FINGER")) {
                    this$0.launchFingerprintActivity();
                    return;
                }
                return;
            }
            str = "FACIAL";
        }
        verificationMode.equals(str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setupClickListeners$lambda$7(TokenGenerationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.CENTER;
        this$0.getLicenseDeliveryCenters();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setupClickListeners$lambda$8(TokenGenerationFragment this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dropdownCalling = MethodName.VALIDATION;
        this$0.getCardValidationYears();
    }

    private final void launchFingerprintActivity() {
        Util util = Util.INSTANCE;
        ArmsLicenseActivity activity = getActivity();
        TextInputLayout maskedCnicTextInputLayout = getBinding().applicantCnicLayout.maskedCnicTextInputLayout;
        Intrinsics.checkNotNullExpressionValue(maskedCnicTextInputLayout, "maskedCnicTextInputLayout");
        TextInputEditText maskedCnicEditText = getBinding().applicantCnicLayout.maskedCnicEditText;
        Intrinsics.checkNotNullExpressionValue(maskedCnicEditText, "maskedCnicEditText");
        if (util.validateEditText(activity, maskedCnicTextInputLayout, maskedCnicEditText)) {
            getBinding().applicantCnicLayout.maskedCnicTextInputLayout.setError(null);
            getBinding().applicantCnicLayout.maskedCnicTextInputLayout.setErrorEnabled(false);
            Intent intent = new Intent(getActivity(), (Class<?>) FingerprintScanSelectionActivityUnikrew.class);
            intent.putExtra(Constant.CAPTURE_TYPE, "VERIFICATION");
            this.fingerprintLauncher.launch(intent);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void fingerprintLauncher$lambda$9(TokenGenerationFragment this$0, ActivityResult result) throws JsonSyntaxException {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1 && result.getData() != null) {
            Intent data = result.getData();
            Intrinsics.checkNotNull(data);
            if (data.hasExtra(Constant.CAPTURE_SUCCESS)) {
                this$0.handleCaptureSuccess();
                return;
            }
        }
        result.getResultCode();
    }

    private final void handleCaptureSuccess() throws JsonSyntaxException {
        String str;
        String strName;
        String fingerprints = AppPreferences.getInstance(getActivity()).getFingerprints();
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d(Constant.TAG, fingerprints);
        }
        Object objFromJson = new Gson().fromJson(fingerprints, (Class<Object>) FingerPreference[].class);
        Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
        List listAsList = ArraysKt.asList((Object[]) objFromJson);
        VerifyFingerprintRequest verifyFingerprintRequest = new VerifyFingerprintRequest(null, null, 0, null, null, false, null, false, false, false, false, false, false, null, false, false, false, null, 262143, null);
        verifyFingerprintRequest.setApplicantName(getSharedViewModel().getReactNativeData().getFullName());
        verifyFingerprintRequest.setCitizenNumber(StringsKt.replace$default(String.valueOf(getBinding().applicantCnicLayout.maskedCnicEditText.getText()), "-", "", false, 4, (Object) null));
        ArrayList arrayList = new ArrayList();
        Iterator it = listAsList.iterator();
        while (true) {
            str = "";
            if (!it.hasNext()) {
                break;
            }
            FingerPreference fingerPreference = (FingerPreference) it.next();
            VerifyFingerprintRequest.Finger finger = new VerifyFingerprintRequest.Finger(null, null, 0, null, 15, null);
            FingerIndexEnum fingerIndexEnumFromId = FingerIndexEnum.INSTANCE.fromId(Integer.parseInt(fingerPreference.getFingerIndex()));
            if (fingerIndexEnumFromId != null && (strName = fingerIndexEnumFromId.name()) != null) {
                str = strName;
            }
            finger.setIndexName(str);
            finger.setWsq(fingerPreference.getBase64());
            arrayList.add(finger);
        }
        verifyFingerprintRequest.setFingerList(arrayList);
        String trackingId = this.verifyFingerprintResponse.getTrackingId();
        verifyFingerprintRequest.setTrackingId(trackingId != null ? trackingId : "");
        verifyFingerprintRequest.setBiometricVerify(true);
        verifyApplicantFingerprint(verifyFingerprintRequest);
    }

    private final void verifyApplicantFingerprint(VerifyFingerprintRequest verifyFingerprintRequest) {
        LoaderManager.INSTANCE.showLoader(getActivity());
        if (Constant.INSTANCE.getDEBUG()) {
            Log.e("TAG", "verifyApplicantFingerprint: " + new Gson().toJson(verifyFingerprintRequest));
        }
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11121(verifyFingerprintRequest, null), 3, null);
    }

    /* compiled from: TokenGenerationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$verifyApplicantFingerprint$1", f = "TokenGenerationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$verifyApplicantFingerprint$1, reason: invalid class name and case insensitive filesystem */
    static final class C11121 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ VerifyFingerprintRequest $verifyFingerprintRequest;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C11121(VerifyFingerprintRequest verifyFingerprintRequest, Continuation<? super C11121> continuation) {
            super(2, continuation);
            this.$verifyFingerprintRequest = verifyFingerprintRequest;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TokenGenerationFragment.this.new C11121(this.$verifyFingerprintRequest, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11121) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            APIRequests aPIRequests = new APIRequests(TokenGenerationFragment.this.getActivity());
            VerifyFingerprintRequest verifyFingerprintRequest = this.$verifyFingerprintRequest;
            final TokenGenerationFragment tokenGenerationFragment = TokenGenerationFragment.this;
            aPIRequests.verifyApplicantFingerprint(verifyFingerprintRequest, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$verifyApplicantFingerprint$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return TokenGenerationFragment.C11121.invokeSuspend$lambda$0(tokenGenerationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(TokenGenerationFragment tokenGenerationFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(tokenGenerationFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("processUpdateChildDetails() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                tokenGenerationFragment.processVerifyApplicantSuccessResponse(jsonObject);
            } else {
                tokenGenerationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processVerifyApplicantSuccessResponse(JsonObject jSonObject) {
        VerifyFingerprintResponse verifyFingerprintResponse = (VerifyFingerprintResponse) new Gson().fromJson(jSonObject.toString(), VerifyFingerprintResponse.class);
        this.verifyFingerprintResponse = verifyFingerprintResponse;
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("processVerify()", verifyFingerprintResponse.toString());
        }
        if (!verifyFingerprintResponse.getCnicVerfStatus()) {
            BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
            ArmsLicenseActivity activity = getActivity();
            String string = getString(R.string.cnic_cannot_be);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            String string2 = getString(R.string.cnic_cannot_be_urdu);
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils, (FragmentActivity) activity, "Alert", string, false, true, string2, (Function1) null, 72, (Object) null);
            return;
        }
        if (!verifyFingerprintResponse.getBiometricVerfStatus()) {
            String verificationMode = verifyFingerprintResponse.getVerificationMode();
            if (verificationMode == null) {
                verificationMode = "FINGER";
            }
            int iHashCode = verificationMode.hashCode();
            if (iHashCode == 2402104) {
                if (verificationMode.equals("NONE")) {
                    BottomSheetUtils bottomSheetUtils2 = BottomSheetUtils.INSTANCE;
                    ArmsLicenseActivity activity2 = getActivity();
                    String string3 = getString(R.string.verification_failed);
                    Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
                    String string4 = getString(R.string.verification_failed_urdu);
                    Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
                    BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils2, (FragmentActivity) activity2, "Alert", string3, false, true, string4, (Function1) null, 72, (Object) null);
                    return;
                }
                return;
            }
            if (iHashCode != 2066137676) {
                if (iHashCode == 2073851753 && verificationMode.equals("FINGER")) {
                    ConfigurableButton configurableButton = getBinding().verifyApplicantFingerprintButtonLayout.commonButton;
                    Util util = Util.INSTANCE;
                    ArmsLicenseActivity activity3 = getActivity();
                    String string5 = getString(R.string.Verify_applicant_fingerprint);
                    Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
                    configurableButton.setText(Util.setEnglishTextSpan$default(util, activity3, string5, " (" + getString(R.string.verify_applicant_fingerprints_urdu) + ')', 0, false, 12, null));
                    BottomSheetUtils.showMessageBottomSheet$default(BottomSheetUtils.INSTANCE, (FragmentActivity) getActivity(), "Alert", "Fingerprint verification failed. Please try again", false, true, "انگلیوں کے نشانات کی تصدیق نہیں ہو سکی۔ برائے کرم دوبارہ کوشش کریں۔", (Function1) null, 72, (Object) null);
                    return;
                }
                return;
            }
            if (verificationMode.equals("FACIAL")) {
                ConfigurableButton configurableButton2 = getBinding().verifyApplicantFingerprintButtonLayout.commonButton;
                Util util2 = Util.INSTANCE;
                ArmsLicenseActivity activity4 = getActivity();
                String string6 = getString(R.string.verify_applicant_facial);
                Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
                configurableButton2.setButtonText(Util.setEnglishTextSpan$default(util2, activity4, string6, " (" + getString(R.string.verify_applicant_facial_urdu) + ')', 0, false, 12, null));
                BottomSheetUtils bottomSheetUtils3 = BottomSheetUtils.INSTANCE;
                ArmsLicenseActivity activity5 = getActivity();
                String biometricVerfStatusMessage = verifyFingerprintResponse.getBiometricVerfStatusMessage();
                if (biometricVerfStatusMessage == null) {
                    biometricVerfStatusMessage = getString(R.string.verification_failed);
                    Intrinsics.checkNotNullExpressionValue(biometricVerfStatusMessage, "getString(...)");
                }
                String string7 = getString(R.string.verification_failed_urdu);
                Intrinsics.checkNotNullExpressionValue(string7, "getString(...)");
                BottomSheetUtils.showMessageBottomSheet$default(bottomSheetUtils3, (FragmentActivity) activity5, "Alert", biometricVerfStatusMessage, false, true, string7, (Function1) null, 72, (Object) null);
                return;
            }
            return;
        }
        ArmsLicenseSharedViewModel sharedViewModel = getSharedViewModel();
        String trackingId = verifyFingerprintResponse.getTrackingId();
        if (trackingId == null) {
            trackingId = "";
        }
        sharedViewModel.setTrackingId(trackingId);
        showRemainingViews();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleFailureCase(JsonObject jsonResponse, int responseCode) throws JsonSyntaxException {
        Object element = new Gson().fromJson(jsonResponse.toString(), (Class<Object>) ErrorResponse.class);
        if (responseCode == 400 || responseCode == 500) {
            ErrorResponse errorResponse = (ErrorResponse) element;
            if (Intrinsics.areEqual(errorResponse.getStatus(), "VALIDATION_FAILED")) {
                List<ErrorResponse.Error> errors = errorResponse.getErrors();
                if (errors == null) {
                    NetworkErrorHandler networkErrorHandler = NetworkErrorHandler.INSTANCE;
                    ArmsLicenseActivity activity = getActivity();
                    Intrinsics.checkNotNullExpressionValue(element, "element");
                    NetworkErrorHandler.handleError$default(networkErrorHandler, activity, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return Unit.INSTANCE;
                        }
                    }, 8, null);
                    return;
                }
                for (ErrorResponse.Error error : errors) {
                    TextInputLayout textInputLayout = getFieldToViewMap().get(error.getField());
                    if (textInputLayout != null) {
                        textInputLayout.setError(String.valueOf(error.getMessage()));
                        textInputLayout.setErrorEnabled(true);
                    } else {
                        if (error.getMessage() != null) {
                            errorResponse.setMessage(((ErrorResponse) new Gson().fromJson(error.getMessage(), ErrorResponse.class)).getMessage());
                        }
                        NetworkErrorHandler networkErrorHandler2 = NetworkErrorHandler.INSTANCE;
                        ArmsLicenseActivity activity2 = getActivity();
                        Intrinsics.checkNotNullExpressionValue(element, "element");
                        NetworkErrorHandler.handleError$default(networkErrorHandler2, activity2, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return Unit.INSTANCE;
                            }
                        }, 8, null);
                    }
                }
                return;
            }
            NetworkErrorHandler networkErrorHandler3 = NetworkErrorHandler.INSTANCE;
            ArmsLicenseActivity activity3 = getActivity();
            Intrinsics.checkNotNullExpressionValue(element, "element");
            NetworkErrorHandler.handleError$default(networkErrorHandler3, activity3, errorResponse, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return Unit.INSTANCE;
                }
            }, 8, null);
            return;
        }
        NetworkErrorHandler networkErrorHandler4 = NetworkErrorHandler.INSTANCE;
        ArmsLicenseActivity activity4 = getActivity();
        Intrinsics.checkNotNullExpressionValue(element, "element");
        NetworkErrorHandler.handleError$default(networkErrorHandler4, activity4, (ErrorResponse) element, responseCode, false, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        }, 8, null);
    }

    private final void processStartApplicationButtonClickAction() {
        if (Intrinsics.areEqual(getSharedViewModel().getAppType(), "reprint")) {
            generateArmsLicenseReprintToken();
        } else {
            generateArmsLicenseRenewalToken();
        }
    }

    /* compiled from: TokenGenerationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$generateArmsLicenseRenewalToken$1", f = "TokenGenerationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$generateArmsLicenseRenewalToken$1, reason: invalid class name and case insensitive filesystem */
    static final class C11091 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C11091(Continuation<? super C11091> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TokenGenerationFragment.this.new C11091(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11091) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests aPIRequests = new pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests(TokenGenerationFragment.this.getActivity());
            ARMSLICENSETokenRequest tIDDataUpdationRequest = TokenGenerationFragment.this.getTIDDataUpdationRequest();
            final TokenGenerationFragment tokenGenerationFragment = TokenGenerationFragment.this;
            aPIRequests.generateArmsLicenseRenewalToken(tIDDataUpdationRequest, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$generateArmsLicenseRenewalToken$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return TokenGenerationFragment.C11091.invokeSuspend$lambda$0(tokenGenerationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(TokenGenerationFragment tokenGenerationFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(tokenGenerationFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("tIDDataUpdation() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                tokenGenerationFragment.processTIDDataUpdationSuccessResponse(jsonObject);
            } else {
                tokenGenerationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void generateArmsLicenseRenewalToken() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11091(null), 3, null);
    }

    /* compiled from: TokenGenerationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$generateArmsLicenseReprintToken$1", f = "TokenGenerationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$generateArmsLicenseReprintToken$1, reason: invalid class name and case insensitive filesystem */
    static final class C11101 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C11101(Continuation<? super C11101> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TokenGenerationFragment.this.new C11101(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11101) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests aPIRequests = new pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests(TokenGenerationFragment.this.getActivity());
            ARMSLICENSETokenRequest tIDDataUpdationRequest = TokenGenerationFragment.this.getTIDDataUpdationRequest();
            final TokenGenerationFragment tokenGenerationFragment = TokenGenerationFragment.this;
            aPIRequests.generateArmsLicenseReprintToken(tIDDataUpdationRequest, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$generateArmsLicenseReprintToken$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return TokenGenerationFragment.C11101.invokeSuspend$lambda$0(tokenGenerationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(TokenGenerationFragment tokenGenerationFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(tokenGenerationFragment.getActivity());
            if (Constant.INSTANCE.getDEBUG()) {
                System.out.println((Object) ("tIDDataUpdation() Response: " + jsonObject));
            }
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                tokenGenerationFragment.processTIDDataUpdationSuccessResponse(jsonObject);
            } else {
                tokenGenerationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void generateArmsLicenseReprintToken() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11101(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processTIDDataUpdationSuccessResponse(JsonObject jSonObject) {
        ARMSLICENSETokenResponse aRMSLICENSETokenResponse = (ARMSLICENSETokenResponse) new Gson().fromJson(jSonObject.toString(), ARMSLICENSETokenResponse.class);
        if (Intrinsics.areEqual(getSharedViewModel().getAppType(), "reprint")) {
            handleReprintFlow(aRMSLICENSETokenResponse.getTrackingId());
        } else {
            handleRenewalFlow(aRMSLICENSETokenResponse.getTrackingId());
        }
    }

    private final void handleReprintFlow(String trackingId) {
        getSharedViewModel().setTrackingId(trackingId);
        getSharedViewModel().setAmount(String.valueOf(getSharedViewModel().getLicenseFeeResponse().getTotalFee()));
        getActivity().navigateToFragment(pk.gov.nadra.oneapp.arms.license.R.id.licenseSupportingDocumentsFragment);
    }

    private final void handleRenewalFlow(String trackingId) {
        getSharedViewModel().setTrackingId(trackingId);
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        ArmsLicenseActivity activity = getActivity();
        String string = getActivity().getString(pk.gov.nadra.oneapp.arms.license.R.string.submission_title);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = getActivity().getString(pk.gov.nadra.oneapp.arms.license.R.string.submission_success_message);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        bottomSheetUtils.showMessageBottomSheet((FragmentActivity) activity, string, string2, true, (CharSequence) "Confirm", true, "آپ کی درخواست کامیابی سے جمع ہو گئی ہے۔ درخواست کی منظوری کے بعد آپ کو فیس کی ادائیگی کے لیے مطلع کیا جائے گا۔ درخواست پہ کاروائی کے دوران ضرورت پڑنے پرہمارا نمائندہ آپ سے رابطہ کر سکتا ہے۔", new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda18
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return TokenGenerationFragment.handleRenewalFlow$lambda$20(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda19
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return TokenGenerationFragment.handleRenewalFlow$lambda$21(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleRenewalFlow$lambda$20(TokenGenerationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_INBOX);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleRenewalFlow$lambda$21(TokenGenerationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getActivity().navigateToReactNativeInbox(Constant.GO_TO_INBOX);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final ARMSLICENSETokenRequest getTIDDataUpdationRequest() {
        String centerId;
        ARMSLICENSETokenRequest aRMSLICENSETokenRequest = new ARMSLICENSETokenRequest(null, null, null, null, null, null, null, null, null, null, null, null, null, null, 16383, null);
        aRMSLICENSETokenRequest.setTrackingId(getSharedViewModel().getTrackingId());
        aRMSLICENSETokenRequest.setCitizenNumber(StringsKt.replace$default(getSharedViewModel().getReactNativeData().getCitizenNumber(), "-", "", false, 4, (Object) null));
        String weaponNumber = getSharedViewModel().getSelectedLicenseProduct().getWeaponNumber();
        String str = "";
        if (weaponNumber == null) {
            weaponNumber = "";
        }
        aRMSLICENSETokenRequest.setWeaponNumber(weaponNumber);
        String weaponType = getSharedViewModel().getSelectedLicenseProduct().getWeaponType();
        if (weaponType == null) {
            weaponType = "";
        }
        aRMSLICENSETokenRequest.setWeaponType(weaponType);
        String weaponCalibreBore = getSharedViewModel().getSelectedLicenseProduct().getWeaponCalibreBore();
        if (weaponCalibreBore == null) {
            weaponCalibreBore = "";
        }
        aRMSLICENSETokenRequest.setWeaponCaliberBore(weaponCalibreBore);
        String licenseNumber = getSharedViewModel().getSelectedLicenseProduct().getLicenseNumber();
        if (licenseNumber == null) {
            licenseNumber = "";
        }
        aRMSLICENSETokenRequest.setLicenseNumber(licenseNumber);
        aRMSLICENSETokenRequest.setCardValidation(String.valueOf(this.selectedValidationYear));
        LicenseDeliveryCenterResponse licenseDeliveryCenterResponse = this.selectedDeliveryCenter;
        if (licenseDeliveryCenterResponse != null && (centerId = licenseDeliveryCenterResponse.getCenterId()) != null) {
            str = centerId;
        }
        aRMSLICENSETokenRequest.setCardDeliveryUnitId(str);
        aRMSLICENSETokenRequest.setProcessingFee(String.valueOf(getSharedViewModel().getLicenseFeeResponse().getProcessingFee()));
        aRMSLICENSETokenRequest.setLicenseFee(String.valueOf(getSharedViewModel().getLicenseFeeResponse().getLicenseFee()));
        aRMSLICENSETokenRequest.setPenalityFee(String.valueOf(getSharedViewModel().getLicenseFeeResponse().getPenaltyFee()));
        aRMSLICENSETokenRequest.setTotalFee(String.valueOf(getSharedViewModel().getLicenseFeeResponse().getTotalFee()));
        aRMSLICENSETokenRequest.setProductCode(getSharedViewModel().getSelectedLicenseProduct().getProductCode());
        aRMSLICENSETokenRequest.setTokenCategory(getSharedViewModel().getAppType());
        return aRMSLICENSETokenRequest;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final DeliveryCentersRequestModel getDeliveryCentersRequest() {
        return new DeliveryCentersRequestModel(getSharedViewModel().getSelectedLicenseProduct().getProductCode());
    }

    private final void getLicenseDeliveryCenters() {
        if (!this.deliveryCentersList.isEmpty()) {
            ArrayList<LicenseDeliveryCenterResponse> arrayList = this.deliveryCentersList;
            ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList, 10));
            Iterator<T> it = arrayList.iterator();
            while (it.hasNext()) {
                arrayList2.add(((LicenseDeliveryCenterResponse) it.next()).getName());
            }
            launchStringPicker(arrayList2);
            return;
        }
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new C11111(null), 3, null);
    }

    /* compiled from: TokenGenerationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$getLicenseDeliveryCenters$1", f = "TokenGenerationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$getLicenseDeliveryCenters$1, reason: invalid class name and case insensitive filesystem */
    static final class C11111 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C11111(Continuation<? super C11111> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TokenGenerationFragment.this.new C11111(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C11111) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests aPIRequests = new pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests(TokenGenerationFragment.this.getActivity());
            DeliveryCentersRequestModel deliveryCentersRequest = TokenGenerationFragment.this.getDeliveryCentersRequest();
            final TokenGenerationFragment tokenGenerationFragment = TokenGenerationFragment.this;
            aPIRequests.getCardDeliveryCenters(deliveryCentersRequest, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$getLicenseDeliveryCenters$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return TokenGenerationFragment.C11111.invokeSuspend$lambda$0(tokenGenerationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(TokenGenerationFragment tokenGenerationFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(tokenGenerationFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                tokenGenerationFragment.processDeliveryCentersResponse(jsonObject, Integer.valueOf(i));
            } else {
                tokenGenerationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processDeliveryCentersResponse(JsonObject jsonObject, final Integer responseCode) {
        JsonParserHelper.INSTANCE.parseJsonData(jsonObject, "data", new Function1() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda11
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return TokenGenerationFragment.processDeliveryCentersResponse$lambda$28(this.f$0, responseCode, (Result) obj);
            }
        });
        if (this.deliveryCentersList.isEmpty()) {
            return;
        }
        ArrayList<LicenseDeliveryCenterResponse> arrayList = this.deliveryCentersList;
        ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList, 10));
        Iterator<T> it = arrayList.iterator();
        while (it.hasNext()) {
            arrayList2.add(((LicenseDeliveryCenterResponse) it.next()).getName());
        }
        launchStringPicker(arrayList2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processDeliveryCentersResponse$lambda$28(final TokenGenerationFragment this$0, Integer num, Result result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Object value = result.getValue();
        Throwable thM7261exceptionOrNullimpl = Result.m7261exceptionOrNullimpl(value);
        if (thM7261exceptionOrNullimpl == null) {
            try {
                Object objFromJson = new Gson().fromJson((JsonElement) value, (Class<Object>) LicenseDeliveryCenterResponse[].class);
                Intrinsics.checkNotNullExpressionValue(objFromJson, "fromJson(...)");
                List list = ArraysKt.toList((Object[]) objFromJson);
                Intrinsics.checkNotNull(list, "null cannot be cast to non-null type java.util.ArrayList<pk.gov.nadra.oneapp.arms.license.models.LicenseDeliveryCenterResponse>");
                this$0.deliveryCentersList = (ArrayList) list;
            } catch (Exception e) {
                this$0.handleArmsLicenseFailureCase(e, num, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda7
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return TokenGenerationFragment.processDeliveryCentersResponse$lambda$28$lambda$25$lambda$24(this.f$0);
                    }
                });
            }
        } else {
            this$0.handleArmsLicenseFailureCase(thM7261exceptionOrNullimpl, num, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda8
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return TokenGenerationFragment.processDeliveryCentersResponse$lambda$28$lambda$27$lambda$26(this.f$0);
                }
            });
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processDeliveryCentersResponse$lambda$28$lambda$25$lambda$24(TokenGenerationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getLicenseDeliveryCenters();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processDeliveryCentersResponse$lambda$28$lambda$27$lambda$26(TokenGenerationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getLicenseDeliveryCenters();
        return Unit.INSTANCE;
    }

    private final void launchStringPicker(ArrayList<String> items) {
        Intent intent = new Intent(getActivity(), (Class<?>) StringPickerActivity.class);
        intent.putStringArrayListExtra("INTENT_STRING_LIST", items);
        this.startForResult.launch(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startForResult$lambda$31(TokenGenerationFragment this$0, ActivityResult result) {
        Intent data;
        Object next;
        List listSplit$default;
        String str;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1 && (data = result.getData()) != null && data.hasExtra("INTENT_STRING_ITEM")) {
            String stringExtra = data.getStringExtra("INTENT_STRING_ITEM");
            int i = WhenMappings.$EnumSwitchMapping$0[this$0.dropdownCalling.ordinal()];
            String upperCase = null;
            numValueOf = null;
            numValueOf = null;
            Integer numValueOf = null;
            if (i != 1) {
                if (i != 2) {
                    throw new NoWhenBranchMatchedException();
                }
                if (stringExtra != null && (listSplit$default = StringsKt.split$default((CharSequence) stringExtra, new String[]{StringUtils.SPACE}, false, 0, 6, (Object) null)) != null && (str = (String) listSplit$default.get(0)) != null) {
                    numValueOf = Integer.valueOf(Integer.parseInt(str));
                }
                this$0.selectedValidationYear = numValueOf;
                this$0.getBinding().spinnerCardValidation.autoCompleteTextView.setText(stringExtra);
                this$0.checkAndCallProcessingFeeAPI();
                return;
            }
            Iterator<T> it = this$0.deliveryCentersList.iterator();
            while (true) {
                if (!it.hasNext()) {
                    next = null;
                    break;
                } else {
                    next = it.next();
                    if (Intrinsics.areEqual(((LicenseDeliveryCenterResponse) next).getName(), stringExtra)) {
                        break;
                    }
                }
            }
            Intrinsics.checkNotNull(next);
            this$0.selectedDeliveryCenter = (LicenseDeliveryCenterResponse) next;
            MaterialAutoCompleteTextView materialAutoCompleteTextView = this$0.getBinding().spinnerNadraCenter.autoCompleteTextView;
            if (stringExtra != null) {
                upperCase = stringExtra.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            }
            materialAutoCompleteTextView.setText(upperCase);
            if (!Intrinsics.areEqual(this$0.getSharedViewModel().getAppType(), "reprint")) {
                MaterialAutoCompleteTextView materialAutoCompleteTextView2 = this$0.getBinding().spinnerCardValidation.autoCompleteTextView;
                Util util = Util.INSTANCE;
                ArmsLicenseActivity activity = this$0.getActivity();
                String string = this$0.getString(pk.gov.nadra.oneapp.arms.license.R.string.select_validation);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                materialAutoCompleteTextView2.setText(Util.setEnglishTextSpan$default(util, activity, string, " (تصدیق منتخب کریں)", 0, false, 12, null));
                this$0.getBinding().tvSelectCardValidation.setVisibility(0);
                this$0.getBinding().spinnerCardValidation.textInputLayout.setVisibility(0);
                return;
            }
            this$0.callProcessingFeeAPI();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final LicenseValidationRequestModel getLicenseValidationRequest() {
        String productCode = getSharedViewModel().getSelectedLicenseProduct().getProductCode();
        String licenseNumber = getSharedViewModel().getSelectedLicenseProduct().getLicenseNumber();
        if (licenseNumber == null) {
            licenseNumber = "";
        }
        return new LicenseValidationRequestModel(productCode, licenseNumber, StringsKt.replace$default(getSharedViewModel().getReactNativeData().getCitizenNumber(), "-", "", false, 4, (Object) null), getSharedViewModel().getAppType());
    }

    private final void getCardValidationYears() {
        ArrayList<Integer> arrayList = this.validationYearsList;
        ArrayList<Integer> arrayList2 = null;
        if (arrayList != null) {
            if (arrayList == null) {
                Intrinsics.throwUninitializedPropertyAccessException("validationYearsList");
                arrayList = null;
            }
            if (!arrayList.isEmpty()) {
                ArrayList<Integer> arrayList3 = this.validationYearsList;
                if (arrayList3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("validationYearsList");
                } else {
                    arrayList2 = arrayList3;
                }
                ArrayList<Integer> arrayList4 = arrayList2;
                ArrayList arrayList5 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList4, 10));
                Iterator<T> it = arrayList4.iterator();
                while (it.hasNext()) {
                    arrayList5.add(((Number) it.next()).intValue() + " years");
                }
                launchStringPicker(arrayList5);
                return;
            }
        }
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass2(null), 3, null);
    }

    /* compiled from: TokenGenerationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$getCardValidationYears$2", f = "TokenGenerationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$getCardValidationYears$2, reason: invalid class name */
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TokenGenerationFragment.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests aPIRequests = new pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests(TokenGenerationFragment.this.getActivity());
            LicenseValidationRequestModel licenseValidationRequest = TokenGenerationFragment.this.getLicenseValidationRequest();
            final TokenGenerationFragment tokenGenerationFragment = TokenGenerationFragment.this;
            aPIRequests.getCardValidations(licenseValidationRequest, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$getCardValidationYears$2$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return TokenGenerationFragment.AnonymousClass2.invokeSuspend$lambda$0(tokenGenerationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(TokenGenerationFragment tokenGenerationFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(tokenGenerationFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                tokenGenerationFragment.processValidationYearsResponse(jsonObject, i);
            } else {
                tokenGenerationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processValidationYearsResponse(JsonObject jsonObject, final int responseCode) {
        JsonParserHelper.INSTANCE.parseJsonData(jsonObject, "data", new Function1() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return TokenGenerationFragment.processValidationYearsResponse$lambda$39(this.f$0, responseCode, (Result) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processValidationYearsResponse$lambda$39(final TokenGenerationFragment this$0, int i, Result result) {
        Integer[] numArr;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Object value = result.getValue();
        Throwable thM7261exceptionOrNullimpl = Result.m7261exceptionOrNullimpl(value);
        if (thM7261exceptionOrNullimpl == null) {
            JsonElement jsonElement = (JsonElement) value;
            try {
                Gson gson = new Gson();
                if (jsonElement.isJsonArray()) {
                    numArr = (Integer[]) gson.fromJson(jsonElement, Integer[].class);
                } else {
                    numArr = new Integer[]{Integer.valueOf(jsonElement.getAsInt())};
                }
                Intrinsics.checkNotNull(numArr);
                ArrayList<Integer> arrayList = new ArrayList<>(numArr.length);
                for (Integer num : numArr) {
                    arrayList.add(Integer.valueOf(num.intValue()));
                }
                ArrayList<Integer> arrayList2 = arrayList;
                this$0.validationYearsList = arrayList2;
                ArrayList<Integer> arrayList3 = arrayList2;
                ArrayList arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList3, 10));
                Iterator<T> it = arrayList3.iterator();
                while (it.hasNext()) {
                    int iIntValue = ((Number) it.next()).intValue();
                    arrayList4.add(iIntValue + ' ' + (iIntValue == 1 ? "year" : "years"));
                }
                this$0.launchStringPicker(arrayList4);
            } catch (Exception e) {
                this$0.handleArmsLicenseFailureCase(e, Integer.valueOf(i), new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda5
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return TokenGenerationFragment.processValidationYearsResponse$lambda$39$lambda$36$lambda$35(this.f$0);
                    }
                });
            }
        } else {
            this$0.handleArmsLicenseFailureCase(thM7261exceptionOrNullimpl, Integer.valueOf(i), new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda6
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return TokenGenerationFragment.processValidationYearsResponse$lambda$39$lambda$38$lambda$37(this.f$0);
                }
            });
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processValidationYearsResponse$lambda$39$lambda$36$lambda$35(TokenGenerationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getCardValidationYears();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processValidationYearsResponse$lambda$39$lambda$38$lambda$37(TokenGenerationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.getCardValidationYears();
        return Unit.INSTANCE;
    }

    private final void checkAndCallProcessingFeeAPI() {
        if (this.selectedValidationYear == null || this.selectedDeliveryCenter == null) {
            return;
        }
        callProcessingFeeAPI();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final LicenseFeeRequestModel getLicenseFeeRequest() {
        String string;
        String productCode = getSharedViewModel().getSelectedLicenseProduct().getProductCode();
        String strReplace$default = StringsKt.replace$default(getSharedViewModel().getReactNativeData().getCitizenNumber(), "-", "", false, 4, (Object) null);
        String licenseNumber = getSharedViewModel().getSelectedLicenseProduct().getLicenseNumber();
        if (licenseNumber == null) {
            licenseNumber = "";
        }
        Integer num = this.selectedValidationYear;
        if (num == null || (string = num.toString()) == null) {
            string = "0";
        }
        return new LicenseFeeRequestModel(productCode, strReplace$default, licenseNumber, string, getSharedViewModel().getAppType());
    }

    /* compiled from: TokenGenerationFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @DebugMetadata(c = "pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$callProcessingFeeAPI$1", f = "TokenGenerationFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$callProcessingFeeAPI$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TokenGenerationFragment.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests aPIRequests = new pk.gov.nadra.oneapp.arms.license.network.retrofit.APIRequests(TokenGenerationFragment.this.getActivity());
            LicenseFeeRequestModel licenseFeeRequest = TokenGenerationFragment.this.getLicenseFeeRequest();
            final TokenGenerationFragment tokenGenerationFragment = TokenGenerationFragment.this;
            aPIRequests.getLicenseFeeSummary(licenseFeeRequest, new Function3() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$callProcessingFeeAPI$1$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return TokenGenerationFragment.AnonymousClass1.invokeSuspend$lambda$0(tokenGenerationFragment, (JsonObject) obj2, (String) obj3, ((Integer) obj4).intValue());
                }
            });
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit invokeSuspend$lambda$0(TokenGenerationFragment tokenGenerationFragment, JsonObject jsonObject, String str, int i) throws JsonSyntaxException {
            LoaderManager.INSTANCE.hideLoader(tokenGenerationFragment.getActivity());
            if (Intrinsics.areEqual(str, "SUCCESS")) {
                tokenGenerationFragment.processLicenseFeeSummaryResponse(jsonObject, i);
            } else {
                tokenGenerationFragment.handleFailureCase(jsonObject, i);
            }
            return Unit.INSTANCE;
        }
    }

    private final void callProcessingFeeAPI() {
        LoaderManager.INSTANCE.showLoader(getActivity());
        BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getMain()), null, null, new AnonymousClass1(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void processLicenseFeeSummaryResponse(JsonObject jsonObject, final int responseCode) {
        JsonParserHelper.INSTANCE.parseJsonData(jsonObject, "data", new Function1() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda22
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return TokenGenerationFragment.processLicenseFeeSummaryResponse$lambda$45(this.f$0, responseCode, (Result) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processLicenseFeeSummaryResponse$lambda$45(final TokenGenerationFragment this$0, int i, Result result) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Object value = result.getValue();
        Throwable thM7261exceptionOrNullimpl = Result.m7261exceptionOrNullimpl(value);
        if (thM7261exceptionOrNullimpl == null) {
            try {
                LicenseFeeResponse.FeeDetails feeDetails = (LicenseFeeResponse.FeeDetails) new Gson().fromJson((JsonElement) value, LicenseFeeResponse.FeeDetails.class);
                FragmentTokenGenerationBinding binding = this$0.getBinding();
                binding.feeSummaryTitle.setVisibility(0);
                binding.cardFeeSummary.setVisibility(0);
                binding.tvProcessingFeeValue.setText(String.valueOf(feeDetails.getProcessingFee()));
                binding.tvLicenseFeeValue.setText(String.valueOf(feeDetails.getLicenseFee()));
                binding.tvPenaltyFeeValue.setText(String.valueOf(feeDetails.getPenaltyFee()));
                binding.tvNetTotalFeeValue.setText(String.valueOf(feeDetails.getTotalFee()));
                binding.startApplicationLicense.commonButton.setVisibility(0);
                this$0.getSharedViewModel().setLicenseFeeResponse(feeDetails);
                if (Constant.INSTANCE.getDEBUG()) {
                    System.out.println((Object) ("Arms Fee Response: " + feeDetails));
                }
            } catch (Exception e) {
                this$0.handleArmsLicenseFailureCase(e, Integer.valueOf(i), new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda16
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return TokenGenerationFragment.processLicenseFeeSummaryResponse$lambda$45$lambda$42$lambda$41(this.f$0);
                    }
                });
            }
        } else {
            this$0.handleArmsLicenseFailureCase(thM7261exceptionOrNullimpl, Integer.valueOf(i), new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda17
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return TokenGenerationFragment.processLicenseFeeSummaryResponse$lambda$45$lambda$44$lambda$43(this.f$0);
                }
            });
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processLicenseFeeSummaryResponse$lambda$45$lambda$42$lambda$41(TokenGenerationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.callProcessingFeeAPI();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit processLicenseFeeSummaryResponse$lambda$45$lambda$44$lambda$43(TokenGenerationFragment this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.callProcessingFeeAPI();
        return Unit.INSTANCE;
    }

    /* JADX WARN: Multi-variable type inference failed */
    static /* synthetic */ void handleArmsLicenseFailureCase$default(TokenGenerationFragment tokenGenerationFragment, Object obj, Integer num, Function0 function0, int i, Object obj2) {
        if ((i & 4) != 0) {
            function0 = null;
        }
        tokenGenerationFragment.handleArmsLicenseFailureCase(obj, num, function0);
    }

    private final void handleArmsLicenseFailureCase(Object error, Integer responseCode, Function0<Unit> retryAction) {
        String string;
        if (error instanceof Throwable) {
            string = ((Throwable) error).getMessage();
            if (string == null) {
                string = getString(R.string.arms_license_generic_error_message);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            }
        } else if (error instanceof JsonObject) {
            string = ((ErrorResponse) new Gson().fromJson((JsonElement) ((JsonObject) error).getAsJsonObject(), ErrorResponse.class)).getMessage();
            if (string == null) {
                string = getString(R.string.arms_license_generic_error_message);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            }
        } else if (error instanceof String) {
            string = (String) error;
        } else {
            string = getString(R.string.arms_license_generic_error_message);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        }
        String str = string;
        BottomSheetUtils bottomSheetUtils = BottomSheetUtils.INSTANCE;
        ArmsLicenseActivity activity = getActivity();
        String string2 = getString(pk.gov.nadra.oneapp.arms.license.R.string.error_title);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        String string3 = getString(pk.gov.nadra.oneapp.arms.license.R.string.try_again);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        String str2 = string3;
        if (retryAction == null) {
            retryAction = new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda20
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return Unit.INSTANCE;
                }
            };
        }
        bottomSheetUtils.showMessageBottomSheet((FragmentActivity) activity, string2, str, true, (CharSequence) str2, false, "", retryAction, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.fragments.TokenGenerationFragment$$ExternalSyntheticLambda21
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        });
        if (Constant.INSTANCE.getDEBUG()) {
            StringBuilder sb = new StringBuilder("Failure - Code: ");
            Object obj = responseCode;
            if (responseCode == null) {
                obj = "N/A";
            }
            System.out.println((Object) sb.append(obj).append(", Message: ").append(str).toString());
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}