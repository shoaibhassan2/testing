package pk.gov.nadra.oneapp.arms.license.fragments;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class TokenGenerationFragment$$ExternalSyntheticLambda16 implements Function0 {
    public /* synthetic */ TokenGenerationFragment$$ExternalSyntheticLambda16() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return TokenGenerationFragment.processLicenseFeeSummaryResponse$lambda$45$lambda$42$lambda$41(this.f$0);
    }
}