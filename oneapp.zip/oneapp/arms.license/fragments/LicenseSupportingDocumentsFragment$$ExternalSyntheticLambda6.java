package pk.gov.nadra.oneapp.arms.license.fragments;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda6 implements View.OnClickListener {
    public /* synthetic */ LicenseSupportingDocumentsFragment$$ExternalSyntheticLambda6() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        LicenseSupportingDocumentsFragment.onViewCreated$lambda$8$lambda$0(this.f$0, view);
    }
}