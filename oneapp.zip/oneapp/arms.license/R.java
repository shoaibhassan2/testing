package pk.gov.nadra.oneapp.arms.license;

/* loaded from: classes5.dex */
public final class R {

    public static final class color {
        public static int blue = 0x7f060029;
        public static int divider_grey = 0x7f0600d7;
        public static int gray = 0x7f0600ed;
        public static int green = 0x7f0600ef;
        public static int light_blue = 0x7f060107;
        public static int light_gray = 0x7f06010a;

        private color() {
        }
    }

    public static final class drawable {
        public static int app_bar_logo = 0x7f08014f;
        public static int arrow_forward = 0x7f08015a;
        public static int back_icon = 0x7f08015f;
        public static int bg_rounded_gray = 0x7f080189;
        public static int calendar_icon = 0x7f08019f;
        public static int drop_down_icon = 0x7f08031c;
        public static int license_action_cancellation = 0x7f080492;
        public static int license_action_inheritance = 0x7f080493;
        public static int license_action_modification = 0x7f080494;
        public static int license_action_renew = 0x7f080495;
        public static int license_action_reprint = 0x7f080496;
        public static int license_action_transfer = 0x7f080497;
        public static int license_list_image = 0x7f080498;
        public static int lincense_type_bg = 0x7f08049d;
        public static int pals_activity_bg = 0x7f08053b;
        public static int rounded_green_button_bg = 0x7f080576;
        public static int spinner_border = 0x7f080597;

        private drawable() {
        }
    }

    public static final class id {
        public static int WeaponBore = 0x7f0a000f;
        public static int WeaponCategory = 0x7f0a0010;
        public static int action_licenseAction_to_licenseList = 0x7f0a0086;
        public static int action_licenseTokenGeneration_to_licenseActions = 0x7f0a0087;
        public static int applicant_cnic_layout = 0x7f0a0129;
        public static int application_detail_heading_layout = 0x7f0a0134;
        public static int arm_license_header_layout = 0x7f0a0193;
        public static int armsLicenseLabel = 0x7f0a0194;
        public static int cardFeeSummary = 0x7f0a028b;
        public static int cardWeaponDetails = 0x7f0a028d;
        public static int crc_footer_layout = 0x7f0a038f;
        public static int crc_header_layout = 0x7f0a0390;
        public static int divider0 = 0x7f0a04af;
        public static int divider2 = 0x7f0a04b1;
        public static int divider3 = 0x7f0a04b2;
        public static int documents_details_heading = 0x7f0a0521;
        public static int documents_list_try_again_imageView = 0x7f0a0525;
        public static int documents_list_try_again_layout = 0x7f0a0526;
        public static int documents_list_try_again_textView = 0x7f0a0527;
        public static int documents_swipeRefresh = 0x7f0a0528;
        public static int expandableListView_uploaded_documents = 0x7f0a058c;
        public static int expiryDate = 0x7f0a05a4;
        public static int expiryLabel = 0x7f0a05a5;
        public static int feeSummaryTitle = 0x7f0a05fc;
        public static int filter_button = 0x7f0a060d;
        public static int forwardArrow = 0x7f0a0668;
        public static int fragmentLicenseList = 0x7f0a066d;
        public static int guideline = 0x7f0a06cf;
        public static int guideline_net_total = 0x7f0a06e4;
        public static int inbox_try_again_imageView = 0x7f0a0780;
        public static int inbox_try_again_layout = 0x7f0a0781;
        public static int inbox_try_again_textView = 0x7f0a0782;
        public static int issuanceDate = 0x7f0a07a9;
        public static int issuanceLabel = 0x7f0a07aa;
        public static int itemImage = 0x7f0a07b1;
        public static int itemNumber = 0x7f0a07b3;
        public static int ivBackground = 0x7f0a07b8;
        public static int licenseActionsFragment = 0x7f0a07f7;
        public static int licenseListFragment = 0x7f0a07f8;
        public static int licenseNumberLabel = 0x7f0a07f9;
        public static int licenseSupportingDocumentsFragment = 0x7f0a07fa;
        public static int licenseTokenGenerationFragment = 0x7f0a07fb;
        public static int licenseTypeLabel = 0x7f0a07fc;
        public static int license_header_layout = 0x7f0a0801;
        public static int license_number_textView = 0x7f0a0806;
        public static int main = 0x7f0a086d;
        public static int main_swipeRefresh = 0x7f0a0870;
        public static int nav_graph = 0x7f0a0959;
        public static int netTotalFeeContainer = 0x7f0a0966;
        public static int pals_nav_host_fragment = 0x7f0a09ec;
        public static int rvLicenseActions = 0x7f0a0b85;
        public static int rvLicenseList = 0x7f0a0b86;
        public static int scrollView = 0x7f0a0bd3;
        public static int spinner_card_validation = 0x7f0a0c35;
        public static int spinner_nadra_center = 0x7f0a0c36;
        public static int start_application_button_layout = 0x7f0a0c6f;
        public static int start_application_license = 0x7f0a0c70;
        public static int step_title_heading_layout = 0x7f0a0c77;
        public static int supporting_uploaded_documents_recyclerView = 0x7f0a0c8e;
        public static int try_again_section = 0x7f0a0d48;
        public static int tvDescription = 0x7f0a0d4b;
        public static int tvLicenseFeeLabel = 0x7f0a0d4e;
        public static int tvLicenseFeeValue = 0x7f0a0d4f;
        public static int tvLicenseTitle = 0x7f0a0d50;
        public static int tvNetTotalFeeLabel = 0x7f0a0d51;
        public static int tvNetTotalFeeValue = 0x7f0a0d52;
        public static int tvPenaltyFeeLabel = 0x7f0a0d53;
        public static int tvPenaltyFeeValue = 0x7f0a0d54;
        public static int tvProcessingFeeLabel = 0x7f0a0d55;
        public static int tvProcessingFeeValue = 0x7f0a0d56;
        public static int tvSelectCardValidation = 0x7f0a0d57;
        public static int tvSelectNadraCenter = 0x7f0a0d58;
        public static int tvTitle = 0x7f0a0d59;
        public static int tvWeaponDetails = 0x7f0a0d5a;
        public static int uploaded_documents_details_heading = 0x7f0a0e08;
        public static int verify_applicant_fingerprint_button_layout = 0x7f0a0e4c;
        public static int weaponDetailTitle = 0x7f0a0f42;
        public static int weaponNumber = 0x7f0a0f43;
        public static int weaponType = 0x7f0a0f44;
        public static int weapon_caliber_textView = 0x7f0a0f45;
        public static int weapon_category_textView = 0x7f0a0f46;
        public static int weapon_number_textView = 0x7f0a0f47;
        public static int weapon_type_textView = 0x7f0a0f48;

        private id() {
        }
    }

    public static final class layout {
        public static int activity_pals = 0x7f0d004e;
        public static int fragment_license_actions = 0x7f0d0130;
        public static int fragment_license_list = 0x7f0d0131;
        public static int fragment_license_supporting_documents = 0x7f0d0132;
        public static int fragment_token_generation = 0x7f0d0143;
        public static int item_license_action = 0x7f0d0161;
        public static int item_license_list = 0x7f0d0162;
        public static int try_again_layout = 0x7f0d0257;

        private layout() {
        }
    }

    public static final class navigation {
        public static int pals_nav_graph = 0x7f110014;

        private navigation() {
        }
    }

    public static final class string {
        public static int arms_license_header = 0x7f1400af;
        public static int arms_license_title = 0x7f1400b0;
        public static int error_title = 0x7f1403f9;
        public static int go_to_inbox_button = 0x7f140482;
        public static int license_action_cancellation = 0x7f1404f1;
        public static int license_action_cancellation_desc = 0x7f1404f2;
        public static int license_action_inheritance = 0x7f1404f3;
        public static int license_action_inheritance_desc = 0x7f1404f4;
        public static int license_action_modification = 0x7f1404f5;
        public static int license_action_modification_desc = 0x7f1404f6;
        public static int license_action_renew = 0x7f1404f7;
        public static int license_action_renew_desc = 0x7f1404f8;
        public static int license_action_reprint = 0x7f1404f9;
        public static int license_action_reprint_desc = 0x7f1404fa;
        public static int license_action_transfer = 0x7f1404fb;
        public static int license_action_transfer_desc = 0x7f1404fc;
        public static int license_fees = 0x7f1404fd;
        public static int no_licenses = 0x7f140612;
        public static int select_center = 0x7f140739;
        public static int select_validation = 0x7f140745;
        public static int submission_success_message = 0x7f140776;
        public static int submission_title = 0x7f140777;
        public static int try_again = 0x7f1407ba;
        public static int verify_fingerprints_button = 0x7f140896;

        private string() {
        }
    }

    public static final class style {
        public static int BlackBgTextView = 0x7f15012b;
        public static int BlueButton = 0x7f15012c;
        public static int FeeDetailTitle = 0x7f150142;
        public static int FeeDetailValue = 0x7f150143;
        public static int FeeTotalValue = 0x7f150144;
        public static int LabelStyle = 0x7f15014a;
        public static int ValueStyle = 0x7f150350;
        public static int WeaponDetailTitle = 0x7f150351;
        public static int WeaponDetailValue = 0x7f150352;

        private style() {
        }
    }

    private R() {
    }
}