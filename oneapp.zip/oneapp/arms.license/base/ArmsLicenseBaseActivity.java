package pk.gov.nadra.oneapp.arms.license.base;

import android.R;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.navigation.NavController;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import pk.gov.nadra.oneapp.commonutils.utils.BottomSheetUtils;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LocaleHelper;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.commonutils.viewmodel.SharedViewModel;

/* compiled from: ArmsLicenseBaseActivity.kt */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\f\b\u0016\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0018H\u0014J\b\u0010\u0019\u001a\u00020\u0016H\u0002J\u0012\u0010\u001a\u001a\u00020\u00162\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cH\u0014J\u000e\u0010\u001d\u001a\u00020\u00162\u0006\u0010\u001e\u001a\u00020\u000bJ\u000e\u0010\u001f\u001a\u00020\u00162\u0006\u0010 \u001a\u00020\u0011J\r\u0010!\u001a\u0004\u0018\u00010\u0011¢\u0006\u0002\u0010\"J\u000e\u0010#\u001a\u00020\u00162\u0006\u0010$\u001a\u00020\u0011J\u000e\u0010%\u001a\u00020\u00162\u0006\u0010&\u001a\u00020\u0014J\u0006\u0010'\u001a\u00020\u0016R\u001b\u0010\u0004\u001a\u00020\u00058FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u001a\u0010\n\u001a\u00020\u000bX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u0012\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u0012R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082D¢\u0006\u0002\n\u0000¨\u0006("}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/base/ArmsLicenseBaseActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "sharedViewModel", "Lpk/gov/nadra/oneapp/commonutils/viewmodel/SharedViewModel;", "getSharedViewModel", "()Lpk/gov/nadra/oneapp/commonutils/viewmodel/SharedViewModel;", "sharedViewModel$delegate", "Lkotlin/Lazy;", "navControllerBase", "Landroidx/navigation/NavController;", "getNavControllerBase", "()Landroidx/navigation/NavController;", "setNavControllerBase", "(Landroidx/navigation/NavController;)V", "fragmentId", "", "Ljava/lang/Integer;", "activityLanguage", "", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "setupWindow", "attachBaseContext", "newBase", "Landroid/content/Context;", "initBaseView", "navController", "setFragmentId", "id", "getFragmentId", "()Ljava/lang/Integer;", "navigateToFragment", "resourceId", "navigateToReactNativeInbox", "responseToReactNative", "handleHomeIconClick", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public class ArmsLicenseBaseActivity extends AppCompatActivity {
    private final String activityLanguage = "en";
    private Integer fragmentId;
    public NavController navControllerBase;

    /* renamed from: sharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy sharedViewModel;

    public ArmsLicenseBaseActivity() {
        final ArmsLicenseBaseActivity armsLicenseBaseActivity = this;
        final Function0 function0 = null;
        this.sharedViewModel = new ViewModelLazy(Reflection.getOrCreateKotlinClass(SharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.arms.license.base.ArmsLicenseBaseActivity$special$$inlined$viewModels$default$2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                return armsLicenseBaseActivity.getViewModelStore();
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.arms.license.base.ArmsLicenseBaseActivity$special$$inlined$viewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                return armsLicenseBaseActivity.getDefaultViewModelProviderFactory();
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.arms.license.base.ArmsLicenseBaseActivity$special$$inlined$viewModels$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                return (function02 == null || (creationExtras = (CreationExtras) function02.invoke()) == null) ? armsLicenseBaseActivity.getDefaultViewModelCreationExtras() : creationExtras;
            }
        });
    }

    public final SharedViewModel getSharedViewModel() {
        return (SharedViewModel) this.sharedViewModel.getValue();
    }

    public final NavController getNavControllerBase() {
        NavController navController = this.navControllerBase;
        if (navController != null) {
            return navController;
        }
        Intrinsics.throwUninitializedPropertyAccessException("navControllerBase");
        return null;
    }

    public final void setNavControllerBase(NavController navController) {
        Intrinsics.checkNotNullParameter(navController, "<set-?>");
        this.navControllerBase = navController;
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindow();
    }

    private final void setupWindow() {
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.white));
        new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
    }

    @Override // androidx.appcompat.app.AppCompatActivity, android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(newBase != null ? LocaleHelper.INSTANCE.wrapContext(newBase, "en") : null);
    }

    public final void initBaseView(NavController navController) {
        Intrinsics.checkNotNullParameter(navController, "navController");
        setNavControllerBase(navController);
    }

    public final void setFragmentId(int id) {
        this.fragmentId = Integer.valueOf(id);
    }

    public final Integer getFragmentId() {
        return this.fragmentId;
    }

    public final void navigateToFragment(int resourceId) {
        if (this.navControllerBase != null) {
            getNavControllerBase().navigate(resourceId);
        }
    }

    public final void navigateToReactNativeInbox(String responseToReactNative) {
        Intrinsics.checkNotNullParameter(responseToReactNative, "responseToReactNative");
        Intent intent = new Intent();
        intent.putExtra("RESPONSE_TO_REACT_NATIVE", responseToReactNative);
        setResult(-1, intent);
        finish();
    }

    public final void handleHomeIconClick() {
        String string = getString(pk.gov.nadra.oneapp.commonui.R.string.do_you_want_exit);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        SpannableString englishTextSpan$default = Util.setEnglishTextSpan$default(Util.INSTANCE, this, "Confirm", " (تصدیق کریں)", 0, false, 12, null);
        String string2 = getString(pk.gov.nadra.oneapp.commonui.R.string.do_you_want_exit_urdu);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        BottomSheetUtils.INSTANCE.showMessageBottomSheet((FragmentActivity) this, "Alert", string, true, (CharSequence) englishTextSpan$default, true, string2, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.base.ArmsLicenseBaseActivity$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ArmsLicenseBaseActivity.handleHomeIconClick$lambda$1(this.f$0);
            }
        }, new Function0() { // from class: pk.gov.nadra.oneapp.arms.license.base.ArmsLicenseBaseActivity$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit handleHomeIconClick$lambda$1(ArmsLicenseBaseActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
        return Unit.INSTANCE;
    }
}