package pk.gov.nadra.oneapp.arms.license.base;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ArmsLicenseBaseActivity$$ExternalSyntheticLambda0 implements Function0 {
    public /* synthetic */ ArmsLicenseBaseActivity$$ExternalSyntheticLambda0() {
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return ArmsLicenseBaseActivity.handleHomeIconClick$lambda$1(this.f$0);
    }
}