package pk.gov.nadra.oneapp.arms.license.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.arms.license.R;
import pk.gov.nadra.oneapp.commonui.databinding.UpdatedHeaderLayoutBinding;

/* loaded from: classes5.dex */
public final class ActivityPalsBinding implements ViewBinding {
    public final UpdatedHeaderLayoutBinding armLicenseHeaderLayout;
    public final ConstraintLayout main;
    private final ConstraintLayout rootView;

    private ActivityPalsBinding(ConstraintLayout constraintLayout, UpdatedHeaderLayoutBinding updatedHeaderLayoutBinding, ConstraintLayout constraintLayout2) {
        this.rootView = constraintLayout;
        this.armLicenseHeaderLayout = updatedHeaderLayoutBinding;
        this.main = constraintLayout2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivityPalsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivityPalsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_pals, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivityPalsBinding bind(View view) {
        int i = R.id.arm_license_header_layout;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            ConstraintLayout constraintLayout = (ConstraintLayout) view;
            return new ActivityPalsBinding(constraintLayout, UpdatedHeaderLayoutBinding.bind(viewFindChildViewById), constraintLayout);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}