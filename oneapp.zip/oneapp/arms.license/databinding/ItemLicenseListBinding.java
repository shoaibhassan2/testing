package pk.gov.nadra.oneapp.arms.license.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.textview.MaterialTextView;
import pk.gov.nadra.oneapp.arms.license.R;

/* loaded from: classes5.dex */
public final class ItemLicenseListBinding implements ViewBinding {
    public final TextView expiryDate;
    public final TextView expiryLabel;
    public final ImageView forwardArrow;
    public final TextView issuanceDate;
    public final TextView issuanceLabel;
    public final ImageView itemImage;
    public final MaterialTextView itemNumber;
    public final TextView licenseNumberLabel;
    public final TextView licenseTypeLabel;
    private final CardView rootView;

    private ItemLicenseListBinding(CardView cardView, TextView textView, TextView textView2, ImageView imageView, TextView textView3, TextView textView4, ImageView imageView2, MaterialTextView materialTextView, TextView textView5, TextView textView6) {
        this.rootView = cardView;
        this.expiryDate = textView;
        this.expiryLabel = textView2;
        this.forwardArrow = imageView;
        this.issuanceDate = textView3;
        this.issuanceLabel = textView4;
        this.itemImage = imageView2;
        this.itemNumber = materialTextView;
        this.licenseNumberLabel = textView5;
        this.licenseTypeLabel = textView6;
    }

    @Override // androidx.viewbinding.ViewBinding
    public CardView getRoot() {
        return this.rootView;
    }

    public static ItemLicenseListBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ItemLicenseListBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_license_list, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ItemLicenseListBinding bind(View view) {
        int i = R.id.expiryDate;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.expiryLabel;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView2 != null) {
                i = R.id.forwardArrow;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                if (imageView != null) {
                    i = R.id.issuanceDate;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView3 != null) {
                        i = R.id.issuanceLabel;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView4 != null) {
                            i = R.id.itemImage;
                            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                            if (imageView2 != null) {
                                i = R.id.itemNumber;
                                MaterialTextView materialTextView = (MaterialTextView) ViewBindings.findChildViewById(view, i);
                                if (materialTextView != null) {
                                    i = R.id.licenseNumberLabel;
                                    TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView5 != null) {
                                        i = R.id.licenseTypeLabel;
                                        TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i);
                                        if (textView6 != null) {
                                            return new ItemLicenseListBinding((CardView) view, textView, textView2, imageView, textView3, textView4, imageView2, materialTextView, textView5, textView6);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}