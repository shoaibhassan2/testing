package pk.gov.nadra.oneapp.arms.license.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.Guideline;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.arms.license.R;
import pk.gov.nadra.oneapp.commonui.databinding.AutocompletetextviewLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.ButtonLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.MaskedEdittextLayoutBinding;
import pk.gov.nadra.oneapp.commonui.databinding.StepActionLayoutBinding;

/* loaded from: classes5.dex */
public final class FragmentTokenGenerationBinding implements ViewBinding {
    public final TextView WeaponBore;
    public final TextView WeaponCategory;
    public final MaskedEdittextLayoutBinding applicantCnicLayout;
    public final StepActionLayoutBinding applicationDetailHeadingLayout;
    public final CardView cardFeeSummary;
    public final CardView cardWeaponDetails;
    public final View divider0;
    public final View divider2;
    public final View divider3;
    public final TextView feeSummaryTitle;
    public final Guideline guideline;
    public final Guideline guidelineNetTotal;
    public final TextView licenseNumberTextView;
    public final FrameLayout netTotalFeeContainer;
    private final ScrollView rootView;
    public final ScrollView scrollView;
    public final AutocompletetextviewLayoutBinding spinnerCardValidation;
    public final AutocompletetextviewLayoutBinding spinnerNadraCenter;
    public final ButtonLayoutBinding startApplicationLicense;
    public final TextView tvLicenseFeeLabel;
    public final TextView tvLicenseFeeValue;
    public final TextView tvNetTotalFeeLabel;
    public final TextView tvNetTotalFeeValue;
    public final TextView tvPenaltyFeeLabel;
    public final TextView tvPenaltyFeeValue;
    public final TextView tvProcessingFeeLabel;
    public final TextView tvProcessingFeeValue;
    public final TextView tvSelectCardValidation;
    public final TextView tvSelectNadraCenter;
    public final TextView tvWeaponDetails;
    public final ButtonLayoutBinding verifyApplicantFingerprintButtonLayout;
    public final TextView weaponCaliberTextView;
    public final TextView weaponCategoryTextView;
    public final TextView weaponDetailTitle;
    public final TextView weaponNumber;
    public final TextView weaponNumberTextView;
    public final TextView weaponType;
    public final TextView weaponTypeTextView;

    private FragmentTokenGenerationBinding(ScrollView scrollView, TextView textView, TextView textView2, MaskedEdittextLayoutBinding maskedEdittextLayoutBinding, StepActionLayoutBinding stepActionLayoutBinding, CardView cardView, CardView cardView2, View view, View view2, View view3, TextView textView3, Guideline guideline, Guideline guideline2, TextView textView4, FrameLayout frameLayout, ScrollView scrollView2, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding, AutocompletetextviewLayoutBinding autocompletetextviewLayoutBinding2, ButtonLayoutBinding buttonLayoutBinding, TextView textView5, TextView textView6, TextView textView7, TextView textView8, TextView textView9, TextView textView10, TextView textView11, TextView textView12, TextView textView13, TextView textView14, TextView textView15, ButtonLayoutBinding buttonLayoutBinding2, TextView textView16, TextView textView17, TextView textView18, TextView textView19, TextView textView20, TextView textView21, TextView textView22) {
        this.rootView = scrollView;
        this.WeaponBore = textView;
        this.WeaponCategory = textView2;
        this.applicantCnicLayout = maskedEdittextLayoutBinding;
        this.applicationDetailHeadingLayout = stepActionLayoutBinding;
        this.cardFeeSummary = cardView;
        this.cardWeaponDetails = cardView2;
        this.divider0 = view;
        this.divider2 = view2;
        this.divider3 = view3;
        this.feeSummaryTitle = textView3;
        this.guideline = guideline;
        this.guidelineNetTotal = guideline2;
        this.licenseNumberTextView = textView4;
        this.netTotalFeeContainer = frameLayout;
        this.scrollView = scrollView2;
        this.spinnerCardValidation = autocompletetextviewLayoutBinding;
        this.spinnerNadraCenter = autocompletetextviewLayoutBinding2;
        this.startApplicationLicense = buttonLayoutBinding;
        this.tvLicenseFeeLabel = textView5;
        this.tvLicenseFeeValue = textView6;
        this.tvNetTotalFeeLabel = textView7;
        this.tvNetTotalFeeValue = textView8;
        this.tvPenaltyFeeLabel = textView9;
        this.tvPenaltyFeeValue = textView10;
        this.tvProcessingFeeLabel = textView11;
        this.tvProcessingFeeValue = textView12;
        this.tvSelectCardValidation = textView13;
        this.tvSelectNadraCenter = textView14;
        this.tvWeaponDetails = textView15;
        this.verifyApplicantFingerprintButtonLayout = buttonLayoutBinding2;
        this.weaponCaliberTextView = textView16;
        this.weaponCategoryTextView = textView17;
        this.weaponDetailTitle = textView18;
        this.weaponNumber = textView19;
        this.weaponNumberTextView = textView20;
        this.weaponType = textView21;
        this.weaponTypeTextView = textView22;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ScrollView getRoot() {
        return this.rootView;
    }

    public static FragmentTokenGenerationBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentTokenGenerationBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_token_generation, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentTokenGenerationBinding bind(View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        View viewFindChildViewById4;
        View viewFindChildViewById5;
        int i = R.id.WeaponBore;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.WeaponCategory;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.applicant_cnic_layout))) != null) {
                MaskedEdittextLayoutBinding maskedEdittextLayoutBindingBind = MaskedEdittextLayoutBinding.bind(viewFindChildViewById);
                i = R.id.application_detail_heading_layout;
                View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById6 != null) {
                    StepActionLayoutBinding stepActionLayoutBindingBind = StepActionLayoutBinding.bind(viewFindChildViewById6);
                    i = R.id.cardFeeSummary;
                    CardView cardView = (CardView) ViewBindings.findChildViewById(view, i);
                    if (cardView != null) {
                        i = R.id.cardWeaponDetails;
                        CardView cardView2 = (CardView) ViewBindings.findChildViewById(view, i);
                        if (cardView2 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i = R.id.divider0))) != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(view, (i = R.id.divider2))) != null && (viewFindChildViewById4 = ViewBindings.findChildViewById(view, (i = R.id.divider3))) != null) {
                            i = R.id.feeSummaryTitle;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView3 != null) {
                                i = R.id.guideline;
                                Guideline guideline = (Guideline) ViewBindings.findChildViewById(view, i);
                                if (guideline != null) {
                                    i = R.id.guideline_net_total;
                                    Guideline guideline2 = (Guideline) ViewBindings.findChildViewById(view, i);
                                    if (guideline2 != null) {
                                        i = R.id.license_number_textView;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                                        if (textView4 != null) {
                                            i = R.id.netTotalFeeContainer;
                                            FrameLayout frameLayout = (FrameLayout) ViewBindings.findChildViewById(view, i);
                                            if (frameLayout != null) {
                                                ScrollView scrollView = (ScrollView) view;
                                                i = R.id.spinner_card_validation;
                                                View viewFindChildViewById7 = ViewBindings.findChildViewById(view, i);
                                                if (viewFindChildViewById7 != null) {
                                                    AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById7);
                                                    i = R.id.spinner_nadra_center;
                                                    View viewFindChildViewById8 = ViewBindings.findChildViewById(view, i);
                                                    if (viewFindChildViewById8 != null) {
                                                        AutocompletetextviewLayoutBinding autocompletetextviewLayoutBindingBind2 = AutocompletetextviewLayoutBinding.bind(viewFindChildViewById8);
                                                        i = R.id.start_application_license;
                                                        View viewFindChildViewById9 = ViewBindings.findChildViewById(view, i);
                                                        if (viewFindChildViewById9 != null) {
                                                            ButtonLayoutBinding buttonLayoutBindingBind = ButtonLayoutBinding.bind(viewFindChildViewById9);
                                                            i = R.id.tvLicenseFeeLabel;
                                                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                                            if (textView5 != null) {
                                                                i = R.id.tvLicenseFeeValue;
                                                                TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                if (textView6 != null) {
                                                                    i = R.id.tvNetTotalFeeLabel;
                                                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                    if (textView7 != null) {
                                                                        i = R.id.tvNetTotalFeeValue;
                                                                        TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                        if (textView8 != null) {
                                                                            i = R.id.tvPenaltyFeeLabel;
                                                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                            if (textView9 != null) {
                                                                                i = R.id.tvPenaltyFeeValue;
                                                                                TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                if (textView10 != null) {
                                                                                    i = R.id.tvProcessingFeeLabel;
                                                                                    TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                    if (textView11 != null) {
                                                                                        i = R.id.tvProcessingFeeValue;
                                                                                        TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                        if (textView12 != null) {
                                                                                            i = R.id.tvSelectCardValidation;
                                                                                            TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                            if (textView13 != null) {
                                                                                                i = R.id.tvSelectNadraCenter;
                                                                                                TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                                if (textView14 != null) {
                                                                                                    i = R.id.tvWeaponDetails;
                                                                                                    TextView textView15 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                                    if (textView15 != null && (viewFindChildViewById5 = ViewBindings.findChildViewById(view, (i = R.id.verify_applicant_fingerprint_button_layout))) != null) {
                                                                                                        ButtonLayoutBinding buttonLayoutBindingBind2 = ButtonLayoutBinding.bind(viewFindChildViewById5);
                                                                                                        i = R.id.weapon_caliber_textView;
                                                                                                        TextView textView16 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                                        if (textView16 != null) {
                                                                                                            i = R.id.weapon_category_textView;
                                                                                                            TextView textView17 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                                            if (textView17 != null) {
                                                                                                                i = R.id.weaponDetailTitle;
                                                                                                                TextView textView18 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                                                if (textView18 != null) {
                                                                                                                    i = R.id.weaponNumber;
                                                                                                                    TextView textView19 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                                                    if (textView19 != null) {
                                                                                                                        i = R.id.weapon_number_textView;
                                                                                                                        TextView textView20 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                                                        if (textView20 != null) {
                                                                                                                            i = R.id.weaponType;
                                                                                                                            TextView textView21 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                                                            if (textView21 != null) {
                                                                                                                                i = R.id.weapon_type_textView;
                                                                                                                                TextView textView22 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                                                                if (textView22 != null) {
                                                                                                                                    return new FragmentTokenGenerationBinding(scrollView, textView, textView2, maskedEdittextLayoutBindingBind, stepActionLayoutBindingBind, cardView, cardView2, viewFindChildViewById2, viewFindChildViewById3, viewFindChildViewById4, textView3, guideline, guideline2, textView4, frameLayout, scrollView, autocompletetextviewLayoutBindingBind, autocompletetextviewLayoutBindingBind2, buttonLayoutBindingBind, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13, textView14, textView15, buttonLayoutBindingBind2, textView16, textView17, textView18, textView19, textView20, textView21, textView22);
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}