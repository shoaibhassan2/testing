package pk.gov.nadra.oneapp.arms.license.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import pk.gov.nadra.oneapp.arms.license.R;

/* loaded from: classes5.dex */
public final class FragmentLicenseListBinding implements ViewBinding {
    public final ConstraintLayout fragmentLicenseList;
    public final SwipeRefreshLayout mainSwipeRefresh;
    private final SwipeRefreshLayout rootView;
    public final RecyclerView rvLicenseList;
    public final TryAgainLayoutBinding tryAgainSection;
    public final TextView tvLicenseTitle;

    private FragmentLicenseListBinding(SwipeRefreshLayout swipeRefreshLayout, ConstraintLayout constraintLayout, SwipeRefreshLayout swipeRefreshLayout2, RecyclerView recyclerView, TryAgainLayoutBinding tryAgainLayoutBinding, TextView textView) {
        this.rootView = swipeRefreshLayout;
        this.fragmentLicenseList = constraintLayout;
        this.mainSwipeRefresh = swipeRefreshLayout2;
        this.rvLicenseList = recyclerView;
        this.tryAgainSection = tryAgainLayoutBinding;
        this.tvLicenseTitle = textView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public SwipeRefreshLayout getRoot() {
        return this.rootView;
    }

    public static FragmentLicenseListBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentLicenseListBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_license_list, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentLicenseListBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.fragmentLicenseList;
        ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(view, i);
        if (constraintLayout != null) {
            SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) view;
            i = R.id.rvLicenseList;
            RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
            if (recyclerView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.try_again_section))) != null) {
                TryAgainLayoutBinding tryAgainLayoutBindingBind = TryAgainLayoutBinding.bind(viewFindChildViewById);
                i = R.id.tvLicenseTitle;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    return new FragmentLicenseListBinding(swipeRefreshLayout, constraintLayout, swipeRefreshLayout, recyclerView, tryAgainLayoutBindingBind, textView);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}