package pk.gov.nadra.oneapp.arms.license.views;

import android.R;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcherKt;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.NavGraph;
import androidx.navigation.fragment.NavHostFragment;
import com.google.gson.Gson;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import pk.gov.nadra.oneapp.arms.license.base.ArmsLicenseBaseActivity;
import pk.gov.nadra.oneapp.arms.license.databinding.ActivityPalsBinding;
import pk.gov.nadra.oneapp.arms.license.network.common.SharedPreferencesTokenProvider;
import pk.gov.nadra.oneapp.arms.license.viewmodel.ArmsLicenseSharedViewModel;
import pk.gov.nadra.oneapp.commonutils.utils.Constant;
import pk.gov.nadra.oneapp.commonutils.utils.LoaderManager;
import pk.gov.nadra.oneapp.commonutils.utils.LocaleHelper;
import pk.gov.nadra.oneapp.commonutils.utils.Util;
import pk.gov.nadra.oneapp.crms.network.common.CrmsConstants;
import pk.gov.nadra.oneapp.models.crc.ReactNativeData;

/* compiled from: ArmsLicenseActivity.kt */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001dH\u0014J\u0012\u0010\u001e\u001a\u00020\u001b2\b\u0010\u001f\u001a\u0004\u0018\u00010 H\u0014J\b\u0010!\u001a\u00020\u001bH\u0002J\b\u0010\"\u001a\u00020\u001bH\u0002J\u0006\u0010#\u001a\u00020\u001bJ\b\u0010$\u001a\u00020\u001bH\u0016J\u000e\u0010%\u001a\u00020\u001b2\u0006\u0010&\u001a\u00020'J\u0006\u0010(\u001a\u00020\u001bJ\u0006\u0010)\u001a\u00020\u001bJ\b\u0010*\u001a\u00020\u001bH\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u000e\u0010\n\u001a\u00020\u000bX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\u00020\u000fX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019¨\u0006+"}, d2 = {"Lpk/gov/nadra/oneapp/arms/license/views/ArmsLicenseActivity;", "Lpk/gov/nadra/oneapp/arms/license/base/ArmsLicenseBaseActivity;", "<init>", "()V", "armsLicenseSharedViewModel", "Lpk/gov/nadra/oneapp/arms/license/viewmodel/ArmsLicenseSharedViewModel;", "getArmsLicenseSharedViewModel", "()Lpk/gov/nadra/oneapp/arms/license/viewmodel/ArmsLicenseSharedViewModel;", "armsLicenseSharedViewModel$delegate", "Lkotlin/Lazy;", "navController", "Landroidx/navigation/NavController;", "navHostFragment", "Landroidx/navigation/fragment/NavHostFragment;", "binding", "Lpk/gov/nadra/oneapp/arms/license/databinding/ActivityPalsBinding;", "getBinding", "()Lpk/gov/nadra/oneapp/arms/license/databinding/ActivityPalsBinding;", "setBinding", "(Lpk/gov/nadra/oneapp/arms/license/databinding/ActivityPalsBinding;)V", "trackingId", "", "getTrackingId", "()Ljava/lang/String;", "setTrackingId", "(Ljava/lang/String;)V", "attachBaseContext", "", "newBase", "Landroid/content/Context;", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "initView", "getIntentData", "popupFromNavHost", "onBackPressed", "showOrHideHeader", "show", "", "showSubTitle", "hideSubTitle", "handleTabSequence", "armsLicense_ProductionRelease"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ArmsLicenseActivity extends ArmsLicenseBaseActivity {

    /* renamed from: armsLicenseSharedViewModel$delegate, reason: from kotlin metadata */
    private final Lazy armsLicenseSharedViewModel;
    public ActivityPalsBinding binding;
    private NavController navController;
    private NavHostFragment navHostFragment;
    private String trackingId = "";

    public ArmsLicenseActivity() {
        final ArmsLicenseActivity armsLicenseActivity = this;
        final Function0 function0 = null;
        this.armsLicenseSharedViewModel = new ViewModelLazy(Reflection.getOrCreateKotlinClass(ArmsLicenseSharedViewModel.class), new Function0<ViewModelStore>() { // from class: pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity$special$$inlined$viewModels$default$2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                return armsLicenseActivity.getViewModelStore();
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity$special$$inlined$viewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                return armsLicenseActivity.getDefaultViewModelProviderFactory();
            }
        }, new Function0<CreationExtras>() { // from class: pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity$special$$inlined$viewModels$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function02 = function0;
                return (function02 == null || (creationExtras = (CreationExtras) function02.invoke()) == null) ? armsLicenseActivity.getDefaultViewModelCreationExtras() : creationExtras;
            }
        });
    }

    private final ArmsLicenseSharedViewModel getArmsLicenseSharedViewModel() {
        return (ArmsLicenseSharedViewModel) this.armsLicenseSharedViewModel.getValue();
    }

    public final ActivityPalsBinding getBinding() {
        ActivityPalsBinding activityPalsBinding = this.binding;
        if (activityPalsBinding != null) {
            return activityPalsBinding;
        }
        Intrinsics.throwUninitializedPropertyAccessException("binding");
        return null;
    }

    public final void setBinding(ActivityPalsBinding activityPalsBinding) {
        Intrinsics.checkNotNullParameter(activityPalsBinding, "<set-?>");
        this.binding = activityPalsBinding;
    }

    public final String getTrackingId() {
        return this.trackingId;
    }

    public final void setTrackingId(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.trackingId = str;
    }

    @Override // pk.gov.nadra.oneapp.arms.license.base.ArmsLicenseBaseActivity, androidx.appcompat.app.AppCompatActivity, android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(newBase != null ? LocaleHelper.INSTANCE.wrapContext(newBase, "en") : null);
    }

    @Override // pk.gov.nadra.oneapp.arms.license.base.ArmsLicenseBaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setBinding(ActivityPalsBinding.inflate(getLayoutInflater()));
        setContentView(getBinding().getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.white));
        new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
        ActivityPalsBinding binding = getBinding();
        binding.armLicenseHeaderLayout.textTitle.setText(getString(pk.gov.nadra.oneapp.arms.license.R.string.arms_license_header));
        binding.armLicenseHeaderLayout.iconHome.setVisibility(8);
        binding.armLicenseHeaderLayout.iconBack.setVisibility(0);
        binding.armLicenseHeaderLayout.viewHeaderSeparator.setVisibility(8);
        binding.armLicenseHeaderLayout.tvHeaderTrackingId.setVisibility(8);
        binding.armLicenseHeaderLayout.tvHeaderTrackingIdHeading.setVisibility(8);
        binding.armLicenseHeaderLayout.tvHeaderFee.setVisibility(8);
        binding.armLicenseHeaderLayout.iconBack.setOnClickListener(new View.OnClickListener() { // from class: pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ArmsLicenseActivity.onCreate$lambda$2$lambda$1(this.f$0, view);
            }
        });
        binding.armLicenseHeaderLayout.textSubtitle.setText("اسلحہ لائسنس");
        binding.armLicenseHeaderLayout.textSubtitle.setGravity(GravityCompat.END);
        LoaderManager loaderManager = LoaderManager.INSTANCE;
        Application application = getApplication();
        Intrinsics.checkNotNullExpressionValue(application, "getApplication(...)");
        loaderManager.initialize(application);
        getIntentData();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$2$lambda$1(ArmsLicenseActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.popupFromNavHost();
    }

    private final void initView() {
        Fragment fragmentFindFragmentById = getSupportFragmentManager().findFragmentById(pk.gov.nadra.oneapp.arms.license.R.id.pals_nav_host_fragment);
        Intrinsics.checkNotNull(fragmentFindFragmentById, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
        NavHostFragment navHostFragment = (NavHostFragment) fragmentFindFragmentById;
        this.navHostFragment = navHostFragment;
        NavController navController = null;
        if (navHostFragment == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navHostFragment");
            navHostFragment = null;
        }
        NavController navController2 = navHostFragment.getNavController();
        this.navController = navController2;
        if (navController2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
            navController2 = null;
        }
        NavGraph navGraphInflate = navController2.getNavInflater().inflate(pk.gov.nadra.oneapp.arms.license.R.navigation.pals_nav_graph);
        NavController navController3 = this.navController;
        if (navController3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
            navController3 = null;
        }
        navController3.setGraph(navGraphInflate);
        NavController navController4 = this.navController;
        if (navController4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("navController");
        } else {
            navController = navController4;
        }
        initBaseView(navController);
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        OnBackPressedDispatcherKt.addCallback$default(getOnBackPressedDispatcher(), this, false, new Function1() { // from class: pk.gov.nadra.oneapp.arms.license.views.ArmsLicenseActivity$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return ArmsLicenseActivity.initView$lambda$3(this.f$0, (OnBackPressedCallback) obj);
            }
        }, 2, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit initView$lambda$3(ArmsLicenseActivity this$0, OnBackPressedCallback addCallback) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(addCallback, "$this$addCallback");
        if (!LoaderManager.INSTANCE.isLoaderVisible()) {
            NavController navController = this$0.navController;
            if (navController == null) {
                Intrinsics.throwUninitializedPropertyAccessException("navController");
                navController = null;
            }
            NavDestination currentDestination = navController.getCurrentDestination();
            Integer numValueOf = currentDestination != null ? Integer.valueOf(currentDestination.getId()) : null;
            int i = pk.gov.nadra.oneapp.arms.license.R.id.licenseListFragment;
            if (numValueOf != null && numValueOf.intValue() == i) {
                this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
            } else {
                int i2 = pk.gov.nadra.oneapp.arms.license.R.id.licenseActionsFragment;
                if (numValueOf != null && numValueOf.intValue() == i2) {
                    this$0.navigateToFragment(pk.gov.nadra.oneapp.arms.license.R.id.action_licenseAction_to_licenseList);
                } else {
                    int i3 = pk.gov.nadra.oneapp.arms.license.R.id.licenseTokenGenerationFragment;
                    if (numValueOf != null && numValueOf.intValue() == i3) {
                        this$0.navigateToFragment(pk.gov.nadra.oneapp.arms.license.R.id.action_licenseTokenGeneration_to_licenseActions);
                    } else {
                        int i4 = pk.gov.nadra.oneapp.arms.license.R.id.licenseSupportingDocumentsFragment;
                        if (numValueOf != null && numValueOf.intValue() == i4) {
                            this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
                        } else {
                            this$0.navigateToReactNativeInbox(Constant.GO_TO_INBOX);
                        }
                    }
                }
            }
        }
        return Unit.INSTANCE;
    }

    private final void getIntentData() {
        if (getIntent() == null || !getIntent().hasExtra(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA)) {
            return;
        }
        Bundle extras = getIntent().getExtras();
        Intrinsics.checkNotNull(extras);
        ReactNativeData reactNativeData = (ReactNativeData) new Gson().fromJson(extras.getString(CrmsConstants.INTENT_STRING_REACT_NATIVE_DATA), ReactNativeData.class);
        getArmsLicenseSharedViewModel().setReactNativeData(reactNativeData);
        this.trackingId = getArmsLicenseSharedViewModel().getReactNativeData().getTrackingId();
        getArmsLicenseSharedViewModel().setTrackingId(this.trackingId);
        getArmsLicenseSharedViewModel().setAppType(getArmsLicenseSharedViewModel().getReactNativeData().getAppType());
        getArmsLicenseSharedViewModel().setAmount(getArmsLicenseSharedViewModel().getReactNativeData().getFeeAmount());
        if (Constant.INSTANCE.getDEBUG()) {
            Log.d("React Data", getArmsLicenseSharedViewModel().getReactNativeData().getCitizenNumber());
        }
        SharedPreferencesTokenProvider sharedPreferencesTokenProvider = new SharedPreferencesTokenProvider(this);
        sharedPreferencesTokenProvider.saveToken(reactNativeData.getToken());
        sharedPreferencesTokenProvider.saveRefreshToken(reactNativeData.getRefreshToken());
        sharedPreferencesTokenProvider.saveAesKey(reactNativeData.getSessionKey());
        sharedPreferencesTokenProvider.saveDeviceId(reactNativeData.getDeviceId());
        sharedPreferencesTokenProvider.saveEncryptionEnabled(reactNativeData.getEncryptionEnabled());
        sharedPreferencesTokenProvider.saveUsername(reactNativeData.getEmail());
        String str = this.trackingId;
        if (str == null || str.length() == 0) {
            initView();
        } else {
            handleTabSequence();
        }
    }

    public final void popupFromNavHost() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (LoaderManager.INSTANCE.isLoaderVisible()) {
            return;
        }
        getOnBackPressedDispatcher().onBackPressed();
    }

    public final void showOrHideHeader(boolean show) {
        View viewFindViewById = findViewById(pk.gov.nadra.oneapp.arms.license.R.id.arm_license_header_layout);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility(show ? 0 : 8);
        }
    }

    public final void showSubTitle() {
        ActivityPalsBinding binding = getBinding();
        binding.armLicenseHeaderLayout.textSubtitle.setText(Util.INSTANCE.capitalizeWords(getArmsLicenseSharedViewModel().getAppType()));
        binding.armLicenseHeaderLayout.textSubtitle.setTypeface(Util.INSTANCE.getRobotoFont(this));
        binding.armLicenseHeaderLayout.textSubtitle.setVisibility(0);
        binding.armLicenseHeaderLayout.textSubtitle.setGravity(GravityCompat.START);
    }

    public final void hideSubTitle() {
        ActivityPalsBinding binding = getBinding();
        binding.armLicenseHeaderLayout.textSubtitle.setText("");
        binding.armLicenseHeaderLayout.textSubtitle.setVisibility(0);
        binding.armLicenseHeaderLayout.textSubtitle.setText("اسلحہ لائسنس");
        binding.armLicenseHeaderLayout.textSubtitle.setGravity(GravityCompat.END);
        binding.armLicenseHeaderLayout.textSubtitle.setTypeface(Util.INSTANCE.getNadraNastaleeqFont(this));
    }

    private final void handleTabSequence() {
        if (Intrinsics.areEqual(getArmsLicenseSharedViewModel().getReactNativeData().getAppType(), "reprint lost")) {
            initView();
            navigateToFragment(pk.gov.nadra.oneapp.arms.license.R.id.licenseSupportingDocumentsFragment);
        }
    }
}