package pk.gov.nadra.oneapp.arms.license.views;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ArmsLicenseActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public /* synthetic */ ArmsLicenseActivity$$ExternalSyntheticLambda0() {
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ArmsLicenseActivity.onCreate$lambda$2$lambda$1(this.f$0, view);
    }
}