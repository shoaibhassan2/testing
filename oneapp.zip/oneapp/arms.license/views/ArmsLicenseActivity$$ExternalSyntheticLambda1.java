package pk.gov.nadra.oneapp.arms.license.views;

import androidx.activity.OnBackPressedCallback;
import kotlin.jvm.functions.Function1;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes5.dex */
public final /* synthetic */ class ArmsLicenseActivity$$ExternalSyntheticLambda1 implements Function1 {
    public /* synthetic */ ArmsLicenseActivity$$ExternalSyntheticLambda1() {
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return ArmsLicenseActivity.initView$lambda$3(this.f$0, (OnBackPressedCallback) obj);
    }
}